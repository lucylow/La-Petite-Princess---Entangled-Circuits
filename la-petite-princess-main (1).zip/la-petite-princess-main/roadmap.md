# Learning rewards
- [x] Add discovery points, explorer ranks, and achievement rules.
- [x] Add a quest strip and animated reward feedback to the studio.
- [x] Verify reward flows, saved progress, and small-screen layout.

# Circuit visualizations
- [ ] Add connected circuit diagrams, state stepping, and amplitude/phase views.
- [ ] Add visual circuit presets and verify their results and controls.

# Immersive experience transformation
- [x] Synthesized sound engine: ambient soundscape, interaction chimes, floating sound controls, saved preferences, no autoplay.
- [x] Scroll-triggered reveals and layered hero starfield parallax with reduced-motion fallbacks.
- [x] Story journey tracking: chapter discovery dots, continue-where-you-left-off card.
- [ ] Narration-ready architecture: transcript/caption slots per chapter, replaceable voice-over media points.
- [ ] Deeper spatial scenes: explorable observatory map or 2.5D chapter environments.
