<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# North star

Learners come to understand how quantum computing works.

## Metric

Lessons completed each week
