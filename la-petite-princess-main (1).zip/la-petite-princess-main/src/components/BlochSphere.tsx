// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import type { CSSProperties } from "react";

export interface BlochSphereProps {
  x: number;
  y: number;
  z: number;
  title?: string;
  compact?: boolean;
}

function projectedPoint(x: number, y: number, z: number): { x: number; y: number } {
  const scale = 82;
  const perspective = 0.38;
  return {
    x: 110 + scale * (x - y * perspective),
    y: 108 - scale * (z - y * perspective),
  };
}

function safeUnit(value: number): number {
  if (!Number.isFinite(value)) return 0;
  return Math.max(-1, Math.min(1, value));
}

export function BlochSphere({ x, y, z, title = "Bloch sphere", compact = false }: BlochSphereProps) {
  const px = safeUnit(x);
  const py = safeUnit(y);
  const pz = safeUnit(z);
  const endpoint = projectedPoint(px, py, pz);
  const size = compact ? 168 : 220;
  const style = { "--bloch-size": `${size}px` } as CSSProperties;

  return (
    <figure className={`qpro-bloch ${compact ? "qpro-bloch-compact" : ""}`} style={style} aria-label={`${title}: x ${px.toFixed(3)}, y ${py.toFixed(3)}, z ${pz.toFixed(3)}`}>
      <svg viewBox="0 0 220 220" role="img" aria-label="Bloch sphere with the qubit state vector">
        <defs>
          <linearGradient id="qpro-bloch-fill" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#e8d9ff" stopOpacity=".36" />
            <stop offset="100%" stopColor="#aa8de9" stopOpacity=".08" />
          </linearGradient>
          <linearGradient id="qpro-vector" x1="0" y1="1" x2="1" y2="0">
            <stop offset="0%" stopColor="#d57eab" />
            <stop offset="100%" stopColor="#9677df" />
          </linearGradient>
        </defs>
        <circle cx="110" cy="108" r="82" fill="url(#qpro-bloch-fill)" stroke="#bca9d7" strokeWidth="1.2" />
        <ellipse cx="110" cy="108" rx="82" ry="29" fill="none" stroke="#cfc1e2" strokeDasharray="4 4" />
        <ellipse cx="110" cy="108" rx="29" ry="82" fill="none" stroke="#d6c9e5" strokeDasharray="4 4" transform="rotate(28 110 108)" />
        <path d="M28 108 H192 M110 26 V190" stroke="#b7a7ca" strokeWidth="1" opacity=".65" />
        <path d="M45 150 L175 66" stroke="#b7a7ca" strokeWidth="1" opacity=".6" strokeDasharray="3 4" />
        <path d="M110 26 L106 35 M110 26 L114 35" stroke="#86719f" strokeWidth="1.2" fill="none" />
        <path d={`M110 108 L${endpoint.x} ${endpoint.y}`} stroke="url(#qpro-vector)" strokeWidth="4" strokeLinecap="round" />
        <circle cx={endpoint.x} cy={endpoint.y} r="6" fill="#c978a4" stroke="#fff" strokeWidth="2" />
        <circle cx="110" cy="108" r="3" fill="#846ca5" />
        <text x="110" y="16" textAnchor="middle" className="qpro-axis-label">|0⟩</text>
        <text x="110" y="211" textAnchor="middle" className="qpro-axis-label">|1⟩</text>
        <text x="199" y="112" className="qpro-axis-label">X</text>
        <text x="32" y="161" className="qpro-axis-label">Y</text>
        <text x="119" y="30" className="qpro-axis-label">Z</text>
      </svg>
      <figcaption>
        <b>{title}</b>
        <span>x {px.toFixed(2)} · y {py.toFixed(2)} · z {pz.toFixed(2)}</span>
      </figcaption>
    </figure>
  );
}

export default BlochSphere;
