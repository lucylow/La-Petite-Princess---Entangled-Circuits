import { QuantumMentor } from "@/components/voice/QuantumMentor";
import "@/styles/quantum-mentor.css";
import React, { useEffect, useMemo, useState } from "react";
import { AdvancedWorkbench } from "@/components/advanced/AdvancedWorkbench";
import { AudioDock } from "@/components/advanced/AudioDock";
import { Reveal } from "@/components/advanced/Reveal";
import { getAudioEngine } from "@/lib/advanced/audioEngine";
import {
  emptyJourney,
  loadJourney,
  markChapterDiscovered,
  markSectionVisited,
  saveJourney,
  type StoryJourney,
} from "@/lib/advanced/storyJourney";
import {
  applyGate,
  collapseToOutcome,
  formatState,
  initialState,
  probabilities,
  sampleMeasurement,
  type Gate,
  type QuantumState,
} from "@/lib/quantum";
import scientistImg from "@/assets/young-scientist.jpg";

type Section = "home" | "story" | "lab" | "learn" | "girls";

const chapters = [
  {
    number: "01",
    title: "The Strand of Possibilities",
    subtitle: "A little mystery called superposition",
    tag: "QUBITS & SUPERPOSITION",
    story:
      "In the corner of an old observatory, a young scientist finds a silver thread in her notebook. It seems to shimmer between two possibilities. She wonders: can something be described as a combination of possibilities before anyone looks?",
    science:
      "A qubit is a quantum system with two computational basis states, written |0⟩ and |1⟩. Before measurement, its state can be a superposition α|0⟩ + β|1⟩, where the complex amplitudes determine measurement probabilities.",
    takeaway: "A superposition is a mathematical combination of possible measurement outcomes—not simply a tiny object secretly switching between two values.",
    experiment: "Try applying a Hadamard gate to Q1. It turns |0⟩ into an equal superposition of |0⟩ and |1⟩.",
  },
  {
    number: "02",
    title: "The Great Braid",
    subtitle: "When two qubits share one story",
    tag: "TWO QUBITS & ENTANGLEMENT",
    story:
      "The scientist draws two looping strands in the margin of her notebook. She discovers that some quantum systems cannot be fully described one piece at a time. Their shared state tells a richer story than either part alone.",
    science:
      "Entanglement is a property of a joint quantum state that cannot be written as a product of separate states for each subsystem. A famous example is the Bell state (|00⟩ + |11⟩)/√2.",
    takeaway: "Entangled particles show correlations that have no classical local-hidden-variable explanation. Those correlations do not allow faster-than-light messaging.",
    experiment: "In the lab, apply H to Q1, then CNOT from Q1 to Q2. The simulator creates a Bell state.",
  },
  {
    number: "03",
    title: "The Mirror of Measurement",
    subtitle: "A probability becomes one result",
    tag: "MEASUREMENT",
    story:
      "A polished brass mirror stands at the end of the observatory. When the scientist asks it a question, it gives one answer—not every possibility at once. She begins to understand the difference between a probability and an observed result.",
    science:
      "In the standard measurement model, measuring a qubit in the computational basis returns 0 or 1 with probabilities given by the squared magnitudes of its amplitudes. A single run gives one outcome; repeated runs reveal the distribution.",
    takeaway: "Quantum measurement is probabilistic. To understand a prepared state, scientists repeat an experiment many times and compare the outcomes.",
    experiment: "Prepare a superposition in the lab and measure repeatedly. Notice that individual outcomes vary while the long-run frequencies approach the predicted probabilities.",
  },
  {
    number: "04",
    title: "The Quantum Storm",
    subtitle: "Why delicate states need protection",
    tag: "NOISE & DECOHERENCE",
    story:
      "A storm rattles the observatory windows. The delicate patterns in the scientist's experiment become harder to preserve. She learns that the outside world can disturb a carefully prepared quantum state.",
    science:
      "Decoherence occurs when interactions with the environment degrade quantum coherence. Noise, imperfect gates, and measurement errors are major challenges in building reliable quantum computers.",
    takeaway: "Quantum computers are not magical or error-free. Engineers work hard to control noise and use error-mitigation and quantum-error-correction techniques.",
    experiment: "Imagine repeating the Bell-state experiment on imperfect hardware. Small errors would make the measured distribution drift away from the ideal 50/50 pattern.",
  },
  {
    number: "05",
    title: "The Quantum Loom",
    subtitle: "Learning the language of circuits",
    tag: "GATES & CIRCUITS",
    story:
      "At last, the scientist finds a new kind of loom: a circuit diagram. Each gate is a carefully chosen operation. By arranging them in sequence, she can prepare states and ask precise questions of the quantum world.",
    science:
      "Quantum circuits are built from gates—unitary operations on qubits—followed by measurements. The Hadamard gate creates useful superpositions, while CNOT is a two-qubit gate that can entangle qubits.",
    takeaway: "Quantum programming is not guesswork. It combines linear algebra, complex amplitudes, careful circuit design, and repeated measurement.",
    experiment: "Build the short circuit Reset → H(Q1) → CNOT(Q1→Q2) → Measure. You have created and measured a Bell pair in an ideal simulator.",
  },
];

const concepts = [
  { symbol: "|ψ⟩", title: "Qubits", body: "The basic unit of quantum information. A qubit can be prepared in many states, including superpositions of |0⟩ and |1⟩.", detail: "A normalized pure qubit state is α|0⟩ + β|1⟩, where |α|² + |β|² = 1." },
  { symbol: "H", title: "Superposition", body: "A quantum state can combine multiple basis states, with amplitudes that determine measurement probabilities.", detail: "The Hadamard gate maps |0⟩ to (|0⟩ + |1⟩)/√2." },
  { symbol: "∞", title: "Entanglement", body: "A shared quantum state whose parts cannot be described independently, producing distinctive correlations.", detail: "The Bell state (|00⟩ + |11⟩)/√2 is a standard two-qubit example." },
  { symbol: "◉", title: "Measurement", body: "A measurement returns a classical outcome sampled according to the quantum state's probabilities.", detail: "For a computational-basis measurement, outcome probabilities are the squared magnitudes of the corresponding amplitudes." },
  { symbol: "H · X", title: "Quantum gates", body: "Reversible operations that transform the state of one or more qubits inside a circuit.", detail: "Common gates include X, H, Z, and CNOT. Gates are represented by unitary matrices." },
  { symbol: "≈", title: "Decoherence", body: "Interactions with the environment can wash out the phase relationships that make quantum effects useful.", detail: "Decoherence is one reason practical quantum processors require careful isolation, calibration, and error control." },
];

function BrandMark() {
  return (
    <div className="brand-mark" aria-label="La Petite Princesse">
      <span className="brand-crown" aria-hidden="true">♕</span>
      <span><b>LA PETITE PRINCESSE</b><small>ENTANGLED · THE QUANTUM UNIVERSE</small></span>
    </div>
  );
}

function SectionButton({ id, current, onClick, children }: { id: Section; current: Section; onClick: (id: Section) => void; children: React.ReactNode }) {
  return <button className={`nav-link ${current === id ? "active" : ""}`} onClick={() => onClick(id)}>{children}</button>;
}

function trackPointer(e: React.PointerEvent<HTMLElement>) {
  const el = e.currentTarget;
  const r = el.getBoundingClientRect();
  el.style.setProperty("--mx", `${((e.clientX - r.left) / r.width) * 100}%`);
  el.style.setProperty("--my", `${((e.clientY - r.top) / r.height) * 100}%`);
  el.style.setProperty("--rx", `${((e.clientY - r.top) / r.height - 0.5) * -8}deg`);
  el.style.setProperty("--ry", `${((e.clientX - r.left) / r.width - 0.5) * 8}deg`);
}
function resetPointer(e: React.PointerEvent<HTMLElement>) {
  e.currentTarget.style.setProperty("--rx", "0deg");
  e.currentTarget.style.setProperty("--ry", "0deg");
}

/** Drives the layered starfield parallax in the hero via CSS variables. */
function trackHeroParallax(e: React.PointerEvent<HTMLElement>) {
  const el = e.currentTarget;
  const r = el.getBoundingClientRect();
  el.style.setProperty("--px", `${((e.clientX - r.left) / r.width - 0.5) * 2}`);
  el.style.setProperty("--py", `${((e.clientY - r.top) / r.height - 0.5) * 2}`);
}

function HeroArt() {
  return (
    <figure className="hero-art hero-art-photo tilt-glow" onPointerMove={trackPointer} onPointerLeave={resetPointer}>
      <img src={scientistImg} alt="A young scientist with a braid holds her notebook in a warm, starlit laboratory" width={1024} height={1152} />
      <figcaption>curiosity is a superpower · |0⟩ + |1⟩</figcaption>
    </figure>
  );
}

function HomeSection({ go, journey }: { go: (section: Section) => void; journey: StoryJourney }) {
  const resumeChapter = chapters[journey.lastChapterIndex] ?? chapters[0];
  const hasJourney = journey.discoveredChapters.length > 0 || journey.lastSection !== "home";
  return (
    <>
      <section className="hero-section" onPointerMove={trackHeroParallax}>
        <div className="hero-stars hero-stars-a" aria-hidden="true" />
        <div className="hero-stars hero-stars-b" aria-hidden="true" />
        <div className="hero-glow" aria-hidden="true" />
        <div className="hero-copy">
          <div className="eyebrow"><span className="eyebrow-line" /> A STORY-LED QUANTUM ADVENTURE</div>
          <h1>A curious mind.<br /><em>A tangled braid.</em><br />A universe of possibilities.</h1>
          <p className="hero-intro">Follow a young scientist as she untangles the mysteries of the quantum world — one experiment at a time.</p>
          <div className="hero-actions">
            <button className="button button-primary" onClick={() => go("story")}>Begin the journey <span>↗</span></button>
            <button className="button button-quiet" onClick={() => go("lab")}>Explore the quantum lab <span>→</span></button>
          </div>
          <div className="hero-footnote"><span className="tiny-orbit">◎</span> A little wonder. A lot of real science.</div>
        </div>
        <HeroArt />
      </section>
      <Reveal>
        <section className="feature-strip" aria-label="Learning highlights">
          <div><span className="feature-icon">✎</span><span><b>Story-led learning</b><small>Big ideas, one chapter at a time</small></span></div>
          <div><span className="feature-icon">◉</span><span><b>Interactive experiments</b><small>Play with real quantum concepts</small></span></div>
          <div><span className="feature-icon">⌘</span><span><b>Build real circuits</b><small>Turn curiosity into code</small></span></div>
        </section>
      </Reveal>
      {hasJourney && (
        <Reveal from="zoom">
          <button className="continue-card" onClick={() => go(journey.lastSection === "home" ? "story" : (journey.lastSection as Section))}>
            <span className="continue-card-spark" aria-hidden="true">✧</span>
            <span className="continue-card-copy">
              <span className="section-kicker">CONTINUE YOUR JOURNEY</span>
              <b>{journey.lastSection === "story" && resumeChapter ? `Chapter ${resumeChapter.number} — ${resumeChapter.title}` : journey.lastSection === "lab" ? "Back to the Quantum Lab" : journey.lastSection === "learn" ? "Back to the Field Guide" : journey.lastSection === "girls" ? "Back to your quantum path" : "Begin the story"}</b>
              <small>{journey.discoveredChapters.length} of {chapters.length} chapters discovered · Pick up where you left off ↗</small>
            </span>
          </button>
        </Reveal>
      )}
      <Reveal delay={80}>
        <section className="home-note"><span className="note-star">✧</span><p>The story uses visual metaphors to spark curiosity. The Quantum Lab teaches the mathematics beneath the magic.</p></section>
      </Reveal>
      <section className="chapter-preview section-shell">
        <div className="section-kicker">A NOTEBOOK OF DISCOVERY</div>
        <div className="section-heading-row"><div><h2>Every great discovery<br /><em>begins with a question.</em></h2></div><button className="text-link" onClick={() => go("story")}>Open the storybook ↗</button></div>
        <div className="preview-grid">{chapters.slice(0, 3).map((chapter) => <button className="preview-card tilt-glow" key={chapter.number} onPointerMove={trackPointer} onPointerLeave={resetPointer} onClick={() => go("story")}><span className="preview-number">CHAPTER {chapter.number}</span><span className="preview-title">{chapter.title}</span><span className="preview-subtitle">{chapter.subtitle}</span><span className="preview-arrow">↗</span></button>)}</div>
      </section>
    </>
  );
}

function StorySection({ goLab, journey, onDiscover }: { goLab: (chapterIndex: number) => void; journey: StoryJourney; onDiscover: (chapterIndex: number) => void }) {
  const [activeChapter, setActiveChapter] = useState(() => Math.min(journey.lastChapterIndex, chapters.length - 1));
  const chapter = chapters[activeChapter] ?? chapters[0]!;
  const selectChapter = (index: number) => {
    if (index === activeChapter) return;
    const isNewDiscovery = !journey.discoveredChapters.includes(chapters[index]?.number ?? "");
    setActiveChapter(index);
    onDiscover(index);
    getAudioEngine().playSfx(isNewDiscovery ? "chime" : "whoosh");
  };
  return (
    <section className="page-section section-shell">
      <div className="page-intro"><div className="section-kicker">THE STORYBOOK</div><h1>Five chapters.<br /><em>One curious mind.</em></h1><p>Open the scientist's notebook and follow the questions that lead into the quantum world.</p></div>
      <div className="chapter-progress" aria-label="Story discovery progress">
        <div className="chapter-dots">
          {chapters.map((item, index) => (
            <button
              key={item.number}
              className={`chapter-dot ${activeChapter === index ? "current" : ""} ${journey.discoveredChapters.includes(item.number) ? "discovered" : ""}`}
              onClick={() => selectChapter(index)}
              aria-label={`Chapter ${item.number}: ${item.title}${journey.discoveredChapters.includes(item.number) ? " (discovered)" : ""}`}
              aria-current={activeChapter === index ? "true" : undefined}
            >
              <span>{item.number}</span>
            </button>
          ))}
        </div>
        <small>{journey.discoveredChapters.length} of {chapters.length} chapters discovered</small>
      </div>
      <div className="story-layout">
        <aside className="chapter-list" aria-label="Choose a story chapter">
          {chapters.map((item, index) => <button key={item.number} onClick={() => selectChapter(index)} className={`chapter-tab ${activeChapter === index ? "selected" : ""}`}><span>{item.number}</span><b>{item.title}</b><small>{item.tag}</small></button>)}
        </aside>
        <article className="story-card">
          <div className="story-card-top"><span>FIELD NOTES · {chapter.number}</span><span className="story-spark">✧</span></div>
          <div className="chapter-illustration"><div className="chapter-orbit orbit-a"><i /></div><div className="chapter-orbit orbit-b"><i /></div><span className="chapter-symbol">{["|ψ⟩", "∞", "◉", "〰", "H ⊕ X"][activeChapter]}</span><span className="chapter-caption">{chapter.tag}</span></div>
          <div className="story-content" key={chapter.number}><div className="section-kicker">CHAPTER {chapter.number} · {chapter.tag}</div><h2>{chapter.title}</h2><p className="story-subtitle">{chapter.subtitle}</p><p className="story-narrative">{chapter.story}</p><div className="science-callout"><div className="callout-label">WHAT THE SCIENCE REALLY SAYS</div><p>{chapter.science}</p></div><div className="takeaway"><b>THE IDEA TO KEEP</b><p>{chapter.takeaway}</p></div><div className="story-footer"><button className="button button-primary" onClick={() => goLab(activeChapter)}>Try this in the lab <span>↗</span></button><div className="story-pager"><button disabled={activeChapter === 0} onClick={() => selectChapter(activeChapter - 1)}>← Previous</button><button disabled={activeChapter === chapters.length - 1} onClick={() => selectChapter(activeChapter + 1)}>Next →</button></div></div></div>
        </article>
      </div>
    </section>
  );
}

function ProbabilityBar({ label, value }: { label: string; value: number }) {
  return <div className="probability-row"><div className="probability-label"><b>{label}</b><span>{(value * 100).toFixed(1)}%</span></div><div className="probability-track"><div className="probability-fill" style={{ width: `${Math.max(0, Math.min(100, value * 100))}%` }} /></div></div>;
}

function QuantumLabSection({ requestedChapter }: { requestedChapter: number | null }) {
  const [state, setState] = useState<QuantumState>(() => initialState());
  const [history, setHistory] = useState<string[]>([]);
  const [measurement, setMeasurement] = useState<string | null>(null);
  const [hint, setHint] = useState("Start with |00⟩, then apply H to Q1 and CNOT from Q1 to Q2 to create a Bell pair.");
  useEffect(() => {
    if (requestedChapter !== null && chapters[requestedChapter]) {
      setHint(chapters[requestedChapter].experiment);
    }
  }, [requestedChapter]);
  const p = useMemo(() => probabilities(state), [state]);
  const addGate = (gate: Gate, label: string) => {
    setState((current) => applyGate(current, gate));
    setHistory((items) => [...items, label]);
    setMeasurement(null);
    setHint(`${label} applied. The state vector and probabilities have been recalculated.`);
    getAudioEngine().playSfx("click");
  };
  const reset = () => { setState(initialState()); setHistory([]); setMeasurement(null); setHint("Circuit reset to the two-qubit state |00⟩."); };
  const measure = () => {
    const result = sampleMeasurement(state);
    setState(collapseToOutcome(state, result));
    setMeasurement(result);
    setHint(`This run returned |${result}⟩. A new run may return a different outcome according to the displayed probabilities.`);
    getAudioEngine().playSfx("measure");
  };
  const runBellRecipe = () => {
    let next = initialState();
    next = applyGate(next, "H_Q1");
    next = applyGate(next, "CNOT_Q1_TO_Q2");
    setState(next);
    setHistory(["H · Q1", "CNOT · Q1 → Q2"]);
    setMeasurement(null);
    setHint("Bell-pair recipe complete. In this ideal simulation, measuring both qubits gives 00 or 11 with equal probability.");
    getAudioEngine().playSfx("success");
  };
  const labels = ["|00⟩", "|01⟩", "|10⟩", "|11⟩"];
  return (
    <section className="page-section section-shell">
      <div className="page-intro"><div className="section-kicker">THE QUANTUM LABORATORY</div><h1>Don't just read it.<br /><em>Experiment with it.</em></h1><p>A tiny idealized two-qubit simulator. Prepare a state, apply gates, and see how the probabilities change.</p></div>
      <div className="lab-banner"><span className="lab-banner-icon">✧</span><div><b>Today's experiment: make a Bell pair</b><p>Follow the recipe to create the entangled state (|00⟩ + |11⟩)/√2.</p></div><button className="button button-light" onClick={runBellRecipe}>Run Bell recipe ↗</button></div>
      <div className="lab-grid">
        <div className="lab-panel circuit-panel"><div className="panel-heading"><div><span className="section-kicker">01 / CIRCUIT BUILDER</span><h2>Your quantum circuit</h2></div><button className="reset-button" onClick={reset}>↺ Reset</button></div><div className="qubit-lines"><div className="qubit-row"><span className="qubit-label">Q1</span><span className="wire"/><span className="gate-chip hadamard">H</span><span className="wire wire-after"/><span className="gate-chip cnot">●</span><span className="wire"/></div><div className="qubit-row"><span className="qubit-label">Q2</span><span className="wire"/><span className="wire"/><span className="wire wire-after"/><span className="gate-chip target">⊕</span><span className="wire"/></div><div className="cnot-stem" /></div><div className="circuit-actions"><button onClick={() => addGate("H_Q1", "H · Q1")} className="gate-action"><b>H</b><span>Hadamard on Q1</span></button><button onClick={() => addGate("H_Q2", "H · Q2")} className="gate-action"><b>H</b><span>Hadamard on Q2</span></button><button onClick={() => addGate("CNOT_Q1_TO_Q2", "CNOT · Q1 → Q2")} className="gate-action"><b>⊕</b><span>CNOT Q1 → Q2</span></button><button onClick={() => addGate("X_Q1", "X · Q1")} className="gate-action"><b>X</b><span>Pauli-X on Q1</span></button></div><div className="operation-history"><span>GATE HISTORY</span><div>{history.length ? history.map((entry, index) => <i key={`${entry}-${index}`}>{entry}</i>) : <small>No gates applied yet.</small>}</div></div><button className="button button-primary measure-button" onClick={measure}>Measure both qubits <span>◉</span></button>{measurement && <div className="measurement-result" key={measurement}><span>MEASUREMENT RESULT</span><b>|{measurement}⟩</b><p>One possible outcome from this run.</p></div>}</div>
        <div className="lab-panel state-panel"><div className="panel-heading"><div><span className="section-kicker">02 / LIVE STATE</span><h2>What is the state?</h2></div><span className="live-dot">IDEAL SIMULATOR</span></div><div className="state-equation"><span className="equation-label">STATE VECTOR</span><code>{formatState(state)}</code></div><div className="probability-heading"><b>Measurement probabilities</b><small>Basis order: |q2 q1⟩</small></div><div className="probability-list">{p.map((value, index) => <ProbabilityBar key={labels[index]} label={labels[index] ?? ""} value={value} />)}</div><div className="lab-explanation"><span>✧</span><p>{hint}</p></div><div className="physics-footnote"><b>Good to know</b><p>This is an ideal mathematical simulation, not a connection to a physical quantum computer. Q1 is the right-hand bit in the displayed basis label.</p></div></div>
      </div>
      <div className="lab-lower-note"><span>THE SCIENCE BEHIND THE BRAID</span><p>Our story uses braids as a visual metaphor for connection. Quantum entanglement is defined by the mathematics of a joint quantum state—not by two ordinary objects being physically connected.</p></div>
      <AdvancedWorkbench />
    </section>
  );
}

function LearnSection() {
  const [expanded, setExpanded] = useState<number | null>(1);
  const [answer, setAnswer] = useState<string | null>(null);
  const correct = answer === "H";
  const chooseAnswer = (value: string) => {
    setAnswer(value);
    getAudioEngine().playSfx(value === "H" ? "success" : "click");
  };
  return (
    <section className="page-section section-shell">
      <div className="page-intro"><div className="section-kicker">THE FIELD GUIDE</div><h1>Quantum, one idea<br /><em>at a time.</em></h1><p>Clear explanations, real notation, and no assumption that you already know the mathematics.</p></div>
      <div className="concept-grid">{concepts.map((concept, index) => <article className={`concept-card ${expanded === index ? "expanded" : ""}`} key={concept.title}><button onClick={() => setExpanded(expanded === index ? null : index)} aria-expanded={expanded === index}><span className="concept-symbol">{concept.symbol}</span><span className="concept-title">{concept.title}</span><span className="concept-toggle">{expanded === index ? "−" : "+"}</span></button><p>{concept.body}</p>{expanded === index && <div className="concept-detail"><b>IN THE NOTEBOOK</b><p>{concept.detail}</p></div>}</article>)}</div>
      <section className="knowledge-check"><div className="quiz-copy"><div className="section-kicker">A QUICK CHECK</div><h2>Try a little<br /><em>thought experiment.</em></h2><p>Which quantum gate transforms the state |0⟩ into an equal superposition of |0⟩ and |1⟩?</p></div><div className="quiz-interaction"><div className="quiz-options">{[{ label: "Pauli-X", value: "X" }, { label: "Hadamard", value: "H" }, { label: "CNOT", value: "CNOT" }].map((choice) => <button key={choice.value} onClick={() => chooseAnswer(choice.value)} className={`quiz-option ${answer === choice.value ? (choice.value === "H" ? "correct" : "incorrect") : ""}`}><span>{choice.value}</span>{choice.label}<i>{answer === choice.value ? (choice.value === "H" ? "✓" : "×") : "→"}</i></button>)}</div>{answer && <div className={`quiz-feedback ${correct ? "success" : "retry"}`}><b>{correct ? "Exactly right." : "Not quite—try again."}</b><p>{correct ? "The Hadamard gate maps |0⟩ to (|0⟩ + |1⟩)/√2. Measuring that state in the computational basis gives 0 or 1 with equal probability." : "Think about the gate that spreads the amplitude of |0⟩ evenly across both basis states."}</p></div>}</div></section>
    </section>
  );
}

function ForGirlsSection() {
  const [checked, setChecked] = useState<boolean[]>([false, false, false, false]);
  const [checklistLoaded, setChecklistLoaded] = useState(false);
  // Keep the experiment checklist between visits, on this device only.
  useEffect(() => {
    try {
      const saved = window.localStorage.getItem("lpp-checklist");
      const parsed = saved ? JSON.parse(saved) : null;
      if (Array.isArray(parsed) && parsed.length === 4) setChecked(parsed.map(Boolean));
    } catch {
      /* storage unavailable: start fresh */
    }
    setChecklistLoaded(true);
  }, []);
  useEffect(() => {
    if (!checklistLoaded) return;
    try {
      window.localStorage.setItem("lpp-checklist", JSON.stringify(checked));
    } catch {
      /* storage unavailable: progress just is not saved */
    }
  }, [checked, checklistLoaded]);
  const steps = ["Meet a qubit: learn what |0⟩ and |1⟩ mean.", "Build a superposition with a Hadamard gate.", "Create a Bell pair with a CNOT gate.", "Write down one question you want to investigate."];
  const completed = checked.filter(Boolean).length;
  return (
    <section className="page-section section-shell girls-section">
      <div className="girls-hero"><div><div className="section-kicker">FOR THE NEXT GENERATION OF SCIENTISTS</div><h1>There is room<br />for <em>your mind</em><br />in this universe.</h1><p>You do not need to be a genius to begin. You need curiosity, practice, and room to experiment. Quantum science belongs to everyone willing to ask a good question.</p><button className="button button-primary" onClick={() => document.getElementById("first-experiment")?.scrollIntoView({ behavior: "smooth", block: "start" })}>Make your first experiment ↓</button></div><div className="girls-quote"><span>“</span><blockquote>Nothing in life is to be feared; it is only to be understood.</blockquote><small>— MARIE CURIE</small><p className="quote-note">A historical scientist whose curiosity and persistence continue to inspire. The story's young protagonist is fictional.</p></div></div>
      <div className="pathway"><div className="section-kicker">YOUR QUANTUM PATH</div><h2>From curious to <em>capable.</em></h2><div className="pathway-steps"><div><i>01</i><b>Curiosity</b><small>Ask your first question.</small></div><div><i>02</i><b>Fundamentals</b><small>Build the physics and math.</small></div><div><i>03</i><b>First circuit</b><small>Make a state and measure it.</small></div><div><i>04</i><b>Your project</b><small>Investigate something original.</small></div></div></div>
      <div className="first-experiment" id="first-experiment" style={{ scrollMarginTop: 120 }}><div><div className="section-kicker">YOUR FIRST QUANTUM EXPERIMENT</div><h2>A small checklist<br /><em>for a big beginning.</em></h2><p>Tick off each step as you explore. Your progress stays in this page only; no account is needed.</p><div className="check-progress"><span style={{ width: `${completed / steps.length * 100}%` }} /></div><small>{completed} of {steps.length} steps complete</small></div><div className="checklist">{steps.map((step, index) => <label className={checked[index] ? "checked" : ""} key={step}><input type="checkbox" checked={checked[index]} onChange={() => setChecked((current) => current.map((v, i) => i === index ? !v : v))}/><span className="custom-check">✓</span><span>{step}</span></label>)}</div></div>
    </section>
  );
}

function Footer({ go }: { go: (section: Section) => void }) {
  return <footer className="site-footer"><div className="footer-top"><BrandMark /><p>Curiosity is where every discovery begins.</p><button className="back-top" onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}>Back to top ↑</button></div><div className="footer-bottom"><span>© {new Date().getFullYear()} LA PETITE PRINCESSE · AN EDUCATIONAL PROTOTYPE</span><div><button onClick={() => go("story")}>Story</button><button onClick={() => go("lab")}>Quantum Lab</button><button onClick={() => go("learn")}>Learn</button><button onClick={() => go("girls")}>For Girls</button></div></div><p className="footer-disclaimer">Independent educational concept. Not affiliated with or endorsed by MIT, IBM, or any university or research institution.</p></footer>;
}

export default function App() {
  const [section, setSection] = useState<Section>("home");
  const [requestedChapter, setRequestedChapter] = useState<number | null>(null);
  const [progress, setProgress] = useState(0);
  const [journey, setJourney] = useState<StoryJourney>(() => emptyJourney());
  const [journeyLoaded, setJourneyLoaded] = useState(false);

  // The reading journey (discovered chapters, last position) is restored after
  // hydration and saved locally on every change — this browser only.
  useEffect(() => {
    setJourney(loadJourney(chapters.length, chapters.map((chapter) => chapter.number)));
    setJourneyLoaded(true);
  }, []);
  useEffect(() => {
    if (journeyLoaded) saveJourney(journey);
  }, [journey, journeyLoaded]);

  // The address bar remembers where you are, so Back/Forward and a refresh
  // both bring you straight back to this part of the site.
  useEffect(() => {
    const fromHash = () => {
      const raw = window.location.hash.replace(/^#\/?/, "");
      if (raw === "home" || raw === "story" || raw === "lab" || raw === "learn" || raw === "girls") {
        setSection(raw as Section);
      }
    };
    fromHash();
    window.addEventListener("hashchange", fromHash);
    return () => window.removeEventListener("hashchange", fromHash);
  }, []);

  // A thin gold rule under the header shows how far down the page you have read.
  useEffect(() => {
    const onScroll = () => {
      const max = document.documentElement.scrollHeight - window.innerHeight;
      setProgress(max > 40 ? Math.min(100, Math.max(0, (window.scrollY / max) * 100)) : 0);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
    };
  }, [section]);

  const navigate = (next: Section) => {
    setSection(next);
    setJourney((current) => markSectionVisited(current, next));
    if (window.location.hash !== `#${next}`) window.location.hash = next;
    window.scrollTo({ top: 0, behavior: "smooth" });
    if (next !== section) getAudioEngine().playSfx("whoosh");
  };
  const openLab = (chapterIndex: number) => { setRequestedChapter(chapterIndex); navigate("lab"); };
  const discoverChapter = (chapterIndex: number) => {
    const chapter = chapters[chapterIndex];
    if (!chapter) return;
    setJourney((current) => markChapterDiscovered(current, chapter.number, chapterIndex));
  };
  return (
    <div className="app-shell">
      <a className="skip-link" href="#main-content">Skip to content</a>
      <div className="scroll-progress" aria-hidden="true"><span style={{ width: `${progress}%` }} /></div>
      <header className="site-header"><button className="brand-button" onClick={() => navigate("home")}><BrandMark /></button><nav aria-label="Primary navigation"><SectionButton id="story" current={section} onClick={navigate}>The Story</SectionButton><SectionButton id="lab" current={section} onClick={navigate}>Quantum Lab</SectionButton><SectionButton id="learn" current={section} onClick={navigate}>Learn</SectionButton><SectionButton id="girls" current={section} onClick={navigate}>For Girls</SectionButton><a className="nav-link" href="/academy">Academy</a><a className="nav-link" href="/circuit-pro">Circuit Pro</a><a className="nav-link" href="/guide">Guide</a></nav><button className="header-cta" onClick={() => navigate("lab")}>Start exploring <span>↗</span></button></header>
<main id="main-content" tabIndex={-1} key={section} className="section-enter">{section === "home" && <HomeSection go={navigate} journey={journey} />}{section === "story" && <StorySection goLab={openLab} journey={journey} onDiscover={discoverChapter} />}{section === "lab" && <QuantumLabSection requestedChapter={requestedChapter} />}{section === "learn" && <LearnSection />}{section === "girls" && <ForGirlsSection />}</main>
      <Footer go={navigate} /><QuantumMentor />
      <AudioDock />
    </div>
  );
}
