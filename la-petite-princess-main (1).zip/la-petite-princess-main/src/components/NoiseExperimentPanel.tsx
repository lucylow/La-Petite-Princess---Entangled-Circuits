// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { useMemo, useState } from "react";
import type { QuantumCircuit } from "../quantum-engine/circuit";
import { simulateNoisyDensity } from "../quantum-engine/noisy-simulator";
import { densityTrace, fidelityPureToDensity, purity, vonNeumannEntropy } from "../quantum-engine/density";
import { simulateState } from "../quantum-engine/simulator";

export interface NoiseExperimentPanelProps {
  circuit: QuantumCircuit;
}

function RateControl({ label, value, onChange }: { label: string; value: number; onChange: (value: number) => void }) {
  return <label className="qpro-noise-control">
    <span>{label}<b>{(value * 100).toFixed(1)}%</b></span>
    <input type="range" min="0" max="0.3" step="0.005" value={value} onChange={(event) => onChange(Number(event.currentTarget.value))} />
  </label>;
}

export function NoiseExperimentPanel({ circuit }: NoiseExperimentPanelProps) {
  const [depolarizing, setDepolarizing] = useState(0.02);
  const [amplitude, setAmplitude] = useState(0.01);
  const [phase, setPhase] = useState(0.01);
  const [showResult, setShowResult] = useState(false);
  const result = useMemo(() => {
    if (!showResult) return null;
    try {
      return simulateNoisyDensity(circuit, {
        singleQubitDepolarizing: depolarizing,
        twoQubitDepolarizing: depolarizing,
        amplitudeDamping: amplitude,
        phaseDamping: phase,
      });
    } catch (error) {
      return { error: error instanceof Error ? error.message : "Noise simulation failed." } as const;
    }
  }, [circuit, depolarizing, amplitude, phase, showResult]);
  const ideal = useMemo(() => {
    try { return simulateState(circuit); } catch { return null; }
  }, [circuit]);
  const idealPurity = ideal ? 1 : null;
  const errors = circuit.instructions.some((instruction) => instruction.type !== "gate" || (instruction.type === "gate" && instruction.condition));

  return <section className="qpro-noise-lab">
    <div className="qpro-noise-intro"><span className="qpro-kicker">OPEN-SYSTEM QUANTUM PHYSICS</span><h3>What if the laboratory isn't perfect?</h3><p>Introduce noise channels after gates and compare the mixed output state with the ideal pure-state result. This dense simulator is capped at six qubits.</p></div>
    <div className="qpro-noise-controls">
      <RateControl label="Depolarizing noise" value={depolarizing} onChange={(value) => { setDepolarizing(value); setShowResult(false); }} />
      <RateControl label="Amplitude damping" value={amplitude} onChange={(value) => { setAmplitude(value); setShowResult(false); }} />
      <RateControl label="Phase damping" value={phase} onChange={(value) => { setPhase(value); setShowResult(false); }} />
    </div>
    <div className="qpro-noise-actions"><button type="button" onClick={() => setShowResult(true)} disabled={errors || circuit.qubits > 6}>Simulate noisy circuit</button><span>{errors ? "Gate-only circuits required" : circuit.qubits > 6 ? "Reduce to 6 qubits or fewer" : `${circuit.qubits} qubit density-matrix simulation`}</span></div>
    {result && "error" in result && <div className="qpro-noise-error" role="alert">{result.error}</div>}
    {result && !("error" in result) && <div className="qpro-noise-results">
      <div><span>TRACE</span><b>{densityTrace(result.density).toFixed(6)}</b><small>Should remain 1</small></div>
      <div><span>PURITY</span><b>{purity(result.density).toFixed(4)}</b><small>1 is a pure state</small></div>
      <div><span>VON NEUMANN ENTROPY</span><b>{vonNeumannEntropy(result.density).toFixed(4)} bits</b><small>Mixedness diagnostic</small></div>
      <div><span>APPLIED CHANNELS</span><b>{result.appliedChannels.length}</b><small>Local Kraus applications</small></div>
      {ideal && <div className="qpro-noise-fidelity"><span>IDEAL-TO-NOISY FIDELITY</span><b>{fidelityPureToDensity(ideal, result.density).toFixed(4)}</b><small>Overlap with the noiseless pure state</small></div>}
      {idealPurity !== null && <p>Ideal state purity: {idealPurity.toFixed(2)}. The configured model applies independent local channels after each gate. The numbers are pedagogical model outputs, not device calibration data.</p>}
    </div>}
  </section>;
}

export default NoiseExperimentPanel;
