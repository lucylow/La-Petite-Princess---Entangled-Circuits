// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import type { CircuitInstruction, QuantumCircuit } from "../quantum-engine/circuit";
import { scheduleCircuitMoments } from "../quantum-engine/circuit-analysis";

export interface CircuitCanvasProps {
  circuit: QuantumCircuit;
  selectedId?: string | null;
  onSelect?: (instruction: CircuitInstruction) => void;
}

const LEFT = 58;
const TOP = 38;
const ROW = 55;
const COLUMN = 76;
const GATE_W = 44;
const GATE_H = 34;

function gateText(instruction: CircuitInstruction): string {
  if (instruction.type === "measure") return "M";
  if (instruction.type === "reset") return "|0⟩";
  if (instruction.type === "barrier") return "‖";
  if (["RX", "RY", "RZ", "P", "CP", "CRX", "CRY", "CRZ"].includes(instruction.gate)) {
    return `${instruction.gate}(${(instruction.params?.theta ?? 0).toFixed(1)})`;
  }
  return instruction.gate;
}

function wireY(qubit: number): number {
  return TOP + qubit * ROW;
}

function touched(instruction: CircuitInstruction): number[] {
  if (instruction.type === "gate") return [...instruction.controls ?? [], ...instruction.targets];
  if (instruction.type === "measure" || instruction.type === "reset") return instruction.qubits;
  return instruction.qubits ?? [];
}

export function CircuitCanvas({ circuit, selectedId, onSelect }: CircuitCanvasProps) {
  const moments = scheduleCircuitMoments(circuit);
  const width = Math.max(300, LEFT + (moments.length + 1) * COLUMN);
  const height = TOP * 2 + Math.max(0, circuit.qubits - 1) * ROW + 32;
  const positions = new Map<string, number>();
  moments.forEach((moment, index) => moment.instructionIds.forEach((id) => positions.set(id, index)));
  const instructionById = new Map(circuit.instructions.map((instruction) => [instruction.id, instruction]));

  return (
    <div className="qpro-canvas-scroll" role="region" aria-label="Quantum circuit diagram" tabIndex={0}>
      <svg className="qpro-circuit-svg" viewBox={`0 0 ${width} ${height}`} role="img" aria-label={`${circuit.qubits} qubit circuit with ${circuit.instructions.length} instructions`}>
        <defs>
          <linearGradient id="qpro-wire" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#c7b5dc" />
            <stop offset="100%" stopColor="#a58abc" />
          </linearGradient>
        </defs>
        {Array.from({ length: circuit.qubits }, (_, qubit) => (
          <g key={`wire-${qubit}`}>
            <text x="12" y={wireY(qubit) + 5} className="qpro-wire-label">q{qubit}</text>
            <line x1={LEFT - 12} x2={width - 16} y1={wireY(qubit)} y2={wireY(qubit)} stroke="url(#qpro-wire)" strokeWidth="2" />
          </g>
        ))}
        {moments.map((moment, momentIndex) => moment.instructionIds.map((id) => {
          const instruction = instructionById.get(id);
          if (!instruction) return null;
          const x = LEFT + momentIndex * COLUMN;
          const wires = touched(instruction);
          const selected = id === selectedId;
          if (instruction.type === "barrier") {
            const affected = instruction.qubits ?? Array.from({ length: circuit.qubits }, (_, q) => q);
            const minY = wireY(Math.min(...affected));
            const maxY = wireY(Math.max(...affected));
            return <g key={id} opacity=".7"><line x1={x} y1={minY - 22} x2={x} y2={maxY + 22} stroke="#a58bcb" strokeWidth="2" strokeDasharray="4 4" /><title>Barrier</title></g>;
          }
          if (instruction.type === "gate" && instruction.controls?.length) {
            const points = [...instruction.controls, ...instruction.targets].map(wireY);
            const minY = Math.min(...points);
            const maxY = Math.max(...points);
            return <g key={id} className={`qpro-circuit-op ${selected ? "is-selected" : ""}`} onClick={() => onSelect?.(instruction)} role="button" tabIndex={0} onKeyDown={(event) => { if (event.key === "Enter" || event.key === " ") onSelect?.(instruction); }}>
              <title>{instruction.gate} · wires {wires.join(", ")}</title>
              {instruction.controls.map((control) => <circle key={`control-${control}`} cx={x} cy={wireY(control)} r="5" className="qpro-control-dot" />)}
              <line x1={x} x2={x} y1={minY} y2={maxY} className="qpro-control-line" />
              {instruction.targets.map((target) => <g key={`target-${target}`}><rect x={x - GATE_W / 2} y={wireY(target) - GATE_H / 2} width={GATE_W} height={GATE_H} rx="9" className={`qpro-gate-box ${selected ? "selected" : ""}`} /><text x={x} y={wireY(target) + 5} textAnchor="middle" className="qpro-gate-text">{gateText(instruction)}</text></g>)}
            </g>;
          }
          if (instruction.type === "gate" && instruction.gate === "SWAP" && instruction.targets.length === 2) {
            const [a, b] = instruction.targets.map(wireY);
            return <g key={id} className={`qpro-circuit-op ${selected ? "is-selected" : ""}`} onClick={() => onSelect?.(instruction)} role="button" tabIndex={0} onKeyDown={(event) => { if (event.key === "Enter") onSelect?.(instruction); }}>
              <line x1={x} x2={x} y1={a} y2={b} className="qpro-control-line" />
              {[a, b].map((y, index) => <g key={index}><circle cx={x} cy={y} r="9" className="qpro-swap-mark" /><path d={`M${x - 5} ${y - 5} L${x + 5} ${y + 5} M${x + 5} ${y - 5} L${x - 5} ${y + 5}`} className="qpro-swap-cross" /></g>)}
              <title>SWAP q{instruction.targets[0]} and q{instruction.targets[1]}</title>
            </g>;
          }
          const q = wires[0] ?? 0;
          const y = wireY(q);
          const label = gateText(instruction);
          const w = Math.max(GATE_W, label.length * 8 + 14);
          return <g key={id} className={`qpro-circuit-op ${selected ? "is-selected" : ""}`} onClick={() => onSelect?.(instruction)} role="button" tabIndex={0} onKeyDown={(event) => { if (event.key === "Enter" || event.key === " ") onSelect?.(instruction); }}>
            <title>{instruction.type === "gate" ? instruction.gate : instruction.type} on q{q}</title>
            <rect x={x - w / 2} y={y - GATE_H / 2} width={w} height={GATE_H} rx="9" className={`qpro-gate-box ${selected ? "selected" : ""}`} />
            <text x={x} y={y + 5} textAnchor="middle" className="qpro-gate-text">{label}</text>
          </g>;
        }))}
        {moments.map((moment, index) => <text key={`moment-${index}`} x={LEFT + index * COLUMN} y={height - 4} textAnchor="middle" className="qpro-moment-label">{index + 1}</text>)}
      </svg>
    </div>
  );
}

export default CircuitCanvas;
