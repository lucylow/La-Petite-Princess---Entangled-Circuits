// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { useMemo } from "react";
import type { QuantumCircuit } from "../quantum-engine/circuit";
import { optimizeCircuit } from "../quantum-engine/optimizer";
import { simulateState } from "../quantum-engine/simulator";
import { stateFidelity } from "../quantum-engine/unitary";
import { calculateCircuitMetrics } from "../quantum-engine/circuit-analysis";

export interface CircuitComparisonPanelProps {
  circuit: QuantumCircuit;
}

export function CircuitComparisonPanel({ circuit }: CircuitComparisonPanelProps) {
  const result = useMemo(() => {
    try {
      const optimized = optimizeCircuit(circuit);
      const beforeState = simulateState(circuit);
      const afterState = simulateState(optimized.circuit);
      return {
        optimized,
        fidelity: stateFidelity(beforeState, afterState),
        beforeMetrics: calculateCircuitMetrics(circuit),
        afterMetrics: calculateCircuitMetrics(optimized.circuit),
      };
    } catch (error) {
      return { error: error instanceof Error ? error.message : "Comparison unavailable." } as const;
    }
  }, [circuit]);

  return <section className="qpro-compare-panel">
    <div className="qpro-compare-heading"><span className="qpro-kicker">CIRCUIT COMPILER REPORT</span><h3>Before and after optimization</h3><p>Local simplification passes remove identities, cancel adjacent inverse gates, and merge neighboring rotations about the same axis.</p></div>
    {"error" in result ? <div className="qpro-empty-state">{result.error}</div> : <>
      <div className="qpro-compare-score"><span>State fidelity</span><b>{result.fidelity.toFixed(8)}</b><small>1.0 means the two output states are identical up to global phase.</small></div>
      <div className="qpro-compare-columns">
        {[{ title: "Original", metrics: result.beforeMetrics }, { title: "Optimized", metrics: result.afterMetrics }].map((item) => <div key={item.title}><b>{item.title}</b><dl><dt>Gate count</dt><dd>{item.metrics.unitaryGates}</dd><dt>Estimated depth</dt><dd>{item.metrics.estimatedDepth}</dd><dt>Controlled gates</dt><dd>{item.metrics.controlledGates}</dd><dt>Parameterized</dt><dd>{item.metrics.parameterizedGates}</dd></dl></div>)}
      </div>
      <div className="qpro-compare-passes">{result.optimized.passes.map((pass) => <div key={pass.name}><span>{pass.name}</span><b>{pass.changed} change(s)</b><small>{pass.notes[0]}</small></div>)}</div>
    </>}
  </section>;
}

export default CircuitComparisonPanel;
