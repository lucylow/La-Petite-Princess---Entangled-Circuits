// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { useMemo, useState } from "react";
import type { ReactNode } from "react";
import type { CircuitInstruction, QuantumCircuit } from "../quantum-engine/circuit";
import {
  appendGate,
  appendMeasurement,
  createCircuit,
  removeInstruction,
  updateGateParameter,
} from "../quantum-engine/circuit";
import { GATE_DEFINITIONS, gateDefinition, type GateId } from "../quantum-engine/gates";
import {
  exactMeasurementDistribution,
  runShots,
  simulateState,
  type SimulationSummary,
} from "../quantum-engine/simulator";
import { stateAsTerms } from "../quantum-engine/statevector";
import { stateQubitBlochCoordinates } from "../quantum-engine/bloch";
import { entanglementReport } from "../quantum-engine/entanglement";
import { optimizeCircuit } from "../quantum-engine/optimizer";
import { compileToCliffordT } from "../quantum-engine/compiler";
import { exportCircuitAsPython, exportOpenQASM3 } from "../quantum-engine/qasm";
import { lineCouplingMap, routeCircuitToCouplingMap } from "../quantum-engine/routing";
import { calculateCircuitMetrics } from "../quantum-engine/circuit-analysis";
import { CircuitCanvas } from "./CircuitCanvas";
import { ProbabilityHistogram } from "./ProbabilityHistogram";
import { BlochSphere } from "./BlochSphere";
import { AlgorithmGallery } from "./AlgorithmGallery";
import { CircuitDiagnostics } from "./CircuitDiagnostics";
import { NoiseExperimentPanel } from "./NoiseExperimentPanel";
import { PauliObservablePanel } from "./PauliObservablePanel";
import { ParameterSweepLab } from "./ParameterSweepLab";
import { GateReference } from "./GateReference";
import { CircuitComparisonPanel } from "./CircuitComparisonPanel";
import "../styles/circuit-studio-pro.css";

type GateCategory = "all" | "single" | "rotation" | "controlled" | "multi";
type OutputTab = "results" | "diagnostics" | "noise" | "observables" | "sweep" | "compare" | "reference" | "export";

const CATEGORY_LABELS: Record<GateCategory, string> = {
  all: "All gates",
  single: "Single-qubit",
  rotation: "Rotations",
  controlled: "Controlled",
  multi: "Multi-qubit",
};

const INITIAL_HELP = "Choose a gate, select the wires it should act on, and add it to the circuit. Or load a prepared algorithm from the circuit library.";

function isDynamic(circuit: QuantumCircuit): boolean {
  return circuit.instructions.some((instruction) => instruction.type === "measure" || instruction.type === "reset" || (instruction.type === "gate" && Boolean(instruction.condition)));
}

function formatAmplitude(real: number, imaginary: number): string {
  const r = Math.abs(real) < 1e-8 ? 0 : real;
  const i = Math.abs(imaginary) < 1e-8 ? 0 : imaginary;
  const sign = i < 0 ? "−" : "+";
  if (Math.abs(i) < 1e-8) return r.toFixed(3);
  if (Math.abs(r) < 1e-8) return `${i.toFixed(3)}i`;
  return `${r.toFixed(3)} ${sign} ${Math.abs(i).toFixed(3)}i`;
}

function SectionLabel({ children }: { children: string }) {
  return <span className="qpro-kicker">{children}</span>;
}

function PanelTitle({ eyebrow, title, action }: { eyebrow: string; title: string; action?: ReactNode }) {
  return <div className="qpro-panel-heading"><div><SectionLabel>{eyebrow}</SectionLabel><h3>{title}</h3></div>{action}</div>;
}

function GateParameterEditor({
  instruction,
  onChange,
}: {
  instruction: Extract<CircuitInstruction, { type: "gate" }>;
  onChange: (key: "theta" | "phi" | "lambda", value: number) => void;
}) {
  const definition = gateDefinition(instruction.gate);
  if (!definition.parameterCount) return <p className="qpro-inspector-note">This gate has no continuous parameters.</p>;
  const parameterKeys: Array<"theta" | "phi" | "lambda"> = definition.parameterCount === 3 ? ["theta", "phi", "lambda"] : ["theta"];
  return <div className="qpro-parameter-editor">
    {parameterKeys.map((key) => <label key={key}>
      <span>{key === "theta" ? "θ" : key === "phi" ? "φ" : "λ"} <small>{key}</small></span>
      <input
        type="number"
        step="0.1"
        value={Number(instruction.params?.[key] ?? 0).toFixed(4)}
        onChange={(event) => onChange(key, Number(event.currentTarget.value))}
      />
    </label>)}
    <div className="qpro-angle-presets">
      {["π/4", "π/2", "π", "2π"].map((label, index) => {
        const value = [Math.PI / 4, Math.PI / 2, Math.PI, 2 * Math.PI][index];
        return <button type="button" key={label} onClick={() => onChange("theta", value)}>{label}</button>;
      })}
    </div>
  </div>;
}

function StateTerms({ circuit }: { circuit: QuantumCircuit }) {
  const state = useMemo(() => {
    try {
      return simulateState(circuit);
    } catch {
      return null;
    }
  }, [circuit]);
  if (!state) return <div className="qpro-empty-state">This circuit contains measurement or reset. Use shot results to inspect its classical outcomes.</div>;
  const terms = stateAsTerms(state, 1e-5).sort((a, b) => b.probability - a.probability).slice(0, 12);
  return <div className="qpro-state-terms">
    {terms.map((term) => <div className="qpro-state-term" key={term.basis}>
      <code>|{term.basis}⟩</code>
      <span>{formatAmplitude(term.re, term.im)}</span>
      <b>{(term.probability * 100).toFixed(2)}%</b>
    </div>)}
    {state.amplitudes.length > 12 && <small>Showing the 12 largest-amplitude basis states.</small>}
  </div>;
}

export interface CircuitStudioProProps {
  initialCircuit?: QuantumCircuit;
  compact?: boolean;
}

export function CircuitStudioPro({ initialCircuit, compact = false }: CircuitStudioProProps) {
  const [circuit, setCircuit] = useState<QuantumCircuit>(() => initialCircuit ?? createCircuit(2, "My first quantum circuit"));
  const [selectedGate, setSelectedGate] = useState<GateId>("H");
  const [selectedQubits, setSelectedQubits] = useState<number[]>([0]);
  const [selectedInstruction, setSelectedInstruction] = useState<CircuitInstruction | null>(null);
  const [category, setCategory] = useState<GateCategory>("all");
  const [angle, setAngle] = useState("1.5707963268");
  const [shots, setShots] = useState(1024);
  const [seed, setSeed] = useState("42");
  const [summary, setSummary] = useState<SimulationSummary | null>(null);
  const [exact, setExact] = useState<Record<string, number>>({});
  const [tab, setTab] = useState<OutputTab>("results");
  const [exportFormat, setExportFormat] = useState<"qasm" | "python">("qasm");
  const [notice, setNotice] = useState(INITIAL_HELP);
  const [error, setError] = useState<string | null>(null);
  const [busyAction, setBusyAction] = useState<string | null>(null);

  const definition = gateDefinition(selectedGate);
  const expectedSelection = definition.targetCount + definition.controlCount;
  const gateList = GATE_DEFINITIONS.filter((gate) => category === "all" || gate.category === category);
  const metrics = useMemo(() => calculateCircuitMetrics(circuit), [circuit]);
  const visibleBloch = useMemo(() => {
    try {
      const state = simulateState(circuit);
      return Array.from({ length: Math.min(3, circuit.qubits) }, (_, qubit) => ({ qubit, vector: stateQubitBlochCoordinates(state, qubit) }));
    } catch {
      return [];
    }
  }, [circuit]);
  const entanglement = useMemo(() => {
    try {
      return entanglementReport(simulateState(circuit));
    } catch {
      return null;
    }
  }, [circuit]);
  const exportText = useMemo(() => {
    try {
      return exportFormat === "qasm" ? exportOpenQASM3(circuit) : exportCircuitAsPython(circuit);
    } catch (caught) {
      return caught instanceof Error ? caught.message : "Export failed.";
    }
  }, [circuit, exportFormat]);

  function updateCircuit(next: QuantumCircuit, message: string): void {
    setCircuit(next);
    setSummary(null);
    setExact({});
    setError(null);
    setNotice(message);
  }

  function toggleQubit(qubit: number): void {
    setSelectedQubits((current) => current.includes(qubit)
      ? current.filter((item) => item !== qubit)
      : [...current, qubit].sort((a, b) => a - b));
  }

  function addSelectedGate(): void {
    if (selectedQubits.length !== expectedSelection) {
      setError(`${definition.label} needs ${expectedSelection} selected wire(s); ${definition.controlCount} control(s) and ${definition.targetCount} target(s).`);
      return;
    }
    const controls = selectedQubits.slice(0, definition.controlCount);
    const targets = selectedQubits.slice(definition.controlCount);
    const parameters = definition.parameterCount === 3
      ? { theta: Math.PI / 2, phi: 0, lambda: 0 }
      : definition.parameterCount > 0 ? { theta: Number(angle) } : {};
    const next = appendGate(circuit, selectedGate, targets, controls, parameters);
    updateCircuit(next, `${definition.label} added to ${controls.length ? `control q${controls.join(", q")} and ` : ""}target q${targets.join(", q")}.`);
    setSelectedInstruction(next.instructions[next.instructions.length - 1]);
  }

  function deleteSelected(): void {
    if (!selectedInstruction) return;
    updateCircuit(removeInstruction(circuit, selectedInstruction.id), "Instruction removed from the circuit.");
    setSelectedInstruction(null);
  }

  function editParameter(key: "theta" | "phi" | "lambda", value: number): void {
    if (!selectedInstruction || selectedInstruction.type !== "gate") return;
    const next = updateGateParameter(circuit, selectedInstruction.id, key, value);
    updateCircuit(next, `${selectedInstruction.gate} parameter ${key} updated.`);
    setSelectedInstruction(next.instructions.find((item) => item.id === selectedInstruction.id) ?? null);
  }

  function addMeasurements(): void {
    const qubits = Array.from({ length: circuit.qubits }, (_, qubit) => qubit);
    const next = appendMeasurement(circuit, qubits, qubits);
    updateCircuit(next, `Measurement operations added for all ${circuit.qubits} qubits.`);
  }

  function runCircuit(): void {
    setError(null);
    setBusyAction("run");
    try {
      const parsedSeed = seed.trim() === "" ? undefined : Number(seed);
      if (parsedSeed !== undefined && (!Number.isInteger(parsedSeed) || parsedSeed < 0)) throw new Error("Seed must be a non-negative integer or left blank.");
      const result = runShots(circuit, { shots, seed: parsedSeed, keepMemory: false });
      setSummary(result);
      if (!isDynamic(circuit)) setExact(exactMeasurementDistribution(circuit));
      else setExact({});
      setTab("results");
      setNotice(`Simulation complete: ${shots.toLocaleString()} shots in ${result.elapsedMs.toFixed(1)} ms. This is an ideal simulator unless noise is explicitly enabled.`);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "The circuit could not be simulated.");
    } finally {
      setBusyAction(null);
    }
  }

  function resetCircuit(): void {
    updateCircuit(createCircuit(circuit.qubits, "Untitled quantum circuit"), "Circuit cleared. Select gates to begin again.");
    setSelectedInstruction(null);
    setSelectedQubits([0]);
  }

  function applyOptimization(): void {
    const result = optimizeCircuit(circuit);
    updateCircuit(result.circuit, `Optimization complete: ${result.before.gates} → ${result.after.gates} gates; depth ${result.before.depth} → ${result.after.depth}.`);
  }

  function applyRouting(): void {
    try {
      const result = routeCircuitToCouplingMap(circuit, lineCouplingMap(circuit.qubits));
      updateCircuit(result.circuit, `Linear hardware routing inserted ${result.insertedSwaps} SWAP operation(s). Final logical-to-physical layout: ${result.logicalToPhysical.join(", ")}.`);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Routing failed.");
    }
  }

  function compileCliffordT(): void {
    try {
      const result = compileToCliffordT(circuit);
      updateCircuit(result.circuit, `Clifford+T pass expanded ${result.decompositionCount} composite gate(s). ${result.warnings.length} synthesis warning(s).`);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Compilation failed.");
    }
  }

  function updateQubitCount(value: number): void {
    if (!Number.isInteger(value) || value < 1 || value > 10) return;
    updateCircuit(createCircuit(value, `New ${value}-qubit circuit`), `Created a new ${value}-qubit register. Previous circuit content was cleared.`);
    setSelectedQubits([0]);
    setSelectedInstruction(null);
  }

  async function copyExport(): Promise<void> {
    try {
      if (typeof navigator === "undefined" || !navigator.clipboard) throw new Error("Clipboard access is unavailable in this browser. Select the code and copy it manually.");
      await navigator.clipboard.writeText(exportText);
      setNotice(`${exportFormat === "qasm" ? "OpenQASM 3" : "Qiskit Python"} copied to clipboard.`);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Clipboard copy failed.");
    }
  }

  function loadPreset(next: QuantumCircuit): void {
    setCircuit(next);
    setSummary(null);
    setExact({});
    setError(null);
    setSelectedInstruction(null);
    setSelectedQubits([0]);
    setNotice(`Loaded ${next.name}. Select Run to simulate it, or edit the gate sequence.`);
  }

  const selectedGateInstruction = selectedInstruction?.type === "gate" ? selectedInstruction : null;
  const resultProbabilities = summary?.probabilities ?? exact;

  return (
    <section className={`qpro-studio ${compact ? "qpro-studio-compact" : ""}`}>
      <header className="qpro-hero">
        <div className="qpro-hero-orbit qpro-orbit-one" />
        <div className="qpro-hero-orbit qpro-orbit-two" />
        <div className="qpro-hero-copy">
          <span className="qpro-kicker">LA PETITE PRINCESS · QUANTUM STUDIO</span>
          <h1>Build a circuit.<br /><em>Explore a universe.</em></h1>
          <p>Compose quantum gates, simulate states, inspect entanglement, and export real circuit code. Your notebook is the laboratory.</p>
        </div>
        <div className="qpro-hero-stats">
          <div><b>{GATE_DEFINITIONS.length}</b><span>gate definitions</span></div>
          <div><b>10</b><span>qubits in this UI</span></div>
          <div><b>09</b><span>algorithm presets</span></div>
        </div>
      </header>

      <div className="qpro-topbar">
        <div className="qpro-register-control"><label htmlFor="qpro-qubit-count">Register size</label><select id="qpro-qubit-count" value={circuit.qubits} onChange={(event) => updateQubitCount(Number(event.currentTarget.value))}>{Array.from({ length: 10 }, (_, index) => index + 1).map((value) => <option key={value} value={value}>{value} qubit{value > 1 ? "s" : ""}</option>)}</select></div>
        <div className="qpro-topbar-meta"><span><i /> IDEAL STATE-VECTOR ENGINE</span><span>{metrics.unitaryGates} gates · depth {metrics.estimatedDepth}</span></div>
        <button type="button" className="qpro-button qpro-button-ghost" onClick={resetCircuit}>↺ Clear circuit</button>
      </div>

      <div className="qpro-content-grid">
        <aside className="qpro-sidebar qpro-panel">
          <PanelTitle eyebrow="01 / GATE PALETTE" title="Choose an operation" />
          <div className="qpro-category-tabs" role="tablist" aria-label="Filter gates">
            {(Object.keys(CATEGORY_LABELS) as GateCategory[]).map((key) => <button type="button" role="tab" aria-selected={category === key} className={category === key ? "active" : ""} key={key} onClick={() => setCategory(key)}>{CATEGORY_LABELS[key]}</button>)}
          </div>
          <div className="qpro-gate-grid">
            {gateList.map((gate) => <button type="button" key={gate.id} className={`qpro-gate-choice ${selectedGate === gate.id ? "active" : ""}`} onClick={() => { setSelectedGate(gate.id); setError(null); }} title={gate.description}>
              <b>{gate.symbol}</b><span>{gate.id}</span>
            </button>)}
          </div>
          <div className="qpro-gate-detail">
            <span className="qpro-kicker">SELECTED OPERATION</span>
            <b>{definition.label}</b>
            <p>{definition.description}</p>
            <small>{definition.educationalNote}</small>
          </div>
          {definition.parameterCount > 0 && <label className="qpro-angle-field">Rotation angle θ (radians)<input type="number" step="0.1" value={angle} onChange={(event) => setAngle(event.currentTarget.value)} /></label>}
          <div className="qpro-wire-picker">
            <div className="qpro-wire-picker-heading"><b>Select wires</b><small>{selectedQubits.length}/{expectedSelection} selected</small></div>
            <div className="qpro-wire-options">
              {Array.from({ length: circuit.qubits }, (_, qubit) => <button type="button" key={qubit} aria-pressed={selectedQubits.includes(qubit)} className={selectedQubits.includes(qubit) ? "selected" : ""} onClick={() => toggleQubit(qubit)}>q{qubit}</button>)}
            </div>
            {definition.controlCount > 0 && <p className="qpro-wire-help">Selection order: first {definition.controlCount} control(s), then {definition.targetCount} target(s).</p>}
          </div>
          <button type="button" className="qpro-button qpro-button-primary qpro-add-gate" onClick={addSelectedGate}>Add {definition.id} to circuit <span>＋</span></button>
          <div className="qpro-palette-divider" />
          <button type="button" className="qpro-button qpro-button-light" onClick={addMeasurements}>Add measurements <span>◉</span></button>
        </aside>

        <section className="qpro-main-column">
          <div className="qpro-panel qpro-circuit-panel">
            <PanelTitle eyebrow="02 / CIRCUIT CANVAS" title={circuit.name} action={<span className="qpro-circuit-count">{metrics.qubits} wires · {metrics.unitaryGates} gates</span>} />
            {circuit.instructions.length === 0 ? <div className="qpro-canvas-empty"><div className="qpro-empty-symbol">H</div><b>Your circuit starts here.</b><p>Add a gate from the palette or load a circuit from the library below.</p></div> : <CircuitCanvas circuit={circuit} selectedId={selectedInstruction?.id ?? null} onSelect={setSelectedInstruction} />}
            <div className="qpro-circuit-toolbar">
              <div><button type="button" className="qpro-mini-action" disabled={!circuit.instructions.length} onClick={() => { const last = circuit.instructions[circuit.instructions.length - 1]; updateCircuit(removeInstruction(circuit, last.id), "Last instruction undone."); }}>↶ Undo last</button><button type="button" className="qpro-mini-action" onClick={applyOptimization}>✧ Optimize</button></div>
              <div><button type="button" className="qpro-mini-action" onClick={applyRouting}>⌁ Route for line hardware</button><button type="button" className="qpro-mini-action" onClick={compileCliffordT}>⇢ Clifford+T</button></div>
            </div>
            {selectedInstruction && <div className="qpro-inspector-inline">
              <div className="qpro-inspector-head"><div><span className="qpro-kicker">SELECTED INSTRUCTION</span><b>{selectedInstruction.type === "gate" ? selectedInstruction.gate : selectedInstruction.type.toUpperCase()}</b></div><button type="button" className="qpro-danger-link" onClick={deleteSelected}>Remove instruction ×</button></div>
              {selectedGateInstruction && <GateParameterEditor instruction={selectedGateInstruction} onChange={editParameter} />}
            </div>}
          </div>

          <div className="qpro-panel qpro-library-panel">
            <PanelTitle eyebrow="03 / ALGORITHM LIBRARY" title="Start from a known result" />
            <AlgorithmGallery onSelect={loadPreset} />
          </div>
        </section>
      </div>

      <div className="qpro-run-panel qpro-panel">
        <div className="qpro-run-copy"><span className="qpro-kicker">04 / SIMULATION CONTROL</span><h2>Run the experiment</h2><p>Choose the number of shots. Use a fixed seed to make sampling reproducible.</p></div>
        <div className="qpro-run-controls">
          <label>Shots<select value={shots} onChange={(event) => setShots(Number(event.currentTarget.value))}><option value={128}>128</option><option value={512}>512</option><option value={1024}>1,024</option><option value={4096}>4,096</option><option value={8192}>8,192</option><option value={16384}>16,384</option></select></label>
          <label>Seed<input value={seed} onChange={(event) => setSeed(event.currentTarget.value)} placeholder="Random" /></label>
          <button type="button" className="qpro-button qpro-button-primary qpro-run-button" disabled={Boolean(busyAction)} onClick={runCircuit}>{busyAction === "run" ? "Running…" : "▶ Run circuit"}</button>
        </div>
      </div>

      {(error || notice) && <div className={`qpro-notice ${error ? "error" : ""}`} role={error ? "alert" : "status"}>{error ? <><b>Attention:</b> {error}</> : notice}<button type="button" aria-label="Dismiss notice" onClick={() => { setError(null); setNotice(""); }}>×</button></div>}

      <section className="qpro-output-section">
        <div className="qpro-output-heading"><div><span className="qpro-kicker">05 / SCIENTIFIC READOUT</span><h2>What did the circuit do?</h2></div><div className="qpro-output-tabs" role="tablist" aria-label="Output panels">
          {([{ id: "results", label: "Results" }, { id: "diagnostics", label: "Diagnostics" }, { id: "noise", label: "Noise lab" }, { id: "observables", label: "Pauli observables" }, { id: "sweep", label: "Parameter sweep" }, { id: "compare", label: "Compare" }, { id: "reference", label: "Gate reference" }, { id: "export", label: "Export code" }] as Array<{ id: OutputTab; label: string }>).map((item) => <button type="button" role="tab" aria-selected={tab === item.id} key={item.id} className={tab === item.id ? "active" : ""} onClick={() => setTab(item.id)}>{item.label}</button>)}
        </div></div>
        {tab === "results" && <div className="qpro-output-grid">
          <div className="qpro-panel qpro-output-panel"><PanelTitle eyebrow="MEASUREMENT" title="Outcome distribution" action={summary ? <span className="qpro-run-time">{summary.elapsedMs.toFixed(1)} ms</span> : undefined} /><ProbabilityHistogram probabilities={resultProbabilities} counts={summary?.counts} />{summary && <div className="qpro-result-meta"><span>{summary.shots.toLocaleString()} shots</span><span>{summary.gateCount} gates</span><span>Depth {summary.depth}</span></div>}</div>
          <div className="qpro-panel qpro-output-panel"><PanelTitle eyebrow="STATE VECTOR" title="Largest amplitudes" /><StateTerms circuit={circuit} /></div>
          <div className="qpro-panel qpro-output-panel"><PanelTitle eyebrow="GEOMETRY" title="Bloch-sphere views" /><div className="qpro-bloch-list">{visibleBloch.length ? visibleBloch.map(({ qubit, vector }) => <BlochSphere key={qubit} title={`q${qubit}`} x={vector.x} y={vector.y} z={vector.z} compact />) : <div className="qpro-empty-state">Bloch vectors are shown for pure unitary circuits. Run shots for dynamic circuits.</div>}</div>{entanglement && <div className="qpro-entanglement-summary"><span>QUBIT CORRELATION</span><b>{entanglement.interpretation}</b>{entanglement.concurrence !== undefined && <small>Concurrence {entanglement.concurrence.toFixed(3)} · tangle {(entanglement.tangle ?? 0).toFixed(3)}</small>}</div>}</div>
        </div>}
        {tab === "diagnostics" && <div className="qpro-panel qpro-diagnostics-panel"><CircuitDiagnostics circuit={circuit} /></div>}
        {tab === "noise" && <NoiseExperimentPanel circuit={circuit} />}
        {tab === "observables" && <PauliObservablePanel circuit={circuit} />}
        {tab === "sweep" && <ParameterSweepLab circuit={circuit} />}
        {tab === "compare" && <CircuitComparisonPanel circuit={circuit} />}
        {tab === "reference" && <div className="qpro-panel qpro-gate-reference-panel"><GateReference onSelect={(gate) => { setSelectedGate(gate); setCategory("all"); setNotice(`${gate} selected in the gate palette.`); }} /></div>}
        {tab === "export" && <div className="qpro-panel qpro-export-panel"><div className="qpro-export-controls"><div><span className="qpro-kicker">PORTABLE CIRCUIT SOURCE</span><h3>Take your circuit with you</h3><p>OpenQASM 3 is a hardware-neutral representation. The Python export targets Qiskit's circuit API.</p></div><div className="qpro-export-actions"><select aria-label="Export format" value={exportFormat} onChange={(event) => setExportFormat(event.currentTarget.value as "qasm" | "python")}><option value="qasm">OpenQASM 3</option><option value="python">Qiskit Python</option></select><button type="button" className="qpro-button qpro-button-light" onClick={copyExport}>Copy code ↗</button></div></div><textarea className="qpro-code-output" value={exportText} readOnly spellCheck={false} aria-label="Generated circuit code" /></div>}
      </section>

      <footer className="qpro-science-note"><span>THE SCIENCE NOTE</span><p>This browser-based state-vector engine is a classical simulation of quantum circuit mathematics. It does not connect to a quantum processor. State-vector memory grows exponentially with qubit count; dense noisy simulations have stricter limits. Braids in the project story are a visual metaphor unless a lesson explicitly discusses mathematical braids and topological quantum computing.</p></footer>
    </section>
  );
}

export default CircuitStudioPro;
