// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
export interface ProbabilityHistogramProps {
  probabilities: Record<string, number>;
  title?: string;
  maxItems?: number;
  counts?: Record<string, number>;
}

function formatPercent(value: number): string {
  return `${(value * 100).toFixed(value >= 0.1 ? 1 : 2)}%`;
}

export function ProbabilityHistogram({ probabilities, title = "Measurement distribution", maxItems = 16, counts }: ProbabilityHistogramProps) {
  const entries = Object.entries(probabilities)
    .sort(([a], [b]) => a.localeCompare(b))
    .slice(0, maxItems);
  const maxProbability = Math.max(0.01, ...entries.map(([, value]) => value));
  const total = Object.values(counts ?? {}).reduce((sum, value) => sum + value, 0);

  return (
    <section className="qpro-histogram" aria-label={title}>
      <div className="qpro-panel-heading">
        <div>
          <span className="qpro-kicker">OUTCOME PROBABILITIES</span>
          <h3>{title}</h3>
        </div>
        {total > 0 && <span className="qpro-small-note">{total.toLocaleString()} shots</span>}
      </div>
      {entries.length === 0 ? (
        <div className="qpro-empty-state">Run the circuit to see its measurement distribution.</div>
      ) : (
        <div className="qpro-bars">
          {entries.map(([label, probability]) => {
            const count = counts?.[label];
            const width = Math.max(0, Math.min(100, (probability / maxProbability) * 100));
            return (
              <div className="qpro-bar-row" key={label}>
                <code className="qpro-bar-label">|{label}⟩</code>
                <div className="qpro-bar-track" role="meter" aria-label={`Probability of ${label}`} aria-valuemin={0} aria-valuemax={100} aria-valuenow={probability * 100}>
                  <span className="qpro-bar-fill" style={{ width: `${width}%` }} />
                </div>
                <span className="qpro-bar-value">{formatPercent(probability)}</span>
                {count !== undefined && <small className="qpro-bar-count">{count}</small>}
              </div>
            );
          })}
        </div>
      )}
      <p className="qpro-chart-footnote">Probabilities are normalized across the displayed outcomes. Sampling results fluctuate from run to run.</p>
    </section>
  );
}

export default ProbabilityHistogram;
