// @ts-nocheck
import React, { FormEvent, KeyboardEvent, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { answerQuantumQuestion, QUANTUM_MENTOR_SYSTEM_PROMPT, type MentorReply } from "../../voice/quantumKnowledge";

type Role = "assistant" | "user";
interface ChatMessage {
  id: string;
  role: Role;
  text: string;
  detail?: MentorReply;
  timestamp: number;
}
interface VoiceOption { name: string; lang: string; voice: SpeechSynthesisVoice; preferred: boolean; }
interface RecognitionAlternative { transcript: string; }
interface RecognitionResult { 0: RecognitionAlternative; isFinal: boolean; }
interface RecognitionEvent { resultIndex: number; results: ArrayLike<RecognitionResult>; }
interface RecognitionErrorEvent { error: string; }
interface SpeechRecognitionLike {
  lang: string; interimResults: boolean; continuous: boolean;
  onresult: ((event: RecognitionEvent) => void) | null;
  onerror: ((event: RecognitionErrorEvent) => void) | null;
  onend: (() => void) | null;
  start(): void; stop(): void; abort(): void;
}
type SpeechRecognitionConstructor = new () => SpeechRecognitionLike;
type ExtendedWindow = Window & { SpeechRecognition?: SpeechRecognitionConstructor; webkitSpeechRecognition?: SpeechRecognitionConstructor; };

const quickPrompts = ["What is a qubit?", "Explain entanglement", "How does a Hadamard gate work?", "Why is quantum measurement probabilistic?"];
const feminineVoiceHints = /female|woman|samantha|victoria|ava|allison|karen|moira|tessa|zira|susan|aria|jenny|sara|serena|fiona|veena|joana|luciana|amelie|sophie|kate/i;
const makeId = () => `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
const textFromReply = (reply: MentorReply) => [reply.paragraphs.join("\n\n"), reply.experiment ? `Try this: ${reply.experiment}` : "", reply.misconception ? `A common mix-up: ${reply.misconception}` : ""].filter(Boolean).join("\n\n");

function getAssistantEndpoint(): string | undefined {
  return import.meta.env.VITE_QUANTUM_MENTOR_ENDPOINT?.trim() || undefined;
}

async function askConfiguredAssistant(history: ChatMessage[], signal: AbortSignal): Promise<string | null> {
  const endpoint = getAssistantEndpoint();
  if (!endpoint) return null;
  const messages = history.slice(-10).map((message) => ({ role: message.role === "assistant" ? "assistant" : "user", content: message.text }));
  const response = await fetch(endpoint, {
    method: "POST", signal, headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ system: QUANTUM_MENTOR_SYSTEM_PROMPT, messages })
  });
  if (!response.ok) throw new Error(`Mentor endpoint returned ${response.status}`);
  const data = await response.json() as { reply?: string; message?: string; output?: string };
  const text = data.reply ?? data.message ?? data.output;
  return typeof text === "string" && text.trim() ? text.trim() : null;
}

function AssistantAvatar() {
  return <div className="qm-avatar" aria-hidden="true"><span>Q</span><i>✦</i></div>;
}

export function QuantumMentor() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>(() => [{
    id: "welcome", role: "assistant", text: "Bonjour! I'm Mademoiselle Q, your quantum-learning companion. Ask me about qubits, superposition, entanglement, circuits, or the mysteries of quantum computing. We can take it one idea at a time.", timestamp: Date.now()
  }]);
  const [draft, setDraft] = useState("");
  const [busy, setBusy] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(false);
  const [autoSpeak, setAutoSpeak] = useState(false);
  const [voiceSettingsOpen, setVoiceSettingsOpen] = useState(false);
  const [voices, setVoices] = useState<VoiceOption[]>([]);
  const [selectedVoice, setSelectedVoice] = useState("");
  const [pitch, setPitch] = useState(1.12);
  const [rate, setRate] = useState(0.96);
  const [speakingId, setSpeakingId] = useState<string | null>(null);
  const [listening, setListening] = useState(false);
  const [voiceNotice, setVoiceNotice] = useState("");
  const [endpointNotice, setEndpointNotice] = useState("");
  const listRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const recognitionRef = useRef<SpeechRecognitionLike | null>(null);
  const abortRef = useRef<AbortController | null>(null);
  const messagesRef = useRef(messages);
  const speechSupported = typeof window !== "undefined" && "speechSynthesis" in window;
  const recognitionConstructor = typeof window !== "undefined" ? ((window as ExtendedWindow).SpeechRecognition || (window as ExtendedWindow).webkitSpeechRecognition) : undefined;
  const dictationSupported = Boolean(recognitionConstructor);

  useEffect(() => { messagesRef.current = messages; }, [messages]);
  useEffect(() => {
    if (!speechSupported) return;
    const synth = window.speechSynthesis;
    const refresh = () => {
      const list = synth.getVoices().map((voice) => ({
        name: voice.name, lang: voice.lang, voice,
        preferred: feminineVoiceHints.test(voice.name)
      })).sort((a, b) => Number(b.preferred) - Number(a.preferred) || a.name.localeCompare(b.name));
      setVoices(list);
      setSelectedVoice((current) => current || list.find((item) => item.preferred)?.name || list[0]?.name || "");
    };
    refresh();
    synth.addEventListener("voiceschanged", refresh);
    return () => { synth.removeEventListener("voiceschanged", refresh); synth.cancel(); };
  }, [speechSupported]);

  useEffect(() => {
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, busy]);

  useEffect(() => {
    if (open) inputRef.current?.focus();
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const onEscape = (event: globalThis.KeyboardEvent) => {
      if (event.key === "Escape") {
        stopSpeaking();
        setOpen(false);
      }
    };
    window.addEventListener("keydown", onEscape);
    return () => window.removeEventListener("keydown", onEscape);
  }, [open]);

  useEffect(() => () => {
    abortRef.current?.abort();
    recognitionRef.current?.abort();
    if ("speechSynthesis" in window) window.speechSynthesis.cancel();
  }, []);

  const activeVoice = useMemo(() => voices.find((item) => item.name === selectedVoice)?.voice, [voices, selectedVoice]);

  const speak = useCallback((text: string, id?: string) => {
    if (!speechSupported) { setVoiceNotice("Speech playback is not available in this browser. You can still read the answers here."); return; }
    const synth = window.speechSynthesis;
    synth.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    if (activeVoice) utterance.voice = activeVoice;
    utterance.pitch = pitch;
    utterance.rate = rate;
    utterance.volume = 1;
    utterance.onstart = () => setSpeakingId(id ?? "current");
    utterance.onend = () => setSpeakingId(null);
    utterance.onerror = () => { setSpeakingId(null); setVoiceNotice("Your browser could not play this voice. Choose another available voice in Voice settings."); };
    synth.speak(utterance);
  }, [activeVoice, pitch, rate, speechSupported]);

  const stopSpeaking = () => {
    if (speechSupported) window.speechSynthesis.cancel();
    setSpeakingId(null);
  };

  const submitQuestion = useCallback(async (raw: string) => {
    const question = raw.trim();
    if (!question || busy) return;
    const userMessage: ChatMessage = { id: makeId(), role: "user", text: question, timestamp: Date.now() };
    const nextHistory = [...messagesRef.current, userMessage];
    setMessages(nextHistory);
    setDraft("");
    setBusy(true);
    setEndpointNotice("");
    abortRef.current?.abort();
    const controller = new AbortController();
    abortRef.current = controller;
    try {
      let replyText: string | null = null;
      try {
        replyText = await askConfiguredAssistant(nextHistory, controller.signal);
      } catch (error) {
        if (controller.signal.aborted) return;
        setEndpointNotice("Live AI connection unavailable; answering with the built-in quantum guide.");
      }
      if (controller.signal.aborted) return;
      const detail = replyText ? undefined : answerQuantumQuestion(question);
      const answer = replyText ?? textFromReply(detail!);
      const assistantMessage: ChatMessage = { id: makeId(), role: "assistant", text: answer, detail, timestamp: Date.now() };
      setMessages((current) => [...current, assistantMessage]);
      if (autoSpeak && voiceEnabled) speak(answer, assistantMessage.id);
    } finally {
      if (!controller.signal.aborted) setBusy(false);
    }
  }, [autoSpeak, busy, speak, voiceEnabled]);

  const handleSubmit = (event: FormEvent) => { event.preventDefault(); void submitQuestion(draft); };
  const handleKeyDown = (event: KeyboardEvent<HTMLTextAreaElement>) => {
    if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); void submitQuestion(draft); }
  };

  const startDictation = () => {
    if (!recognitionConstructor) { setVoiceNotice("Voice input is not supported in this browser. Type your question instead."); return; }
    if (listening) { recognitionRef.current?.stop(); return; }
    try {
      const recognition = new recognitionConstructor();
      recognition.lang = "en-US";
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.onresult = (event) => {
        const transcript = Array.from({ length: event.results.length }, (_, index) => event.results[index]?.[0]?.transcript ?? "").join(" ").trim();
        if (transcript) setDraft((current) => current ? `${current} ${transcript}` : transcript);
      };
      recognition.onerror = (event) => {
        setVoiceNotice(event.error === "not-allowed" ? "Microphone permission was denied. You can still type your question." : `Voice input stopped (${event.error}). You can type instead.`);
        setListening(false);
      };
      recognition.onend = () => setListening(false);
      recognitionRef.current = recognition;
      setVoiceNotice("Listening once. Your browser may process speech according to its own privacy settings.");
      setListening(true);
      recognition.start();
    } catch {
      setListening(false);
      setVoiceNotice("Could not start the microphone. Check browser permission or type your question.");
    }
  };

  const clearConversation = () => {
    stopSpeaking();
    setMessages([{ id: makeId(), role: "assistant", text: "Conversation cleared. What quantum idea shall we explore next?", timestamp: Date.now() }]);
    setEndpointNotice("");
  };

  const formatTime = (time: number) => new Intl.DateTimeFormat(undefined, { hour: "numeric", minute: "2-digit" }).format(time);

  return <>
    <button className={`qm-launcher ${open ? "is-open" : ""}`} onClick={() => setOpen((value) => !value)} aria-label={open ? "Close Mademoiselle Q quantum mentor" : "Open Mademoiselle Q quantum mentor"} aria-expanded={open}>
      <span className="qm-launcher-spark">✦</span><span className="qm-launcher-face">Q</span><span className="qm-launcher-label">Ask Mademoiselle Q</span>
    </button>
    {open && <section className="qm-window" role="dialog" aria-modal="false" aria-label="Mademoiselle Q quantum mentor">
      <header className="qm-header">
        <AssistantAvatar />
        <div className="qm-header-copy"><strong>Mademoiselle Q</strong><span>Your quantum-learning companion</span></div>
        <span className="qm-online-dot" title="Ready" />
        <button className="qm-icon-button" onClick={clearConversation} title="Clear conversation" aria-label="Clear conversation">↺</button>
        <button className="qm-icon-button" onClick={() => setOpen(false)} title="Close" aria-label="Close chat">×</button>
      </header>
      <div className="qm-toolbar">
        <span><i /> QUANTUM GUIDE · AI-READY</span>
        <button onClick={() => setVoiceSettingsOpen((value) => !value)} aria-expanded={voiceSettingsOpen}>♫ Voice settings</button>
      </div>
      {voiceSettingsOpen && <div className="qm-voice-settings">
        <div className="qm-setting-row"><label htmlFor="qm-voice-select">Speaking voice</label><select id="qm-voice-select" value={selectedVoice} onChange={(event) => setSelectedVoice(event.target.value)} disabled={!voices.length}><option value="">System default</option>{voices.map((voice) => <option key={`${voice.name}-${voice.lang}`} value={voice.name}>{voice.preferred ? "☆ " : ""}{voice.name} · {voice.lang}</option>)}</select></div>
        <div className="qm-setting-row"><label htmlFor="qm-pitch">Voice pitch <output>{pitch.toFixed(2)}</output></label><input id="qm-pitch" type="range" min="0.8" max="1.35" step="0.05" value={pitch} onChange={(event) => setPitch(Number(event.target.value))} /></div>
        <div className="qm-setting-row"><label htmlFor="qm-rate">Speaking pace <output>{rate.toFixed(2)}×</output></label><input id="qm-rate" type="range" min="0.75" max="1.2" step="0.05" value={rate} onChange={(event) => setRate(Number(event.target.value))} /></div>
        <div className="qm-voice-actions"><button onClick={() => { setVoiceEnabled(true); speak("Bonjour! I am Mademoiselle Q. Let's explore the quantum universe together."); }}>▶ Preview voice</button><button onClick={stopSpeaking}>■ Stop</button></div>
        <p className="qm-fine-print">Available voices depend on your device and browser. Starred voices have names commonly associated with feminine-sounding voices, but voice gender cannot be reliably identified or guaranteed. You can choose any voice.</p>
      </div>}
      <div className="qm-messages" ref={listRef} aria-live="polite" aria-relevant="additions text">
        {messages.map((message) => <article key={message.id} className={`qm-message ${message.role}`}>
          {message.role === "assistant" && <AssistantAvatar />}
          <div className="qm-bubble-wrap"><div className="qm-bubble">
            {message.text.split(/\n\n+/).map((paragraph, index) => <p key={index}>{paragraph}</p>)}
            {message.detail?.formula && <div className="qm-formula"><span>IN THE NOTEBOOK</span><code>{message.detail.formula}</code></div>}
            {message.detail?.followUps?.length ? <div className="qm-followups">{message.detail.followUps.slice(0, 3).map((prompt) => <button key={prompt} onClick={() => void submitQuestion(prompt)}>{prompt} <span>↗</span></button>)}</div> : null}
          </div><div className="qm-message-meta"><time>{formatTime(message.timestamp)}</time>{message.role === "assistant" && <button onClick={() => { setVoiceEnabled(true); speak(message.text, message.id); }} aria-label="Read this answer aloud">{speakingId === message.id ? "♫ Speaking" : "♫ Listen"}</button>}</div></div>
        </article>)}
        {busy && <div className="qm-typing"><AssistantAvatar /><span><i /><i /><i /></span><small>Mademoiselle Q is thinking…</small></div>}
      </div>
      {endpointNotice && <div className="qm-notice" role="status">{endpointNotice}</div>}
      {voiceNotice && <div className="qm-notice" role="status"><span>{voiceNotice}</span><button onClick={() => setVoiceNotice("")} aria-label="Dismiss notice">×</button></div>}
      <div className="qm-quick-prompts" aria-label="Suggested questions">{quickPrompts.slice(0, 3).map((prompt) => <button key={prompt} onClick={() => void submitQuestion(prompt)}>{prompt}</button>)}</div>
      <form className="qm-composer" onSubmit={handleSubmit}>
        <textarea ref={inputRef} value={draft} onChange={(event) => setDraft(event.target.value)} onKeyDown={handleKeyDown} placeholder="Ask about qubits, entanglement…" rows={2} aria-label="Your quantum question" disabled={busy} />
        <div className="qm-composer-actions"><div><button type="button" className={`qm-mic-button ${listening ? "active" : ""}`} onClick={startDictation} disabled={!dictationSupported} title={dictationSupported ? "Dictate a question" : "Voice input unavailable in this browser"} aria-label="Dictate a question">{listening ? "◼" : "🎙"}</button><button type="button" className={`qm-sound-toggle ${voiceEnabled ? "enabled" : ""}`} onClick={() => { setVoiceEnabled((value) => !value); if (voiceEnabled) stopSpeaking(); }} aria-pressed={voiceEnabled} title="Toggle voice replies">♫ {voiceEnabled ? "Voice on" : "Voice off"}</button><label className="qm-auto-speak"><input type="checkbox" checked={autoSpeak} onChange={(event) => { setAutoSpeak(event.target.checked); if (event.target.checked) setVoiceEnabled(true); }} /> Auto-read</label></div><button type="submit" className="qm-send" disabled={busy || !draft.trim()}>Ask <span>↗</span></button></div>
      </form>
      <footer className="qm-footer">Built-in quantum guide · Optional secure AI connection · No account needed</footer>
    </section>}
  </>;
}
