// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { useMemo, useState } from "react";
import type { QuantumCircuit } from "../quantum-engine/circuit";
import { updateGateParameter } from "../quantum-engine/circuit";
import { simulateState } from "../quantum-engine/simulator";
import { parameterizedInstructionIds } from "../quantum-engine/circuit-analysis";
import { pauliExpectation, pauliWordFromLabel } from "../quantum-engine/pauli";

export interface SweepPoint {
  parameter: number;
  expectation: number;
}

export interface ParameterSweepLabProps {
  circuit: QuantumCircuit;
}

export function ParameterSweepLab({ circuit }: ParameterSweepLabProps) {
  const parameterIds = useMemo(() => parameterizedInstructionIds(circuit), [circuit]);
  const [instructionId, setInstructionId] = useState("");
  const [minimum, setMinimum] = useState(-Math.PI);
  const [maximum, setMaximum] = useState(Math.PI);
  const [steps, setSteps] = useState(31);
  const [observable, setObservable] = useState("Z".repeat(circuit.qubits));
  const [points, setPoints] = useState<SweepPoint[]>([]);
  const [error, setError] = useState<string | null>(null);

  const selectedId = instructionId || parameterIds[0] || "";
  const sourceInstruction = circuit.instructions.find((instruction) => instruction.id === selectedId);
  const initialAngle = sourceInstruction?.type === "gate" ? sourceInstruction.params?.theta ?? 0 : 0;
  const yMin = points.length ? Math.min(-1, ...points.map((point) => point.expectation)) : -1;
  const yMax = points.length ? Math.max(1, ...points.map((point) => point.expectation)) : 1;
  const chartPoints = points.map((point, index) => ({
    x: 40 + (index / Math.max(1, points.length - 1)) * 420,
    y: 150 - ((point.expectation - yMin) / (yMax - yMin || 1)) * 120,
  }));

  function runSweep(): void {
    setError(null);
    try {
      if (!selectedId) throw new Error("Select a parameterized gate in the circuit first.");
      if (!Number.isFinite(minimum) || !Number.isFinite(maximum) || minimum >= maximum) throw new Error("Minimum angle must be finite and less than maximum angle.");
      if (!Number.isInteger(steps) || steps < 2 || steps > 201) throw new Error("Choose between 2 and 201 sweep points.");
      const word = pauliWordFromLabel(observable.trim());
      if (word.length !== circuit.qubits) throw new Error(`Observable must contain exactly ${circuit.qubits} Pauli symbols.`);
      const generated: SweepPoint[] = [];
      for (let index = 0; index < steps; index += 1) {
        const parameter = minimum + (maximum - minimum) * index / (steps - 1);
        const updated = updateGateParameter(circuit, selectedId, "theta", parameter);
        const state = simulateState(updated);
        generated.push({ parameter, expectation: pauliExpectation(state, word) });
      }
      setPoints(generated);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Parameter sweep failed.");
      setPoints([]);
    }
  }

  return <section className="qpro-sweep-lab">
    <div className="qpro-sweep-heading"><span className="qpro-kicker">VARIATIONAL CIRCUITS & PARAMETER LANDSCAPES</span><h3>Explore how an angle changes the result</h3><p>Choose a parameterized gate and sweep its θ value. The chart shows the expectation value of a Pauli observable for each circuit evaluation.</p></div>
    <div className="qpro-sweep-controls">
      <label>Gate parameter<select value={selectedId} onChange={(event) => setInstructionId(event.currentTarget.value)}>{parameterIds.map((id) => <option value={id} key={id}>{id === selectedId && sourceInstruction?.type === "gate" ? `${sourceInstruction.gate} · ${id}` : id}</option>)}</select></label>
      <label>Observable<input value={observable} onChange={(event) => setObservable(event.currentTarget.value.toUpperCase().replace(/[^IXYZ]/g, ""))} /></label>
      <label>Minimum θ<input type="number" value={minimum} step="0.1" onChange={(event) => setMinimum(Number(event.currentTarget.value))} /></label>
      <label>Maximum θ<input type="number" value={maximum} step="0.1" onChange={(event) => setMaximum(Number(event.currentTarget.value))} /></label>
      <label>Points<select value={steps} onChange={(event) => setSteps(Number(event.currentTarget.value))}><option value={11}>11</option><option value={21}>21</option><option value={31}>31</option><option value={51}>51</option><option value={101}>101</option></select></label>
      <button type="button" onClick={runSweep} disabled={!parameterIds.length}>Calculate sweep</button>
    </div>
    {error && <p className="qpro-sweep-error" role="alert">{error}</p>}
    <div className="qpro-sweep-chart">
      {points.length ? <svg viewBox="0 0 500 190" role="img" aria-label="Parameter sweep expectation-value plot">
        <line x1="40" x2="460" y1="150" y2="150" stroke="#e4d8eb" />
        <line x1="40" x2="460" y1="90" y2="90" stroke="#eee5f1" strokeDasharray="4 4" />
        <line x1="40" x2="460" y1="30" y2="30" stroke="#e4d8eb" />
        <polyline points={chartPoints.map((point) => `${point.x},${point.y}`).join(" ")} fill="none" stroke="#a17ebc" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
        {chartPoints.map((point, index) => <circle key={index} cx={point.x} cy={point.y} r="3.5" fill="#c981a8"><title>{`θ=${points[index].parameter.toFixed(3)}, expectation=${points[index].expectation.toFixed(4)}`}</title></circle>)}
        <text x="10" y="34" fill="#9c8ba4" fontSize="10">+1</text><text x="15" y="94" fill="#9c8ba4" fontSize="10">0</text><text x="10" y="154" fill="#9c8ba4" fontSize="10">−1</text>
        <text x="40" y="177" fill="#9c8ba4" fontSize="10">{minimum.toFixed(2)}</text><text x="460" y="177" fill="#9c8ba4" fontSize="10" textAnchor="end">{maximum.toFixed(2)}</text>
      </svg> : <div className="qpro-empty-state">Run a parameter sweep to reveal the expectation-value landscape.</div>}
    </div>
    {points.length > 0 && <div className="qpro-sweep-summary"><span>{points.length} evaluations</span><span>Range {Math.min(...points.map((item) => item.expectation)).toFixed(3)} to {Math.max(...points.map((item) => item.expectation)).toFixed(3)}</span><span>Current gate angle {initialAngle.toFixed(3)} rad</span></div>}
  </section>;
}

export default ParameterSweepLab;
