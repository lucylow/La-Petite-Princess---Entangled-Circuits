// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import type { QuantumCircuit } from "../quantum-engine/circuit";
import { validateCircuit } from "../quantum-engine/circuit";
import { calculateCircuitMetrics, countGateFamilies, gateFrequency, gateInteractionGraph } from "../quantum-engine/circuit-analysis";
import { suggestOptimizations } from "../quantum-engine/optimizer";

export interface CircuitDiagnosticsProps {
  circuit: QuantumCircuit;
}

export function CircuitDiagnostics({ circuit }: CircuitDiagnosticsProps) {
  const issues = validateCircuit(circuit);
  const errors = issues.filter((issue) => issue.severity === "error");
  const metrics = calculateCircuitMetrics(circuit);
  const families = countGateFamilies(circuit);
  const frequency = gateFrequency(circuit);
  const interactions = gateInteractionGraph(circuit);
  const suggestions = suggestOptimizations(circuit);

  return (
    <div className="qpro-diagnostics">
      <div className="qpro-diagnostic-status">
        <span className={`qpro-status-dot ${errors.length ? "danger" : "good"}`} />
        <div>
          <b>{errors.length ? "Circuit needs attention" : "Circuit structure looks valid"}</b>
          <small>{errors.length} error(s) · {issues.filter((issue) => issue.severity === "warning").length} warning(s) · {issues.filter((issue) => issue.severity === "info").length} note(s)</small>
        </div>
      </div>
      <div className="qpro-metric-grid">
        <div><span>Gates</span><b>{metrics.unitaryGates}</b></div>
        <div><span>Depth</span><b>{metrics.estimatedDepth}</b></div>
        <div><span>Entanglers</span><b>{metrics.controlledGates + metrics.multiQubitGates}</b></div>
        <div><span>Qubit use</span><b>{Math.round(metrics.qubitUtilization * 100)}%</b></div>
      </div>
      {issues.length > 0 && <section className="qpro-diagnostic-list">
        <h4>Validation findings</h4>
        {issues.map((issue, index) => <div className={`qpro-issue ${issue.severity}`} key={`${issue.code}-${issue.instructionId ?? index}`}>
          <span>{issue.severity === "error" ? "×" : issue.severity === "warning" ? "!" : "i"}</span>
          <div><b>{issue.code.replaceAll("_", " ")}</b><p>{issue.message}</p></div>
        </div>)}
      </section>}
      <section className="qpro-diagnostic-list">
        <h4>Gate inventory</h4>
        <div className="qpro-chip-cloud">
          {Object.entries(frequency).length === 0 ? <small>No unitary gates yet.</small> : Object.entries(frequency).sort((a, b) => b[1] - a[1]).map(([name, count]) => <span key={name}>{name} <b>{count}</b></span>)}
        </div>
        <div className="qpro-family-line">{Object.entries(families).map(([name, count]) => `${name}: ${count}`).join(" · ") || "No gate families"}</div>
      </section>
      <section className="qpro-diagnostic-list">
        <h4>Most-used qubit interactions</h4>
        {interactions.length === 0 ? <small>No multi-qubit interactions detected.</small> : interactions.slice(0, 6).map((edge) => <div className="qpro-interaction" key={`${edge.source}-${edge.target}`}><span>q{edge.source} ↔ q{edge.target}</span><div><i style={{ width: `${Math.max(4, edge.weight / interactions[0].weight * 100)}%` }} /></div><b>{edge.weight}</b></div>)}
      </section>
      <section className="qpro-diagnostic-list">
        <h4>Optimization suggestions</h4>
        {suggestions.length === 0 ? <small>No obvious local optimizations found.</small> : <ul>{suggestions.map((suggestion) => <li key={suggestion}>{suggestion}</li>)}</ul>}
      </section>
    </div>
  );
}

export default CircuitDiagnostics;
