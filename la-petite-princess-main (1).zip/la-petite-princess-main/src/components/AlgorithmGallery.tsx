// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import type { QuantumCircuit } from "../quantum-engine/circuit";
import {
  bellCircuit,
  ghzCircuit,
  wStateCircuit,
  qftCircuit,
  groverCircuit,
  deutschJozsaCircuit,
  bernsteinVaziraniCircuit,
  teleportationCircuit,
  phaseEstimationCircuit,
  qaoaMaxCutCircuit,
} from "../quantum-engine/algorithms";

export interface AlgorithmPreset {
  id: string;
  name: string;
  category: "Foundations" | "Algorithms" | "Research";
  description: string;
  concept: string;
  qubits: number;
  build: () => QuantumCircuit;
}

export const ALGORITHM_PRESETS: AlgorithmPreset[] = [
  { id: "bell", name: "Bell pair", category: "Foundations", description: "Create a maximally entangled two-qubit state.", concept: "Superposition + entanglement", qubits: 2, build: () => bellCircuit() },
  { id: "ghz", name: "GHZ state", category: "Foundations", description: "Spread coherent correlations across three qubits.", concept: "Multipartite entanglement", qubits: 3, build: () => ghzCircuit(3) },
  { id: "w", name: "W state", category: "Foundations", description: "Prepare a symmetric one-excitation state.", concept: "Robust multipartite entanglement", qubits: 3, build: () => wStateCircuit(3) },
  { id: "qft", name: "Quantum Fourier transform", category: "Algorithms", description: "Transform amplitudes into a phase-frequency representation.", concept: "Interference + controlled phase", qubits: 3, build: () => qftCircuit(3) },
  { id: "grover", name: "Grover search", category: "Algorithms", description: "Amplify the amplitude of one marked basis state.", concept: "Amplitude amplification", qubits: 3, build: () => groverCircuit(3, 5) },
  { id: "dj", name: "Deutsch–Jozsa", category: "Algorithms", description: "Distinguish constant and balanced oracle behavior.", concept: "Quantum query complexity", qubits: 4, build: () => deutschJozsaCircuit(3, 5) },
  { id: "bv", name: "Bernstein–Vazirani", category: "Algorithms", description: "Recover a hidden bit string with one oracle query.", concept: "Phase kickback", qubits: 5, build: () => bernsteinVaziraniCircuit("1011") },
  { id: "teleport", name: "Teleportation", category: "Foundations", description: "Transfer an unknown state using shared entanglement and classical bits.", concept: "LOCC + entanglement", qubits: 3, build: () => teleportationCircuit() },
  { id: "qpe", name: "Phase estimation", category: "Research", description: "Estimate an eigenphase using controlled powers and inverse QFT.", concept: "Eigenvalue estimation", qubits: 4, build: () => phaseEstimationCircuit(3, 0.25) },
  { id: "qaoa", name: "QAOA Max-Cut", category: "Research", description: "Explore a variational circuit for a small graph optimization problem.", concept: "Hybrid quantum-classical optimization", qubits: 4, build: () => qaoaMaxCutCircuit(4, 1) },
];

export interface AlgorithmGalleryProps {
  onSelect: (circuit: QuantumCircuit) => void;
  activeId?: string | null;
}

export function AlgorithmGallery({ onSelect, activeId }: AlgorithmGalleryProps) {
  const categories: AlgorithmPreset["category"][] = ["Foundations", "Algorithms", "Research"];
  return (
    <div className="qpro-algorithm-gallery">
      {categories.map((category) => <section className="qpro-algorithm-group" key={category}>
        <div className="qpro-panel-heading"><div><span className="qpro-kicker">CIRCUIT LIBRARY</span><h3>{category}</h3></div><span className="qpro-small-note">{ALGORITHM_PRESETS.filter((item) => item.category === category).length} presets</span></div>
        <div className="qpro-algorithm-grid">
          {ALGORITHM_PRESETS.filter((item) => item.category === category).map((preset) => <button type="button" key={preset.id} className={`qpro-algorithm-card ${activeId === preset.id ? "active" : ""}`} onClick={() => onSelect(preset.build())}>
            <span className="qpro-algo-qubits">{preset.qubits} QUBITS</span>
            <b>{preset.name}</b>
            <p>{preset.description}</p>
            <small>{preset.concept}</small>
            <span className="qpro-algo-open">Load circuit ↗</span>
          </button>)}
        </div>
      </section>)}
    </div>
  );
}

export default AlgorithmGallery;
