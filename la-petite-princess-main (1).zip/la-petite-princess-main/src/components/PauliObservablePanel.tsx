// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { useMemo, useState } from "react";
import type { QuantumCircuit } from "../quantum-engine/circuit";
import { simulateState } from "../quantum-engine/simulator";
import { groupCommutingPaulis, pauliExpectation, pauliWordFromLabel, pauliWeight } from "../quantum-engine/pauli";

export interface PauliObservablePanelProps {
  circuit: QuantumCircuit;
}

export function PauliObservablePanel({ circuit }: PauliObservablePanelProps) {
  const [label, setLabel] = useState("ZZ");
  const [showGroups, setShowGroups] = useState(false);
  const state = useMemo(() => {
    try { return simulateState(circuit); } catch { return null; }
  }, [circuit]);
  const observable = useMemo(() => {
    if (!state) return null;
    try {
      const word = pauliWordFromLabel(label);
      if (word.length !== state.qubits) throw new Error(`Enter exactly ${state.qubits} Pauli symbols.`);
      return { word, expectation: pauliExpectation(state, word), weight: pauliWeight(word) };
    } catch (error) {
      return { error: error instanceof Error ? error.message : "Invalid observable." } as const;
    }
  }, [label, state]);
  const commutingExamples = useMemo(() => {
    if (!state) return [];
    const words = ["XX", "YY", "ZZ", "XI", "IX", "ZI", "IZ"].filter((word) => word.length === state.qubits).map(pauliWordFromLabel);
    return groupCommutingPaulis(words).map((group) => group.map((word) => word.join("")));
  }, [state]);

  if (!state) return <div className="qpro-pauli-empty">Pauli observables require a gate-only circuit without mid-circuit measurement or reset.</div>;
  return <section className="qpro-pauli-lab">
    <div className="qpro-pauli-intro"><span className="qpro-kicker">OBSERVABLES & EXPECTATION VALUES</span><h3>Ask the state a question</h3><p>A Pauli string defines a measurable operator. Its expectation value lies between −1 and +1 for a normalized state.</p></div>
    <label className="qpro-pauli-input">Pauli word <input value={label} maxLength={circuit.qubits} onChange={(event) => setLabel(event.currentTarget.value.toUpperCase().replace(/[^IXYZ]/g, ""))} placeholder={"I".repeat(circuit.qubits)} /><small>Use I, X, Y or Z once per qubit, in q0-to-qN order.</small></label>
    {observable && "error" in observable && <p className="qpro-pauli-error" role="alert">{observable.error}</p>}
    {observable && !("error" in observable) && <div className="qpro-pauli-value"><span>⟨{observable.word.join("")}⟩</span><b>{observable.expectation.toFixed(6)}</b><small>Pauli weight {observable.weight}</small></div>}
    <button type="button" className="qpro-pauli-toggle" onClick={() => setShowGroups((value) => !value)}>{showGroups ? "Hide" : "Show"} example commuting groups</button>
    {showGroups && <div className="qpro-pauli-groups">{commutingExamples.map((group, index) => <div key={index}><b>Group {index + 1}</b><span>{group.join(" · ")}</span></div>)}</div>}
  </section>;
}

export default PauliObservablePanel;
