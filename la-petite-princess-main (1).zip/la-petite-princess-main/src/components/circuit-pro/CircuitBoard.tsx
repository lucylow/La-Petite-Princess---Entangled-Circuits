// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import React, { useMemo } from "react";
import type { CircuitDefinition, CircuitOperation } from "../../lib/circuit-pro/types";
import { createCircuitLayout } from "../../lib/circuit-pro/layout";

interface Props { circuit: CircuitDefinition; onRemove?: (operationId: string) => void; }
export function CircuitBoard({ circuit, onRemove }: Props) {
  const layout = useMemo(() => createCircuitLayout(circuit, { left: 78, top: 38, columnWidth: 72, rowHeight: 62, gateWidth: 38 }), [circuit]);
  const operationMap = new Map(circuit.operations.map((operation) => [operation.id, operation]));
  return (
    <div className="circuit-pro-board-wrap">
      <svg className="circuit-pro-board" viewBox={`0 0 ${layout.width} ${layout.height}`} role="img" aria-label={`${circuit.name}, ${circuit.qubitCount} qubits and ${circuit.operations.length} operations`}>
        <rect width={layout.width} height={layout.height} rx="15" className="cp-board-bg" />
        {layout.wires.map((wire) => <g key={wire.qubit}>
          <text x="20" y={wire.y + 5} className="cp-wire-label">{wire.label}</text>
          <line x1="68" y1={wire.y} x2={layout.width - 24} y2={wire.y} className="cp-wire" />
        </g>)}
        {layout.connectors.map((connector) => <line key={connector.operationId} x1={connector.x} y1={connector.y1} x2={connector.x} y2={connector.y2} className="cp-connector" />)}
        {layout.nodes.map((node) => {
          const operation = operationMap.get(node.operationId);
          if (!operation) return null;
          const targetY = (qubit: number) => layout.wires[qubit].y;
          const isSwap = operation.gate === "SWAP" || operation.gate === "ISWAP";
          const isBarrier = operation.gate === "BARRIER";
          return <g key={node.operationId} className="cp-operation" onClick={() => onRemove?.(node.operationId)} role={onRemove ? "button" : undefined} tabIndex={onRemove ? 0 : undefined} aria-label={onRemove ? `Remove ${operation.gate}` : operation.gate}>
            {isBarrier ? <line x1={node.x + 19} y1={Math.min(...operation.targets.map(targetY)) - 15} x2={node.x + 19} y2={Math.max(...operation.targets.map(targetY)) + 15} className="cp-barrier" /> : null}
            {operation.controls?.map((control) => <circle key={control} cx={node.x + 19} cy={targetY(control)} r="5" className="cp-control-dot" />)}
            {isSwap ? operation.targets.map((target) => <g key={target}><circle cx={node.x + 19} cy={targetY(target)} r="14" className="cp-swap-ring"/><path d={`M ${node.x + 12} ${targetY(target) - 7} L ${node.x + 26} ${targetY(target) + 7} M ${node.x + 26} ${targetY(target) - 7} L ${node.x + 12} ${targetY(target) + 7}`} className="cp-swap-cross"/></g>) : null}
            {!isSwap && !isBarrier && operation.targets.map((target) => <g key={target}>
              <rect x={node.x} y={targetY(target) - 17} width="38" height="34" rx="8" className={`cp-gate-box ${operation.gate === "MEASURE" ? "measurement" : ""}`} />
              <text x={node.x + 19} y={targetY(target) + 4} className="cp-gate-text">{operation.gate === "MEASURE" ? "M" : operation.gate}</text>
            </g>)}
            {onRemove ? <title>Click to remove {operation.gate}</title> : <title>{operation.gate}</title>}
          </g>;
        })}
      </svg>
      <div className="cp-board-hint">{onRemove ? "Select any gate to remove it. The circuit recalculates from |0…0⟩." : "Circuit diagram · Q1 is the least-significant qubit."}</div>
    </div>
  );
}
