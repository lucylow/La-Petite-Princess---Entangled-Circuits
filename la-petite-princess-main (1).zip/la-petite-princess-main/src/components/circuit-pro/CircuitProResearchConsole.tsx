// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import React, { useMemo, useState } from "react";
import type { CircuitDefinition } from "../../lib/circuit-pro/types";
import { simulateCircuit } from "../../lib/circuit-pro/simulator";
import { stateBlochReport } from "../../lib/circuit-pro/bloch";
import { lintCircuit, formatLintReport } from "../../lib/circuit-pro/circuitLint";
import { estimateCircuitResources, formatBytes } from "../../lib/circuit-pro/resourceEstimate";
import { routeCircuitToConnectivity, LINEAR_COUPLING, RING_COUPLING } from "../../lib/circuit-pro/connectivity";
import { reconstructPureStateTomography } from "../../lib/circuit-pro/multiQubitTomography";
import { quantumTeleportationDemo } from "../../lib/circuit-pro/advancedAlgorithms";
import { runDynamicShots } from "../../lib/circuit-pro/dynamic";
import { sweepNoiseStrength } from "../../lib/circuit-pro/noiseEnsemble";
import { circuitToOpenQasm3 } from "../../lib/circuit-pro/qasm3";
import { singleQubitProcessTomography } from "../../lib/circuit-pro/processTomography";

type ConsoleTab = "inspect" | "tomography" | "routing" | "noise" | "teleport" | "export";
const tabs: Array<{ id: ConsoleTab; label: string }> = [
  { id: "inspect", label: "Circuit health" },
  { id: "tomography", label: "Tomography" },
  { id: "routing", label: "Hardware routing" },
  { id: "noise", label: "Noise study" },
  { id: "teleport", label: "Teleportation" },
  { id: "export", label: "OpenQASM 3" },
];
function downloadText(filename: string, content: string, mime = "text/plain") {
  const url = URL.createObjectURL(new Blob([content], { type: mime }));
  const anchor = document.createElement("a"); anchor.href = url; anchor.download = filename; anchor.click(); URL.revokeObjectURL(url);
}
function PanelHeading({ kicker, title, description }: { kicker: string; title: string; description: string }) {
  return <div className="cpr-heading"><span className="section-kicker">{kicker}</span><h5>{title}</h5><p>{description}</p></div>;
}
export function CircuitProResearchConsole({ circuit }: { circuit: CircuitDefinition }) {
  const [activeTab, setActiveTab] = useState<ConsoleTab>("inspect");
  const [topology, setTopology] = useState<"linear" | "ring">("linear");
  const [noiseChannel, setNoiseChannel] = useState<"depolarizing" | "amplitudeDamping" | "phaseDamping" | "readoutFlip">("depolarizing");
  const [noiseStrength, setNoiseStrength] = useState(0.08);
  const [noiseRuns, setNoiseRuns] = useState<ReturnType<typeof sweepNoiseStrength> | null>(null);
  const [teleportCounts, setTeleportCounts] = useState<ReturnType<typeof runDynamicShots> | null>(null);
  const [exportCode, setExportCode] = useState("");
  const [notice, setNotice] = useState("Choose a research instrument to inspect your circuit.");
  const simulation = useMemo(() => {
    try { return simulateCircuit(circuit); } catch { return null; }
  }, [circuit]);
  const lint = useMemo(() => lintCircuit(circuit), [circuit]);
  const resources = useMemo(() => estimateCircuitResources(circuit), [circuit]);
  const bloch = useMemo(() => simulation ? stateBlochReport(simulation.state, circuit.qubitCount) : [], [simulation, circuit.qubitCount]);
  const tomography = useMemo(() => {
    if (!simulation || circuit.qubitCount > 3 || circuit.operations.some((operation) => operation.gate === "MEASURE")) return null;
    try { return reconstructPureStateTomography(simulation.state, circuit.qubitCount); } catch { return null; }
  }, [simulation, circuit]);
  const process = useMemo(() => {
    if (circuit.qubitCount !== 1 || circuit.operations.some((operation) => operation.gate === "MEASURE")) return null;
    try { return singleQubitProcessTomography(circuit); } catch { return null; }
  }, [circuit]);
  const runRouting = () => {
    try {
      const map = topology === "linear" ? LINEAR_COUPLING(circuit.qubitCount) : RING_COUPLING(circuit.qubitCount);
      const result = routeCircuitToConnectivity(circuit, map);
      setNotice(`Routing complete: ${result.insertedSwaps} SWAP(s) inserted. Final logical-to-physical layout: ${result.finalLayout.map((q) => q + 1).join(", ")}.`);
    } catch (error) { setNotice(error instanceof Error ? error.message : "Routing failed."); }
  };
  const runNoiseStudy = () => {
    try {
      const result = sweepNoiseStrength(circuit, noiseChannel, [0, noiseStrength / 2, noiseStrength, Math.min(1, noiseStrength * 1.5)], 500, 19);
      setNoiseRuns(result); setNotice(`Noise sweep completed: ${result.points.length} strength values, 500 shots per point.`);
    } catch (error) { setNotice(error instanceof Error ? error.message : "Noise study failed."); }
  };
  const runTeleportation = () => {
    const demo = quantumTeleportationDemo({ theta: Math.PI * 0.37, phi: Math.PI / 5, lambda: -Math.PI / 7 });
    setTeleportCounts(runDynamicShots(demo.circuit, 512, 2718));
    setNotice("512 teleportation shots completed. The two classical bits select the Pauli correction branch.");
  };
  const createQasm = () => {
    try { setExportCode(circuitToOpenQasm3(circuit)); setNotice("OpenQASM 3.0 source generated from the current circuit."); }
    catch (error) { setNotice(error instanceof Error ? error.message : "OpenQASM 3 export failed."); }
  };
  return <section className="cpr-console" aria-label="Circuit research instruments">
    <div className="cpr-console-intro"><div><span className="section-kicker">RESEARCH INSTRUMENTS / CIRCUIT ENGINE</span><h4>Go beyond the circuit diagram.</h4><p>Inspect the state, study noise, route to a coupling map, and export a standards-based circuit representation.</p></div><span className="cpr-console-stamp">LAB<br/>TOOLS</span></div>
    <div className="cpr-tabs" role="tablist" aria-label="Circuit research tools">
      {tabs.map((tab) => <button type="button" role="tab" aria-selected={activeTab === tab.id} className={activeTab === tab.id ? "active" : ""} key={tab.id} onClick={() => setActiveTab(tab.id)}>{tab.label}</button>)}
    </div>
    {activeTab === "inspect" && <div className="cpr-panel">
      <PanelHeading kicker="01 / STRUCTURAL REVIEW" title="Circuit diagnostics" description="Catch invalid structure, common redundancies and resource growth before running an experiment."/>
      <div className="cpr-stat-grid"><div><b>{lint.score}/100</b><small>lint score</small></div><div><b>{resources.operationCount}</b><small>operations</small></div><div><b>{resources.qubitCount}</b><small>qubits</small></div><div><b>{formatBytes(resources.stateVectorBytes)}</b><small>state-vector memory</small></div></div>
      <p className={lint.passed ? "cpr-pass" : "cpr-fail"}>{lint.summary}</p>
      <div className="cpr-issue-list">{lint.issues.length ? lint.issues.map((issue, index) => <article key={`${issue.code}-${index}`} className={`cpr-issue ${issue.severity}`}><b>{issue.code}</b><p>{issue.message}</p>{issue.suggestion && <small>Suggestion: {issue.suggestion}</small>}</article>) : <p>No findings. This is a structural check, not a proof of scientific correctness.</p>}</div>
      <div className="cpr-subheading"><b>Local qubit Bloch vectors</b><small>Single-qubit reduced states. Entangled qubits can appear mixed.</small></div>
      <div className="cpr-bloch-grid">{bloch.map((point, index) => <article key={index}><b>Q{index + 1}</b><span>X {point.x.toFixed(2)}</span><span>Y {point.y.toFixed(2)}</span><span>Z {point.z.toFixed(2)}</span><small>purity {point.purity.toFixed(3)}</small></article>)}</div>
    </div>}
    {activeTab === "tomography" && <div className="cpr-panel">
      <PanelHeading kicker="02 / STATE CHARACTERIZATION" title="Pauli-basis tomography" description="Reconstruct the density matrix from the full Pauli expectation basis. Ideal reconstruction uses exact expectations; sampled tomography is also available in the source library."/>
      {tomography ? <><div className="cpr-stat-grid"><div><b>{tomography.trace.toFixed(5)}</b><small>trace</small></div><div><b>{tomography.purity.toFixed(5)}</b><small>purity</small></div><div><b>{tomography.minimumEigenvalue.toFixed(5)}</b><small>min eigenvalue</small></div><div><b>{tomography.estimates.length}</b><small>Pauli settings</small></div></div><div className="cpr-matrix-wrap"><b>Reconstructed density matrix</b><div className="cpr-matrix-grid" style={{ gridTemplateColumns: `repeat(${tomography.densityMatrix.cols}, minmax(50px, 1fr))` }}>{tomography.densityMatrix.data.map((row, r) => row.map((value, c) => <span key={`${r}-${c}`}>{value.re.toFixed(2)}{value.im < 0 ? "−" : "+"}{Math.abs(value.im).toFixed(2)}i</span>))}</div></div><p className="cpr-science-note">A finite-shot reconstruction can have small negative eigenvalues from statistical noise. Physical maximum-likelihood reconstruction is a separate, more advanced estimation step.</p></> : <p className="cpr-warning">Full state tomography is enabled for coherent circuits with up to three qubits.</p>}
      {process && <div className="cpr-subheading"><b>Single-qubit process transfer matrix</b><small>Available because this circuit has one qubit and no measurement.</small></div>}
      {process && <div className="cpr-matrix-grid" style={{ gridTemplateColumns: "repeat(3, minmax(60px, 1fr))" }}>{process.transferMatrix.flat().map((value, index) => <span key={index}>{value.toFixed(3)}</span>)}</div>}
    </div>}
    {activeTab === "routing" && <div className="cpr-panel">
      <PanelHeading kicker="03 / DEVICE MAPPING" title="Connectivity-aware routing" description="Real processors connect only selected pairs of physical qubits. This educational router inserts SWAPs along shortest paths."/>
      <div className="cpr-control-row"><label>Coupling topology<select value={topology} onChange={(event) => setTopology(event.target.value as "linear" | "ring")}><option value="linear">Linear chain</option><option value="ring">Ring</option></select></label><button type="button" className="cpr-action" onClick={runRouting}>Route this circuit</button></div>
      <p className="cpr-science-note">The route result is calculated using a logical-to-physical qubit map. For circuits with more physical qubits than logical qubits, measurement results must be interpreted through the returned final layout.</p>
    </div>}
    {activeTab === "noise" && <div className="cpr-panel">
      <PanelHeading kicker="04 / DEVICE IMPERFECTIONS" title="Noise sensitivity study" description="Sweep a noise parameter and compare sampled output distributions against the zero-noise baseline."/>
      <div className="cpr-control-row"><label>Noise channel<select value={noiseChannel} onChange={(event) => setNoiseChannel(event.target.value as typeof noiseChannel)}><option value="depolarizing">Depolarizing</option><option value="amplitudeDamping">Amplitude damping</option><option value="phaseDamping">Phase damping</option><option value="readoutFlip">Readout flip</option></select></label><label>Maximum strength <b>{(noiseStrength * 100).toFixed(0)}%</b><input type="range" min="0.01" max="0.5" step="0.01" value={noiseStrength} onChange={(event) => setNoiseStrength(Number(event.target.value))}/></label><button type="button" className="cpr-action" onClick={runNoiseStudy}>Run sweep</button></div>
      {noiseRuns && <div className="cpr-sweep-list">{noiseRuns.points.map((point) => <article key={point.probability}><b>{(point.probability * 100).toFixed(1)}%</b><span>TV distance {(point.totalVariation * 100).toFixed(1)}%</span><span>entropy {point.entropy.toFixed(2)} bits</span><small>mode |{point.dominantOutcome}⟩ · {(point.dominantFrequency * 100).toFixed(1)}%</small></article>)}</div>}
    </div>}
    {activeTab === "teleport" && <div className="cpr-panel">
      <PanelHeading kicker="05 / DYNAMIC QUANTUM CIRCUITS" title="Quantum teleportation experiment" description="Prepare an unknown qubit, share a Bell pair, measure locally, send two classical bits, and apply conditional Pauli corrections."/>
      <button type="button" className="cpr-action" onClick={runTeleportation}>Run 512 teleportation shots</button>
      {teleportCounts && <div className="cpr-shot-grid">{Object.entries(teleportCounts.counts).sort().map(([label, count]) => <article key={label}><b>|{label}⟩</b><span>{count} shots</span><small>{(100 * count / teleportCounts.shots).toFixed(1)}%</small></article>)}</div>}
      <p className="cpr-science-note">Teleportation transfers an unknown quantum state using shared entanglement and classical communication. It does not transport matter or permit faster-than-light communication.</p>
    </div>}
    {activeTab === "export" && <div className="cpr-panel">
      <PanelHeading kicker="06 / INTEROPERABILITY" title="OpenQASM 3.0 export" description="Generate an inspectable representation of the current circuit using OpenQASM 3.0 syntax."/>
      <div className="cpr-control-row"><button type="button" className="cpr-action" onClick={createQasm}>Generate QASM 3.0</button>{exportCode && <button type="button" className="cpr-action secondary" onClick={() => downloadText("la-petite-princess-circuit.qasm", exportCode, "text/plain")}>Download .qasm</button>}</div>
      <textarea className="cpr-code-output" value={exportCode} readOnly rows={Math.min(16, Math.max(6, exportCode.split("\n").length))} placeholder="Generated OpenQASM source will appear here."/>
    </div>}
    <div className="cpr-console-status" role="status">✧ {notice}</div>
  </section>;
}
