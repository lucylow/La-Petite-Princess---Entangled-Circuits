// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import React, { useMemo, useState } from "react";
import { CircuitBoard } from "./CircuitBoard";
import { CircuitProResearchConsole } from "./CircuitProResearchConsole";
import { appendOperation, createCircuit, createOperation, removeOperation, validateCircuit } from "../../lib/circuit-pro/circuit";
import { createCircuitPresets, groverSearchCircuit, ghzCircuit } from "../../lib/circuit-pro/algorithms";
import { simulateCircuit, runCircuitShots } from "../../lib/circuit-pro/simulator";
import { probabilityMap, formatState } from "../../lib/circuit-pro/statevector";
import { circuitMetrics } from "../../lib/circuit-pro/metrics";
import { optimizeCircuit } from "../../lib/circuit-pro/optimizer";
import { transpileCircuit } from "../../lib/circuit-pro/transpiler";
import { runNoisyShots } from "../../lib/circuit-pro/noise";
import { circuitToOpenQasm, serializeCircuit, circuitToQiskitPython } from "../../lib/circuit-pro/serialization";
import type { CircuitDefinition, GateName, NoiseParameters } from "../../lib/circuit-pro/types";

const PRESETS = createCircuitPresets();
const SINGLE_GATES: GateName[] = ["H", "X", "Y", "Z", "S", "SDG", "T", "TDG", "SX", "RX", "RY", "RZ"];
function downloadFile(name: string, content: string, type = "text/plain;charset=utf-8") {
  const url = URL.createObjectURL(new Blob([content], { type })); const anchor = document.createElement("a");
  anchor.href = url; anchor.download = name; anchor.click(); URL.revokeObjectURL(url);
}
function prettyProbability(value: number): string { return `${(value * 100).toFixed(2)}%`; }

export function CircuitProStudio() {
  const [qubitCount, setQubitCount] = useState(3);
  const [circuit, setCircuit] = useState<CircuitDefinition>(() => createCircuit("My quantum experiment", 3));
  const [target, setTarget] = useState(0); const [control, setControl] = useState(1); const [rotation, setRotation] = useState(Math.PI / 2);
  const [shots, setShots] = useState(1000); const [seed, setSeed] = useState(42);
  const [report, setReport] = useState<ReturnType<typeof simulateCircuit> | null>(null);
  const [counts, setCounts] = useState<ReturnType<typeof runCircuitShots> | null>(null);
  const [noise, setNoise] = useState<NoiseParameters>({ depolarizing: 0, amplitudeDamping: 0, phaseDamping: 0, readoutFlip: 0 });
  const [noisyCounts, setNoisyCounts] = useState<ReturnType<typeof runNoisyShots> | null>(null);
  const [notice, setNotice] = useState("Build a circuit with the gate palette, or load a guided experiment.");
  const [presetId, setPresetId] = useState("custom");
  const metrics = useMemo(() => circuitMetrics(circuit), [circuit]);
  const validation = useMemo(() => validateCircuit(circuit), [circuit]);
  const errors = validation.filter((issue) => issue.severity === "error");
  const currentState = useMemo(() => {
    try { return simulateCircuit(circuit).state; } catch { return null; }
  }, [circuit]);
  const probabilities = useMemo(() => currentState ? probabilityMap(currentState, circuit.qubitCount, false) : {}, [currentState, circuit.qubitCount]);

  const append = (gate: GateName, targetQubits: number | number[], controls: number[] = [], theta?: number) => {
    const params = theta === undefined ? undefined : { theta };
    const operation = createOperation(gate, targetQubits, controls, params);
    if (gate === "MEASURE") operation.classicalBit = Array.isArray(targetQubits) ? targetQubits[0] : targetQubits;
    setCircuit((current) => appendOperation(current, operation)); setReport(null); setCounts(null); setNoisyCounts(null);
    setNotice(`${gate} added. The ideal state has been recomputed.`);
  };
  const reset = () => { setCircuit(createCircuit("My quantum experiment", qubitCount)); setReport(null); setCounts(null); setNoisyCounts(null); setNotice("Circuit cleared to the all-zero state."); };
  const changeQubitCount = (next: number) => {
    setQubitCount(next); setCircuit(createCircuit("My quantum experiment", next)); setTarget(0); setControl(Math.min(1, next - 1)); setPresetId("custom"); setReport(null); setCounts(null); setNotice(`New ${next}-qubit register created.`);
  };
  const loadCircuit = (next: CircuitDefinition, id: string) => {
    setCircuit(next); setQubitCount(next.qubitCount); setTarget(0); setControl(Math.min(1, next.qubitCount - 1));
    setPresetId(id); setReport(null); setCounts(null); setNoisyCounts(null); setNotice(`${next.name} loaded.`);
  };
  const run = () => {
    try {
      const result = simulateCircuit(circuit); const shotResult = runCircuitShots(circuit, shots, seed);
      setReport(result); setCounts(shotResult); setNoisyCounts(null); setNotice(`Completed ${shots.toLocaleString()} ideal shots using seed ${seed}.`);
    } catch (error) { setNotice(error instanceof Error ? error.message : "Simulation failed."); }
  };
  const runNoise = () => {
    try { const result = runNoisyShots(circuit, shots, noise, seed); setNoisyCounts(result); setNotice(`Completed ${shots.toLocaleString()} noisy trajectory shots.`); }
    catch (error) { setNotice(error instanceof Error ? error.message : "Noisy simulation failed."); }
  };
  const optimize = () => {
    const result = optimizeCircuit(circuit); setCircuit(result.circuit); setPresetId("custom"); setReport(null); setCounts(null);
    setNotice(`Optimization removed ${result.removedOperations} operation(s) in ${result.passes} pass(es).`);
  };
  const transpile = () => {
    const result = transpileCircuit(circuit); setCircuit(result.circuit); setPresetId("custom"); setReport(null); setCounts(null);
    setNotice(`Transpiled circuit: ${result.originalGateCount} → ${result.outputGateCount} operations. ${result.warnings.join(" ")}`);
  };
  const setNoiseParameter = (key: keyof NoiseParameters, value: number) => setNoise((current) => ({ ...current, [key]: value }));
  const stateText = report ? formatState(report.state, circuit.qubitCount, 4) : currentState ? formatState(currentState, circuit.qubitCount, 4) : "Invalid circuit";

  return <div className="circuit-pro-studio">
    <div className="circuit-pro-intro"><div><span className="section-kicker">CIRCUIT ENGINE · PRO WORKBENCH</span><h3>Build beyond the <em>first qubit.</em></h3><p>Design multi-qubit circuits, inspect their state vectors, test noise and export portable code. This is an ideal educational simulator—not a live hardware connection.</p></div><div className="circuit-pro-seal"><span>Q+</span><small>ENGINE<br/>V2</small></div></div>

    <div className="cp-toolbar-panel">
      <div className="cp-control-group"><label htmlFor="cp-qubits">Register size</label><select id="cp-qubits" value={qubitCount} onChange={(event) => changeQubitCount(Number(event.target.value))}>{[2, 3, 4, 5, 6, 7, 8].map((n) => <option key={n} value={n}>{n} qubits</option>)}</select></div>
      <div className="cp-control-group"><label htmlFor="cp-preset">Guided experiment</label><select id="cp-preset" value={presetId} onChange={(event) => { const selected = PRESETS.find((preset) => preset.id === event.target.value); if (selected) loadCircuit(selected.circuit, selected.id); }}>{<option value="custom">Custom circuit</option>}{PRESETS.map((preset) => <option key={preset.id} value={preset.id}>{preset.title}</option>)}</select></div>
      <button className="mini-action" onClick={reset}>Clear circuit</button>
      <button className="mini-action" onClick={optimize} disabled={errors.length > 0}>Optimize</button>
      <button className="mini-action" onClick={transpile} disabled={errors.length > 0}>Decompose gates</button>
    </div>

    <div className="cp-main-grid">
      <section className="cp-panel cp-builder-panel">
        <div className="cp-panel-heading"><div><span className="section-kicker">01 / CIRCUIT CANVAS</span><h4>{circuit.name}</h4></div><span className="cp-count-pill">{circuit.operations.length} ops</span></div>
        <CircuitBoard circuit={circuit} onRemove={(id) => { setCircuit((current) => removeOperation(current, id)); setReport(null); setCounts(null); setNoisyCounts(null); setNotice("Operation removed and circuit replayed from the beginning."); }} />
        <div className="cp-operation-timeline"><b>Operation sequence</b>{circuit.operations.length === 0 ? <p>No gates yet. Choose a target and add your first operation.</p> : <ol>{circuit.operations.map((operation, index) => <li key={operation.id}><span>{String(index + 1).padStart(2, "0")}</span><b>{operation.gate}</b><small>targets {operation.targets.map((q) => `Q${q + 1}`).join(", ")}{operation.controls?.length ? ` · controls ${operation.controls.map((q) => `Q${q + 1}`).join(", ")}` : ""}{operation.params?.theta !== undefined ? ` · θ ${(operation.params.theta / Math.PI).toFixed(2)}π` : ""}</small><button onClick={() => setCircuit((current) => removeOperation(current, operation.id))} aria-label={`Remove operation ${index + 1}`}>×</button></li>)}</ol>}</div>
      </section>

      <section className="cp-panel cp-palette-panel">
        <div className="cp-panel-heading"><div><span className="section-kicker">02 / GATE LIBRARY</span><h4>Choose an operation</h4></div></div>
        <div className="cp-wire-selectors"><label>Target <select value={target} onChange={(event) => setTarget(Number(event.target.value))}>{Array.from({ length: qubitCount }, (_, q) => <option key={q} value={q}>Q{q + 1}</option>)}</select></label><label>Control <select value={control} onChange={(event) => setControl(Number(event.target.value))}>{Array.from({ length: qubitCount }, (_, q) => <option key={q} value={q}>Q{q + 1}</option>)}</select></label></div>
        <div className="cp-gate-section"><span className="section-kicker">SINGLE-QUBIT GATES</span><div className="cp-gate-palette">{SINGLE_GATES.map((gate) => <button key={gate} onClick={() => append(gate, target, [], ["RX", "RY", "RZ"].includes(gate) ? rotation : undefined)}><b>{gate}</b><small>{gate === "H" ? "superposition" : gate === "X" ? "bit flip" : gate === "Z" ? "phase" : ["RX", "RY", "RZ"].includes(gate) ? "rotation" : "gate"}</small></button>)}</div></div>
        <div className="cp-gate-section"><span className="section-kicker">CONTROLLED & MULTI-QUBIT</span><div className="cp-multi-gates"><button disabled={target === control} onClick={() => append("CX", target, [control])}>CX <small>controlled X</small></button><button disabled={target === control} onClick={() => append("CZ", target, [control])}>CZ <small>controlled Z</small></button><button disabled={target === control} onClick={() => append("SWAP", [control, target])}>SWAP <small>exchange wires</small></button><button disabled={target === control} onClick={() => append("ISWAP", [control, target])}>iSWAP <small>exchange + phase</small></button><button disabled={target === control} onClick={() => append("CH", target, [control])}>CH <small>controlled H</small></button><button disabled={target === control} onClick={() => append("CP", target, [control], rotation)}>CP <small>controlled phase</small></button></div></div>
        <div className="cp-rotation-box"><div><span className="section-kicker">ROTATION ANGLE</span><b>{(rotation / Math.PI).toFixed(2)}π</b></div><input aria-label="Rotation angle" type="range" min={-2 * Math.PI} max={2 * Math.PI} step={0.01} value={rotation} onChange={(event) => setRotation(Number(event.target.value))}/><small>Angle is in radians. Rotation gates use half-angle conventions in their matrices.</small></div>
        <div className="cp-multi-gates cp-extra-gates"><button onClick={() => append("CCX", target, [control, (control + 1) % qubitCount])} disabled={new Set([target, control, (control + 1) % qubitCount]).size !== 3}>CCX <small>Toffoli gate</small></button><button onClick={() => append("BARRIER", Array.from({ length: qubitCount }, (_, q) => q))}>Barrier <small>all wires</small></button><button onClick={() => append("MEASURE", target, [])}>Measure <small>computational Z</small></button></div>
      </section>
    </div>

    <div className="cp-analysis-grid">
      <section className="cp-panel"><div className="cp-panel-heading"><div><span className="section-kicker">03 / STATE VECTOR</span><h4>Live mathematical state</h4></div></div><code className="cp-state-expression">{stateText}</code><div className="cp-probability-list">{Object.entries(probabilities).sort(([a], [b]) => a.localeCompare(b)).map(([label, value]) => <div key={label} className="cp-probability-row"><span>|{label}⟩</span><div><i style={{ width: `${value * 100}%` }}/></div><b>{prettyProbability(value)}</b></div>)}</div></section>
      <section className="cp-panel"><div className="cp-panel-heading"><div><span className="section-kicker">04 / CIRCUIT HEALTH</span><h4>Structural diagnostics</h4></div></div><div className="cp-metric-grid"><div><b>{metrics.depth}</b><small>estimated depth</small></div><div><b>{metrics.entanglingGateCount}</b><small>entangling gates</small></div><div><b>{metrics.twoQubitGateCount + metrics.multiQubitGateCount}</b><small>multi-wire ops</small></div><div><b>{errors.length}</b><small>validation errors</small></div></div>{validation.filter((issue) => issue.severity === "warning").map((issue, index) => <p className="cp-warning" key={index}>! {issue.message}</p>)}{errors.map((issue, index) => <p className="cp-error" key={index}>× {issue.message}</p>)}{!errors.length && <p className="cp-valid">✓ Circuit structure passes validation.</p>}</section>
    </div>

    <section className="cp-panel cp-run-panel"><div className="cp-panel-heading"><div><span className="section-kicker">05 / EXECUTE EXPERIMENT</span><h4>Run measurements</h4><p>Simulate independent shots from the current circuit. A seed makes the sampling reproducible.</p></div></div><div className="cp-run-controls"><label>Shots <select value={shots} onChange={(event) => setShots(Number(event.target.value))}>{[100, 500, 1000, 5000, 10000].map((value) => <option key={value} value={value}>{value.toLocaleString()}</option>)}</select></label><label>Seed <input type="number" value={seed} onChange={(event) => setSeed(Number(event.target.value))}/></label><button className="button button-primary" onClick={run} disabled={errors.length > 0}>Run ideal circuit ↗</button></div>
      {(counts || noisyCounts) && <div className="cp-shot-results"><b>{noisyCounts ? "Noisy observed counts" : "Observed ideal counts"}</b>{Object.entries(noisyCounts?.counts ?? counts?.counts ?? {}).sort(([a], [b]) => a.localeCompare(b)).filter(([, count]) => count > 0).map(([label, count]) => <div className="cp-count-row" key={label}><span>|{label}⟩</span><div><i style={{ width: `${100 * count / shots}%` }}/></div><b>{count}</b><small>{prettyProbability(count / shots)}</small></div>)}</div>}
    </section>

    <section className="cp-panel cp-noise-panel"><div className="cp-panel-heading"><div><span className="section-kicker">06 / HARDWARE REALISM</span><h4>Noise and imperfect devices</h4><p>Use a stochastic quantum-trajectory approximation to explore how noise changes circuit outcomes.</p></div><button className="mini-action" onClick={runNoise} disabled={errors.length > 0}>Run noisy shots</button></div><div className="cp-noise-sliders">{([ ["depolarizing", "Depolarizing", noise.depolarizing ?? 0], ["amplitudeDamping", "Amplitude damping", noise.amplitudeDamping ?? 0], ["phaseDamping", "Phase damping", noise.phaseDamping ?? 0], ["readoutFlip", "Readout bit-flip", noise.readoutFlip ?? 0] ] as [keyof NoiseParameters, string, number][]).map(([key, label, value]) => <label key={key}><span>{label}</span><b>{(value * 100).toFixed(0)}%</b><input type="range" min="0" max="0.5" step="0.01" value={value} onChange={(event) => setNoiseParameter(key, Number(event.target.value))}/></label>)}</div><p className="cp-science-footnote">Noise is applied after gates to touched qubits using sampled Kraus trajectories; readout flips occur after computational-basis sampling. This simplified model does not represent any particular vendor's hardware calibration.</p></section>

    <section className="cp-export-panel"><div><span className="section-kicker">07 / TAKE YOUR WORK WITH YOU</span><b>Export and continue elsewhere</b><small>Save the circuit as portable JSON, OpenQASM 2.0 or a Qiskit Python starter.</small></div><div><button className="mini-action" onClick={() => downloadFile("la-petite-princess-circuit.json", serializeCircuit(circuit), "application/json")}>JSON</button><button className="mini-action" onClick={() => { try { downloadFile("circuit.qasm", circuitToOpenQasm(circuit)); } catch (error) { setNotice(error instanceof Error ? error.message : "QASM export failed."); } }}>OpenQASM</button><button className="mini-action" onClick={() => downloadFile("circuit_qiskit.py", circuitToQiskitPython(circuit), "text/x-python")}>Qiskit Python</button></div></section>
    <CircuitProResearchConsole circuit={circuit}/>
    <div className="cp-status" role="status">✧ {notice}</div>
  </div>;
}
