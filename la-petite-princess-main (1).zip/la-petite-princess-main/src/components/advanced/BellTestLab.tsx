import React, { useMemo, useState } from "react";
import {
  chshValue,
  describeChshValue,
  OPTIMAL_CHSH_ANGLES,
  runBellExperiment,
  type BellAngles,
  type BellExperimentResult,
} from "../../lib/advanced/bell";
import { MetricCard, ScienceNote } from "./LabFrame";

const angleLabels: { key: keyof BellAngles; label: string }[] = [
  { key: "a", label: "Alice setting a" },
  { key: "aPrime", label: "Alice setting a′" },
  { key: "b", label: "Bob setting b" },
  { key: "bPrime", label: "Bob setting b′" },
];

export function BellTestLab() {
  const [angles, setAngles] = useState<BellAngles>(OPTIMAL_CHSH_ANGLES);
  const [shots, setShots] = useState(600);
  const [result, setResult] = useState<BellExperimentResult | null>(null);
  const predictedS = useMemo(() => chshValue(angles), [angles]);
  const update = (key: keyof BellAngles, value: number) => {
    setAngles((current) => ({ ...current, [key]: value }));
    setResult(null);
  };
  const run = () => setResult(runBellExperiment(angles, shots));

  return (
    <div className="bell-lab-grid">
      <section className="bell-settings">
        <div className="section-kicker">THE EXPERIMENT</div>
        <h3>Choose measurement settings</h3>
        <p>Imagine a source preparing many identical |Φ+⟩ pairs. Alice and Bob choose one of two analyzer settings for each trial.</p>
        <div className="bell-angle-list">
          {angleLabels.map(({ key, label }) => (
            <label className="bell-angle" key={key}>
              <span><b>{label}</b><output>{angles[key]}°</output></span>
              <input type="range" min="-180" max="180" step="1" value={angles[key]} onChange={(event) => update(key, Number(event.target.value))} aria-label={label}/>
            </label>
          ))}
        </div>
        <label className="shots-select-label" htmlFor="bell-shots">Trials per setting</label>
        <select id="bell-shots" value={shots} onChange={(event) => { setShots(Number(event.target.value)); setResult(null); }}><option value={100}>100</option><option value={300}>300</option><option value={600}>600</option><option value={1000}>1,000</option><option value={5000}>5,000</option></select>
        <div className="bell-setting-actions"><button className="button button-primary" onClick={run}>Run four settings ↗</button><button className="mini-action" onClick={() => { setAngles(OPTIMAL_CHSH_ANGLES); setResult(null); }}>Optimal preset</button></div>
        <ScienceNote title="A statistical experiment">The simulator samples a simple ideal correlation model for a Bell pair. It is not a loophole-free laboratory Bell test and does not include detector imperfections, source imperfections, or real device data.</ScienceNote>
      </section>
      <section className="bell-results">
        <div className="bell-score-row">
          <MetricCard label="Theoretical CHSH S" value={predictedS.toFixed(3)} detail="From the selected angles"/>
          <MetricCard label="Local bound" value="2.000" detail="|S| ≤ 2"/>
          <MetricCard label="Quantum bound" value="2.828" detail="2√2 · Tsirelson bound"/>
        </div>
        <div className="bell-gauge-card">
          <div className="bell-gauge-title"><b>Where does this setting land?</b><span>{Math.abs(predictedS) > 2 ? "Beyond the classical bound" : "Within the classical bound"}</span></div>
          <div className="bell-gauge"><div className="bell-gauge-classical"/><div className="bell-gauge-quantum"/><div className="bell-gauge-marker" style={{ left: `${Math.min(100, Math.max(0, ((predictedS + 2.828) / 5.656) * 100))}%` }}/></div>
          <div className="bell-gauge-labels"><span>−2√2</span><span>−2</span><span>0</span><span>2</span><span>2√2</span></div>
          <p>{describeChshValue(predictedS)}</p>
        </div>
        {result ? (
          <div className="bell-observations">
            <div className="bell-observation-heading"><b>Sampled results</b><strong>S = {result.observedS.toFixed(3)}</strong></div>
            {result.correlations.map((sample) => (
              <div className="correlation-row" key={sample.label}>
                <span>{sample.label}</span><div className="correlation-track"><i style={{ width: `${(sample.observedCorrelation + 1) * 50}%` }}/></div><b>{sample.observedCorrelation.toFixed(3)}</b><small>theory {sample.expectedCorrelation.toFixed(3)}</small>
              </div>
            ))}
            <p className="sample-disclaimer">Finite-shot sampling fluctuates around the model's theoretical correlations. A larger number of trials usually reduces sampling uncertainty.</p>
          </div>
        ) : (
          <div className="bell-empty"><span>⟷</span><b>Your lab notebook is waiting.</b><p>Run the four measurement settings to collect a finite-shot sample and compare it with the theoretical prediction.</p></div>
        )}
      </section>
    </div>
  );
}
