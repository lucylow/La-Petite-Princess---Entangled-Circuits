import { useEffect, useMemo, useState } from "react";
import { ChevronLeft, ChevronRight, Pause, Play, RotateCcw } from "lucide-react";
import { Button } from "../ui/button";
import { circuitFrames } from "../../lib/advanced/circuitFrames";
import { cFormat, cMagnitude, cPhase } from "../../lib/advanced/complex";
import { formatStateVector, operationLabel, probabilityDistribution, pureTwoQubitConcurrence, type CircuitOperation } from "../../lib/advanced/quantumAdvanced";

export function CircuitVisualization({ operations }: { operations: CircuitOperation[] }) {
  const frames = useMemo(() => circuitFrames(operations), [operations]);
  const [selected, setSelected] = useState<number | null>(null);
  const [playing, setPlaying] = useState(false);
  const step = Math.min(selected ?? operations.length, operations.length);
  const state = frames[step] ?? frames[0] ?? [];
  const probabilities = probabilityDistribution(state);
  const prevProbs = probabilityDistribution(frames[Math.max(step - 1, 0)] ?? state);
  useEffect(() => {
    if (!playing) return;
    const timer = window.setTimeout(() => {
      if (step >= operations.length) { setPlaying(false); return; }
      setSelected(step + 1);
    }, 850);
    return () => window.clearTimeout(timer);
  }, [playing, step, operations.length]);
  const width = Math.max(380, 125 + operations.length * 66);
  const current = operations[step - 1];
  const playX = step === 0 ? 70 : 100 + (step - 1) * 66 + 33;
  return <section className={`circuit-visualization${playing ? " is-playing" : ""}`} aria-label="Circuit state visualization">
    <div className="circuit-viz-heading"><div><span className="section-kicker">GATE BY GATE</span><h3>The circuit, unfolding</h3></div><span>{step} / {operations.length} gates</span></div>
    <div className="circuit-diagram-scroll">
      <svg className="circuit-diagram" width={width} height={158} viewBox={`0 0 ${width} 158`} role="img" aria-label={`Two-qubit circuit with ${operations.length} gates; ${step} applied`}>
        {[0, 1].map((q) => <g key={q}><text x="8" y={55 + q * 65}>Q{q + 1}</text><text x="35" y={55 + q * 65}>|0⟩</text><line className="circuit-wire" x1="66" x2={width - 12} y1={50 + q * 65} y2={50 + q * 65}/><line className="circuit-wire-lit" x1="0" x2="1" y1={50 + q * 65} y2={50 + q * 65} style={{ transform: `translateX(66px) scaleX(${playX - 66})` }}/></g>)}
        {pureTwoQubitConcurrence(state) > 0.5 && <g className="circuit-entangle" key={`ent-${step}`}><path d={`M${playX} 50 C ${playX + 40} 70, ${playX + 40} 95, ${playX} 115`} /><path d={`M${playX} 50 C ${playX - 40} 70, ${playX - 40} 95, ${playX} 115`} /></g>}
        <g className="circuit-playhead" style={{ transform: `translateX(${playX}px)` }}><line x1="0" x2="0" y1="30" y2="135"/>{[0, 1].map((q) => <circle key={q} className="circuit-pulse" cx="0" cy={50 + q * 65} r="5"/>)}</g>
        {operations.map((op, index) => {
          const x = 100 + index * 66;
          const y = 50 + op.target * 65;
          const cy = 50 + (op.control ?? 0) * 65;
          return <g key={op.id + (index === step - 1 ? "-active" : "")} className={`${index < step ? "circuit-applied" : "circuit-pending"}${index === step - 1 ? " circuit-active" : ""}`} style={{ transformOrigin: `${x}px ${(y + cy) / 2}px` }}><title>{operationLabel(op)}</title>
            <text className="circuit-step-label" x={x} y="20" textAnchor="middle">{index + 1}</text>
            {op.control !== undefined && <line className="circuit-connector" x1={x} x2={x} y1={cy} y2={y}/>}
            {op.control !== undefined && index === step - 1 && <circle className="circuit-zap" cx={x} cy={cy} r="4" style={{ ["--zap-dy" as string]: `${y - cy}px` }}/>}
            {index === step - 1 && <circle className="circuit-ripple" cx={x} cy={y} r="18"/>}
            {index === step - 1 && <circle className="circuit-ripple circuit-ripple-late" cx={x} cy={y} r="18"/>}
            {index === step - 1 && <g className="circuit-burst">{Array.from({ length: 10 }, (_, i) => { const a = (i / 10) * Math.PI * 2; return <circle key={i} className={`circuit-spark spark-${i % 3}`} cx={x} cy={y} r={i % 2 ? 2 : 3} style={{ ["--sx" as string]: `${Math.cos(a) * 34}px`, ["--sy" as string]: `${Math.sin(a) * 34}px`, animationDelay: `${(i % 3) * 40}ms` }}/>; })}</g>}
            {op.gate === "SWAP" ? [y, cy].map((sy, i) => <g key={i}><line x1={x - 8} x2={x + 8} y1={sy - 8} y2={sy + 8}/><line x1={x - 8} x2={x + 8} y1={sy + 8} y2={sy - 8}/></g>) : <>
              {op.control !== undefined && <circle className="circuit-control-dot" cx={x} cy={cy} r="5"/>}
              {op.gate === "CNOT" ? <g><circle className="circuit-gate-box" cx={x} cy={y} r="14"/><line x1={x - 8} x2={x + 8} y1={y} y2={y}/><line x1={x} x2={x} y1={y - 8} y2={y + 8}/></g> : <g><rect className="circuit-gate-box" x={x - 20} y={y - 19} width="40" height="38" rx="4"/><text className="circuit-gate-text" x={x} y={y + 4} textAnchor="middle">{op.gate === "CZ" ? "Z" : op.gate}</text></g>}
            </>}
          </g>;
        })}
      </svg>
    </div>
    <div className="circuit-playback">
      <Button variant="expedition" size="icon" title="Return to initial state" aria-label="Return to initial state" onClick={() => { setPlaying(false); setSelected(0); }}><RotateCcw/></Button>
      <Button variant="expedition" size="icon" title="Previous gate" aria-label="Previous gate" disabled={step === 0} onClick={() => { setPlaying(false); setSelected(step - 1); }}><ChevronLeft/></Button>
      <Button variant="expedition" size="icon" title={playing ? "Pause circuit" : "Play circuit"} aria-label={playing ? "Pause circuit" : "Play circuit"} disabled={!operations.length} onClick={() => { if (!playing && step === operations.length) setSelected(0); setPlaying(!playing); }}>{playing ? <Pause/> : <Play/>}</Button>
      <Button variant="expedition" size="icon" title="Next gate" aria-label="Next gate" disabled={step === operations.length} onClick={() => { setPlaying(false); setSelected(step + 1); }}><ChevronRight/></Button>
      <input aria-label="Circuit step" type="range" min={0} max={operations.length} value={step} onChange={(e) => { setPlaying(false); setSelected(Number(e.target.value)); }}/>
    </div>
    <div className="circuit-frame-label"><b>{current ? operationLabel(current) : "Initial state · |00⟩"}</b><span>Entanglement · {pureTwoQubitConcurrence(state).toFixed(2)} concurrence</span></div>
    <code className="circuit-frame-state">{formatStateVector(state, 2)}</code>
    <div className="circuit-amplitudes">{state.map((amplitude, index) => {
      const phase = cPhase(amplitude);
      const radius = 23 * cMagnitude(amplitude);
      return <div className="circuit-amplitude" key={index}>
        {Math.abs((probabilities[index] ?? 0) - (prevProbs[index] ?? 0)) > 1e-6 && <i className="circuit-flash" key={step} aria-hidden="true"/>}
        <svg viewBox="0 0 64 64" role="img" aria-label={`${index.toString(2).padStart(2, "0")}: amplitude ${cFormat(amplitude)}, phase ${(phase * 180 / Math.PI).toFixed(0)} degrees`}><circle className="phase-ring" cx="32" cy="32" r="24"/><path className="phase-axis" d="M8 32H56M32 8V56"/><circle className="phase-disc" cx="32" cy="32" r="24" style={{ transform: `scale(${cMagnitude(amplitude) ** 2})` }}/><g className="phase-arm" style={{ transform: `rotate(${-phase}rad)` }}><line className="phase-hand" x1="32" y1="32" x2="33" y2="32" style={{ transform: `scaleX(${Math.max(radius, 0.001)})`, opacity: radius < 0.5 ? 0 : 1 }}/><circle className="phase-tip" cx="32" cy="32" r="3" style={{ transform: `translateX(${radius}px)`, opacity: radius < 0.5 ? 0 : 1 }}/></g></svg>
        <div className="circuit-prob-bar"><i style={{ transform: `scaleX(${probabilities[index] ?? 0})` }}/></div>
        <b>|{index.toString(2).padStart(2, "0")}⟩</b><span>{((probabilities[index] ?? 0) * 100).toFixed(1)}%</span><small>{cMagnitude(amplitude) < 1e-9 ? "Phase —" : `${(phase * 180 / Math.PI).toFixed(0)}° phase`}</small>
      </div>;
    })}</div>
  </section>;
}