import React, { useState, useSyncExternalStore } from "react";
import { Music, Volume2, VolumeX, Waves, X, Zap } from "lucide-react";
import { getAudioEngine } from "../../lib/advanced/audioEngine";

/**
 * Floating audio controls for the story experience. Sound is synthesized
 * locally and never starts on its own — the reader turns it on here.
 * Preferences are remembered in this browser.
 */
export function AudioDock() {
  const engine = getAudioEngine();
  const prefs = useSyncExternalStore(engine.subscribe, engine.getPrefs, engine.getPrefs);
  const [open, setOpen] = useState(false);
  const soundOn = !prefs.muted && (prefs.ambientEnabled || prefs.sfxEnabled);

  return (
    <div className={`audio-dock ${open ? "open" : ""}`}>
      {open && (
        <div className="audio-dock-panel" role="group" aria-label="Sound settings">
          <div className="audio-dock-heading">
            <span className="section-kicker">SOUNDSCAPE</span>
            <button className="audio-dock-close" onClick={() => setOpen(false)} aria-label="Close sound settings">
              <X size={14} />
            </button>
          </div>
          <p className="audio-dock-note">A gentle observatory hum and soft chimes, synthesized on your device. Nothing plays until you ask.</p>
          <label className="audio-dock-slider">
            <span><Volume2 size={14} /> Volume</span>
            <input
              type="range"
              min={0}
              max={100}
              value={Math.round(prefs.masterVolume * 100)}
              onChange={(event) => engine.setMasterVolume(Number(event.target.value) / 100)}
              aria-label="Master volume"
            />
          </label>
          <div className="audio-dock-toggles">
            <button
              className={`audio-toggle ${prefs.ambientEnabled ? "on" : ""}`}
              onClick={() => engine.toggleAmbient()}
              aria-pressed={prefs.ambientEnabled}
            >
              <Waves size={15} />
              <span><b>Ambience</b><small>{prefs.ambientEnabled ? "Playing" : "Off"}</small></span>
            </button>
            <button
              className={`audio-toggle ${prefs.sfxEnabled ? "on" : ""}`}
              onClick={() => { engine.toggleSfx(); }}
              aria-pressed={prefs.sfxEnabled}
            >
              <Zap size={15} />
              <span><b>Chimes</b><small>{prefs.sfxEnabled ? "On" : "Off"}</small></span>
            </button>
          </div>
          <button className="audio-dock-mute" onClick={() => engine.toggleMute()} aria-pressed={prefs.muted}>
            {prefs.muted ? <VolumeX size={14} /> : <Volume2 size={14} />}
            {prefs.muted ? "Unmute all sound" : "Mute all sound"}
          </button>
        </div>
      )}
      <button
        className={`audio-dock-fab ${soundOn ? "active" : ""}`}
        onClick={() => setOpen((value) => !value)}
        aria-expanded={open}
        aria-label={open ? "Close sound controls" : "Open sound controls"}
      >
        <Music size={19} />
        {prefs.ambientEnabled && !prefs.muted && <i className="audio-dock-pulse" aria-hidden="true" />}
      </button>
    </div>
  );
}
