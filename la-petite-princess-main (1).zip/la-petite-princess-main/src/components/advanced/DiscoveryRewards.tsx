import { useEffect, useRef, useState } from "react";
import { ArrowRight, Atom, BookOpen, Check, Compass, FlaskConical, GraduationCap, LockKeyhole, Sparkles, Trophy, X, Zap } from "lucide-react";
import { Button } from "../ui/button";
import { getRewards } from "../../lib/advanced/rewards";
import type { LocalProgress } from "../../lib/advanced/progressStore";
import { LESSONS } from "../../data/lessons";
import { CHALLENGES } from "../../data/challenges";

const badgeIcons = [Zap, FlaskConical, Compass, Trophy, Atom, GraduationCap];
export function BadgeCollection({ progress }: { progress: LocalProgress }) {
  const { badges } = getRewards(progress);
  return <section className="discovery-collection" aria-label="Achievement collection">
    <div className="discovery-section-heading"><h3>Your discovery collection</h3><span>{badges.filter((badge) => badge.earned).length} / {badges.length} earned</span></div>
    <div className="discovery-badges">{badges.map((badge, index) => {
      const Icon = badgeIcons[index] ?? Sparkles;
      return <article key={badge.id} className={`discovery-badge ${badge.earned ? "earned" : "locked"}`}>
        <div className="discovery-medal"><Icon size={28} aria-hidden="true"/>{badge.earned ? <Check size={14}/> : <LockKeyhole size={12}/>}</div>
        <b>{badge.name}</b><p>{badge.goal}</p><span>{badge.earned ? "Earned" : `${badge.current} / ${badge.target}`}</span>
      </article>;
    })}</div>
  </section>;
}

export function DiscoveryRewards({ progress, ready, onNavigate }: { progress: LocalProgress; ready: boolean; onNavigate: (tab: "lessons" | "quiz" | "challenges" | "progress") => void }) {
  const rewards = getRewards(progress);
  const previous = useRef<ReturnType<typeof getRewards> | null>(null);
  const [celebration, setCelebration] = useState<{ points: number; message: string } | null>(null);
  useEffect(() => {
    if (!ready) return;
    const last = previous.current;
    if (last && rewards.points > last.points) {
      const badge = rewards.badges.find((item) => item.earned && !last.badges.some((old) => old.id === item.id && old.earned));
      setCelebration({ points: rewards.points - last.points, message: rewards.rankIndex > last.rankIndex ? `Level up! ${rewards.rank.name}` : badge ? `${badge.name} unlocked!` : "Another discovery. Keep going!" });
    }
    previous.current = rewards;
  }, [progress, ready]);
  useEffect(() => {
    if (!celebration) return;
    const timer = window.setTimeout(() => setCelebration(null), 6000);
    return () => window.clearTimeout(timer);
  }, [celebration]);
  const lesson = LESSONS.find((item) => !progress.completedLessons.includes(item.id));
  const challenge = CHALLENGES.find((item) => !progress.completedChallenges.includes(item.id));
  const quests = [
    { title: lesson?.title ?? "Learning path complete", points: "+50", icon: BookOpen, tab: "lessons" as const, done: !lesson },
    { title: challenge?.title ?? "Expedition complete", points: "+100", icon: Compass, tab: "challenges" as const, done: !challenge },
    { title: progress.bestQuizPercent >= 80 ? "Sharp mind earned" : "Aim for 80% in a quiz", points: "80%", icon: Atom, tab: "quiz" as const, done: progress.bestQuizPercent >= 80 },
  ];
  return <div className="discovery-hub">
    <div className="discovery-rank">
      <div className="discovery-rank-icon"><Sparkles size={26}/></div>
      <div className="discovery-rank-copy"><span>EXPLORER LEVEL {rewards.rankIndex + 1}</span><h3>{rewards.rank.name}</h3></div>
      <Button variant="expedition" onClick={() => onNavigate("progress")} aria-label="View achievements" className="discovery-points"><Trophy/>{rewards.points} XP<ArrowRight/></Button>
      <div className="discovery-rank-track"><progress max={100} value={rewards.rankPercent} aria-label="Explorer level progress"/><small>{rewards.nextRank ? `${rewards.nextRank.threshold - rewards.points} XP to ${rewards.nextRank.name}` : "Top rank reached. The universe is still yours to explore."}</small></div>
    </div>
    <div className="discovery-section-heading"><h3>Your next adventures</h3><span>{rewards.badges.filter((badge) => badge.earned).length} badges earned</span></div>
    <div className="discovery-quests">{quests.map((quest) => <Button key={quest.tab} variant="expedition" className={`discovery-quest ${quest.done ? "done" : ""}`} onClick={() => onNavigate(quest.tab)}><quest.icon/><span><small>{quest.done ? "COMPLETE" : quest.tab === "lessons" ? "READ & DISCOVER" : quest.tab === "challenges" ? "TAKE A CHALLENGE" : "KNOWLEDGE QUEST"}</small><b>{quest.title}</b></span><em>{quest.done ? <Check/> : quest.points}</em><ArrowRight/></Button>)}</div>
    {celebration && <div className="discovery-celebration" role="status" key={`${rewards.points}`}><div className="discovery-burst" aria-hidden="true">{Array.from({ length: 10 }, (_, i) => <i key={i}/>)}</div><Sparkles size={30}/><div><strong>+{celebration.points} discovery XP</strong><p>{celebration.message}</p></div><Button variant="expedition" size="icon" onClick={() => setCelebration(null)} aria-label="Dismiss reward"><X/></Button></div>}
  </div>;
}