import React, { useMemo, useState } from "react";
import { createZeroState, runCircuit } from "../../lib/advanced/quantumAdvanced";
import { applyReadoutNoiseToState } from "../../lib/advanced/noise";
import { ProbabilityChart } from "./ProbabilityChart";
import { ScienceNote } from "./LabFrame";

export function NoiseLab() {
  const [preset, setPreset] = useState<"bell" | "uniform" | "zero">("bell");
  const [q1Rate, setQ1Rate] = useState(0.05);
  const [q2Rate, setQ2Rate] = useState(0.05);
  const state = useMemo(() => {
    if (preset === "zero") return createZeroState(2);
    if (preset === "uniform") return runCircuit(2, [{ id: "h1", gate: "H", target: 0 }, { id: "h2", gate: "H", target: 1 }]);
    return runCircuit(2, [{ id: "h", gate: "H", target: 0 }, { id: "cx", gate: "CNOT", control: 0, target: 1 }]);
  }, [preset]);
  const result = useMemo(() => applyReadoutNoiseToState(state, 2, [q1Rate, q2Rate]), [state, q1Rate, q2Rate]);
  const labels = ["00", "01", "10", "11"];
  return (
    <div className="noise-lab">
      <div className="noise-controls">
        <span className="section-kicker">THE NOISY DETECTOR</span><h3>What if a detector reads a bit incorrectly?</h3><p>This lab applies a simple independent classical readout-flip model after ideal state preparation.</p>
        <label htmlFor="noise-preset">Prepared ideal state</label><select id="noise-preset" value={preset} onChange={(event) => setPreset(event.target.value as typeof preset)}><option value="bell">Bell pair · (|00⟩ + |11⟩)/√2</option><option value="uniform">Uniform four-state superposition</option><option value="zero">|00⟩</option></select>
        <label className="noise-slider" htmlFor="noise-q1"><span>Q1 readout bit-flip rate</span><b>{(q1Rate * 100).toFixed(0)}%</b></label><input id="noise-q1" type="range" min="0" max="0.5" step="0.01" value={q1Rate} onChange={(event) => setQ1Rate(Number(event.target.value))}/>
        <label className="noise-slider" htmlFor="noise-q2"><span>Q2 readout bit-flip rate</span><b>{(q2Rate * 100).toFixed(0)}%</b></label><input id="noise-q2" type="range" min="0" max="0.5" step="0.01" value={q2Rate} onChange={(event) => setQ2Rate(Number(event.target.value))}/>
        <button className="mini-action" onClick={() => { setQ1Rate(0.05); setQ2Rate(0.05); }}>Reset to 5% each</button>
      </div>
      <div className="noise-charts">
        <ProbabilityChart title="Ideal distribution" data={labels.map((label, index) => ({ label, value: result.ideal[index] ?? 0 }))}/>
        <ProbabilityChart title="After readout errors" data={labels.map((label, index) => ({ label, value: result.observed[index] ?? 0 }))}/>
        <div className="noise-table"><b>Probability comparison</b>{labels.map((label, index) => <div key={label}><span>|{label}⟩</span><span>{((result.ideal[index] ?? 0) * 100).toFixed(1)}%</span><b>{((result.observed[index] ?? 0) * 100).toFixed(1)}%</b></div>)}</div>
        <ScienceNote title="Important distinction">This is readout misclassification, modeled as independent bit flips on classical measurement outcomes. It is not a physical simulation of decoherence or noisy quantum gates. Real processors require hardware-specific calibration data.</ScienceNote>
      </div>
    </div>
  );
}
