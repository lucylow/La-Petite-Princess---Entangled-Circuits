import React, { useState } from "react";
import { createEmptyNotebookEntry, downloadTextFile, notebookEntryToMarkdown, slugify, type NotebookEntry } from "../../lib/advanced/notebook";
import { ScienceNote } from "./LabFrame";

const fields: { key: keyof Omit<NotebookEntry, "createdAt">; label: string; placeholder: string; rows: number }[] = [
  { key: "title", label: "Experiment title", placeholder: "e.g. What happens after H → RZ → H?", rows: 1 },
  { key: "question", label: "Research question", placeholder: "What do you want to find out?", rows: 2 },
  { key: "prediction", label: "Prediction", placeholder: "What do you expect to happen, and why?", rows: 2 },
  { key: "method", label: "Method", placeholder: "List the gates, settings, shots, and steps you used.", rows: 3 },
  { key: "observation", label: "Observation", placeholder: "Record the state vector, counts, probabilities, or pattern you observed.", rows: 3 },
  { key: "explanation", label: "Explanation", placeholder: "How do you interpret the result? Separate observation from interpretation.", rows: 3 },
  { key: "nextQuestion", label: "Next question", placeholder: "What would you change or investigate next?", rows: 2 },
];

export function ResearchNotebook() {
  const [entry, setEntry] = useState<NotebookEntry>(() => createEmptyNotebookEntry());
  const [saved, setSaved] = useState(false);
  const update = (key: keyof Omit<NotebookEntry, "createdAt">, value: string) => {
    setEntry((current) => ({ ...current, [key]: value }));
    setSaved(false);
  };
  const exportMarkdown = () => {
    downloadTextFile(`${slugify(entry.title)}.md`, notebookEntryToMarkdown(entry));
    setSaved(true);
  };
  const clear = () => {
    setEntry(createEmptyNotebookEntry());
    setSaved(false);
  };
  return (
    <div className="notebook-layout">
      <section className="notebook-editor">
        <div className="notebook-top"><div><span className="section-kicker">THE RESEARCH NOTEBOOK</span><h3>Ask. Predict. Test. Explain.</h3><p>A structured place to record an experiment. Nothing here asks for a name, email, or profile.</p></div><span className="notebook-stamp">FIELD<br/>NOTES</span></div>
        <div className="notebook-fields">{fields.map((field) => (
          <label className={`notebook-field field-${field.key}`} key={field.key}><span>{field.label}</span>{field.rows === 1 ? <input value={entry[field.key]} onChange={(event) => update(field.key, event.target.value)} placeholder={field.placeholder}/> : <textarea value={entry[field.key]} onChange={(event) => update(field.key, event.target.value)} placeholder={field.placeholder} rows={field.rows}/>}</label>
        ))}</div>
        <div className="notebook-actions"><button className="button button-primary" onClick={exportMarkdown}>Export notebook (.md) ↗</button><button className="mini-action" onClick={() => window.print()}>Print / Save as PDF</button><button className="mini-action" onClick={clear}>Clear draft</button>{saved && <span role="status">Export started.</span>}</div>
      </section>
      <aside className="notebook-guide"><div className="section-kicker">THE SCIENTIST'S HABIT</div><h3>Separate what you saw from what you think it means.</h3><ol><li><b>Question</b><span>Make it specific enough to test.</span></li><li><b>Prediction</b><span>Write down your expectation before running.</span></li><li><b>Method</b><span>Record exact settings and number of shots.</span></li><li><b>Observation</b><span>Describe the data without adding an explanation.</span></li><li><b>Interpretation</b><span>Connect the evidence to the model.</span></li></ol><ScienceNote title="Reproducibility">A strong notebook lets another learner repeat your steps and understand how you reached your conclusion. This local notebook draft is not automatically saved to a server.</ScienceNote></aside>
    </div>
  );
}
