import React, { useMemo, useState } from "react";
import { QUIZ_QUESTIONS, scoreQuiz, shuffleQuestions, type QuizDifficulty } from "../../data/quizzes";

export function QuizEngine({ onScore }: { onScore: (score: number) => void }) {
  const [difficulty, setDifficulty] = useState<QuizDifficulty | "all">("curious");
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);
  const [seed, setSeed] = useState(0);
  const questions = useMemo(() => {
    const selected = difficulty === "all" ? QUIZ_QUESTIONS : QUIZ_QUESTIONS.filter((question) => question.difficulty === difficulty);
    return shuffleQuestions(selected, () => {
      // A deterministic local ordering per restart keeps the test reproducible.
      const value = Math.sin((seed + 1) * 12.9898 + selected.length * 78.233) * 43758.5453;
      return value - Math.floor(value);
    });
  }, [difficulty, seed]);
  const score = scoreQuiz(answers);
  const completed = Object.keys(answers).length;
  const allAnswered = completed === questions.length;

  const changeDifficulty = (value: QuizDifficulty | "all") => {
    setDifficulty(value);
    setAnswers({});
    setSubmitted(false);
  };

  const submit = () => {
    if (!allAnswered) return;
    setSubmitted(true);
    onScore(score.percentage);
  };

  const restart = () => {
    setAnswers({});
    setSubmitted(false);
    setSeed((current) => current + 1);
  };

  return (
    <div className="quiz-engine">
      <div className="quiz-engine-heading"><div><span className="section-kicker">THE QUANTUM KNOWLEDGE CHECK</span><h3>Test your understanding.</h3><p>Choose a path, answer the questions, and read the explanation behind every answer.</p></div><div className="quiz-progress-ring"><b>{completed}/{questions.length}</b><small>answered</small></div></div>
      <div className="quiz-level-picker" role="group" aria-label="Quiz difficulty">
        {([{ value: "curious", label: "Curious" }, { value: "practitioner", label: "Practitioner" }, { value: "researcher", label: "Researcher" }, { value: "all", label: "All levels" }] as const).map((choice) => <button key={choice.value} className={difficulty === choice.value ? "selected" : ""} onClick={() => changeDifficulty(choice.value)}>{choice.label}</button>)}
      </div>
      <div className="quiz-question-grid">
        {questions.map((question, index) => {
          const answer = answers[question.id];
          const correct = answer === question.correctOptionId;
          return (
            <article className="quiz-question-card" key={question.id}>
              <div className="quiz-question-meta"><span>QUESTION {String(index + 1).padStart(2, "0")}</span><small>{question.topic}</small></div>
              <h4>{question.prompt}</h4>
              <div className="quiz-answer-options">
                {question.options.map((option) => {
                  const isSelected = answer === option.id;
                  const isCorrect = submitted && option.id === question.correctOptionId;
                  const isIncorrect = submitted && isSelected && !correct;
                  return <button key={option.id} disabled={submitted} className={`${isSelected ? "selected" : ""} ${isCorrect ? "correct" : ""} ${isIncorrect ? "incorrect" : ""}`} onClick={() => setAnswers((current) => ({ ...current, [question.id]: option.id }))}><span>{option.id.toUpperCase()}</span>{option.label}{isCorrect && <b>✓</b>}{isIncorrect && <b>×</b>}</button>;
                })}
              </div>
              {answer && !submitted && <div className="quiz-hint">Hint: {question.hint}</div>}
              {submitted && <div className={`quiz-answer-explanation ${correct ? "correct" : "incorrect"}`}><b>{correct ? "Correct" : "Review this one"}</b><p>{question.explanation}</p></div>}
            </article>
          );
        })}
      </div>
      <div className="quiz-engine-footer">
        {!submitted ? <><span>{completed} of {questions.length} answers selected</span><button className="button button-primary" disabled={!allAnswered} onClick={submit}>Submit answers ↗</button></> : <><div className="quiz-final-score"><b>{score.correct} / {score.total} correct</b><span>{score.percentage}%</span></div><button className="button button-primary" onClick={restart}>Try another round ↻</button></>}
      </div>
    </div>
  );
}
