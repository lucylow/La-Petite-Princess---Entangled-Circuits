import React from "react";
import type { LocalProgress } from "../../lib/advanced/progressStore";
import { LESSONS } from "../../data/lessons";
import { CHALLENGES } from "../../data/challenges";
import { MetricCard } from "./LabFrame";
import { BadgeCollection } from "./DiscoveryRewards";

export function ProgressDashboard({ progress, onReset }: { progress: LocalProgress; onReset: () => void }) {
  const lessonPercent = LESSONS.length ? Math.round(progress.completedLessons.length / LESSONS.length * 100) : 0;
  const challengePercent = CHALLENGES.length ? Math.round(progress.completedChallenges.length / CHALLENGES.length * 100) : 0;
  return (
    <section className="progress-dashboard">
      <div className="progress-dashboard-heading"><div><span className="section-kicker">YOUR FIELD NOTES</span><h3>Curiosity in motion.</h3><p>This dashboard reads only the progress stored locally in this browser. It does not create a profile or send data to a server.</p></div><button className="mini-action" onClick={onReset}>Clear local progress</button></div>
      <div className="progress-metrics">
        <MetricCard label="Lessons complete" value={`${progress.completedLessons.length}/${LESSONS.length}`} detail={`${lessonPercent}% of the learning path`}/>
        <MetricCard label="Best quiz result" value={`${progress.bestQuizPercent}%`} detail={`${progress.quizAttempts} recorded attempts`}/>
        <MetricCard label="Challenges" value={`${progress.completedChallenges.length}/${CHALLENGES.length}`} detail={`${challengePercent}% completed`}/>
        <MetricCard label="Lab runs" value={String(progress.labRuns)} detail="Experiments counted locally"/>
      </div>
      <div className="progress-bars"><div><span>Learning path</span><b>{lessonPercent}%</b><i><em style={{ width: `${lessonPercent}%` }}/></i></div><div><span>Challenge collection</span><b>{challengePercent}%</b><i><em style={{ width: `${challengePercent}%` }}/></i></div></div>
      <BadgeCollection progress={progress}/>
    </section>
  );
}
