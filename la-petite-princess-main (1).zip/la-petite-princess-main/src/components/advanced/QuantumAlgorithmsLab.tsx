import React, { useMemo, useState } from "react";
import { createBasisState, probabilityDistribution } from "../../lib/advanced/quantumAdvanced";
import { runBernsteinVazirani, runDeutschJozsa, runQuantumFourierTransform } from "../../lib/advanced/algorithms";
import { ProbabilityChart } from "./ProbabilityChart";
import { ScienceNote } from "./LabFrame";

type AlgorithmChoice = "bv" | "dj" | "qft";

export function QuantumAlgorithmsLab() {
  const [algorithm, setAlgorithm] = useState<AlgorithmChoice>("bv");
  const [secret, setSecret] = useState("101");
  const [djKind, setDjKind] = useState<"constant" | "balanced">("balanced");
  const [djQubits, setDjQubits] = useState(3);
  const [qftQubits, setQftQubits] = useState(3);
  const [qftInput, setQftInput] = useState("001");
  const [runNumber, setRunNumber] = useState(0);
  const result = useMemo(() => {
    if (runNumber === 0) return null;
    if (algorithm === "bv") return runBernsteinVazirani(secret);
    if (algorithm === "dj") return runDeutschJozsa(djQubits, djKind);
    const input = createBasisState(qftQubits, qftInput.padStart(qftQubits, "0"));
    const state = runQuantumFourierTransform(input, qftQubits);
    const probabilities = probabilityDistribution(state);
    return {
      algorithm: "Quantum Fourier Transform",
      qubitCount: qftQubits,
      state,
      outcomes: probabilities.map((probability, index) => ({ label: index.toString(2).padStart(qftQubits, "0"), probability })),
      explanation: `The QFT maps basis input |${qftInput.padStart(qftQubits, "0")}⟩ to a Fourier-phase pattern across ${2 ** qftQubits} basis states. The displayed chart shows probabilities; the complex phases remain in the state vector.`,
      oracleQueries: 0,
    };
  }, [algorithm, secret, djKind, djQubits, qftQubits, qftInput, runNumber]);

  const run = () => setRunNumber((value) => value + 1);
  return (
    <div className="algorithm-lab">
      <div className="algorithm-picker" role="group" aria-label="Choose quantum algorithm">
        <button className={algorithm === "bv" ? "active" : ""} onClick={() => { setAlgorithm("bv"); setRunNumber(0); }}><b>01</b><span>Bernstein–Vazirani</span><small>Find a hidden bit string</small></button>
        <button className={algorithm === "dj" ? "active" : ""} onClick={() => { setAlgorithm("dj"); setRunNumber(0); }}><b>02</b><span>Deutsch–Jozsa</span><small>Classify an oracle promise</small></button>
        <button className={algorithm === "qft" ? "active" : ""} onClick={() => { setAlgorithm("qft"); setRunNumber(0); }}><b>03</b><span>Quantum Fourier transform</span><small>Transform phases</small></button>
      </div>
      <div className="algorithm-run-area">
        <div className="algorithm-controls">
          {algorithm === "bv" && <><span className="section-kicker">HIDDEN STRING ORACLE</span><h3>Can one query reveal the pattern?</h3><p>Choose a secret bit string for the promise function f(x) = s · x mod 2.</p><label htmlFor="bv-secret">Secret string s</label><input id="bv-secret" value={secret} maxLength={5} inputMode="numeric" pattern="[01]*" onChange={(event) => { setSecret(event.target.value.replace(/[^01]/g, "")); setRunNumber(0); }}/><small>Use 1–5 binary digits.</small></>}
          {algorithm === "dj" && <><span className="section-kicker">CONSTANT OR BALANCED</span><h3>Classify a promised function.</h3><p>For the balanced case, the demo oracle is f(x)=x₀. For the constant case, f(x)=0 for every input.</p><label htmlFor="dj-kind">Oracle promise</label><select id="dj-kind" value={djKind} onChange={(event) => { setDjKind(event.target.value as typeof djKind); setRunNumber(0); }}><option value="constant">Constant zero</option><option value="balanced">Balanced · f(x)=x₀</option></select><label htmlFor="dj-qubits">Input qubits</label><select id="dj-qubits" value={djQubits} onChange={(event) => { setDjQubits(Number(event.target.value)); setRunNumber(0); }}><option value={1}>1</option><option value={2}>2</option><option value={3}>3</option><option value={4}>4</option><option value={5}>5</option></select></>}
          {algorithm === "qft" && <><span className="section-kicker">FOURIER PHASE PATTERN</span><h3>Transform a basis state.</h3><p>Choose a computational basis input and inspect the output probability distribution. The transform's complex phases are retained in the returned state.</p><label htmlFor="qft-qubits">Register size</label><select id="qft-qubits" value={qftQubits} onChange={(event) => { const size = Number(event.target.value); setQftQubits(size); setQftInput((current) => current.padStart(size, "0").slice(-size)); setRunNumber(0); }}><option value={2}>2 qubits</option><option value={3}>3 qubits</option><option value={4}>4 qubits</option><option value={5}>5 qubits</option></select><label htmlFor="qft-input">Input basis state</label><select id="qft-input" value={qftInput.padStart(qftQubits, "0")} onChange={(event) => { setQftInput(event.target.value); setRunNumber(0); }}>{Array.from({ length: 2 ** qftQubits }, (_, index) => index.toString(2).padStart(qftQubits, "0")).map((label) => <option key={label} value={label}>|{label}⟩</option>)}</select></>}
          <button className="button button-primary" onClick={run} disabled={algorithm === "bv" && !/^[01]{1,5}$/.test(secret)}>Run algorithm ↗</button>
        </div>
        <div className="algorithm-output">
          {result ? <><div className="algorithm-output-top"><span className="section-kicker">SIMULATION RESULT</span><b>{result.algorithm}</b></div><ProbabilityChart title="Input-register measurement distribution" data={result.outcomes.map((outcome) => ({ label: outcome.label, value: outcome.probability }))}/><div className="algorithm-explanation"><b>What happened?</b><p>{result.explanation}</p>{result.oracleQueries > 0 && <small>Oracle queries in this circuit: {result.oracleQueries}</small>}</div></> : <div className="algorithm-empty"><span>∑</span><b>Your algorithm is ready to run.</b><p>Choose the parameters, then run the ideal state-vector simulation to reveal the output distribution.</p></div>}
          <ScienceNote title="Algorithm boundaries">These are small, idealized educational simulations. Query-complexity results rely on the stated oracle promises; they do not imply that every practical problem is faster on a quantum computer.</ScienceNote>
        </div>
      </div>
    </div>
  );
}
