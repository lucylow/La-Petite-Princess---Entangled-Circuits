import React, { useMemo, useState } from "react";
import { runBitFlipCodeExperiment, type LogicalErrorQubit } from "../../lib/advanced/bitFlipCode";
import { ProbabilityChart } from "./ProbabilityChart";
import { MetricCard, ScienceNote } from "./LabFrame";

export function BitFlipCodeLab() {
  const [thetaDegrees, setThetaDegrees] = useState(70);
  const [errorQubit, setErrorQubit] = useState<LogicalErrorQubit>(1);
  const experiment = useMemo(() => runBitFlipCodeExperiment(thetaDegrees * Math.PI / 180, errorQubit), [thetaDegrees, errorQubit]);
  const labels = Array.from({ length: 8 }, (_, index) => index.toString(2).padStart(3, "0"));
  const before = labels.map((label, index) => ({ label, value: experiment.probabilitiesBeforeCorrection[index] ?? 0 }));
  const after = labels.map((label, index) => ({ label, value: experiment.probabilitiesAfterCorrection[index] ?? 0 }));
  const errorLabel = errorQubit === null ? "No error" : `X error on Q${errorQubit + 1}`;
  return (
    <div className="qec-lab">
      <div className="qec-intro"><span className="section-kicker">THREE-QUBIT BIT-FLIP CODE</span><h3>Protect a logical qubit from one bit flip.</h3><p>Encode one qubit into three, calculate two parity checks, infer a single bit-flip location, and apply a correction.</p>
        <label htmlFor="qec-theta">Prepare logical input |ψ⟩ · RY({thetaDegrees}°)</label><input id="qec-theta" type="range" min="0" max="180" step="1" value={thetaDegrees} onChange={(event) => setThetaDegrees(Number(event.target.value))}/>
        <div className="qec-error-picker"><span>Inject a bit-flip error</span>{([{ value: "none", label: "None" }, { value: "0", label: "Q1" }, { value: "1", label: "Q2" }, { value: "2", label: "Q3" }] as const).map((choice) => <button key={choice.value} className={(choice.value === "none" ? errorQubit === null : errorQubit === Number(choice.value)) ? "selected" : ""} onClick={() => setErrorQubit(choice.value === "none" ? null : Number(choice.value) as 0 | 1 | 2)}>{choice.label}</button>)}</div>
        <div className="qec-syndrome"><span>Measured syndrome</span><b>{experiment.syndrome}</b><small>s₁₂ = q1 ⊕ q2 · s₂₃ = q2 ⊕ q3</small></div>
        <p className="qec-explanation">{experiment.explanation}</p>
      </div>
      <div className="qec-results"><div className="qec-metrics"><MetricCard label="Injected error" value={errorLabel} detail="Single bit-flip model"/><MetricCard label="Correction fidelity" value={`${(experiment.fidelityAfterCorrection * 100).toFixed(2)}%`} detail="Compared with encoded state"/></div>
        <div className="qec-chart-pair"><ProbabilityChart title="Corrupted encoded state" data={before}/><ProbabilityChart title="After syndrome correction" data={after}/></div>
        <div className="qec-state-lanes"><div><b>Encoding</b><span>Q1 → Q2, Q3 with two CNOT gates</span></div><div><b>Detection</b><span>Compare neighbouring bits to obtain parity syndrome</span></div><div><b>Correction</b><span>Apply X to the qubit identified by the syndrome</span></div></div>
        <ScienceNote title="What this code can—and cannot—do">The three-qubit repetition code corrects one bit-flip error under the idealized assumptions used here. It does not by itself correct phase-flip errors, arbitrary single-qubit errors, or multiple simultaneous errors. A real quantum error-correction protocol also requires careful syndrome measurement and fault-tolerant operations.</ScienceNote>
      </div>
    </div>
  );
}
