import React, { useMemo, useState } from "react";
import { applyOperation, createOperation, createZeroState, formatStateVector, probabilityDistribution, runCircuit } from "../../lib/advanced/quantumAdvanced";
import { ProbabilityChart } from "./ProbabilityChart";
import { ScienceNote } from "./LabFrame";

export function InterferenceLab() {
  const [degrees, setDegrees] = useState(90);
  const phase = degrees * Math.PI / 180;
  const operations = useMemo(() => [
    createOperation("H", 0, undefined, undefined, "interference-h-first"),
    createOperation("RZ", 0, undefined, phase, "interference-phase"),
    createOperation("H", 0, undefined, undefined, "interference-h-second"),
  ], [phase]);
  const state = useMemo(() => runCircuit(1, operations), [operations]);
  const distribution = probabilityDistribution(state);
  const stateDisplay = formatStateVector(state, 1);
  return (
    <div className="interference-layout">
      <section className="interference-control">
        <span className="section-kicker">PHASE EXPERIMENT</span>
        <h3>Turn the phase dial.</h3>
        <p>Prepare a superposition, apply a Z-axis rotation, then recombine the amplitudes with a second Hadamard gate.</p>
        <div className="phase-dial"><div className="phase-dial-ring"><div className="phase-dial-needle" style={{ transform: `rotate(${degrees}deg)` }}/><span>{degrees}°</span></div></div>
        <label htmlFor="phase-range">Relative phase</label>
        <input id="phase-range" type="range" min="0" max="360" step="1" value={degrees} onChange={(event) => setDegrees(Number(event.target.value))}/>
        <div className="phase-range-labels"><span>0°</span><span>180°</span><span>360°</span></div>
        <div className="interference-sequence"><b>H</b><i>→</i><b>RZ({degrees}°)</b><i>→</i><b>H</b></div>
      </section>
      <section className="interference-output">
        <ProbabilityChart title="Final measurement distribution" data={[{ label: "0", value: distribution[0] ?? 0 }, { label: "1", value: distribution[1] ?? 0 }]}/>
        <div className="interference-state"><span>FINAL STATE VECTOR</span><code>{stateDisplay}</code></div>
        <div className="interference-explanation"><b>What changed?</b><p>Changing the relative phase changes how the two amplitudes combine at the final Hadamard gate. At 0°, the state returns to |0⟩. At 180°, the final result is |1⟩ in this circuit convention.</p></div>
        <ScienceNote title="Global versus relative phase">Multiplying every amplitude in a state by the same complex phase does not change observable predictions. A relative phase between components can affect interference after later operations.</ScienceNote>
      </section>
    </div>
  );
}
