import React from "react";

export interface ProbabilityDatum {
  label: string;
  value: number;
  count?: number;
}

export function ProbabilityChart({
  data,
  title = "Measurement distribution",
  showCounts = false,
}: {
  data: ProbabilityDatum[];
  title?: string;
  showCounts?: boolean;
}) {
  return (
    <div className="advanced-probability-chart">
      <div className="advanced-chart-title"><b>{title}</b><span>0–100%</span></div>
      <div className="advanced-bars">
        {data.map((item) => {
          const safeValue = Math.min(1, Math.max(0, item.value));
          return (
            <div className="advanced-bar-row" key={item.label}>
              <span className="advanced-bar-label">|{item.label}⟩</span>
              <div className="advanced-bar-track" role="img" aria-label={`${item.label}: ${(safeValue * 100).toFixed(1)} percent`}>
                <span className="advanced-bar-fill" style={{ width: `${safeValue * 100}%` }} />
              </div>
              <span className="advanced-bar-value">{(safeValue * 100).toFixed(1)}%</span>
              {showCounts && <small className="advanced-bar-count">{item.count ?? 0}</small>}
            </div>
          );
        })}
      </div>
    </div>
  );
}
