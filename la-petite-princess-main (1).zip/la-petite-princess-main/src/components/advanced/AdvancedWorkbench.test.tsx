import { cleanup, render, waitFor } from "@testing-library/react";
import { renderToString } from "react-dom/server";
import { afterEach, describe, expect, it, vi } from "vitest";
import { AdvancedWorkbench } from "./AdvancedWorkbench";
import { emptyProgress, loadProgress, saveProgress } from "../../lib/advanced/progressStore";

vi.mock("../../lib/advanced/progressStore", async (importOriginal) => {
  const original = await importOriginal<typeof import("../../lib/advanced/progressStore")>();
  return { ...original, loadProgress: vi.fn(), saveProgress: vi.fn() };
});

afterEach(() => {
  cleanup();
  vi.clearAllMocks();
});

describe("workbench progress initialization", () => {
  it("does not read browser progress during server rendering", () => {
    renderToString(<AdvancedWorkbench />);
    expect(loadProgress).not.toHaveBeenCalled();
    expect(saveProgress).not.toHaveBeenCalled();
  });

  it("loads saved progress before persisting without overwriting it with defaults", async () => {
    const saved = { ...emptyProgress(), completedLessons: ["entanglement"], labRuns: 7 };
    vi.mocked(loadProgress).mockReturnValue(saved);
    render(<AdvancedWorkbench />);
    await waitFor(() => expect(saveProgress).toHaveBeenCalledWith(saved));
    expect(vi.mocked(saveProgress).mock.calls.every(([value]) => value.labRuns === 7)).toBe(true);
  });
});