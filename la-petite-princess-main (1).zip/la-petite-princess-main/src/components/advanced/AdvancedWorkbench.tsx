import React, { useEffect, useState } from "react";
import { BellTestLab } from "./BellTestLab";
import { BitFlipCodeLab } from "./BitFlipCodeLab";
import { BraidMathLab } from "./BraidMathLab";
import { ChallengeBoard } from "./ChallengeBoard";
import { CircuitComposer } from "./CircuitComposer";
import { GroverLab } from "./GroverLab";
import { InterferenceLab } from "./InterferenceLab";
import { LabFrame } from "./LabFrame";
import { LessonLibrary } from "./LessonLibrary";
import { ProgressDashboard } from "./ProgressDashboard";
import { QuizEngine } from "./QuizEngine";
import { NoiseLab } from "./NoiseLab";
import { QuantumAlgorithmsLab } from "./QuantumAlgorithmsLab";
import { ResearchNotebook } from "./ResearchNotebook";
import { StateExplorer } from "./StateExplorer";
import { DiscoveryRewards } from "./DiscoveryRewards";
import {
  clearProgress,
  emptyProgress,
  loadProgress,
  markChallengeComplete,
  markLessonComplete,
  recordLabRun,
  recordQuizAttempt,
  saveProgress,
  type LocalProgress,
} from "../../lib/advanced/progressStore";

type WorkbenchTab = "composer" | "bloch" | "bell" | "grover" | "interference" | "noise" | "qec" | "braid" | "algorithms" | "lessons" | "quiz" | "challenges" | "notebook" | "progress";
const tabs: { id: WorkbenchTab; label: string; eyebrow: string }[] = [
  { id: "composer", label: "Circuit composer", eyebrow: "BUILD" },
  { id: "bloch", label: "Bloch spheres", eyebrow: "VISUALIZE" },
  { id: "bell", label: "Bell test", eyebrow: "INVESTIGATE" },
  { id: "grover", label: "Grover search", eyebrow: "ALGORITHMS" },
  { id: "interference", label: "Interference", eyebrow: "EXPLORE" },
  { id: "noise", label: "Readout noise", eyebrow: "ENGINEERING" },
  { id: "qec", label: "Error correction", eyebrow: "ENGINEERING" },
  { id: "braid", label: "Braid mathematics", eyebrow: "TOPOLOGY" },
  { id: "algorithms", label: "Algorithms", eyebrow: "COMPUTATION" },
  { id: "lessons", label: "Lesson library", eyebrow: "LEARN" },
  { id: "quiz", label: "Knowledge check", eyebrow: "PRACTICE" },
  { id: "challenges", label: "Challenges", eyebrow: "APPLY" },
  { id: "notebook", label: "Research notebook", eyebrow: "DOCUMENT" },
  { id: "progress", label: "My progress", eyebrow: "REFLECT" },
];

export function AdvancedWorkbench() {
  const [activeTab, setActiveTab] = useState<WorkbenchTab>("composer");
  const [progress, setProgress] = useState<LocalProgress>(() => emptyProgress());
  const [progressLoaded, setProgressLoaded] = useState(false);

  useEffect(() => {
    setProgress(loadProgress());
    setProgressLoaded(true);
  }, []);

  useEffect(() => {
    if (progressLoaded) saveProgress(progress);
  }, [progress, progressLoaded]);

  const completeLesson = (lessonId: string) => setProgress((current) => markLessonComplete(current, lessonId));
  const completeChallenge = (challengeId: string) => setProgress((current) => markChallengeComplete(current, challengeId));
  const quizAttempt = (score: number) => setProgress((current) => recordQuizAttempt(current, score));
  const labRun = () => setProgress((current) => recordLabRun(current));
  const resetProgress = () => {
    const confirmed = typeof window === "undefined" || window.confirm("Clear all learning progress saved in this browser?");
    if (!confirmed) return;
    clearProgress();
    setProgress(emptyProgress());
  };

  const active = tabs.find((tab) => tab.id === activeTab) ?? tabs[0];
  if (!active) return null;

  return (
    <section className="advanced-workbench-section" aria-labelledby="advanced-workbench-title">
      <div className="advanced-workbench-heading">
        <div><span className="section-kicker">THE EXTENDED QUANTUM STUDIO</span><h2 id="advanced-workbench-title">From story to <em>scientific practice.</em></h2><p>Build circuits, inspect quantum states, test algorithms, and keep a research notebook—all inside an idealized educational simulator.</p></div>
        <div className="workbench-seal"><span>Q</span><small>STUDIO<br/>EDITION</small></div>
      </div>
      <DiscoveryRewards progress={progress} ready={progressLoaded} onNavigate={setActiveTab}/>
      <nav className="workbench-tabs" aria-label="Quantum Studio tools">
        {tabs.map((tab) => <button key={tab.id} className={activeTab === tab.id ? "active" : ""} onClick={() => setActiveTab(tab.id)}><small>{tab.eyebrow}</small><span>{tab.label}</span></button>)}
      </nav>
      <div className="workbench-active-label"><span className="section-kicker">{active.eyebrow}</span><b>{active.label}</b></div>
      {activeTab === "composer" && <LabFrame kicker="EXPERIMENT 01" title="Design a circuit" description="Use a gate palette to prepare a state and collect repeated measurement outcomes."><CircuitComposer onRun={labRun}/></LabFrame>}
      {activeTab === "bloch" && <LabFrame kicker="EXPERIMENT 02" title="See the state on a sphere" description="Inspect local qubit states, purity, and two-qubit entanglement. The sphere is a visualization of the Bloch vector."><StateExplorer/></LabFrame>}
      {activeTab === "bell" && <LabFrame kicker="EXPERIMENT 03" title="Question the classical picture" description="Change measurement settings and compare a sampled CHSH score with its theoretical value and classical bound."><BellTestLab/></LabFrame>}
      {activeTab === "grover" && <LabFrame kicker="EXPERIMENT 04" title="Search with amplitudes" description="Mark one item, reflect amplitudes about their mean, and watch the target probability grow in a four-item ideal search."><GroverLab/></LabFrame>}
      {activeTab === "interference" && <LabFrame kicker="EXPERIMENT 05" title="Follow the phase" description="A sequence of H → RZ(φ) → H shows how relative phase changes the final measurement distribution."><InterferenceLab/></LabFrame>}
      {activeTab === "noise" && <LabFrame kicker="EXPERIMENT 06" title="Model an imperfect detector" description="Apply independent readout bit-flip probabilities to an ideal two-qubit measurement distribution."><NoiseLab/></LabFrame>}
      {activeTab === "qec" && <LabFrame kicker="EXPERIMENT 07" title="Protect information with redundancy" description="Explore the three-qubit bit-flip repetition code, parity syndromes, and a simple correction procedure."><BitFlipCodeLab/></LabFrame>}
      {activeTab === "braid" && <LabFrame kicker="EXPERIMENT 08" title="A braid is a mathematical object" description="Compose braid-group generators and trace strands. This is a topology visualizer, not an anyon or quantum-state simulator."><BraidMathLab/></LabFrame>}
      {activeTab === "algorithms" && <LabFrame kicker="EXPERIMENT 09" title="Meet three quantum algorithms" description="Simulate Bernstein–Vazirani, Deutsch–Jozsa, and the quantum Fourier transform using state vectors."><QuantumAlgorithmsLab/></LabFrame>}
      {activeTab === "lessons" && <LabFrame kicker="THE FIELD GUIDE" title="Ten steps into the quantum universe" description="An ordered learning path from the first qubit to Bell tests and the mathematics of topological braids."><LessonLibrary completedLessonIds={progress.completedLessons} onComplete={completeLesson}/></LabFrame>}
      {activeTab === "quiz" && <LabFrame kicker="CHECK YOUR UNDERSTANDING" title="Practice the ideas" description="Questions span first steps, hands-on practice, and advanced quantum concepts. Explanations appear after submission."><QuizEngine onScore={quizAttempt}/></LabFrame>}
      {activeTab === "challenges" && <LabFrame kicker="THE EXPEDITION BOARD" title="Put the ideas to work" description="Challenges ask learners to make predictions, run experiments, and explain what the evidence shows."><ChallengeBoard completedIds={progress.completedChallenges} onComplete={completeChallenge}/></LabFrame>}
      {activeTab === "notebook" && <LabFrame kicker="RESEARCH PRACTICE" title="Keep a scientific record" description="Record a question, prediction, method, observations, and next steps. Export the draft as Markdown or print it."><ResearchNotebook/></LabFrame>}
      {activeTab === "progress" && <LabFrame kicker="YOUR PRIVATE FIELD NOTES" title="A record of your discoveries" description="Progress is stored only in this browser. There are no accounts, public profiles, or tracking pixels in this prototype."><ProgressDashboard progress={progress} onReset={resetProgress}/></LabFrame>}
      <p className="workbench-disclaimer">Educational state-vector simulations only. No live quantum hardware, real-world experimental data, or institutional endorsement is implied.</p>
    </section>
  );
}
