import React, { useMemo, useState } from "react";
import { LESSONS, getLessonById } from "../../data/lessons";
import type { Lesson } from "../../data/lessons";
import { ScienceNote } from "./LabFrame";
import { Button } from "../ui/button";

export function LessonLibrary({ completedLessonIds, onComplete }: { completedLessonIds: string[]; onComplete: (lessonId: string) => void }) {
  const [selectedId, setSelectedId] = useState(LESSONS.find((item) => !completedLessonIds.includes(item.id))?.id ?? LESSONS[0]?.id ?? "");
  const [showAll, setShowAll] = useState(false);
  const lesson = useMemo(() => getLessonById(selectedId) ?? LESSONS[0], [selectedId]);
  if (!lesson) return null;
  const visibleLessons = showAll ? LESSONS : LESSONS.filter((item) => item.level !== "going deeper");
  const isComplete = completedLessonIds.includes(lesson.id);
  const handleSelect = (item: Lesson) => setSelectedId(item.id);

  return (
    <div className="lesson-library-layout">
      <aside className="lesson-list-panel">
        <div className="lesson-list-heading"><span className="section-kicker">THE LEARNING PATH</span><b>{completedLessonIds.length} / {LESSONS.length} complete</b></div>
        <div className="lesson-list-items">
          {visibleLessons.map((item) => (
            <button key={item.id} className={`lesson-list-item ${selectedId === item.id ? "selected" : ""}`} onClick={() => handleSelect(item)}>
              <span className="lesson-number">{item.number}</span><span className="lesson-list-copy"><b>{item.title}</b><small>{item.subtitle}</small></span><span className="lesson-complete-mark">{completedLessonIds.includes(item.id) ? "✓" : "·"}</span>
            </button>
          ))}
        </div>
        <button className="mini-action full-width" onClick={() => setShowAll((value) => !value)}>{showAll ? "Show core path" : "Unlock deeper lessons"}</button>
      </aside>
      <article className="lesson-reader">
        <div className="lesson-reader-top"><span className="section-kicker">LESSON {lesson.number} · {lesson.level.toUpperCase()}</span><span className="lesson-duration">◷ {lesson.duration}</span></div>
        <h3>{lesson.title}</h3><p className="lesson-subtitle">{lesson.subtitle}</p>
        <div className="lesson-goal"><b>Learning goal</b><p>{lesson.goal}</p></div>
        <div className="lesson-story"><span className="lesson-ornament">✧</span><p>{lesson.story}</p></div>
        <section className="lesson-article-section"><h4>What the science says</h4><p>{lesson.explanation}</p>{lesson.equation && <div className="lesson-equation">{lesson.equation}</div>}</section>
        <section className="lesson-article-section two-columns"><div><h4>A helpful intuition</h4><p>{lesson.analogy}</p></div><div><h4>Keep the distinction clear</h4><p>{lesson.caveat}</p></div></section>
        <section className="lesson-activity"><span className="section-kicker">TRY IT</span><p>{lesson.activity}</p></section>
        <div className="lesson-vocabulary"><b>Vocabulary</b><div>{lesson.vocabulary.map((word) => <span key={word}>{word}</span>)}</div></div>
        <ScienceNote title="Checkpoint">{lesson.checkpoint}</ScienceNote>
        <div className="lesson-actions"><Button variant="expedition" disabled={isComplete} onClick={() => onComplete(lesson.id)}>{isComplete ? "Lesson completed ✓" : "Complete lesson · +50 XP"}</Button><span>Progress is stored only in this browser.</span></div>
      </article>
    </div>
  );
}
