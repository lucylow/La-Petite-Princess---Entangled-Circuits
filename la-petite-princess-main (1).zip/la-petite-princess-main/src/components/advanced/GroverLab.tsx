import React, { useMemo, useState } from "react";
import { groverSearchSpaceLabels, runGroverSearch } from "../../lib/advanced/grover";
import { ProbabilityChart } from "./ProbabilityChart";
import { ScienceNote } from "./LabFrame";

export function GroverLab() {
  const [target, setTarget] = useState("10");
  const [ran, setRan] = useState(false);
  const result = useMemo(() => runGroverSearch(2, target, 1), [target]);
  const labels = groverSearchSpaceLabels(2);
  const data = labels.map((label, index) => ({ label, value: result.probabilities[index] ?? 0 }));
  const beforeData = labels.map((label) => ({ label, value: 0.25 }));

  return (
    <div className="grover-layout">
      <section className="grover-story-card">
        <span className="section-kicker">THE MARKED PAGE</span>
        <h3>Find one item in a tiny search space.</h3>
        <p>Grover's algorithm uses an oracle to flip the phase of a marked state, then a diffusion operation to amplify its amplitude.</p>
        <label htmlFor="grover-target">Choose the hidden marked bit string</label>
        <select id="grover-target" value={target} onChange={(event) => { setTarget(event.target.value); setRan(false); }}><option value="00">|00⟩</option><option value="01">|01⟩</option><option value="10">|10⟩</option><option value="11">|11⟩</option></select>
        <button className="button button-primary" onClick={() => setRan(true)}>Run one Grover iteration ↗</button>
        <div className="grover-sequence"><span>Uniform superposition</span><i>→</i><span>Phase oracle</span><i>→</i><span>Diffusion</span><i>→</i><span>Measure</span></div>
        {ran && <div className="grover-success" role="status"><b>Amplitude amplified.</b><p>Ideal success probability for {`|${target}⟩`} is {(result.successProbability * 100).toFixed(1)}% after one iteration in this four-item search.</p></div>}
      </section>
      <section className="grover-visuals">
        <div className="grover-chart-pair"><ProbabilityChart title="Before search · uniform" data={beforeData}/><ProbabilityChart title="After oracle + diffusion" data={data}/></div>
        <div className="grover-target-metric"><span>Marked-state probability</span><b>{(result.successProbability * 100).toFixed(1)}%</b><small>One idealized iteration · N = 4</small></div>
        <ScienceNote title="What this demonstrates">This small state-vector example illustrates amplitude amplification. It does not prove quantum advantage for a practical task or connect to physical quantum hardware. The asymptotic query-complexity result for unstructured search is O(√N).</ScienceNote>
      </section>
    </div>
  );
}
