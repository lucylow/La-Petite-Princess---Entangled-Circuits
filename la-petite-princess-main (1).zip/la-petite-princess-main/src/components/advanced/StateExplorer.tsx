import React, { useMemo, useState } from "react";
import { BlochSphere } from "./BlochSphere";
import { MetricCard, ScienceNote } from "./LabFrame";
import {
  blochVectorForQubit,
  createZeroState,
  formatStateVector,
  pureTwoQubitConcurrence,
  pureTwoQubitEntanglementEntropy,
  runCircuit,
  type StateVector,
} from "../../lib/advanced/quantumAdvanced";

type StatePreset = "zero" | "plus" | "bell" | "product";

function presetState(preset: StatePreset): StateVector {
  if (preset === "zero") return createZeroState(2);
  if (preset === "plus") return runCircuit(2, [{ id: "h-q1", gate: "H", target: 0 }]);
  if (preset === "product") return runCircuit(2, [
    { id: "h-q1", gate: "H", target: 0 },
    { id: "x-q2", gate: "X", target: 1 },
  ]);
  return runCircuit(2, [
    { id: "h-q1", gate: "H", target: 0 },
    { id: "cx", gate: "CNOT", control: 0, target: 1 },
  ]);
}

export function StateExplorer() {
  const [preset, setPreset] = useState<StatePreset>("bell");
  const state = useMemo(() => presetState(preset), [preset]);
  const q1 = useMemo(() => blochVectorForQubit(state, 2, 0), [state]);
  const q2 = useMemo(() => blochVectorForQubit(state, 2, 1), [state]);
  const concurrence = pureTwoQubitConcurrence(state);
  const entropy = pureTwoQubitEntanglementEntropy(state);
  return (
    <div className="state-explorer">
      <div className="state-explorer-controls">
        <div><span className="section-kicker">CHOOSE A STATE</span><h3>Look at one qubit—and the pair.</h3><p>A Bloch sphere describes a single-qubit state. For an entangled pair, each qubit's reduced state can be mixed even when the joint two-qubit state is pure.</p></div>
        <div className="preset-buttons" role="group" aria-label="State preset">
          {([{ value: "zero", label: "|00⟩" }, { value: "plus", label: "|+⟩ on Q1" }, { value: "product", label: "Product state" }, { value: "bell", label: "Bell pair" }] as const).map((item) => <button key={item.value} className={preset === item.value ? "active" : ""} onClick={() => setPreset(item.value)}>{item.label}</button>)}
        </div>
      </div>
      <div className="state-explorer-body">
        <div className="bloch-pair"><BlochSphere vector={q1} label="Q1"/><BlochSphere vector={q2} label="Q2"/></div>
        <div className="state-explorer-summary">
          <div className="state-readout-card"><span className="section-kicker">JOINT STATE</span><code>{formatStateVector(state, 2)}</code></div>
          <div className="entanglement-metrics"><MetricCard label="Concurrence" value={concurrence.toFixed(3)} detail="0 = separable · 1 = maximally entangled"/><MetricCard label="Entanglement entropy" value={`${entropy.toFixed(3)} bits`} detail="For this pure two-qubit state"/></div>
          <ScienceNote title="Why do the spheres change?">A Bell pair is a pure joint state, but either qubit by itself is maximally mixed. The local Bloch vectors are at the centre of their spheres. This is a mathematical property of the reduced states, not a statement that the qubits are physically tangled together.</ScienceNote>
        </div>
      </div>
    </div>
  );
}
