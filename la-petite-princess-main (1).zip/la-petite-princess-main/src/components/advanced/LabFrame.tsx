import React from "react";

export function LabFrame({
  kicker,
  title,
  description,
  children,
  className = "",
}: {
  kicker: string;
  title: string;
  description?: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <section className={`advanced-frame ${className}`}>
      <div className="advanced-frame-heading">
        <div>
          <span className="section-kicker">{kicker}</span>
          <h2>{title}</h2>
          {description && <p>{description}</p>}
        </div>
        <span className="advanced-frame-seal" aria-hidden="true">✧</span>
      </div>
      {children}
    </section>
  );
}

export function MetricCard({ label, value, detail }: { label: string; value: string; detail?: string }) {
  return (
    <div className="advanced-metric">
      <span>{label}</span>
      <strong>{value}</strong>
      {detail && <small>{detail}</small>}
    </div>
  );
}

export function ScienceNote({ title = "Science note", children }: { title?: string; children: React.ReactNode }) {
  return (
    <aside className="science-note">
      <span className="science-note-mark" aria-hidden="true">✦</span>
      <div><b>{title}</b><p>{children}</p></div>
    </aside>
  );
}
