import React, { useMemo, useState } from "react";
import {
  braidPermutation,
  braidRelationPermutationCheck,
  braidWordLabel,
  buildBraidTraces,
  reduceBraidWord,
  YOUNG_BRAID_RELATION_LEFT,
  YOUNG_BRAID_RELATION_RIGHT,
  type BraidGenerator,
} from "../../lib/advanced/braidMath";

const strandPalette = ["#c28da8", "#8f83b7", "#c49f64"];

export function BraidMathLab() {
  const [word, setWord] = useState<BraidGenerator[]>([
    { index: 1, sign: 1 }, { index: 2, sign: -1 }, { index: 1, sign: 1 },
  ]);
  const traces = useMemo(() => buildBraidTraces(3, word), [word]);
  const permutation = braidPermutation(3, word);
  const add = (index: number, sign: 1 | -1) => setWord((current) => [...current, { index, sign }]);
  const relationExample = () => setWord([...YOUNG_BRAID_RELATION_LEFT]);
  const reduce = () => setWord((current) => reduceBraidWord(current));
  const identity = () => setWord([]);
  const height = Math.max(90, 45 + word.length * 54);
  return (
    <div className="braid-math-lab">
      <div className="braid-math-controls">
        <span className="section-kicker">THE MATHEMATICS OF BRAIDS</span><h3>Compose crossings. Track the strands.</h3>
        <p>In braid-group notation, σᵢ exchanges the strands currently in adjacent positions i and i+1. The inverse generator σᵢ⁻¹ reverses that crossing.</p>
        <div className="braid-generator-actions"><button onClick={() => add(1, 1)}>Add σ₁</button><button onClick={() => add(1, -1)}>Add σ₁⁻¹</button><button onClick={() => add(2, 1)}>Add σ₂</button><button onClick={() => add(2, -1)}>Add σ₂⁻¹</button></div>
        <div className="braid-word-display"><span>YOUR WORD</span><b>{braidWordLabel(word)}</b><small>{word.length} generator{word.length === 1 ? "" : "s"}</small></div>
        <div className="braid-math-actions"><button className="mini-action" onClick={reduce}>Cancel adjacent inverses</button><button className="mini-action" onClick={relationExample}>Load σ₁σ₂σ₁</button><button className="mini-action" onClick={identity}>Clear</button></div>
        <div className="braid-permutation"><span>Final strand order</span><b>{permutation.join(" → ")}</b></div>
        <div className="braid-relation-note"><b>Try the braid relation</b><p>For three strands, σ₁σ₂σ₁ = σ₂σ₁σ₂ in the braid group. The two words have the same endpoint permutation, although permutation alone is not enough to distinguish all braids.</p><button onClick={() => setWord([...YOUNG_BRAID_RELATION_RIGHT])}>Show σ₂σ₁σ₂</button><small>Permutation check: {braidRelationPermutationCheck() ? "both examples reverse the order" : "check failed"}</small></div>
      </div>
      <div className="braid-diagram-panel">
        <div className="braid-diagram-heading"><b>Strand trace</b><span>Mathematical diagram · 3 strands</span></div>
        <svg className="braid-diagram" viewBox={`0 0 360 ${height}`} role="img" aria-label={`Three-strand braid diagram for ${braidWordLabel(word)}`}>
          <rect x="1" y="1" width="358" height={height - 2} rx="14" fill="#fbf8f2" stroke="#e4d9d7"/>
          {[1, 2, 3].map((strand) => <text key={`start-${strand}`} x={30 + (strand - 1) * 150} y="12" textAnchor="middle" className="braid-diagram-label">{strand}</text>)}
          {traces.map((trace) => <path key={trace.strand} d={trace.path} fill="none" stroke={strandPalette[(trace.strand - 1) % strandPalette.length]} strokeWidth="5" strokeLinecap="round" strokeLinejoin="round"/>)}
          {permutation.map((strand, position) => <text key={`end-${strand}`} x={30 + position * 150} y={height - 7} textAnchor="middle" className="braid-diagram-label">{strand}</text>)}
        </svg>
        <div className="braid-strand-legend">{strandPalette.map((color, index) => <span key={color}><i style={{ background: color }}/>{`Strand ${index + 1}`}</span>)}</div>
        <div className="braid-history"><b>Generator history</b>{word.length === 0 ? <p>The identity braid has no crossings.</p> : <ol>{word.map((generator, index) => <li key={`${generator.index}-${generator.sign}-${index}`}>σ{generator.index}{generator.sign < 0 ? "⁻¹" : ""}</li>)}</ol>}</div>
      </div>
      <div className="braid-science-guardrail"><b>Important scientific distinction</b><p>Ordinary hair braiding is a metaphor in this story. A braid-group diagram is a mathematical object used in topology. In certain theoretical models of topological quantum computing, exchanging non-Abelian anyons is represented by braid-group operations. This is distinct from the general phenomenon of quantum entanglement. This visualizer tracks strands and permutations only; it does not simulate anyons or a quantum processor.</p></div>
    </div>
  );
}
