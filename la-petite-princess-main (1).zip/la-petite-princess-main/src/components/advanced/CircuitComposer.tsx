import React, { useMemo, useState } from "react";
import {
  createOperation,
  formatStateVector,
  probabilityDistribution,
  runCircuit,
  runShots,
  operationLabel,
  type CircuitOperation,
  type QuantumGateName,
} from "../../lib/advanced/quantumAdvanced";
import { ProbabilityChart } from "./ProbabilityChart";
import { ScienceNote } from "./LabFrame";
import { circuitToOpenQasm, circuitToQiskitPython } from "../../lib/advanced/codeExport";
import { downloadTextFile } from "../../lib/advanced/notebook";
import { CircuitVisualization } from "./CircuitVisualization";
import { CIRCUIT_PRESETS } from "../../lib/advanced/circuitFrames";
import { Button } from "../ui/button";

const basisLabels = ["00", "01", "10", "11"];

export function CircuitComposer({ onRun }: { onRun?: () => void }) {
  const [operations, setOperations] = useState<CircuitOperation[]>([]);
  const [measurement, setMeasurement] = useState<ReturnType<typeof runShots> | null>(null);
  const [shots, setShots] = useState(500);
  const [rotation, setRotation] = useState(Math.PI / 2);
  const [notice, setNotice] = useState("Start with |00⟩ and add gates to build your own two-qubit experiment.");
  const state = useMemo(() => runCircuit(2, operations), [operations]);
  const probabilities = useMemo(() => probabilityDistribution(state), [state]);

  const append = (gate: QuantumGateName, target: number, control?: number, angle?: number) => {
    const operation = createOperation(gate, target, control, angle);
    setOperations((current) => [...current, operation]);
    setMeasurement(null);
    setNotice(`${operationLabel(operation)} added. The state vector has been recalculated.`);
  };

  const reset = () => {
    setOperations([]);
    setMeasurement(null);
    setNotice("Circuit reset to |00⟩.");
  };

  const undo = () => {
    setOperations((current) => current.slice(0, -1));
    setMeasurement(null);
    setNotice("Removed the last operation and replayed the remaining circuit from |00⟩.");
  };

  const executeShots = () => {
    setMeasurement(runShots(state, 2, shots));
    onRun?.();
    setNotice(`Simulated ${shots.toLocaleString()} independent measurements from the current prepared state.`);
  };

  const runBell = () => {
    setOperations([
      createOperation("H", 0),
      createOperation("CNOT", 1, 0),
    ]);
    setMeasurement(null);
    setNotice("Bell recipe loaded: H(Q1) followed by CNOT(Q1 → Q2). This prepares |Φ+⟩ in the ideal model.");
  };

  const shotData = measurement
    ? basisLabels.map((label) => ({
        label,
        value: (measurement.counts[label] ?? 0) / measurement.totalShots,
        count: measurement.counts[label] ?? 0,
      }))
    : basisLabels.map((label, index) => ({ label, value: probabilities[index] ?? 0 }));

  return (
    <div className="composer-layout">
      <section className="composer-main">
        <div className="composer-toolbar">
          <div><span className="section-kicker">BUILD · REORDER · OBSERVE</span><h3>Two-qubit circuit composer</h3></div>
          <div className="composer-toolbar-actions"><button className="mini-action" onClick={undo} disabled={operations.length === 0}>Undo last</button><button className="mini-action" onClick={reset}>Reset</button></div>
        </div>
        <div className="circuit-preset-picker" role="group" aria-label="Circuit examples">{CIRCUIT_PRESETS.map((preset) => <Button key={preset.id} variant="expedition" size="sm" onClick={() => { setOperations(preset.operations.map((op) => ({ ...op }))); setMeasurement(null); setNotice(`${preset.title} loaded.`); }}>{preset.title}</Button>)}</div>
        <CircuitVisualization key={operations.map((operation) => operation.id).join("|")} operations={operations}/>
        <div className="composer-operation-list">
          <b>Operation sequence</b>
          {operations.length === 0 ? <p className="empty-copy">No gates yet. Choose an operation below.</p> : (
            <ol>{operations.map((operation, index) => <li key={operation.id}><span>{String(index + 1).padStart(2, "0")}</span>{operationLabel(operation)}</li>)}</ol>
          )}
        </div>
        <div className="gate-palette">
          <div className="gate-palette-heading"><span className="section-kicker">SINGLE-QUBIT GATES</span><small>Choose a target qubit</small></div>
          <div className="gate-palette-grid">
            {(["H", "X", "Y", "Z", "S", "T"] as QuantumGateName[]).map((gate) => (
              <div className="gate-choice" key={gate}><b>{gate}</b><span>{gate === "H" ? "Hadamard" : gate === "X" ? "Bit flip" : gate === "Y" ? "Y rotation" : gate === "Z" ? "Phase flip" : gate === "S" ? "Quarter phase" : "Eighth phase"}</span><div><button onClick={() => append(gate, 0)}>Q1</button><button onClick={() => append(gate, 1)}>Q2</button></div></div>
            ))}
          </div>
          <div className="gate-palette-heading gate-palette-spaced"><span className="section-kicker">TWO-QUBIT GATES</span><small>Q1 is control; Q2 is target</small></div>
          <div className="two-gate-actions"><button onClick={() => append("CNOT", 1, 0)}><b>●──⊕</b><span>CNOT Q1 → Q2</span></button><button onClick={() => append("CZ", 1, 0)}><b>●──Z</b><span>Controlled-Z</span></button><button onClick={() => append("SWAP", 1, 0)}><b>×──×</b><span>SWAP Q1 ↔ Q2</span></button></div>
          <div className="rotation-control"><div><b>Rotation angle</b><span>{(rotation * 180 / Math.PI).toFixed(0)}°</span></div><input type="range" min="-6.283" max="6.283" step="0.01745" value={rotation} onChange={(event) => setRotation(Number(event.target.value))} aria-label="Rotation angle"/><div className="rotation-buttons"><button onClick={() => append("RX", 0, undefined, rotation)}>RX · Q1</button><button onClick={() => append("RY", 0, undefined, rotation)}>RY · Q1</button><button onClick={() => append("RZ", 0, undefined, rotation)}>RZ · Q1</button><button onClick={() => append("RZ", 1, undefined, rotation)}>RZ · Q2</button></div></div>
        </div>
        <div className="circuit-export"><div><b>Take your circuit with you</b><small>Export a portable circuit description or a Qiskit Python starter.</small></div><button className="mini-action" onClick={() => downloadTextFile("la-petite-princesse-circuit.qasm", circuitToOpenQasm(2, operations), "text/plain;charset=utf-8")}>Export OpenQASM 2.0</button><button className="mini-action" onClick={() => downloadTextFile("la-petite-princesse-circuit.py", circuitToQiskitPython(2, operations), "text/x-python;charset=utf-8")}>Export Qiskit Python</button></div>
        <ScienceNote title="Circuit convention">Q1 is the least-significant bit. In a displayed two-bit label |q2 q1⟩, Q1 appears on the right. The composer always rebuilds the state from |00⟩ when operations change.</ScienceNote>
      </section>
      <aside className="composer-side">
        <div className="state-readout-card"><span className="section-kicker">LIVE STATE VECTOR</span><code>{formatStateVector(state, 2)}</code><div className="state-readout-line"><span>Normalized</span><b>✓ Yes</b></div><div className="state-readout-line"><span>Operations</span><b>{operations.length}</b></div></div>
        <div className="shot-controls"><div className="section-kicker">MEASUREMENT</div><h3>Take a collection of shots</h3><label htmlFor="shot-count">Number of shots</label><select id="shot-count" value={shots} onChange={(event) => setShots(Number(event.target.value))}><option value={100}>100 shots</option><option value={500}>500 shots</option><option value={1000}>1,000 shots</option><option value={5000}>5,000 shots</option><option value={10000}>10,000 shots</option></select><button className="button button-primary shot-run" onClick={executeShots}>Run measurements ↗</button><button className="mini-action full-width" onClick={runBell}>Load Bell-pair recipe</button></div>
        <ProbabilityChart title={measurement ? `Observed counts · ${measurement.totalShots.toLocaleString()} shots` : "Theoretical probabilities"} data={shotData} showCounts={Boolean(measurement)}/>
        {measurement && <div className="shot-summary"><b>Shot summary</b><p>Observed frequencies are estimates from a finite sample. They may differ slightly from the theoretical probabilities.</p></div>}
        <div className="composer-notice" role="status">✧ {notice}</div>
      </aside>
    </div>
  );
}
