import React, { useMemo, useState } from "react";
import { CHALLENGES, type ChallengeDifficulty } from "../../data/challenges";
import { Button } from "../ui/button";

export function ChallengeBoard({ completedIds, onComplete }: { completedIds: string[]; onComplete: (challengeId: string) => void }) {
  const [difficulty, setDifficulty] = useState<ChallengeDifficulty | "all">("all");
  const [selectedId, setSelectedId] = useState(CHALLENGES.find((item) => !completedIds.includes(item.id))?.id ?? CHALLENGES[0]?.id ?? "");
  const [checkedCriteria, setCheckedCriteria] = useState<Record<string, boolean[]>>({});
  const challenges = useMemo(() => difficulty === "all" ? CHALLENGES : CHALLENGES.filter((challenge) => challenge.difficulty === difficulty), [difficulty]);
  const selected = challenges.find((challenge) => challenge.id === selectedId) ?? challenges[0] ?? CHALLENGES[0];
  if (!selected) return null;
  const checks = checkedCriteria[selected.id] ?? selected.successCriteria.map(() => false);
  const ready = checks.length > 0 && checks.every(Boolean);
  const selectChallenge = (id: string) => setSelectedId(id);
  const toggle = (index: number) => setCheckedCriteria((current) => {
    const existing = current[selected.id] ?? selected.successCriteria.map(() => false);
    return { ...current, [selected.id]: existing.map((value, position) => position === index ? !value : value) };
  });
  const updateDifficulty = (value: ChallengeDifficulty | "all") => {
    setDifficulty(value);
    const next = value === "all" ? CHALLENGES[0] : CHALLENGES.find((challenge) => challenge.difficulty === value);
    if (next) setSelectedId(next.id);
  };

  return (
    <div className="challenge-board">
      <div className="challenge-board-sidebar">
        <div className="section-kicker">THE EXPEDITION BOARD</div><h3>Choose your challenge.</h3>
        <div className="challenge-filters">{([{ value: "all", label: "All" }, { value: "starter", label: "Starter" }, { value: "builder", label: "Builder" }, { value: "investigator", label: "Investigator" }] as const).map((item) => <button key={item.value} className={difficulty === item.value ? "selected" : ""} onClick={() => updateDifficulty(item.value)}>{item.label}</button>)}</div>
        <div className="challenge-list">{challenges.map((challenge) => <button key={challenge.id} className={`challenge-list-item ${selected.id === challenge.id ? "active" : ""}`} onClick={() => selectChallenge(challenge.id)}><span className="challenge-status">{completedIds.includes(challenge.id) ? "✓" : "◇"}</span><span><b>{challenge.title}</b><small>{challenge.difficulty} · {challenge.estimatedMinutes} min</small></span></button>)}</div>
      </div>
      <article className="challenge-detail">
        <div className="challenge-detail-top"><span className="section-kicker">{selected.difficulty.toUpperCase()} CHALLENGE</span><span>◷ {selected.estimatedMinutes} MIN</span></div>
        <h3>{selected.title}</h3><p className="challenge-objective">{selected.objective}</p>
        <div className="challenge-section"><b>Set up your experiment</b><ol>{selected.setup.map((step) => <li key={step}>{step}</li>)}</ol></div>
        <div className="challenge-task"><span className="section-kicker">YOUR TASK</span><p>{selected.task}</p></div>
        <div className="challenge-section"><b>Success criteria</b><p className="challenge-instruction">Check each item after you have evidence in your own experiment notes.</p><div className="challenge-checks">{selected.successCriteria.map((criterion, index) => <label key={criterion} className={checks[index] ? "checked" : ""}><input type="checkbox" checked={Boolean(checks[index])} onChange={() => toggle(index)}/><span>{checks[index] ? "✓" : "○"}</span>{criterion}</label>)}</div></div>
        <div className="challenge-reflection"><b>Reflect</b><p>{selected.reflection}</p></div>
        <Button variant="expedition" disabled={!ready || completedIds.includes(selected.id)} onClick={() => onComplete(selected.id)}>{completedIds.includes(selected.id) ? "Challenge completed ✓" : ready ? "Complete challenge · +100 XP" : "Complete the criteria first"}</Button>
      </article>
    </div>
  );
}
