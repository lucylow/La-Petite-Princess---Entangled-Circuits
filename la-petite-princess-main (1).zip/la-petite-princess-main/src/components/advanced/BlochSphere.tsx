import React from "react";
import type { BlochVector } from "../../lib/advanced/quantumAdvanced";

function clamp(value: number): number {
  return Math.min(1, Math.max(-1, value));
}

export function BlochSphere({ vector, label }: { vector: BlochVector; label: string }) {
  const x = clamp(vector.x);
  const y = clamp(vector.y);
  const z = clamp(vector.z);
  // A simple oblique projection: x is horizontal, z is vertical, y adds depth.
  const endX = 150 + x * 82 + y * 24;
  const endY = 124 - z * 82 - y * 18;
  const length = Math.sqrt(x * x + y * y + z * z);
  return (
    <div className="bloch-card">
      <div className="bloch-card-head"><b>{label}</b><span>Reduced-state view</span></div>
      <svg className="bloch-svg" viewBox="0 0 300 250" role="img" aria-label={`Bloch sphere for ${label}, vector x ${x.toFixed(2)}, y ${y.toFixed(2)}, z ${z.toFixed(2)}`}>
        <defs>
          <linearGradient id="blochFill" x1="0" x2="1" y1="0" y2="1"><stop offset="0" stopColor="#e5cbdc" stopOpacity=".55"/><stop offset="1" stopColor="#a99acb" stopOpacity=".12"/></linearGradient>
          <marker id="blochArrow" markerWidth="7" markerHeight="7" refX="5" refY="3" orient="auto"><path d="M0,0 L6,3 L0,6" fill="#946d9d"/></marker>
        </defs>
        <circle cx="150" cy="124" r="82" fill="url(#blochFill)" stroke="#b49bb9" strokeWidth="1.4"/>
        <ellipse cx="150" cy="124" rx="82" ry="27" fill="none" stroke="#c4b4c9" strokeDasharray="4 4"/>
        <ellipse cx="150" cy="124" rx="28" ry="82" fill="none" stroke="#c4b4c9" strokeDasharray="4 4"/>
        <path d="M55 124 H245 M150 28 V220" stroke="#a69aa8" strokeWidth="1" strokeDasharray="3 5"/>
        <path d={`M150 124 L${endX} ${endY}`} stroke="#8b628f" strokeWidth="3" strokeLinecap="round" markerEnd="url(#blochArrow)"/>
        <circle cx={endX} cy={endY} r="5" fill="#d69bb5" stroke="#fffaf3" strokeWidth="2"/>
        <text x="150" y="17" textAnchor="middle" className="bloch-axis-label">|0⟩</text>
        <text x="150" y="241" textAnchor="middle" className="bloch-axis-label">|1⟩</text>
        <text x="252" y="128" className="bloch-axis-label">+X</text>
        <text x="33" y="128" className="bloch-axis-label">−X</text>
        <text x="162" y="43" className="bloch-axis-label">+Z</text>
        <text x="162" y="211" className="bloch-axis-label">−Z</text>
      </svg>
      <div className="bloch-values">
        <span><b>X</b>{x.toFixed(3)}</span><span><b>Y</b>{y.toFixed(3)}</span><span><b>Z</b>{z.toFixed(3)}</span>
      </div>
      <div className="bloch-purity"><span>State purity</span><b>{vector.purity.toFixed(3)}</b><small>{length < 0.02 ? "No local Bloch direction: the subsystem is maximally mixed in this ideal model." : length > 0.98 ? "Near the surface: the subsystem is close to a pure state." : "Inside the sphere: the subsystem is mixed."}</small></div>
    </div>
  );
}
