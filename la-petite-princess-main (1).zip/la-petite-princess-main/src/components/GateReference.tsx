// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { useMemo, useState } from "react";
import { GATE_DEFINITIONS, type GateDefinition, type GateId } from "../quantum-engine/gates";

export interface GateReferenceProps {
  onSelect?: (gate: GateId) => void;
}

const GATE_GROUPS: Array<{ id: GateDefinition["category"]; title: string; explanation: string }> = [
  { id: "single", title: "Single-qubit gates", explanation: "Act on one qubit without a control condition." },
  { id: "rotation", title: "Parameterized rotations", explanation: "Continuously rotate or phase-shift a qubit." },
  { id: "controlled", title: "Controlled gates", explanation: "Apply an operation when one or more control qubits are |1⟩." },
  { id: "multi", title: "Multi-qubit gates", explanation: "Operate on multiple targets or controls together." },
];

export function GateReference({ onSelect }: GateReferenceProps) {
  const [query, setQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [expandedGate, setExpandedGate] = useState<GateId | null>("H");
  const results = useMemo(() => GATE_DEFINITIONS.filter((gate) => {
    const matchesCategory = selectedCategory === "all" || gate.category === selectedCategory;
    const searchable = `${gate.id} ${gate.label} ${gate.description} ${gate.educationalNote}`.toLowerCase();
    return matchesCategory && searchable.includes(query.toLowerCase().trim());
  }), [query, selectedCategory]);

  return <section className="qpro-gate-reference">
    <div className="qpro-gate-reference-heading"><span className="qpro-kicker">QUANTUM GATE ENCYCLOPEDIA</span><h3>Know the language of circuits</h3><p>Explore each operation, its mathematical role, and its teaching note. Choose a gate to send it to the circuit editor.</p></div>
    <div className="qpro-gate-reference-filters"><input aria-label="Search gate definitions" value={query} onChange={(event) => setQuery(event.currentTarget.value)} placeholder="Search gates or concepts…" /><select aria-label="Filter by gate family" value={selectedCategory} onChange={(event) => setSelectedCategory(event.currentTarget.value)}><option value="all">All gate families</option>{GATE_GROUPS.map((group) => <option key={group.id} value={group.id}>{group.title}</option>)}</select></div>
    {GATE_GROUPS.filter((group) => selectedCategory === "all" || selectedCategory === group.id).map((group) => {
      const gates = results.filter((gate) => gate.category === group.id);
      if (!gates.length) return null;
      return <div className="qpro-gate-reference-group" key={group.id}><div><b>{group.title}</b><small>{group.explanation}</small></div><div className="qpro-reference-gates">{gates.map((gate) => <article className={`qpro-reference-card ${expandedGate === gate.id ? "expanded" : ""}`} key={gate.id}>
        <button type="button" className="qpro-reference-main" onClick={() => setExpandedGate(expandedGate === gate.id ? null : gate.id)} aria-expanded={expandedGate === gate.id}><span>{gate.symbol}</span><b>{gate.label}</b><small>{gate.id}</small><i>{expandedGate === gate.id ? "−" : "+"}</i></button>
        {expandedGate === gate.id && <div className="qpro-reference-detail"><p>{gate.description}</p><small>{gate.educationalNote}</small><div><span>{gate.targetCount} target(s)</span><span>{gate.controlCount} control(s)</span><span>{gate.parameterCount} parameter(s)</span></div>{onSelect && <button type="button" onClick={() => onSelect(gate.id)}>Use this gate ↗</button>}</div>}
      </article>)}</div></div>;
    })}
    {!results.length && <div className="qpro-empty-state">No gate definitions match that search.</div>}
  </section>;
}

export default GateReference;
