// @ts-nocheck
import React, { useMemo, useState } from "react";
import { LESSONS } from "../../data/lessons";
import type { LearningProgress, NotebookEntry } from "../../education/types";

interface NotebookPanelProps {
  progress: LearningProgress;
  onSave: (entry: NotebookEntry) => void;
  onDelete: (entryId: string) => void;
}

function downloadFile(filename: string, contents: string, type: string) {
  const blob = new Blob([contents], { type });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  URL.revokeObjectURL(url);
}

export function NotebookPanel({ progress, onSave, onDelete }: NotebookPanelProps) {
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [lessonId, setLessonId] = useState("");
  const [tagInput, setTagInput] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [filter, setFilter] = useState("all");
  const [search, setSearch] = useState("");

  const entries = useMemo(() => progress.notebook
    .filter((entry) => filter === "all" || entry.lessonId === filter)
    .filter((entry) => `${entry.title} ${entry.body} ${entry.tags.join(" ")}`.toLowerCase().includes(search.toLowerCase()))
    .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()), [progress.notebook, filter, search]);

  const clearForm = () => { setTitle(""); setBody(""); setLessonId(""); setTagInput(""); setEditingId(null); };

  const editEntry = (entry: NotebookEntry) => {
    setTitle(entry.title);
    setBody(entry.body);
    setLessonId(entry.lessonId ?? "");
    setTagInput(entry.tags.join(", "));
    setEditingId(entry.id);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const submit = (event: React.FormEvent) => {
    event.preventDefault();
    if (!title.trim() || !body.trim()) return;
    const now = new Date().toISOString();
    const previous = progress.notebook.find((entry) => entry.id === editingId);
    const entry: NotebookEntry = {
      id: editingId ?? `note-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      lessonId: lessonId || null,
      title: title.trim().slice(0, 90),
      body: body.trim().slice(0, 12000),
      tags: tagInput.split(",").map((tag) => tag.trim()).filter(Boolean).slice(0, 8),
      createdAt: previous?.createdAt ?? now,
      updatedAt: now,
    };
    onSave(entry);
    clearForm();
  };

  const exportMarkdown = () => {
    const markdown = ["# La Petite Princesse · Quantum Notebook", "", `Exported ${new Date().toLocaleString()}`, "", ...progress.notebook.map((entry) => `## ${entry.title}\n\n${entry.lessonId ? `Lesson: ${LESSONS.find((lesson) => lesson.id === entry.lessonId)?.title ?? entry.lessonId}\n\n` : ""}${entry.body}\n\n${entry.tags.length ? `Tags: ${entry.tags.join(", ")}\n\n` : ""}---\n`)].join("\n");
    downloadFile("quantum-notebook.md", markdown, "text/markdown;charset=utf-8");
  };

  return (
    <section className="edu-notebook">
      <div className="edu-section-heading"><div><span className="edu-eyebrow">YOUR RESEARCH JOURNAL</span><h2>Keep the questions that matter</h2><p>Write predictions, explain a result in your own words, or save a question for later. Notes stay in this browser in this prototype.</p></div><button className="edu-secondary-button" onClick={exportMarkdown} disabled={!progress.notebook.length}>Export notes ↗</button></div>
      <div className="edu-notebook-grid">
        <form className="edu-note-editor" onSubmit={submit}>
          <div className="edu-note-editor-heading"><span>✎</span><div><b>{editingId ? "Edit your note" : "New notebook entry"}</b><small>Make the idea your own.</small></div></div>
          <label>Title<input value={title} onChange={(event) => setTitle(event.target.value)} maxLength={90} placeholder="e.g. What surprised me about phase" required /></label>
          <label>Related lesson<select value={lessonId} onChange={(event) => setLessonId(event.target.value)}><option value="">General note</option>{LESSONS.map((lesson) => <option key={lesson.id} value={lesson.id}>{lesson.title}</option>)}</select></label>
          <label>Your note<textarea value={body} onChange={(event) => setBody(event.target.value)} rows={7} maxLength={12000} placeholder="My prediction was… The simulator showed… I think this means…" required /></label>
          <label>Tags<input value={tagInput} onChange={(event) => setTagInput(event.target.value)} placeholder="qubits, questions, experiment" /></label>
          <div className="edu-note-form-actions"><button className="edu-primary-button" type="submit" disabled={!title.trim() || !body.trim()}>{editingId ? "Save changes" : "Save note"} <span>✓</span></button>{editingId && <button className="edu-secondary-button" type="button" onClick={clearForm}>Cancel</button>}</div>
          <small className="edu-private-note">Your entries are saved locally on this device. This demo does not send notes to a server.</small>
        </form>
        <div className="edu-notes-list">
          <div className="edu-notes-toolbar"><div><b>Saved entries</b><small>{progress.notebook.length} note{progress.notebook.length === 1 ? "" : "s"}</small></div><input aria-label="Search notes" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search notes…" /><select aria-label="Filter notes by lesson" value={filter} onChange={(event) => setFilter(event.target.value)}><option value="all">All lessons</option>{LESSONS.map((lesson) => <option key={lesson.id} value={lesson.id}>{lesson.title}</option>)}</select></div>
          {entries.length ? entries.map((entry) => <article className="edu-note-card" key={entry.id}><div className="edu-note-card-top"><span>{entry.lessonId ? LESSONS.find((lesson) => lesson.id === entry.lessonId)?.title ?? "Lesson note" : "General note"}</span><small>{new Date(entry.updatedAt).toLocaleDateString()}</small></div><h3>{entry.title}</h3><p>{entry.body}</p><div className="edu-note-card-bottom"><div>{entry.tags.map((tag) => <span key={tag}>#{tag}</span>)}</div><div><button onClick={() => editEntry(entry)}>Edit</button><button onClick={() => onDelete(entry.id)}>Delete</button></div></div></article>) : <div className="edu-empty-state"><span>✧</span><b>No notes found</b><p>Save your first prediction or discovery in the editor.</p></div>}
        </div>
      </div>
    </section>
  );
}
