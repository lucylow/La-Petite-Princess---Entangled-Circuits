// @ts-nocheck
import React, { useMemo } from "react";
import { LESSONS } from "../../data/lessons";
import { LEARNING_PATHS } from "../../education/curriculum";
import { buildLearningSummary, isLessonCompleted, recommendLessons } from "../../education/learningEngine";
import type { LearningProgress } from "../../education/types";

interface ProgressDashboardProps {
  progress: LearningProgress;
  onSelectLesson: (lessonId: string) => void;
  onOpenPractice: () => void;
}

const BADGE_COPY: Record<string, { title: string; description: string; symbol: string }> = {
  "first-discovery": { title: "First Discovery", description: "Completed your first lesson.", symbol: "✦" },
  "curiosity-streak": { title: "Curiosity Keeper", description: "Completed five lessons.", symbol: "∞" },
  "quantum-cartographer": { title: "Quantum Cartographer", description: "Completed every core lesson.", symbol: "⌁" },
  "careful-thinker": { title: "Careful Thinker", description: "Answered ten questions correctly.", symbol: "◇" },
  "memory-weaver": { title: "Memory Weaver", description: "Completed five spaced reviews.", symbol: "✧" },
  "lab-notebook-star": { title: "Notebook Star", description: "Earned 250 learning points.", symbol: "☆" },
};

export function ProgressDashboard({ progress, onSelectLesson, onOpenPractice }: ProgressDashboardProps) {
  const summary = useMemo(() => buildLearningSummary(progress), [progress]);
  const recommendations = useMemo(() => recommendLessons(progress), [progress]);
  const nextLessonId = recommendations.find((item) => item.blockedBy.length === 0)?.lessonId ?? recommendations[0]?.lessonId ?? LESSONS[0].id;
  const nextLesson = LESSONS.find((lesson) => lesson.id === nextLessonId) ?? LESSONS[0];

  return (
    <div className="edu-dashboard">
      <section className="edu-welcome-card">
        <div><span className="edu-eyebrow">YOUR QUANTUM JOURNEY</span><h2>Welcome back, {progress.profile.displayName}.</h2><p>Every careful question is progress. Keep following your curiosity, one idea at a time.</p><button className="edu-primary-button" onClick={() => onSelectLesson(nextLessonId)}>Continue learning <span>→</span></button></div>
        <div className="edu-welcome-orbit" aria-hidden="true"><div>ψ</div><i /><i /><i /></div>
      </section>
      <div className="edu-stat-grid">
        <article><span>LESSONS COMPLETE</span><strong>{summary.completedLessons}<small>/{summary.totalLessons}</small></strong><div className="edu-stat-track"><i style={{ width: `${summary.completionPercent}%` }} /></div></article>
        <article><span>QUESTIONS ANSWERED</span><strong>{summary.totalAttempts}</strong><small>{summary.accuracy}% correct so far</small></article>
        <article><span>LEARNING POINTS</span><strong>{summary.xp}<small>XP</small></strong><small>Level {summary.learnerLevel} explorer</small></article>
        <article><span>CURRENT STREAK</span><strong>{summary.currentStreak}<small>days</small></strong><small>{summary.dueReviews} reviews due</small></article>
      </div>
      <div className="edu-dashboard-columns">
        <section className="edu-dashboard-panel"><div className="edu-panel-heading"><div><span className="edu-eyebrow">YOUR LEARNING PATHS</span><h3>Four steps into the quantum universe</h3></div></div>{LEARNING_PATHS.map((path) => { const done = path.lessonIds.filter((id) => isLessonCompleted(progress, id)).length; const percent = Math.round((done / path.lessonIds.length) * 100); return <article className={`edu-path-progress ${path.accent}`} key={path.id}><div className="edu-path-progress-icon">{path.icon}</div><div className="edu-path-progress-main"><div><b>{path.title}</b><span>{done}/{path.lessonIds.length} lessons</span></div><p>{path.subtitle}</p><div className="edu-stat-track"><i style={{ width: `${percent}%` }} /></div></div></article>; })}</section>
        <section className="edu-dashboard-panel edu-next-panel"><div className="edu-panel-heading"><div><span className="edu-eyebrow">A GOOD NEXT STEP</span><h3>{nextLesson.title}</h3></div><span className="edu-next-ornament">✧</span></div><p>{nextLesson.goal}</p><div className="edu-next-meta"><span>{nextLesson.duration}</span><span>{nextLesson.level}</span></div><button className="edu-primary-button" onClick={() => onSelectLesson(nextLesson.id)}>Open this lesson <span>→</span></button><button className="edu-text-button" onClick={onOpenPractice}>Or warm up with practice first</button></section>
      </div>
      <div className="edu-dashboard-columns lower">
        <section className="edu-dashboard-panel"><div className="edu-panel-heading"><div><span className="edu-eyebrow">CONCEPT MASTERY ESTIMATES</span><h3>Ideas taking shape</h3></div></div>{summary.topics.length ? summary.topics.slice(0, 6).map((topic) => <div className="edu-mastery-row" key={topic.topic}><div><b>{topic.topic.replace(/-/g, " ")}</b><span>{topic.attempts} attempts</span></div><div className="edu-stat-track"><i style={{ width: `${topic.mastery}%` }} /></div><strong>{topic.mastery}%</strong></div>) : <div className="edu-empty-state compact"><span>◌</span><b>Your learning map will grow here</b><p>Answer practice questions to estimate topic mastery.</p></div>}<small className="edu-estimate-note">These are model-based learning estimates, not grades or validated measurements of ability.</small></section>
        <section className="edu-dashboard-panel"><div className="edu-panel-heading"><div><span className="edu-eyebrow">DISCOVERIES EARNED</span><h3>Your badges</h3></div><span>{summary.badges.length}/{Object.keys(BADGE_COPY).length}</span></div><div className="edu-badge-grid">{Object.entries(BADGE_COPY).map(([id, badge]) => <div className={`edu-badge ${progress.earnedBadges.includes(id) ? "earned" : "locked"}`} key={id}><span>{badge.symbol}</span><b>{badge.title}</b><small>{progress.earnedBadges.includes(id) ? badge.description : "Keep exploring to unlock"}</small></div>)}</div></section>
      </div>
    </div>
  );
}
