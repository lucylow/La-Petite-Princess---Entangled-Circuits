// @ts-nocheck
import React, { useEffect, useRef, useState } from "react";
import { LESSONS } from "../../data/lessons";
import { LEARNING_PATHS, getLevelLabel, getPathById, getPathForLesson } from "../../education/curriculum";
import {
  completeLesson, createInitialProgress, gradeReview, markActivityCompleted, recordAnswer,
  renameLearner, startLesson,
} from "../../education/learningEngine";
import { loadProgress, saveProgress } from "../../education/storage";
import type { AnswerInput, AnswerOutcome, LearningProgress, LearningTab, NotebookEntry, ReviewRating } from "../../education/types";
import { EducatorSummary } from "./EducatorSummary";
import { GlossaryExplorer } from "./GlossaryExplorer";
import { InteractiveConceptLab } from "./InteractiveConceptLab";
import { LessonPlayer } from "./LessonPlayer";
import { NotebookPanel } from "./NotebookPanel";
import { PracticeStudio } from "./PracticeStudio";
import { ProgressDashboard } from "./ProgressDashboard";
import { ReviewDeck } from "./ReviewDeck";
import "../../styles/education.css";

interface LearningAcademyProps {
  onOpenQuantumLab?: () => void;
}

const NAV_ITEMS: { id: LearningTab; label: string; compact: string }[] = [
  { id: "overview", label: "My learning", compact: "Home" },
  { id: "pathways", label: "Pathways", compact: "Paths" },
  { id: "practice", label: "Practice", compact: "Practice" },
  { id: "review", label: "Review", compact: "Review" },
  { id: "notebook", label: "Notebook", compact: "Notes" },
  { id: "glossary", label: "Glossary", compact: "Terms" },
  { id: "educator", label: "Share progress", compact: "Share" },
];

export function LearningAcademy({ onOpenQuantumLab }: LearningAcademyProps) {
  const [progress, setProgress] = useState<LearningProgress>(() => loadProgress() ?? createInitialProgress());
  const progressRef = useRef(progress);
  const [tab, setTab] = useState<LearningTab>("overview");
  const [selectedLessonId, setSelectedLessonId] = useState(LESSONS[0].id);
  const [profileName, setProfileName] = useState(progress.profile.displayName);
  const [nameEditorOpen, setNameEditorOpen] = useState(false);
  const [toast, setToast] = useState("");

  useEffect(() => {
    progressRef.current = progress;
    const saved = saveProgress(progress);
    if (!saved) setToast("Progress could not be saved in this browser. You can still use the learning tools during this session.");
  }, [progress]);

  const commit = (transform: (current: LearningProgress) => LearningProgress) => {
    const next = transform(progressRef.current);
    progressRef.current = next;
    setProgress(next);
  };

  const openLesson = (lessonId: string) => {
    setSelectedLessonId(lessonId);
    commit((current) => startLesson(current, lessonId));
    setTab("lesson");
    setToast("");
  };

  const handleAnswer = (input: AnswerInput): AnswerOutcome => {
    const result = recordAnswer(progressRef.current, input);
    progressRef.current = result.progress;
    setProgress(result.progress);
    return result.outcome;
  };

  const handleCompleteLesson = (lessonId: string) => {
    commit((current) => completeLesson(current, lessonId));
    setToast("Lesson complete — your discovery has been recorded.");
  };

  const handleReviewGrade = (questionId: string, rating: ReviewRating) => {
    commit((current) => gradeReview(current, questionId, rating));
  };

  const handleSaveNote = (entry: NotebookEntry) => {
    commit((current) => ({
      ...current,
      notebook: [entry, ...current.notebook.filter((note) => note.id !== entry.id)].slice(0, 200),
    }));
    setToast("Notebook entry saved on this device.");
  };

  const handleDeleteNote = (entryId: string) => {
    commit((current) => ({ ...current, notebook: current.notebook.filter((entry) => entry.id !== entryId) }));
  };

  const saveName = () => {
    commit((current) => renameLearner(current, profileName));
    setNameEditorOpen(false);
  };

  const completeMiniActivity = () => {
    commit((current) => markActivityCompleted(current, "Quantum concept laboratory"));
    setToast("Experiment recorded. +15 learning points.");
  };

  const activeLesson = LESSONS.find((lesson) => lesson.id === selectedLessonId) ?? LESSONS[0];
  const activePath = getPathForLesson(activeLesson.id);

  return (
    <section className="edu-academy-shell">
      <div className="edu-academy-hero">
        <div className="edu-academy-hero-copy"><span className="edu-eyebrow">THE LITTLE SCIENTIST'S FIELD GUIDE</span><h1>Learn quantum.<br /><em>Untangle the universe.</em></h1><p>A story-led academy with real science, interactive experiments, practice that adapts, and a notebook for your discoveries.</p><div className="edu-academy-hero-tags"><span>✦ Clear explanations</span><span>⌁ Hands-on experiments</span><span>∞ Your own pace</span></div></div>
        <div className="edu-academy-hero-art" aria-hidden="true"><div className="edu-academy-orbit orbit-one" /><div className="edu-academy-orbit orbit-two" /><div className="edu-academy-orbit orbit-three" /><div className="edu-academy-hero-core">ψ</div><span className="edu-academy-star star-a">✦</span><span className="edu-academy-star star-b">✧</span><span className="edu-academy-star star-c">✦</span><div className="edu-academy-hero-note">curiosity<br />is a superpower</div></div>
      </div>

      <div className="edu-academy-toolbar">
        <div className="edu-learner-chip"><span className="edu-learner-avatar">{progress.profile.displayName.trim().charAt(0).toUpperCase() || "Q"}</span><span><b>{progress.profile.displayName}</b><small>Level {progress.profile.level} · {progress.profile.xp} XP</small></span><button aria-label="Edit learner name" onClick={() => setNameEditorOpen((open) => !open)}>✎</button></div>
        <nav className="edu-academy-nav" aria-label="Learning academy sections">{NAV_ITEMS.map((item) => <button key={item.id} className={tab === item.id || (item.id === "pathways" && tab === "lesson") ? "active" : ""} onClick={() => setTab(item.id)}><span>{item.compact}</span><small>{item.label}</small></button>)}</nav>
      </div>
      {nameEditorOpen && <div className="edu-name-editor"><label htmlFor="learner-name">What should we call you?</label><input id="learner-name" value={profileName} onChange={(event) => setProfileName(event.target.value)} maxLength={36} /><button onClick={saveName}>Save name</button><button onClick={() => setNameEditorOpen(false)}>Cancel</button></div>}
      {toast && <div className="edu-toast" role="status"><span>✧</span>{toast}<button onClick={() => setToast("")} aria-label="Dismiss notification">×</button></div>}

      <div className="edu-academy-content">
        {tab === "overview" && <><ProgressDashboard progress={progress} onSelectLesson={openLesson} onOpenPractice={() => setTab("practice")} /><InteractiveConceptLab /><div className="edu-activity-complete-row"><span>Did you make a prediction or test a setting?</span><button onClick={completeMiniActivity}>Record this experiment +15 XP</button></div></>}

        {tab === "pathways" && <section className="edu-pathways-page"><div className="edu-section-heading"><div><span className="edu-eyebrow">CHOOSE YOUR ADVENTURE</span><h2>Four paths through the quantum universe</h2><p>Each path introduces a connected set of concepts. Complete the foundations first, or revisit a topic whenever you need it.</p></div></div><div className="edu-pathway-grid">{LEARNING_PATHS.map((path) => { const done = path.lessonIds.filter((id) => progress.lessonProgress[id]?.completedAt).length; return <article className={`edu-pathway-card ${path.accent}`} key={path.id}><div className="edu-pathway-card-top"><span>{path.icon}</span><small>{getLevelLabel(path.level)} · {path.estimatedHours.toFixed(1)} hr</small></div><h3>{path.title}</h3><h4>{path.subtitle}</h4><p>{path.description}</p><div className="edu-pathway-outcome"><b>YOU WILL BE ABLE TO</b><span>{path.outcome}</span></div><div className="edu-pathway-progress"><span>{done}/{path.lessonIds.length} lessons completed</span><div className="edu-stat-track"><i style={{ width: `${(done / path.lessonIds.length) * 100}%` }} /></div></div><div className="edu-pathway-lessons">{path.lessonIds.map((id, index) => { const lesson = LESSONS.find((item) => item.id === id)!; const completed = Boolean(progress.lessonProgress[id]?.completedAt); return <button key={id} onClick={() => openLesson(id)}><span>{completed ? "✓" : String(index + 1).padStart(2, "0")}</span><b>{lesson.title}</b><small>{lesson.duration}</small><i>→</i></button>; })}</div></article>; })}</div></section>}

        {tab === "lesson" && <div className="edu-lesson-view"><div className="edu-lesson-breadcrumb"><button onClick={() => setTab("pathways")}>Pathways</button><span>/</span><span>{activePath?.title ?? "Learning"}</span><span>/</span><b>{activeLesson.title}</b></div><LessonPlayer lessonId={selectedLessonId} progress={progress} onProgressChange={(next) => commit(() => next)} onAnswer={handleAnswer} onComplete={handleCompleteLesson} onOpenLab={() => onOpenQuantumLab?.()} onSelectLesson={openLesson} onBackToPathways={() => setTab("pathways")} /></div>}

        {tab === "practice" && <PracticeStudio progress={progress} onAnswer={handleAnswer} />}
        {tab === "review" && <ReviewDeck progress={progress} onGrade={handleReviewGrade} />}
        {tab === "notebook" && <NotebookPanel progress={progress} onSave={handleSaveNote} onDelete={handleDeleteNote} />}
        {tab === "glossary" && <GlossaryExplorer />}
        {tab === "educator" && <EducatorSummary progress={progress} onImport={(next) => { progressRef.current = next; setProgress(next); setToast("Progress file imported into this browser."); }} />}
      </div>
      <div className="edu-academy-disclaimer"><span>✦</span><p>Learning science note: this platform uses simplified ideal simulations and a prototype learning model. It is educational software—not a physical quantum computer, a formal course credential, or a high-stakes assessment.</p></div>
    </section>
  );
}
