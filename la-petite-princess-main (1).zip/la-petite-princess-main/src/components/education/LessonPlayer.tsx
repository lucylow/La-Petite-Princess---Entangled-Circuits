// @ts-nocheck
import React, { useEffect, useMemo, useState } from "react";
import { LESSONS } from "../../data/lessons";
import { getLessonMetadata } from "../../education/curriculum";
import { questionsForLesson } from "../../education/questionBank";
import type { AnswerInput, AnswerOutcome, ConfidenceLevel, LearningProgress } from "../../education/types";

interface LessonPlayerProps {
  lessonId: string;
  progress: LearningProgress;
  onProgressChange: (next: LearningProgress) => void;
  onAnswer: (input: AnswerInput) => AnswerOutcome;
  onComplete: (lessonId: string) => void;
  onOpenLab: () => void;
  onSelectLesson: (lessonId: string) => void;
  onBackToPathways: () => void;
}

type LessonStage = "story" | "understand" | "experiment" | "checkpoint";

export function LessonPlayer({ lessonId, progress, onProgressChange, onAnswer, onComplete, onOpenLab, onSelectLesson, onBackToPathways }: LessonPlayerProps) {
  const lesson = LESSONS.find((item) => item.id === lessonId) ?? LESSONS[0];
  const metadata = getLessonMetadata(lesson.id);
  const question = useMemo(() => questionsForLesson(lesson.id)[0], [lesson.id]);
  const [stage, setStage] = useState<LessonStage>("story");
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [confidence, setConfidence] = useState<ConfidenceLevel>("unsure");
  const [showHint, setShowHint] = useState(false);
  const [feedback, setFeedback] = useState<AnswerOutcome | null>(null);
  const [startedAt, setStartedAt] = useState(() => Date.now());

  const lessonProgress = progress.lessonProgress[lesson.id];
  const completedObjectives = lessonProgress?.completedObjectives ?? [];
  const objectiveCount = metadata?.objectives.length ?? 0;
  const allObjectivesDone = objectiveCount > 0 && completedObjectives.length >= objectiveCount;

  useEffect(() => {
    setStage("story");
    setSelectedOption(null);
    setFeedback(null);
    setShowHint(false);
    setConfidence("unsure");
    setStartedAt(Date.now());
  }, [lesson.id]);

  const toggleObjective = (objectiveId: string) => {
    const current = progress.lessonProgress[lesson.id] ?? {
      startedAt: new Date().toISOString(), completedAt: null, completedObjectives: [], lastStep: 0, revisitCount: 0,
    };
    const nextObjectives = current.completedObjectives.includes(objectiveId)
      ? current.completedObjectives.filter((item) => item !== objectiveId)
      : [...current.completedObjectives, objectiveId];
    onProgressChange({
      ...progress,
      lessonProgress: {
        ...progress.lessonProgress,
        [lesson.id]: { ...current, completedObjectives: nextObjectives },
      },
    });
  };

  const checkAnswer = () => {
    if (!question || !selectedOption) return;
    const result = onAnswer({
      question,
      selectedOptionId: selectedOption,
      confidence,
      usedHint: showHint,
      responseMs: Date.now() - startedAt,
    });
    setFeedback(result);
  };

  const stages: { id: LessonStage; label: string; number: string }[] = [
    { id: "story", label: "The story", number: "01" },
    { id: "understand", label: "The science", number: "02" },
    { id: "experiment", label: "Try it", number: "03" },
    { id: "checkpoint", label: "Check understanding", number: "04" },
  ];

  const nextLesson = LESSONS[LESSONS.findIndex((item) => item.id === lesson.id) + 1];

  return (
    <div className="edu-lesson-player">
      <div className="edu-lesson-topline">
        <button className="edu-back-link" onClick={onBackToPathways}>← Lesson overview</button>
        <span>{lesson.number} / {String(LESSONS.length).padStart(2, "0")}</span>
        <span>{lesson.duration}</span>
      </div>
      <div className="edu-lesson-heading">
        <div><span className="edu-eyebrow">{lesson.level.toUpperCase()} · {metadata?.estimatedMinutes ?? 10} MINUTES</span><h2>{lesson.title}</h2><p>{lesson.subtitle}</p></div>
        {lessonProgress?.completedAt && <span className="edu-completed-pill">✓ Completed</span>}
      </div>
      <div className="edu-stage-nav" role="tablist" aria-label="Lesson sections">
        {stages.map((item) => <button key={item.id} role="tab" aria-selected={stage === item.id} className={stage === item.id ? "active" : ""} onClick={() => setStage(item.id)}><small>{item.number}</small><span>{item.label}</span></button>)}
      </div>

      {stage === "story" && (
        <div className="edu-reading-layout">
          <article className="edu-story-card"><span className="edu-story-mark">✦</span><span className="edu-eyebrow">A PAGE FROM HER NOTEBOOK</span><p className="edu-story-text">{lesson.story}</p><div className="edu-story-lesson"><b>The question she asks</b><p>{lesson.checkpoint}</p></div></article>
          <aside className="edu-side-note"><span className="edu-eyebrow">YOUR MISSION</span><h3>By the end, you can…</h3><ul>{metadata?.objectives.map((objective) => <li key={objective.id}>{objective.label}</li>)}</ul><button className="edu-primary-button" onClick={() => setStage("understand")}>Turn the page <span>→</span></button></aside>
        </div>
      )}

      {stage === "understand" && (
        <div className="edu-science-reading">
          <div className="edu-explanation-card"><span className="edu-eyebrow">THE SCIENCE, CLEARLY</span><p>{lesson.explanation}</p>{lesson.equation && <div className="edu-equation-card"><small>KEY EQUATION</small><code>{lesson.equation}</code></div>}</div>
          <div className="edu-two-notes"><article><span>✧</span><b>An intuition</b><p>{lesson.analogy}</p></article><article className="edu-caveat"><span>!</span><b>Keep the science precise</b><p>{lesson.caveat}</p></article></div>
          <div className="edu-objectives"><div className="edu-objectives-title"><div><span className="edu-eyebrow">LEARNING OBJECTIVES</span><h3>What can you explain now?</h3></div><span>{completedObjectives.length}/{objectiveCount} checked</span></div>{metadata?.objectives.map((objective) => <label className="edu-objective-check" key={objective.id}><input type="checkbox" checked={completedObjectives.includes(objective.id)} onChange={() => toggleObjective(objective.id)} /><span><b>{objective.label}</b><small>{objective.checkFor}</small></span></label>)}</div>
          <div className="edu-stage-actions"><button className="edu-secondary-button" onClick={() => setStage("story")}>← Back to story</button><button className="edu-primary-button" onClick={() => setStage("experiment")}>Try an experiment <span>→</span></button></div>
        </div>
      )}

      {stage === "experiment" && (
        <div className="edu-experiment-card">
          <div className="edu-experiment-intro"><span className="edu-eyebrow">A SMALL EXPERIMENT</span><h3>Turn the idea into an observation.</h3><p>{lesson.activity}</p></div>
          <div className="edu-experiment-actions"><button className="edu-primary-button" onClick={onOpenLab}>Open the Quantum Lab <span>↗</span></button><button className="edu-secondary-button" onClick={() => setStage("checkpoint")}>I explored it — check me</button></div>
          <div className="edu-experiment-reminder"><b>Record before you run:</b><p>What do you predict will happen? What result would support your prediction? What result would make you rethink it?</p></div>
        </div>
      )}

      {stage === "checkpoint" && (
        <div className="edu-checkpoint-card">
          <div><span className="edu-eyebrow">RETRIEVE, DON'T JUST REREAD</span><h3>Check your understanding</h3><p>{question?.prompt ?? lesson.checkpoint}</p></div>
          {question ? <>
            <div className="edu-answer-options">{question.options.map((option) => <button key={option.id} className={`edu-answer-option ${selectedOption === option.id ? "selected" : ""} ${feedback && option.id === question.correctOptionId ? "is-correct" : ""}`} onClick={() => { setSelectedOption(option.id); setFeedback(null); }} disabled={Boolean(feedback)}><span>{option.id.toUpperCase()}</span>{option.label}<i>{feedback && option.id === question.correctOptionId ? "✓" : ""}</i></button>)}</div>
            <div className="edu-confidence-control"><label htmlFor="lesson-confidence">How sure do you feel?</label><select id="lesson-confidence" value={confidence} onChange={(event) => setConfidence(event.target.value as ConfidenceLevel)}><option value="guessing">I am guessing</option><option value="unsure">Somewhat sure</option><option value="confident">Confident</option></select></div>
            {!feedback && <div className="edu-check-actions"><button className="edu-hint-button" onClick={() => setShowHint(true)}>Need a hint?</button><button className="edu-primary-button" disabled={!selectedOption} onClick={checkAnswer}>Check answer <span>→</span></button></div>}
            {showHint && !feedback && <div className="edu-hint-box"><b>Hint</b><p>{question.hint}</p></div>}
            {feedback && <div className={`edu-answer-feedback ${feedback.correct ? "success" : "retry"}`}><b>{feedback.correct ? "That is right. Keep going." : "A useful mistake. Let's untangle it."}</b><p>{feedback.correct ? feedback.explanation : feedback.misconceptionFeedback}</p><p>{feedback.explanation}</p><div className="edu-mastery-change"><span>Estimated concept mastery</span><b>{Math.round(feedback.masteryBefore * 100)}% → {Math.round(feedback.masteryAfter * 100)}%</b></div><button className="edu-secondary-button" onClick={() => { setFeedback(null); setSelectedOption(null); setShowHint(false); }}>Try another answer</button></div>}
          </> : <p>{lesson.checkpoint}</p>}
          <div className="edu-stage-actions"><button className="edu-secondary-button" onClick={() => setStage("experiment")}>← Back to experiment</button><button className="edu-primary-button" disabled={!allObjectivesDone} onClick={() => onComplete(lesson.id)}>Complete lesson <span>✓</span></button></div>
          {!allObjectivesDone && <small className="edu-completion-hint">Check all learning objectives in the science section to complete this lesson.</small>}
        </div>
      )}

      {lessonProgress?.completedAt && <div className="edu-next-lesson-banner"><span>✦</span><div><b>Discovery recorded</b><p>{nextLesson ? `Next up: ${nextLesson.title}` : "You have reached the end of this learning path."}</p></div>{nextLesson && <button onClick={() => onSelectLesson(nextLesson.id)}>Continue →</button>}</div>}
    </div>
  );
}
