// @ts-nocheck
import React, { useMemo, useState } from "react";
import { ACADEMY_QUESTIONS } from "../../education/questionBank";
import { masteryFor, topicKey } from "../../education/learningEngine";
import type { AnswerInput, AnswerOutcome, ConfidenceLevel, LearningLevel, LearningProgress } from "../../education/types";

interface PracticeStudioProps {
  progress: LearningProgress;
  onAnswer: (input: AnswerInput) => AnswerOutcome;
}

export function PracticeStudio({ progress, onAnswer }: PracticeStudioProps) {
  const [level, setLevel] = useState<LearningLevel | "adaptive">("adaptive");
  const [topic, setTopic] = useState("all");
  const [questionId, setQuestionId] = useState<string | null>(null);
  const [selected, setSelected] = useState<string | null>(null);
  const [confidence, setConfidence] = useState<ConfidenceLevel>("unsure");
  const [hintOpen, setHintOpen] = useState(false);
  const [result, setResult] = useState<AnswerOutcome | null>(null);
  const [answeredAt, setAnsweredAt] = useState(Date.now());
  const [sessionCount, setSessionCount] = useState(0);

  const availableTopics = useMemo(() => [...new Set(ACADEMY_QUESTIONS.map((question) => question.topic))].sort(), []);
  const eligibleQuestions = useMemo(() => ACADEMY_QUESTIONS.filter((question) => {
    const levelMatches = level === "adaptive" || question.level === level;
    const topicMatches = topic === "all" || question.topic === topic;
    return levelMatches && topicMatches;
  }), [level, topic]);

  const selectedQuestion = eligibleQuestions.find((question) => question.id === questionId) ?? null;
  const correctCount = progress.attempts.filter((attempt) => attempt.correct).length;

  const chooseQuestion = () => {
    if (!eligibleQuestions.length) return;
    const question = [...eligibleQuestions].sort((a, b) => {
      if (level !== "adaptive") return 0;
      const aMastery = masteryFor(progress, a.topic).probabilityKnown;
      const bMastery = masteryFor(progress, b.topic).probabilityKnown;
      const aAttempts = masteryFor(progress, a.topic).attempts;
      const bAttempts = masteryFor(progress, b.topic).attempts;
      return (aMastery + Math.min(0.2, aAttempts * 0.025)) - (bMastery + Math.min(0.2, bAttempts * 0.025)) || Math.random() - 0.5;
    });
    const pool = question.slice(0, Math.min(4, question.length));
    const next = pool[Math.floor(Math.random() * pool.length)];
    setQuestionId(next.id);
    setSelected(null);
    setConfidence("unsure");
    setHintOpen(false);
    setResult(null);
    setAnsweredAt(Date.now());
  };

  const submit = () => {
    if (!selectedQuestion || !selected) return;
    const outcome = onAnswer({
      question: selectedQuestion,
      selectedOptionId: selected,
      confidence,
      usedHint: hintOpen,
      responseMs: Date.now() - answeredAt,
    });
    setResult(outcome);
    setSessionCount((count) => count + 1);
  };

  return (
    <section className="edu-practice-studio">
      <div className="edu-section-heading"><div><span className="edu-eyebrow">RETRIEVAL PRACTICE</span><h2>Practice makes understanding stick</h2><p>Short questions, useful explanations, and a small nudge toward the concepts that need another look.</p></div><div className="edu-practice-score"><strong>{sessionCount}</strong><small>THIS SESSION</small></div></div>
      <div className="edu-practice-controls">
        <label>Difficulty<select value={level} onChange={(event) => { setLevel(event.target.value as LearningLevel | "adaptive"); setQuestionId(null); setResult(null); }}><option value="adaptive">Adaptive · suggest my next step</option><option value="curious">First steps</option><option value="practitioner">Building intuition</option><option value="researcher">Going deeper</option></select></label>
        <label>Topic<select value={topic} onChange={(event) => { setTopic(event.target.value); setQuestionId(null); setResult(null); }}><option value="all">All topics</option>{availableTopics.map((item) => <option key={item} value={item}>{item}</option>)}</select></label>
        <div className="edu-practice-stat"><small>ACCURACY SO FAR</small><b>{progress.attempts.length ? Math.round((correctCount / progress.attempts.length) * 100) : 0}%</b></div>
      </div>
      {!selectedQuestion ? (
        <div className="edu-practice-empty"><span className="edu-empty-star">✧</span><h3>Ready for a little brain stretch?</h3><p>{eligibleQuestions.length} question{eligibleQuestions.length === 1 ? "" : "s"} available in this selection. Adaptive mode starts with topics that look less familiar.</p><button className="edu-primary-button" onClick={chooseQuestion} disabled={!eligibleQuestions.length}>Start practice <span>→</span></button></div>
      ) : (
        <article className="edu-question-card">
          <div className="edu-question-meta"><span>{selectedQuestion.topic}</span><span>{selectedQuestion.level === "curious" ? "FIRST STEPS" : selectedQuestion.level === "practitioner" ? "PRACTITIONER" : "RESEARCHER"}</span><span>{selectedQuestion.estimatedSeconds}s</span></div>
          <h3>{selectedQuestion.prompt}</h3>
          <div className="edu-answer-options">{selectedQuestion.options.map((option) => <button key={option.id} disabled={Boolean(result)} className={`edu-answer-option ${selected === option.id ? "selected" : ""} ${result && option.id === selectedQuestion.correctOptionId ? "is-correct" : ""} ${result && option.id === selected && !result.correct ? "is-wrong" : ""}`} onClick={() => setSelected(option.id)}><span>{option.id.toUpperCase()}</span>{option.label}<i>{result && option.id === selectedQuestion.correctOptionId ? "✓" : result && option.id === selected ? "×" : ""}</i></button>)}</div>
          {!result && <div className="edu-question-footer"><div className="edu-question-tools"><button className="edu-hint-button" onClick={() => setHintOpen((open) => !open)}>{hintOpen ? "Hide hint" : "Show hint"}</button><label>Confidence<select value={confidence} onChange={(event) => setConfidence(event.target.value as ConfidenceLevel)}><option value="guessing">Guessing</option><option value="unsure">Somewhat sure</option><option value="confident">Confident</option></select></label></div><button className="edu-primary-button" disabled={!selected} onClick={submit}>Check answer <span>→</span></button></div>}
          {hintOpen && !result && <div className="edu-hint-box"><b>A small clue</b><p>{selectedQuestion.hint}</p></div>}
          {result && <div className={`edu-answer-feedback ${result.correct ? "success" : "retry"}`}><b>{result.correct ? "Nicely reasoned." : "A useful moment to learn."}</b><p>{result.correct ? result.explanation : selectedQuestion.misconceptionFeedback}</p><p>{selectedQuestion.explanation}</p><div className="edu-feedback-footer"><span>Estimated mastery: {Math.round(result.masteryBefore * 100)}% → {Math.round(result.masteryAfter * 100)}%</span><span>+{result.xpEarned} XP</span></div><button className="edu-primary-button" onClick={chooseQuestion}>Next question <span>→</span></button></div>}
        </article>
      )}
      <div className="edu-practice-tip"><span>✦</span><p><b>Learning tip:</b> Try to explain why an answer is correct before looking at the feedback. Retrieval practice is more powerful when you attempt to remember first.</p></div>
    </section>
  );
}
