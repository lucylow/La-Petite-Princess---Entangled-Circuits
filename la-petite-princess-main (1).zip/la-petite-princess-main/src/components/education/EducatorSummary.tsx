// @ts-nocheck
import React, { useMemo, useState } from "react";
import { LESSONS } from "../../data/lessons";
import { buildLearningSummary, getLearningInsights, isLessonCompleted } from "../../education/learningEngine";
import { exportProgress, importProgress } from "../../education/storage";
import type { LearningProgress } from "../../education/types";

interface EducatorSummaryProps { progress: LearningProgress; onImport: (progress: LearningProgress) => void; }

function downloadJson(filename: string, contents: string) {
  const blob = new Blob([contents], { type: "application/json;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  URL.revokeObjectURL(url);
}

export function EducatorSummary({ progress, onImport }: EducatorSummaryProps) {
  const summary = useMemo(() => buildLearningSummary(progress), [progress]);
  const insights = useMemo(() => getLearningInsights(progress), [progress]);
  const [copied, setCopied] = useState(false);
  const [importMessage, setImportMessage] = useState("");

  const exportJson = () => downloadJson("la-petite-princesse-learning-progress.json", exportProgress(progress));
  const summaryText = [
    "LA PETITE PRINCESSE · QUANTUM ACADEMY LEARNING SUMMARY",
    `Learner label: ${progress.profile.displayName}`,
    `Lessons: ${summary.completedLessons}/${summary.totalLessons} (${summary.completionPercent}%)`,
    `Practice attempts: ${summary.totalAttempts}`,
    `Practice accuracy: ${summary.accuracy}%`,
    `Learning points: ${summary.xp}`,
    `Current streak: ${summary.currentStreak} days`,
    "",
    ...LESSONS.map((lesson) => `${isLessonCompleted(progress, lesson.id) ? "[x]" : "[ ]"} ${lesson.title}`),
    "",
    "Learning reflections:",
    ...insights.map((insight) => `- ${insight}`),
    "",
    "This summary is generated from local prototype activity. It is not a formal assessment or validated measure of ability.",
  ].join("\n");

  const handleImport = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    try {
      const imported = importProgress(await file.text());
      onImport(imported);
      setImportMessage("Progress imported successfully.");
    } catch (error) {
      setImportMessage(error instanceof Error ? error.message : "Could not read that progress file.");
    }
    event.target.value = "";
  };

  const copySummary = async () => {
    try {
      await navigator.clipboard.writeText(summaryText);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      downloadJson("learning-summary.txt", JSON.stringify({ text: summaryText }));
    }
  };

  return (
    <section className="edu-educator-summary">
      <div className="edu-section-heading"><div><span className="edu-eyebrow">SHARE THE LEARNING, NOT THE PRESSURE</span><h2>A simple progress summary</h2><p>A transparent snapshot of lessons, practice attempts, and areas to revisit. This page is local to the current browser.</p></div><div className="edu-report-mark">✧<small>LEARNING<br />RECORD</small></div></div>
      <div className="edu-report-grid">
        <article><small>LESSONS COMPLETE</small><strong>{summary.completedLessons}/{summary.totalLessons}</strong></article>
        <article><small>QUESTIONS ATTEMPTED</small><strong>{summary.totalAttempts}</strong></article>
        <article><small>ACCURACY IN PRACTICE</small><strong>{summary.accuracy}%</strong></article>
        <article><small>POINTS EARNED</small><strong>{summary.xp} XP</strong></article>
      </div>
      <div className="edu-report-two-col"><div className="edu-report-card"><span className="edu-eyebrow">LESSON CHECKLIST</span>{LESSONS.map((lesson) => <div className="edu-report-lesson" key={lesson.id}><span className={isLessonCompleted(progress, lesson.id) ? "done" : "pending"}>{isLessonCompleted(progress, lesson.id) ? "✓" : "○"}</span><span>{lesson.title}</span><small>{isLessonCompleted(progress, lesson.id) ? "Completed" : "Not yet"}</small></div>)}</div><div className="edu-report-card"><span className="edu-eyebrow">SUGGESTED CONVERSATION STARTERS</span>{insights.map((insight) => <p className="edu-report-insight" key={insight}>✧ {insight}</p>)}<div className="edu-report-caveat"><b>What these numbers mean</b><p>Completion records indicate that a lesson was marked complete. Practice accuracy is descriptive, while mastery estimates use a simplified Bayesian Knowledge Tracing model. Neither should be used alone for high-stakes decisions.</p></div></div></div>
      <div className="edu-report-actions"><button className="edu-primary-button" onClick={exportJson}>Export progress data <span>↓</span></button><label className="edu-secondary-button edu-import-label">Import progress<input type="file" accept="application/json,.json" onChange={handleImport} /></label><button className="edu-secondary-button" onClick={copySummary}>{copied ? "Copied ✓" : "Copy readable summary"}</button><button className="edu-secondary-button" onClick={() => window.print()}>Print summary ↗</button></div>{importMessage && <p className="edu-import-message" role="status">{importMessage}</p>}
      <p className="edu-privacy-note"><b>Privacy note:</b> This prototype stores the learning record in browser local storage. There is no teacher account, cloud sync, classroom roster, or server-side reporting in this add-on.</p>
    </section>
  );
}
