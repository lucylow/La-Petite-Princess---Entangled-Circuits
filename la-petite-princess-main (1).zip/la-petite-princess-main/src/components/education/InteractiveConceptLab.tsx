// @ts-nocheck
import React, { useMemo, useState } from "react";
import "../../styles/education.css";

type DemoMode = "amplitudes" | "shots" | "interference" | "entanglement";

function percent(value: number): string {
  return `${(value * 100).toFixed(1)}%`;
}

function ProbabilityMeter({ label, value, tone }: { label: string; value: number; tone: "rose" | "violet" }) {
  return (
    <div className="edu-probability-meter">
      <div className="edu-probability-meta"><strong>{label}</strong><span>{percent(value)}</span></div>
      <div className="edu-meter-track"><div className={`edu-meter-fill ${tone}`} style={{ width: `${Math.max(0, Math.min(100, value * 100))}%` }} /></div>
    </div>
  );
}

export function InteractiveConceptLab() {
  const [mode, setMode] = useState<DemoMode>("amplitudes");
  const [theta, setTheta] = useState(90);
  const [phase, setPhase] = useState(180);
  const [shots, setShots] = useState(100);
  const [counts, setCounts] = useState<{ zero: number; one: number } | null>(null);
  const [seedLabel, setSeedLabel] = useState("No experiment run yet");

  const amplitudeProbabilities = useMemo(() => {
    const radians = (theta * Math.PI) / 180;
    return { zero: Math.cos(radians / 2) ** 2, one: Math.sin(radians / 2) ** 2 };
  }, [theta]);

  const interferenceProbabilities = useMemo(() => {
    const radians = (phase * Math.PI) / 180;
    return { zero: Math.cos(radians / 2) ** 2, one: Math.sin(radians / 2) ** 2 };
  }, [phase]);

  const runShots = () => {
    const zeroProbability = mode === "interference" ? interferenceProbabilities.zero : amplitudeProbabilities.zero;
    let zero = 0;
    for (let index = 0; index < shots; index += 1) {
      if (Math.random() < zeroProbability) zero += 1;
    }
    setCounts({ zero, one: shots - zero });
    setSeedLabel(`${shots.toLocaleString()} simulated shots · ${new Date().toLocaleTimeString()}`);
  };

  const modes: { id: DemoMode; label: string; caption: string }[] = [
    { id: "amplitudes", label: "Amplitudes", caption: "Prepare a qubit" },
    { id: "shots", label: "Measurement", caption: "One result per shot" },
    { id: "interference", label: "Interference", caption: "Change relative phase" },
    { id: "entanglement", label: "Entanglement", caption: "Explore a Bell pair" },
  ];

  return (
    <section className="edu-concept-lab" aria-labelledby="concept-lab-title">
      <div className="edu-section-heading">
        <div><span className="edu-eyebrow">TRY IT, THEN EXPLAIN IT</span><h2 id="concept-lab-title">The little quantum laboratory</h2></div>
        <span className="edu-lab-stamp">IDEAL SIMULATION</span>
      </div>
      <div className="edu-demo-tabs" role="tablist" aria-label="Quantum demonstrations">
        {modes.map((item) => <button key={item.id} role="tab" aria-selected={mode === item.id} className={mode === item.id ? "active" : ""} onClick={() => { setMode(item.id); setCounts(null); }}><strong>{item.label}</strong><small>{item.caption}</small></button>)}
      </div>

      {mode === "amplitudes" && (
        <div className="edu-demo-grid">
          <div className="edu-demo-copy">
            <span className="edu-step-label">01 · PREPARE A QUBIT</span>
            <h3>Turn the state dial</h3>
            <p>Imagine the qubit is prepared with a rotation around the Y axis. The slider changes its amplitudes in the computational basis.</p>
            <label className="edu-slider-label" htmlFor="theta-slider"><span>Rotation angle θ</span><b>{theta}°</b></label>
            <input id="theta-slider" type="range" min="0" max="180" step="1" value={theta} onChange={(event) => { setTheta(Number(event.target.value)); setCounts(null); }} />
            <div className="edu-range-ends"><span>0° · |0⟩</span><span>180° · |1⟩</span></div>
            <div className="edu-equation-card"><small>PREPARED STATE</small><code>|ψ⟩ = cos(θ/2)|0⟩ + sin(θ/2)|1⟩</code></div>
          </div>
          <div className="edu-demo-output">
            <div className="edu-ket-display"><div className="edu-ket-orbit"><span className="edu-ket-point" style={{ transform: `rotate(${theta}deg) translateY(-42px)` }} /></div><div><small>YOUR QUBIT</small><strong>{Math.abs(theta - 0) < 1 ? "|0⟩" : Math.abs(theta - 180) < 1 ? "|1⟩" : "α|0⟩ + β|1⟩"}</strong></div></div>
            <ProbabilityMeter label="P(0) = |α|²" value={amplitudeProbabilities.zero} tone="rose" />
            <ProbabilityMeter label="P(1) = |β|²" value={amplitudeProbabilities.one} tone="violet" />
            <p className="edu-science-note">The probabilities always add to 100%. The state is a mathematical description; the slider is not showing a tiny object physically rotating.</p>
          </div>
        </div>
      )}

      {mode === "shots" && (
        <div className="edu-demo-grid">
          <div className="edu-demo-copy">
            <span className="edu-step-label">02 · REPEAT THE EXPERIMENT</span>
            <h3>One shot, one answer</h3>
            <p>Set the number of independent measurements. Each shot returns either 0 or 1; the distribution is what lets us estimate probabilities.</p>
            <label className="edu-slider-label" htmlFor="shot-slider"><span>Number of shots</span><b>{shots.toLocaleString()}</b></label>
            <input id="shot-slider" type="range" min="10" max="2000" step="10" value={shots} onChange={(event) => { setShots(Number(event.target.value)); setCounts(null); }} />
            <div className="edu-range-ends"><span>10 · quick test</span><span>2,000 · larger sample</span></div>
            <button className="edu-primary-button" onClick={runShots}>Run {shots.toLocaleString()} shots <span>↗</span></button>
          </div>
          <div className="edu-demo-output">
            <div className="edu-outcome-pair"><div><small>OUTCOME 0</small><strong>{counts ? counts.zero : "—"}</strong></div><div><small>OUTCOME 1</small><strong>{counts ? counts.one : "—"}</strong></div></div>
            {counts ? <><ProbabilityMeter label="Observed 0 frequency" value={counts.zero / shots} tone="rose" /><ProbabilityMeter label="Observed 1 frequency" value={counts.one / shots} tone="violet" /><p className="edu-science-note">{seedLabel}. Run again: a new sample may produce slightly different counts.</p></> : <div className="edu-empty-chart"><span>◉</span><p>Your histogram will appear after you run the experiment.</p></div>}
            <p className="edu-science-note">This is a classroom sampling demo using a pseudo-random number generator, not a hardware quantum measurement.</p>
          </div>
        </div>
      )}

      {mode === "interference" && (
        <div className="edu-demo-grid">
          <div className="edu-demo-copy">
            <span className="edu-step-label">03 · RELATIVE PHASE</span>
            <h3>Give one path a phase</h3>
            <p>Prepare |0⟩, apply H, apply a Z-axis phase rotation, then apply H again. The relative phase changes the final measurement probabilities.</p>
            <label className="edu-slider-label" htmlFor="phase-slider"><span>Phase φ</span><b>{phase}°</b></label>
            <input id="phase-slider" type="range" min="0" max="360" step="1" value={phase} onChange={(event) => { setPhase(Number(event.target.value)); setCounts(null); }} />
            <div className="edu-range-ends"><span>0° · constructive return</span><span>360° · full turn</span></div>
            <div className="edu-equation-card"><small>IDEAL CIRCUIT</small><code>H → Rz(φ) → H → Measure</code></div>
          </div>
          <div className="edu-demo-output">
            <ProbabilityMeter label="P(0) after the final H" value={interferenceProbabilities.zero} tone="rose" />
            <ProbabilityMeter label="P(1) after the final H" value={interferenceProbabilities.one} tone="violet" />
            <div className="edu-phase-result"><strong>{Math.round(interferenceProbabilities.one * 100)}%</strong><span>probability of outcome 1</span></div>
            <p className="edu-science-note">A global phase applied to the entire state would not change observations. This demo changes a relative phase between components.</p>
          </div>
        </div>
      )}

      {mode === "entanglement" && (
        <div className="edu-entanglement-demo">
          <div className="edu-entanglement-visual" aria-label="Two qubits in a Bell state with correlated measurement outcomes">
            <div className="edu-entangled-node"><span>Q₀</span><b>0 / 1</b><small>first qubit</small></div>
            <div className="edu-entangled-thread"><i /><i /><i /><span>joint state</span></div>
            <div className="edu-entangled-node second"><span>Q₁</span><b>0 / 1</b><small>second qubit</small></div>
          </div>
          <div className="edu-bell-equation"><small>BELL STATE · Φ⁺</small><code>(|00⟩ + |11⟩) / √2</code></div>
          <div className="edu-outcome-pair"><div><small>JOINT OUTCOME 00</small><strong>50%</strong></div><div><small>JOINT OUTCOME 11</small><strong>50%</strong></div></div>
          <div className="edu-callout"><b>What should you notice?</b><p>Each qubit alone looks random in this basis, but the pair is perfectly correlated: this ideal Bell state produces 00 or 11, never 01 or 10. The hair-braid artwork is a metaphor for relationships—not the physical cause of entanglement.</p></div>
        </div>
      )}
      <div className="edu-lab-footer"><span>✧</span> Ask yourself: what changed in the mathematics, and what did the experiment let you observe?</div>
    </section>
  );
}
