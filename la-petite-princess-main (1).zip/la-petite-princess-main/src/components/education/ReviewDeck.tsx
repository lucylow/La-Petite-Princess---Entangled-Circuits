// @ts-nocheck
import React, { useMemo, useState } from "react";
import { getAcademyQuestion } from "../../education/questionBank";
import { getDueReviewCards } from "../../education/learningEngine";
import type { LearningProgress, ReviewRating } from "../../education/types";

interface ReviewDeckProps {
  progress: LearningProgress;
  onGrade: (questionId: string, rating: ReviewRating) => void;
}

export function ReviewDeck({ progress, onGrade }: ReviewDeckProps) {
  const dueCards = useMemo(() => getDueReviewCards(progress), [progress]);
  const [revealed, setRevealed] = useState(false);
  const current = dueCards[0];
  const question = current ? getAcademyQuestion(current.questionId) : undefined;

  const grade = (rating: ReviewRating) => {
    if (!current) return;
    onGrade(current.questionId, rating);
    setRevealed(false);

  };

  const upcoming = Object.values(progress.reviewCards)
    .filter((card) => new Date(card.dueAt).getTime() > Date.now())
    .sort((a, b) => new Date(a.dueAt).getTime() - new Date(b.dueAt).getTime());

  return (
    <section className="edu-review-deck">
      <div className="edu-section-heading"><div><span className="edu-eyebrow">SPACED REVIEW</span><h2>Revisit the ideas at the right time</h2><p>Short recall cards help move concepts from “I just saw that” to “I can explain that.”</p></div><div className="edu-review-counter"><strong>{Math.max(0, dueCards.length - index)}</strong><small>DUE NOW</small></div></div>
      {current && question && dueCards.length > 0 ? (
        <article className={`edu-flashcard ${revealed ? "revealed" : ""}`}>
          <div className="edu-flashcard-top"><span>{question.topic}</span><span>CARD 1 OF {dueCards.length} REMAINING</span></div>
          <div className="edu-flashcard-face"><span className="edu-eyebrow">PROMPT</span><h3>{question.prompt}</h3>{!revealed ? <button className="edu-primary-button" onClick={() => setRevealed(true)}>Reveal explanation <span>↗</span></button> : <div className="edu-flashcard-answer"><b>Key idea</b><p>{question.explanation}</p><small>Remember: {question.whyItMatters}</small></div>}</div>
          {revealed && <div className="edu-review-ratings"><span>How well could you recall it?</span><div><button onClick={() => grade("again")}><b>Again</b><small>Not yet</small></button><button onClick={() => grade("hard")}><b>Hard</b><small>With effort</small></button><button onClick={() => grade("good")}><b>Good</b><small>Mostly clear</small></button><button onClick={() => grade("easy")}><b>Easy</b><small>Confident</small></button></div></div>}
        </article>
      ) : (
        <div className="edu-review-complete"><span>✧</span><h3>{dueCards.length ? "Review session complete" : "Your review queue is clear"}</h3><p>{dueCards.length ? "Lovely work. Your next review dates have been updated." : "Answer a few practice questions to create review cards. They will return when it is time to revisit them."}</p><div className="edu-upcoming-review"><b>Coming up next</b>{upcoming.slice(0, 4).map((card) => { const item = getAcademyQuestion(card.questionId); return <div key={card.id}><span>{item?.topic ?? "Quantum concept"}</span><small>{new Date(card.dueAt).toLocaleString()}</small></div>; })}{upcoming.length === 0 && <small>No upcoming reviews yet.</small>}</div></div>
      )}
      <div className="edu-review-method"><b>How scheduling works</b><p>This prototype uses a simple SM-2-inspired interval scheduler. “Again” brings a card back in about ten minutes; successful recalls gradually lengthen the interval. It is a learning aid, not a clinical or validated memory assessment.</p></div>
    </section>
  );
}
