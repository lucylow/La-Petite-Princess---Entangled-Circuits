export type QuizDifficulty = "curious" | "practitioner" | "researcher";
export interface QuizQuestion {
  id: string;
  topic: string;
  difficulty: QuizDifficulty;
  prompt: string;
  options: { id: string; label: string }[];
  correctOptionId: string;
  explanation: string;
  hint: string;
  sourceLessonId: string;
}

export const QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: "q01-normalization", topic: "Qubits", difficulty: "curious",
    prompt: "A pure qubit is written α|0⟩ + β|1⟩. Which condition makes the state normalized?",
    options: [{ id: "a", label: "α + β = 1" }, { id: "b", label: "|α|² + |β|² = 1" }, { id: "c", label: "α = β" }],
    correctOptionId: "b", explanation: "The squared magnitudes of the probability amplitudes sum to one. The amplitudes may be complex.", hint: "Think about the total probability of all possible outcomes.", sourceLessonId: "what-is-a-qubit",
  },
  {
    id: "q02-hadamard", topic: "Superposition", difficulty: "curious",
    prompt: "What does a Hadamard gate do to |0⟩?",
    options: [{ id: "a", label: "It creates (|0⟩ + |1⟩)/√2" }, { id: "b", label: "It always produces |1⟩" }, { id: "c", label: "It measures the qubit" }],
    correctOptionId: "a", explanation: "H maps |0⟩ to an equal-amplitude superposition of the two computational basis states.", hint: "The output has equal amplitudes for 0 and 1.", sourceLessonId: "superposition",
  },
  {
    id: "q03-probability", topic: "Measurement", difficulty: "curious",
    prompt: "A qubit is measured in the computational basis. What determines the probability of outcome 1?",
    options: [{ id: "a", label: "The real part of β" }, { id: "b", label: "The squared magnitude |β|²" }, { id: "c", label: "The number of gates used" }],
    correctOptionId: "b", explanation: "The Born rule assigns probability |β|² to outcome 1 for α|0⟩ + β|1⟩.", hint: "Complex amplitudes are converted to probabilities using their magnitude squared.", sourceLessonId: "measurement",
  },
  {
    id: "q04-bell", topic: "Entanglement", difficulty: "curious",
    prompt: "For the Bell state (|00⟩ + |11⟩)/√2, which computational-basis outcomes are possible?",
    options: [{ id: "a", label: "00 and 11" }, { id: "b", label: "01 and 10" }, { id: "c", label: "All four with equal probability" }],
    correctOptionId: "a", explanation: "Only |00⟩ and |11⟩ have nonzero amplitude, each with probability 1/2.", hint: "Look at the two terms that appear in the state vector.", sourceLessonId: "entanglement",
  },
  {
    id: "q05-factor", topic: "Entanglement", difficulty: "practitioner",
    prompt: "Which statement correctly characterizes a pure two-qubit entangled state?",
    options: [{ id: "a", label: "It cannot be written as a tensor product of two pure single-qubit states" }, { id: "b", label: "It always has four equal amplitudes" }, { id: "c", label: "It has no measurement probabilities" }],
    correctOptionId: "a", explanation: "For pure bipartite states, entanglement means the joint state is not separable into a product of subsystem states.", hint: "Consider whether the two-qubit state can be factored into one state for each qubit.", sourceLessonId: "entanglement",
  },
  {
    id: "q06-cnot", topic: "Gates", difficulty: "practitioner",
    prompt: "What is the action of CNOT when its control qubit is |1⟩?",
    options: [{ id: "a", label: "It flips the target qubit" }, { id: "b", label: "It measures both qubits" }, { id: "c", label: "It flips the control qubit" }],
    correctOptionId: "a", explanation: "CNOT applies X to the target if and only if the control is 1. If the control is 0, the target is unchanged.", hint: "CNOT is a controlled-NOT operation; ask which qubit is controlled.", sourceLessonId: "gates",
  },
  {
    id: "q07-global-phase", topic: "Interference", difficulty: "practitioner",
    prompt: "Which phase can change measurement probabilities after later gates?",
    options: [{ id: "a", label: "A global phase on the entire state" }, { id: "b", label: "A relative phase between components" }, { id: "c", label: "Neither, because phase is never observable" }],
    correctOptionId: "b", explanation: "Relative phase can affect interference. A global phase multiplying the entire state has no observable effect.", hint: "Compare changing one component's phase with multiplying every component by the same phase.", sourceLessonId: "interference",
  },
  {
    id: "q08-decoherence", topic: "Noise", difficulty: "practitioner",
    prompt: "What does decoherence describe?",
    options: [{ id: "a", label: "Loss of quantum coherence due to interactions with the environment" }, { id: "b", label: "A faster way to run code" }, { id: "c", label: "A type of classical sorting algorithm" }],
    correctOptionId: "a", explanation: "Interactions with the environment can reduce coherence and make quantum interference harder to observe or use.", hint: "Think about unwanted interactions between the system and its surroundings.", sourceLessonId: "decoherence",
  },
  {
    id: "q09-chsh", topic: "Bell tests", difficulty: "researcher",
    prompt: "What is the CHSH bound for local-hidden-variable models under the standard assumptions?",
    options: [{ id: "a", label: "2" }, { id: "b", label: "2√2" }, { id: "c", label: "4" }],
    correctOptionId: "a", explanation: "The CHSH expression is bounded in magnitude by 2 for local-hidden-variable models. Quantum mechanics can reach 2√2.", hint: "The quantum Tsirelson bound is larger than the local bound.", sourceLessonId: "bell-test",
  },
  {
    id: "q10-grover", topic: "Algorithms", difficulty: "researcher",
    prompt: "What is the key effect of Grover's diffusion operator?",
    options: [{ id: "a", label: "It reflects amplitudes about their mean" }, { id: "b", label: "It deletes all unmarked states" }, { id: "c", label: "It measures the marked item directly" }],
    correctOptionId: "a", explanation: "The diffusion operator performs an inversion about the mean, amplifying the marked state's amplitude after the oracle phase flip.", hint: "The phrase 'inversion about the mean' is the central clue.", sourceLessonId: "grover",
  },
  {
    id: "q11-braids", topic: "Topological computing", difficulty: "researcher",
    prompt: "In topological quantum computing, what does a braid diagram represent in certain models?",
    options: [{ id: "a", label: "Mathematical paths of particle exchanges that encode operations" }, { id: "b", label: "Ordinary hair physically entangling photons" }, { id: "c", label: "A way to send messages faster than light" }],
    correctOptionId: "a", explanation: "In suitable topological models, exchanging anyons is represented by braid-group operations on a computational space.", hint: "This is a mathematical framework, not a claim about ordinary braids.", sourceLessonId: "topological",
  },
  {
    id: "q12-unitary", topic: "Gates", difficulty: "researcher",
    prompt: "What mathematical property must an ideal quantum gate matrix have?",
    options: [{ id: "a", label: "It must be unitary" }, { id: "b", label: "Every entry must be positive" }, { id: "c", label: "It must be symmetric" }],
    correctOptionId: "a", explanation: "A unitary matrix preserves inner products and therefore preserves state-vector normalization.", hint: "A quantum gate must preserve total probability for every valid input state.", sourceLessonId: "gates",
  },
];

export function questionsForDifficulty(difficulty: QuizDifficulty): QuizQuestion[] {
  return QUIZ_QUESTIONS.filter((question) => question.difficulty === difficulty);
}

export function getQuestionById(id: string): QuizQuestion | undefined {
  return QUIZ_QUESTIONS.find((question) => question.id === id);
}

export function shuffleQuestions<T>(items: T[], rng: () => number = Math.random): T[] {
  const copy = [...items];
  for (let index = copy.length - 1; index > 0; index -= 1) {
    const swapIndex = Math.floor(rng() * (index + 1));
    const current = copy[index];
    const swap = copy[swapIndex];
    if (current === undefined || swap === undefined) continue;
    copy[index] = swap;
    copy[swapIndex] = current;
  }
  return copy;
}

export function scoreQuiz(answers: Record<string, string>): { correct: number; total: number; percentage: number } {
  const total = Object.keys(answers).length;
  const correct = Object.entries(answers).reduce((score, [questionId, answerId]) => {
    const question = getQuestionById(questionId);
    return score + (question?.correctOptionId === answerId ? 1 : 0);
  }, 0);
  return { correct, total, percentage: total === 0 ? 0 : Math.round((correct / total) * 100) };
}
