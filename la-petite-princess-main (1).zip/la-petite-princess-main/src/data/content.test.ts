import { describe, expect, it } from "vitest";
import { LESSONS, getLessonById, getNextLessonId, getPreviousLessonId } from "./lessons";
import { QUIZ_QUESTIONS, questionsForDifficulty, scoreQuiz, shuffleQuestions } from "./quizzes";
import { CHALLENGES, getChallengeById } from "./challenges";

describe("learning content catalogue", () => {
  it("has ten ordered lessons with unique ids", () => {
    expect(LESSONS).toHaveLength(10);
    expect(new Set(LESSONS.map((lesson) => lesson.id)).size).toBe(LESSONS.length);
    expect(getLessonById("entanglement")?.title).toBe("The great braid");
  });

  it("provides safe lesson navigation at both boundaries", () => {
    expect(getPreviousLessonId(LESSONS[0]!.id)).toBeNull();
    expect(getNextLessonId(LESSONS[LESSONS.length - 1]!.id)).toBeNull();
    expect(getNextLessonId(LESSONS[0]!.id)).toBe(LESSONS[1]!.id);
  });

  it("includes quiz coverage for each learner level", () => {
    expect(questionsForDifficulty("curious").length).toBeGreaterThan(0);
    expect(questionsForDifficulty("practitioner").length).toBeGreaterThan(0);
    expect(questionsForDifficulty("researcher").length).toBeGreaterThan(0);
    expect(QUIZ_QUESTIONS).toHaveLength(12);
  });

  it("scores selected answers consistently", () => {
    const first = QUIZ_QUESTIONS[0]!;
    const score = scoreQuiz({ [first.id]: first.correctOptionId });
    expect(score.correct).toBe(1);
    expect(score.total).toBe(1);
    expect(score.percentage).toBe(100);
  });

  it("shuffles without losing or mutating catalogue entries", () => {
    const original = [...QUIZ_QUESTIONS];
    const shuffled = shuffleQuestions(QUIZ_QUESTIONS, () => 0.2);
    expect(shuffled).toHaveLength(QUIZ_QUESTIONS.length);
    expect(new Set(shuffled.map((question) => question.id)).size).toBe(QUIZ_QUESTIONS.length);
    expect(QUIZ_QUESTIONS).toEqual(original);
  });

  it("contains eight practical experiment challenges", () => {
    expect(CHALLENGES).toHaveLength(8);
    expect(getChallengeById("make-a-bell-pair")?.successCriteria.length).toBeGreaterThan(1);
  });
});
