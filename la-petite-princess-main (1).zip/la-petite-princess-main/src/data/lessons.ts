export type LessonLevel = "first steps" | "building intuition" | "going deeper";
export interface Lesson {
  id: string;
  number: string;
  title: string;
  subtitle: string;
  level: LessonLevel;
  duration: string;
  goal: string;
  story: string;
  explanation: string;
  equation?: string;
  analogy: string;
  caveat: string;
  activity: string;
  checkpoint: string;
  vocabulary: string[];
}

export const LESSONS: Lesson[] = [
  {
    id: "what-is-a-qubit", number: "01", title: "A new kind of bit", subtitle: "Meet the qubit", level: "first steps", duration: "8 min",
    goal: "Distinguish a classical bit from a qubit and read the symbols |0⟩ and |1⟩.",
    story: "In the notebook, the young scientist finds two familiar labels: zero and one. But the quantum page has room for more than a single definite label before measurement.",
    explanation: "A classical bit is represented as either 0 or 1. A qubit is a quantum two-level system whose pure state can be written as a combination of the basis states |0⟩ and |1⟩. The coefficients are complex probability amplitudes.",
    equation: "|ψ⟩ = α|0⟩ + β|1⟩, with |α|² + |β|² = 1",
    analogy: "Think of the notation as a recipe: α and β tell the experimenter how the state is prepared and what probabilities a chosen measurement can produce.",
    caveat: "A qubit is not simply a classical bit that is secretly both values. Quantum amplitudes include phase, which affects later interference.",
    activity: "Open the Quantum Lab, reset Q1 and apply a Hadamard gate. Compare the state vector with the measurement probabilities.",
    checkpoint: "What condition must the amplitudes α and β satisfy for a pure qubit state to be normalized?",
    vocabulary: ["qubit", "basis state", "amplitude", "normalization"],
  },
  {
    id: "superposition", number: "02", title: "The strand of possibilities", subtitle: "Superposition and phase", level: "first steps", duration: "10 min",
    goal: "Explain superposition as a linear combination of basis states and recognize why phase matters.",
    story: "One loose strand in the scientist's braid catches the light in different colours. It becomes her reminder that a quantum state contains amplitudes, not just a list of likely answers.",
    explanation: "Superposition is the principle that quantum states can be added together with complex coefficients. When measured in the computational basis, the outcomes occur with probabilities equal to the squared magnitudes of the amplitudes.",
    equation: "H|0⟩ = (|0⟩ + |1⟩)/√2",
    analogy: "A musical chord combines notes. The notes can interfere when the system is transformed; quantum amplitudes can also reinforce or cancel.",
    caveat: "The musical analogy is limited: a quantum state is represented by a vector in a complex Hilbert space, and measurement follows the Born rule.",
    activity: "Apply H, then H again. The state returns to |0⟩. This demonstrates that quantum gates transform amplitudes coherently.",
    checkpoint: "After H is applied to |0⟩, what are the computational-basis measurement probabilities?",
    vocabulary: ["superposition", "phase", "Hadamard gate", "Born rule"],
  },
  {
    id: "measurement", number: "03", title: "The mirror of measurement", subtitle: "From amplitudes to outcomes", level: "first steps", duration: "9 min",
    goal: "Connect amplitudes to measurement probabilities and distinguish one shot from many shots.",
    story: "The brass mirror gives one result each time it is consulted. The scientist learns to repeat the experiment and record a distribution rather than expecting every run to match.",
    explanation: "For a computational-basis measurement of a pure state, the probability of basis outcome i is |αᵢ|². A single measurement samples one result. Repeated independent shots estimate the distribution.",
    equation: "P(i) = |αᵢ|²",
    analogy: "A weather forecast gives a probability, not a promise about one specific raindrop. Quantum probabilities describe an ensemble of identically prepared experiments.",
    caveat: "The exact measurement update depends on the measurement being performed. This lesson uses the computational basis and the standard projective measurement model.",
    activity: "Prepare an equal superposition, run 100 shots, then 1,000 shots. Compare the empirical frequencies with the 50/50 prediction.",
    checkpoint: "Does one measurement of a 50/50 state have to return 0.5?",
    vocabulary: ["measurement", "shot", "probability", "frequency"],
  },
  {
    id: "entanglement", number: "04", title: "The great braid", subtitle: "Two qubits, one joint state", level: "building intuition", duration: "12 min",
    goal: "Recognize a Bell state and explain why it cannot be factored into separate single-qubit states.",
    story: "Two diagrams in the notebook look simple when viewed separately. The scientist discovers that their complete description must include the pair as one joint system.",
    explanation: "A pure two-qubit state is entangled when it cannot be expressed as a tensor product of two single-qubit pure states. The Bell state |Φ+⟩ = (|00⟩ + |11⟩)/√2 is a standard example.",
    equation: "|Φ+⟩ = (|00⟩ + |11⟩)/√2",
    analogy: "The story's braid reminds us to think about relationships. The actual test for entanglement is mathematical: can the joint state be factored into separate states?",
    caveat: "Ordinary braids do not create quantum entanglement. Entanglement also cannot transmit a controllable message faster than light.",
    activity: "Prepare H on Q1 followed by CNOT(Q1 → Q2). Inspect the state vector and measure both qubits repeatedly.",
    checkpoint: "For |Φ+⟩ measured in the computational basis, which two bit strings can appear?",
    vocabulary: ["entanglement", "tensor product", "Bell state", "correlation"],
  },
  {
    id: "gates", number: "05", title: "The quantum loom", subtitle: "Gates and circuits", level: "building intuition", duration: "14 min",
    goal: "Interpret a circuit as an ordered sequence of unitary operations.",
    story: "The scientist finds a loom with a row for each qubit. Symbols in each column represent operations applied in sequence.",
    explanation: "A quantum gate is represented by a unitary matrix. A circuit composes gates in order. Multi-qubit gates such as CNOT can create entanglement when applied to suitable input states.",
    equation: "|ψ_out⟩ = Uₙ … U₂ U₁ |ψ_in⟩",
    analogy: "A recipe has ordered steps. In a quantum circuit, changing the order of operations can change the final state because gates generally do not commute.",
    caveat: "A circuit diagram is a compact mathematical specification. Real devices may add noise, routing constraints, and imperfect gates.",
    activity: "Build H(Q1) → CNOT(Q1 → Q2), then reverse the order and compare the result.",
    checkpoint: "Why can swapping the order of two quantum gates change a circuit's output?",
    vocabulary: ["unitary", "gate", "circuit", "control", "target"],
  },
  {
    id: "interference", number: "06", title: "The colours of phase", subtitle: "Quantum interference", level: "building intuition", duration: "12 min",
    goal: "Explain how relative phase changes later measurement probabilities.",
    story: "The scientist draws two paths across the page. One path carries a phase mark. When the paths meet again, the final result depends on how their amplitudes combine.",
    explanation: "Quantum amplitudes add before their squared magnitudes are interpreted as probabilities. Relative phase can therefore cause constructive or destructive interference after subsequent gates.",
    equation: "H Rz(φ) H |0⟩ = cos(φ/2)|0⟩ − i sin(φ/2)|1⟩",
    analogy: "Water waves can reinforce or cancel. This helps visualize interference, although quantum amplitudes are complex probability amplitudes rather than water heights.",
    caveat: "A global phase multiplying the entire state has no observable effect; relative phase between components can affect interference.",
    activity: "Move the phase slider from 0° to 360° and observe the probability of measuring 0 after the second Hadamard gate.",
    checkpoint: "Which kind of phase can affect interference: global phase or relative phase?",
    vocabulary: ["interference", "relative phase", "global phase", "rotation"],
  },
  {
    id: "decoherence", number: "07", title: "The quantum storm", subtitle: "Noise and fragile information", level: "going deeper", duration: "13 min",
    goal: "Describe decoherence and distinguish it from a simple coding error.",
    story: "A storm shakes the observatory. The scientist's carefully prepared patterns become harder to preserve because the laboratory is never perfectly isolated from its surroundings.",
    explanation: "Decoherence describes the loss of observable phase coherence in a system due to interactions with its environment. It is a central challenge for quantum technologies.",
    equation: "ρᵢⱼ → 0 for selected off-diagonal terms in a simple dephasing model",
    analogy: "A delicate pattern can become blurred when information leaks into the surroundings. The analogy points to lost coherence, not a literal erasure of a classical file.",
    caveat: "Decoherence, gate errors, readout errors, and leakage are related but distinct noise mechanisms.",
    activity: "Compare ideal probabilities with a deliberately simplified noisy distribution. Identify which measurement outcomes gain or lose frequency.",
    checkpoint: "Why do quantum processors need careful isolation and error-control methods?",
    vocabulary: ["decoherence", "noise", "coherence", "readout error"],
  },
  {
    id: "bell-test", number: "08", title: "A question across distance", subtitle: "Bell tests and CHSH", level: "going deeper", duration: "16 min",
    goal: "Interpret a CHSH correlation score and its classical bound.",
    story: "The scientist sends the same carefully prepared pair to two distant laboratories. Each lab chooses a measurement setting and records a result.",
    explanation: "Bell inequalities constrain correlations predicted by local hidden-variable models under their assumptions. The CHSH expression has a local bound of 2; quantum mechanics permits values up to 2√2.",
    equation: "S = E(a,b) + E(a,b′) + E(a′,b) − E(a′,b′)",
    analogy: "Think of two labs comparing patterns in their notebooks. The surprise is not a message sent between them; it is a statistical pattern across many trials.",
    caveat: "A violation rules out a broad class of local hidden-variable explanations under the experiment's assumptions. It does not permit faster-than-light communication.",
    activity: "Open the Bell Test Lab, use the optimal angle preset, and compare the theoretical S value with a finite-shot estimate.",
    checkpoint: "What is the CHSH bound for local hidden-variable theories?",
    vocabulary: ["Bell inequality", "CHSH", "correlation", "local hidden variable"],
  },
  {
    id: "grover", number: "09", title: "The marked page", subtitle: "A first quantum search algorithm", level: "going deeper", duration: "17 min",
    goal: "Understand the roles of an oracle and amplitude amplification in Grover's algorithm.",
    story: "A library contains many identical-looking pages. The scientist marks one page with a secret symbol and uses a sequence of reflections to increase the chance of finding it.",
    explanation: "Grover's search algorithm uses a phase oracle and a diffusion operator to amplify the amplitude of a marked item. Its query complexity scales as O(√N) for an unstructured search, compared with O(N) classical queries in the worst case.",
    equation: "|ψ⟩ → Oracle → Diffusion → … → Measure",
    analogy: "The reflections are like carefully timed turns that make the marked direction more prominent. The algorithm's speedup is a query-complexity result, not a promise that every real task becomes faster.",
    caveat: "This platform's small state-vector demo is an ideal simulation and does not demonstrate practical quantum advantage on real hardware.",
    activity: "Choose a marked two-bit string and run one Grover iteration. Inspect how the target probability changes.",
    checkpoint: "What does the phase oracle do to the marked basis state's amplitude?",
    vocabulary: ["oracle", "diffusion", "amplitude amplification", "query complexity"],
  },
  {
    id: "topological", number: "10", title: "The mathematics of braids", subtitle: "An optional advanced connection", level: "going deeper", duration: "18 min",
    goal: "Distinguish ordinary hair braiding, entanglement, and topological quantum computing.",
    story: "The scientist discovers that mathematicians also study braids as paths traced by objects through time. The resemblance gives her a new question—but she knows a metaphor is not a mechanism.",
    explanation: "Topological quantum computing is a proposed approach in which information is encoded in global properties of a system. In some models, exchanging non-Abelian anyons implements operations represented by braid-group transformations.",
    equation: "Braid operations are represented by matrices acting on a protected computational space in suitable models.",
    analogy: "A braid diagram records the ordering of exchanges. This makes braids a useful mathematical language for certain topological models.",
    caveat: "This advanced mathematical use of braids is distinct from ordinary hair braiding and distinct from the general concept of quantum entanglement. The status of practical fault-tolerant topological hardware remains an active research topic.",
    activity: "Explore a static braid-group diagram and write down which strands cross over or under. Do not interpret it as a simulation of a physical device.",
    checkpoint: "Are ordinary hair braids themselves quantum-entangled states?",
    vocabulary: ["topological quantum computing", "anyon", "braid group", "non-Abelian"],
  },
];

export function getLessonById(id: string): Lesson | undefined {
  return LESSONS.find((lesson) => lesson.id === id);
}

export function getNextLessonId(currentId: string): string | null {
  const index = LESSONS.findIndex((lesson) => lesson.id === currentId);
  return index >= 0 && index < LESSONS.length - 1 ? LESSONS[index + 1]?.id ?? null : null;
}

export function getPreviousLessonId(currentId: string): string | null {
  const index = LESSONS.findIndex((lesson) => lesson.id === currentId);
  return index > 0 ? LESSONS[index - 1]?.id ?? null : null;
}
