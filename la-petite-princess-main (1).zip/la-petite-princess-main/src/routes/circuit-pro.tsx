import { createFileRoute, Link } from "@tanstack/react-router";
import { CircuitStudioPro } from "@/components/CircuitStudioPro";
import "@/styles/circuit-pro.css";

export const Route = createFileRoute("/circuit-pro")({
  head: () => ({
    meta: [
      { title: "Circuit Studio Pro — La Petite Princesse" },
      { name: "description", content: "Build, simulate, optimize and export quantum circuits." },
      { property: "og:title", content: "Circuit Studio Pro — La Petite Princesse" },
      { property: "og:description", content: "Build, simulate, optimize and export quantum circuits." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => (
    <main>
      <p style={{ padding: "1rem" }}><Link to="/">← Back to the story</Link></p>
      <CircuitStudioPro />
    </main>
  ),
});
