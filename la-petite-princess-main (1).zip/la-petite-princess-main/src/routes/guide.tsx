import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import rehypeSlug from "rehype-slug";
import guide from "@/content/guide.md?raw";

export const Route = createFileRoute("/guide")({
  head: () => ({
    meta: [
      { title: "Quantum Circuits Guide — An Interactive Journey" },
      { name: "description", content: "A visual guide to qubits, gates, entanglement, teleportation and Grover's search." },
      { property: "og:title", content: "Quantum Circuits Guide" },
      { property: "og:description", content: "Learn qubits, gates, entanglement and quantum algorithms step by step." },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: GuidePage,
});

const chapters = [...guide.matchAll(/^# (\d+)\.\s+(.+)$/gm)].map((m) => ({
  n: m[1] ?? "",
  title: (m[2] ?? "").toLowerCase().replace(/(^|\s|:)\S/g, (s) => s.toUpperCase()),
  id: `${m[1]}-${(m[2] ?? "").toLowerCase().replace(/[^a-z0-9\s-]/g, "").trim().replace(/\s+/g, "-")}`,
}));

function GuidePage() {
  const [progress, setProgress] = useState(0);
  const [active, setActive] = useState("");
  useEffect(() => {
    const onScroll = () => {
      const h = document.documentElement;
      setProgress(h.scrollTop / Math.max(1, h.scrollHeight - h.clientHeight));
      let cur = "";
      for (const c of chapters) {
        const el = document.getElementById(c.id);
        if (el && el.getBoundingClientRect().top < 140) cur = c.id;
      }
      setActive(cur);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div className="guide-shell">
      <div className="guide-progress" style={{ transform: `scaleX(${progress})` }} />
      <header className="guide-top">
        <a href="/">← Home</a>
        <span>{Math.round(progress * 100)}% read</span>
      </header>
      <div className="guide-layout">
        <nav className="guide-toc" aria-label="Chapters">
          <p>Chapters</p>
          {chapters.map((c) => (
            <a key={c.id} href={`#${c.id}`} className={active === c.id ? "is-active" : ""}>
              <b>{c.n}</b> {c.title}
            </a>
          ))}
        </nav>
        <article className="guide-prose">
          <ReactMarkdown remarkPlugins={[remarkGfm]} rehypePlugins={[rehypeSlug]}>{guide}</ReactMarkdown>
        </article>
      </div>
      {progress > 0.05 && (
        <button className="guide-totop" aria-label="Back to top" onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}>↑</button>
      )}
    </div>
  );
}
