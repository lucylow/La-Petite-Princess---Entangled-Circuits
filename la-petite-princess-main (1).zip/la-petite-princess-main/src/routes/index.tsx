import { createFileRoute } from "@tanstack/react-router";
import PrincesseApp from "@/components/PrincesseApp";

const title = "La Petite Princesse — Entangled: The Quantum Universe";
const description =
  "A story-led journey into quantum physics and computing. A curious mind. A tangled braid. A universe of possibilities.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: PrincesseApp,
});
