import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { LearningAcademy } from "@/components/education/LearningAcademy";
import "@/styles/education.css";

export const Route = createFileRoute("/academy")({
  head: () => ({
    meta: [
      { title: "Quantum Academy — La Petite Princesse" },
      { name: "description", content: "Guided lessons, practice, review and progress for learning quantum computing." },
      { property: "og:title", content: "Quantum Academy — La Petite Princesse" },
      { property: "og:description", content: "Guided lessons, practice, review and progress for learning quantum computing." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AcademyPage,
});

function AcademyPage() {
  const navigate = useNavigate();
  return (
    <main>
      <p style={{ padding: "1rem" }}><Link to="/">← Back to the story</Link></p>
      <LearningAcademy onOpenQuantumLab={() => navigate({ to: "/" })} />
    </main>
  );
}
