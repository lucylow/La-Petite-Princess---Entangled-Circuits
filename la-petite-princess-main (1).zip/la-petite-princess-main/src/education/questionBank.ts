// @ts-nocheck
import { QUIZ_QUESTIONS } from "../data/quizzes";
import type { AcademyQuestion, LearningLevel } from "./types";

const EXTENDED_QUESTIONS: AcademyQuestion[] = [
  {
    id: "academy-q13-normalization", lessonId: "what-is-a-qubit", topic: "Normalization", level: "curious",
    prompt: "A qubit is |ψ⟩ = α|0⟩ + β|1⟩. Which statement must be true for a valid normalized pure state?",
    options: [{ id: "a", label: "α + β = 1" }, { id: "b", label: "|α|² + |β|² = 1" }, { id: "c", label: "Both amplitudes must be real" }],
    correctOptionId: "b", explanation: "The squared magnitudes of the amplitudes sum to one. The amplitudes themselves may be complex.", hint: "The total probability across all computational-basis outcomes must add to 1.",
    misconceptionId: "amplitudes-vs-probabilities", misconceptionFeedback: "Amplitudes are not probabilities. The probability associated with an amplitude is its squared magnitude.", whyItMatters: "Normalization is the mathematical condition that makes measurement probabilities consistent.", estimatedSeconds: 35,
  },
  {
    id: "academy-q14-phase", lessonId: "superposition", topic: "Relative phase", level: "curious",
    prompt: "Two states have the same measurement probabilities in the computational basis. What could still make them behave differently in a later circuit?",
    options: [{ id: "a", label: "A different relative phase" }, { id: "b", label: "A different global label" }, { id: "c", label: "Nothing; probabilities fully specify a quantum state" }],
    correctOptionId: "a", explanation: "Relative phase is part of the quantum state and can change the result of later interference, even when the current computational-basis probabilities are identical.", hint: "Think about what changes when one component is multiplied by −1 while the other is unchanged.",
    misconceptionId: "phase-is-irrelevant", misconceptionFeedback: "Phase is not always irrelevant. Relative phase can be revealed by applying another gate before measurement.", whyItMatters: "Interference is one of the key resources used in quantum algorithms.", estimatedSeconds: 40,
  },
  {
    id: "academy-q15-many-shots", lessonId: "measurement", topic: "Repeated measurement", level: "curious",
    prompt: "A qubit has a 70% probability of producing outcome 0. What should you expect from a single shot?",
    options: [{ id: "a", label: "Exactly 0.7" }, { id: "b", label: "Either 0 or 1" }, { id: "c", label: "Always 0" }],
    correctOptionId: "b", explanation: "One measurement returns one classical outcome. The 70% describes the probability across repeated identically prepared trials.", hint: "An individual measurement result is a discrete bit, not a probability value.",
    misconceptionId: "probability-as-outcome", misconceptionFeedback: "Probability describes how often an outcome is expected across many repeated trials, not the value returned by one shot.", whyItMatters: "Quantum experiments rely on repeated measurements to estimate distributions.", estimatedSeconds: 30,
  },
  {
    id: "academy-q16-bell", lessonId: "entanglement", topic: "Bell states", level: "practitioner",
    prompt: "For |Φ⁺⟩ = (|00⟩ + |11⟩)/√2, what is the probability of measuring 01 in the computational basis?",
    options: [{ id: "a", label: "0%" }, { id: "b", label: "25%" }, { id: "c", label: "50%" }],
    correctOptionId: "a", explanation: "Only |00⟩ and |11⟩ have nonzero amplitude in this Bell state. Each occurs with probability 1/2.", hint: "Only the basis states written in the ket have nonzero amplitude.",
    misconceptionId: "bell-all-outcomes", misconceptionFeedback: "A Bell state is not a uniform mixture of all four two-bit strings. This Bell state contains only 00 and 11 in this basis.", whyItMatters: "Reading a joint state vector is the first step toward reasoning about entanglement.", estimatedSeconds: 35,
  },
  {
    id: "academy-q17-factor", lessonId: "entanglement", topic: "Separability", level: "practitioner",
    prompt: "What is the defining feature of a pure bipartite entangled state?",
    options: [{ id: "a", label: "It cannot be written as a product of separate pure states for each subsystem" }, { id: "b", label: "It must have four equal probabilities in every basis" }, { id: "c", label: "It must contain a measurement gate" }],
    correctOptionId: "a", explanation: "For a pure bipartite state, entanglement means the joint state cannot be factored into a tensor product of individual pure states.", hint: "Ask whether the joint state can be separated into one ket for each qubit.",
    misconceptionId: "entanglement-equals-correlation", misconceptionFeedback: "Correlation alone is not the full definition. For pure bipartite states, entanglement is non-factorizability of the joint state.", whyItMatters: "The mathematical definition distinguishes quantum entanglement from ordinary classical correlations.", estimatedSeconds: 50,
  },
  {
    id: "academy-q18-cnot", lessonId: "gates", topic: "Controlled gates", level: "practitioner",
    prompt: "A CNOT gate has control Q0 and target Q1. What happens when Q0 = 0?",
    options: [{ id: "a", label: "Q1 is flipped" }, { id: "b", label: "Q1 is unchanged" }, { id: "c", label: "Both qubits are measured" }],
    correctOptionId: "b", explanation: "CNOT flips its target if and only if the control is 1. If the control is 0, the target is unchanged.", hint: "The operation is conditional: NOT is applied only when the control is 1.",
    misconceptionId: "control-target-reversed", misconceptionFeedback: "The control determines whether the target is flipped. The control itself is not the target of the NOT operation.", whyItMatters: "Controlled operations are the main building blocks for multi-qubit algorithms and entanglement.", estimatedSeconds: 35,
  },
  {
    id: "academy-q19-unitary", lessonId: "gates", topic: "Unitary operations", level: "practitioner",
    prompt: "Why must an ideal closed-system quantum gate be represented by a unitary operation?",
    options: [{ id: "a", label: "It preserves inner products and normalization" }, { id: "b", label: "It makes every amplitude positive" }, { id: "c", label: "It removes all phase information" }],
    correctOptionId: "a", explanation: "Unitary transformations preserve inner products, including state-vector norm, so valid states remain normalized.", hint: "Think about which property guarantees total probability stays equal to one.",
    misconceptionId: "unitary-means-symmetric", misconceptionFeedback: "Unitary does not mean symmetric or positive. It means U†U = I.", whyItMatters: "Unitarity is the mathematical structure behind reversible ideal quantum evolution.", estimatedSeconds: 45,
  },
  {
    id: "academy-q20-order", lessonId: "gates", topic: "Gate order", level: "practitioner",
    prompt: "Why can H followed by X differ from X followed by H?",
    options: [{ id: "a", label: "Quantum gates generally do not commute" }, { id: "b", label: "The circuit only reads the first gate" }, { id: "c", label: "The second gate is always ignored" }],
    correctOptionId: "a", explanation: "Matrix multiplication is order-sensitive in general. Many pairs of quantum gates do not commute.", hint: "Compare the two products HX and XH.",
    misconceptionId: "gate-order-irrelevant", misconceptionFeedback: "A circuit is an ordered composition of operations. Reordering gates can change the output state.", whyItMatters: "Circuit design depends on the order in which operations are applied.", estimatedSeconds: 35,
  },
  {
    id: "academy-q21-interference", lessonId: "interference", topic: "Interference", level: "practitioner",
    prompt: "Which type of phase can affect later interference between components of a quantum state?",
    options: [{ id: "a", label: "Relative phase" }, { id: "b", label: "Global phase only" }, { id: "c", label: "Neither type" }],
    correctOptionId: "a", explanation: "A relative phase changes how components combine after later gates. A global phase multiplies the whole state and has no observable effect by itself.", hint: "Imagine changing the sign of only one component, not every component.",
    misconceptionId: "global-relative-phase", misconceptionFeedback: "Global phase is unobservable; relative phase can change interference patterns.", whyItMatters: "Quantum algorithms use interference to amplify some outcomes and suppress others.", estimatedSeconds: 40,
  },
  {
    id: "academy-q22-decoherence", lessonId: "decoherence", topic: "Decoherence", level: "researcher",
    prompt: "In a simple dephasing model, which part of a density matrix is directly reduced?",
    options: [{ id: "a", label: "Off-diagonal coherence terms" }, { id: "b", label: "Every diagonal probability must become zero" }, { id: "c", label: "The number of qubits" }],
    correctOptionId: "a", explanation: "Dephasing reduces off-diagonal terms that encode coherence in a chosen basis, while diagonal populations may remain unchanged in a pure dephasing model.", hint: "The diagonal entries encode populations; off-diagonal entries encode coherence between basis states.",
    misconceptionId: "decoherence-erases-everything", misconceptionFeedback: "Decoherence need not erase all populations. In pure dephasing, coherences decay while computational-basis populations remain the same.", whyItMatters: "Density matrices help describe mixed states and noisy quantum systems.", estimatedSeconds: 55,
  },
  {
    id: "academy-q23-bell-bound", lessonId: "bell-test", topic: "CHSH", level: "researcher",
    prompt: "What is the maximum CHSH value allowed by local-hidden-variable models under the standard assumptions?",
    options: [{ id: "a", label: "2" }, { id: "b", label: "2√2" }, { id: "c", label: "4" }],
    correctOptionId: "a", explanation: "The local bound is 2. Quantum theory permits up to the Tsirelson bound 2√2.", hint: "The quantum maximum is larger than the classical local bound.",
    misconceptionId: "chsh-bounds-swapped", misconceptionFeedback: "2 is the local-hidden-variable bound; 2√2 is the quantum Tsirelson bound.", whyItMatters: "The inequality quantifies a distinctive quantum correlation that can be tested experimentally.", estimatedSeconds: 40,
  },
  {
    id: "academy-q24-tsirelson", lessonId: "bell-test", topic: "Quantum correlations", level: "researcher",
    prompt: "What is the Tsirelson bound for the CHSH expression in quantum theory?",
    options: [{ id: "a", label: "2" }, { id: "b", label: "2√2" }, { id: "c", label: "3" }],
    correctOptionId: "b", explanation: "Quantum mechanics can reach 2√2, approximately 2.828, for suitable entangled states and measurement settings.", hint: "It is about 2.83, greater than 2 but less than 3.",
    misconceptionId: "chsh-bounds-swapped", misconceptionFeedback: "Keep the two bounds distinct: 2 for local models and 2√2 for quantum theory.", whyItMatters: "The quantum bound is a precise prediction, not an unlimited correlation strength.", estimatedSeconds: 35,
  },
  {
    id: "academy-q25-grover-oracle", lessonId: "grover", topic: "Grover oracle", level: "researcher",
    prompt: "What does the phase oracle do to a marked computational-basis state in Grover's algorithm?",
    options: [{ id: "a", label: "It flips the sign of its amplitude" }, { id: "b", label: "It measures the marked state" }, { id: "c", label: "It deletes all unmarked states" }],
    correctOptionId: "a", explanation: "The phase oracle changes the sign of the marked state's amplitude. The diffusion operator then uses interference to amplify its probability.", hint: "The oracle marks the target with a phase, not by directly measuring it.",
    misconceptionId: "oracle-measures-answer", misconceptionFeedback: "An oracle does not reveal the answer by measurement. It applies a phase marking that the algorithm uses later.", whyItMatters: "The distinction between marking and reading out is central to how quantum search works.", estimatedSeconds: 50,
  },
  {
    id: "academy-q26-grover-scaling", lessonId: "grover", topic: "Query complexity", level: "researcher",
    prompt: "For unstructured search over N possibilities, how does Grover's oracle-query count scale?",
    options: [{ id: "a", label: "O(√N)" }, { id: "b", label: "O(log N)" }, { id: "c", label: "O(N²)" }],
    correctOptionId: "a", explanation: "Grover's algorithm uses O(√N) oracle queries, improving on the O(N) classical worst-case query complexity for unstructured search.", hint: "The quantum scaling contains a square root.",
    misconceptionId: "quantum-exponential-speedup", misconceptionFeedback: "Grover offers a quadratic query improvement, not an exponential speedup.", whyItMatters: "Careful complexity claims prevent overstating what quantum computers can do.", estimatedSeconds: 35,
  },
  {
    id: "academy-q27-topological", lessonId: "topological", topic: "Topological computing", level: "researcher",
    prompt: "In certain topological quantum-computing models, what does a braid-group element encode?",
    options: [{ id: "a", label: "An ordered exchange of anyons represented as an operation" }, { id: "b", label: "A literal hairstyle made of photons" }, { id: "c", label: "A faster-than-light communication route" }],
    correctOptionId: "a", explanation: "In suitable models, exchanging non-Abelian anyons corresponds to braid-group operations represented on a computational state space.", hint: "This is a mathematical description of exchanges in spacetime.",
    misconceptionId: "hair-braid-is-quantum-operation", misconceptionFeedback: "The hair braid is an educational metaphor. The mathematical braid records particle exchanges in a topological model.", whyItMatters: "This gives the story a real advanced mathematical connection without confusing it with ordinary entanglement.", estimatedSeconds: 55,
  },
  {
    id: "academy-q28-no-signalling", lessonId: "entanglement", topic: "No-signalling", level: "researcher",
    prompt: "Why does quantum entanglement not let one person send a controllable message faster than light?",
    options: [{ id: "a", label: "Each local outcome is random; correlations appear only when results are compared" }, { id: "b", label: "Entangled particles are always farther apart than light can travel" }, { id: "c", label: "The distant measurement instantly sends a readable bit" }],
    correctOptionId: "a", explanation: "Entanglement produces correlations, but the local measurement outcomes are not controllable. Comparing the records requires a classical communication channel.", hint: "Can the sender choose whether their local detector returns 0 or 1?", 
    misconceptionId: "entanglement-faster-than-light", misconceptionFeedback: "Entanglement does not provide a controllable faster-than-light signal. The local outcomes remain random.", whyItMatters: "It prevents a common and important misinterpretation of quantum correlations.", estimatedSeconds: 55,
  },
  {
    id: "academy-q29-shot-noise", lessonId: "measurement", topic: "Sampling", level: "practitioner",
    prompt: "What usually happens to statistical sampling uncertainty as the number of independent shots increases?",
    options: [{ id: "a", label: "It generally decreases roughly like 1/√N" }, { id: "b", label: "It grows linearly with N" }, { id: "c", label: "It becomes exactly zero after 10 shots" }],
    correctOptionId: "a", explanation: "For many simple estimators, standard error scales as 1/√N. More shots improve estimates but do not make finite-sample uncertainty vanish instantly.", hint: "Doubling the number of shots does not halve the standard error; think square root.",
    misconceptionId: "more-shots-perfect", misconceptionFeedback: "More shots reduce sampling uncertainty gradually. Finite data never guarantees exact probabilities.", whyItMatters: "A good quantum experiment reports uncertainty, not only a point estimate.", estimatedSeconds: 45,
  },
  {
    id: "academy-q30-fidelity", lessonId: "decoherence", topic: "Fidelity", level: "researcher",
    prompt: "For a pure target state |ψ⟩ and a pure output state |φ⟩, what is their state fidelity?",
    options: [{ id: "a", label: "|⟨ψ|φ⟩|²" }, { id: "b", label: "⟨ψ|φ⟩ + 1" }, { id: "c", label: "The number of gates in the circuit" }],
    correctOptionId: "a", explanation: "For two pure states, fidelity is the squared magnitude of their inner product. It ranges from 0 to 1.", hint: "Fidelity measures overlap between states and is bounded between 0 and 1.",
    misconceptionId: "fidelity-is-gate-count", misconceptionFeedback: "Fidelity is a measure of state similarity, not circuit size or the number of gates.", whyItMatters: "Fidelity helps quantify how closely an experiment or simulation matches a target state.", estimatedSeconds: 40,
  },
];

const BASE_QUESTIONS: AcademyQuestion[] = QUIZ_QUESTIONS.map((question) => ({
  id: question.id,
  lessonId: question.sourceLessonId,
  topic: question.topic,
  level: question.difficulty === "curious" ? "curious" : question.difficulty === "practitioner" ? "practitioner" : "researcher",
  prompt: question.prompt,
  options: question.options,
  correctOptionId: question.correctOptionId,
  explanation: question.explanation,
  hint: question.hint,
  misconceptionId: `legacy-${question.id}`,
  misconceptionFeedback: question.explanation,
  whyItMatters: "This concept supports the next stage of quantum reasoning and experimentation.",
  estimatedSeconds: 40,
}));

export const ACADEMY_QUESTIONS: AcademyQuestion[] = [...BASE_QUESTIONS, ...EXTENDED_QUESTIONS];

export function questionsForLesson(lessonId: string): AcademyQuestion[] {
  return ACADEMY_QUESTIONS.filter((question) => question.lessonId === lessonId);
}

export function questionsForLevel(level: LearningLevel): AcademyQuestion[] {
  return ACADEMY_QUESTIONS.filter((question) => question.level === level);
}

export function getAcademyQuestion(questionId: string): AcademyQuestion | undefined {
  return ACADEMY_QUESTIONS.find((question) => question.id === questionId);
}

export function getQuestionCountByLesson(): Record<string, number> {
  return ACADEMY_QUESTIONS.reduce<Record<string, number>>((counts, question) => {
    counts[question.lessonId] = (counts[question.lessonId] ?? 0) + 1;
    return counts;
  }, {});
}
