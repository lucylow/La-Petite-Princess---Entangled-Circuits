// @ts-nocheck
import { LESSONS } from "../data/lessons";
import type { LearningPath, LessonMetadata, LearningLevel } from "./types";

export const LEARNING_PATHS: LearningPath[] = [
  {
    id: "quantum-foundations",
    title: "The Curious Mind",
    subtitle: "Quantum foundations",
    description: "Meet qubits, explore superposition, and discover how measurement turns amplitudes into observed outcomes.",
    level: "curious",
    estimatedHours: 0.7,
    accent: "rose",
    lessonIds: ["what-is-a-qubit", "superposition", "measurement"],
    outcome: "Explain what a qubit is and predict simple measurement probabilities.",
    icon: "✦",
  },
  {
    id: "quantum-connections",
    title: "The Entangled Story",
    subtitle: "Connections and circuits",
    description: "Build Bell states, read circuit diagrams, and understand why order, phase, and interference matter.",
    level: "practitioner",
    estimatedHours: 0.9,
    accent: "violet",
    lessonIds: ["entanglement", "gates", "interference"],
    outcome: "Create a Bell pair and explain the role of gates and relative phase.",
    icon: "∞",
  },
  {
    id: "quantum-engineering",
    title: "The Quantum Workshop",
    subtitle: "Noise, tests, and algorithms",
    description: "Investigate real engineering limits, Bell tests, and the basic idea behind quantum search.",
    level: "researcher",
    estimatedHours: 0.8,
    accent: "blue",
    lessonIds: ["decoherence", "bell-test", "grover"],
    outcome: "Interpret a noisy experiment and describe the purpose of a simple quantum algorithm.",
    icon: "⌘",
  },
  {
    id: "quantum-frontiers",
    title: "The Mathematical Frontier",
    subtitle: "An advanced braid connection",
    description: "Explore how braid groups appear in certain models of topological quantum computing—while keeping metaphor and physics distinct.",
    level: "researcher",
    estimatedHours: 0.4,
    accent: "gold",
    lessonIds: ["topological"],
    outcome: "Describe what a braid representation means in a topological quantum-computing model.",
    icon: "⌁",
  },
];

const META: Record<string, Omit<LessonMetadata, "lessonId">> = {
  "what-is-a-qubit": {
    pathId: "quantum-foundations", order: 1, level: "curious", estimatedMinutes: 8, prerequisites: [],
    objectives: [
      { id: "bit-vs-qubit", label: "Distinguish a classical bit from a qubit", checkFor: "A bit is 0 or 1; a pure qubit may be a normalized superposition." },
      { id: "basis-ket", label: "Read |0⟩ and |1⟩ notation", checkFor: "These are computational-basis states." },
      { id: "normalization", label: "State the normalization condition", checkFor: "The squared magnitudes of all amplitudes sum to one." },
    ],
    keyTerms: ["qubit", "basis state", "amplitude", "normalization"],
    misconception: "A qubit is not simply a classical bit whose value is hidden. Its complex amplitudes and phase affect experiments.",
    nextAction: "Prepare |0⟩ and apply a Hadamard gate in the Quantum Lab.",
  },
  "superposition": {
    pathId: "quantum-foundations", order: 2, level: "curious", estimatedMinutes: 10, prerequisites: ["what-is-a-qubit"],
    objectives: [
      { id: "linear-combination", label: "Describe superposition as a linear combination", checkFor: "The state is a sum of basis states weighted by amplitudes." },
      { id: "born-rule", label: "Connect amplitudes to probabilities", checkFor: "Probability is the squared magnitude of the amplitude." },
      { id: "phase-intro", label: "Recognize that phase matters", checkFor: "Relative phase can affect later interference." },
    ],
    keyTerms: ["superposition", "phase", "Hadamard gate", "Born rule"],
    misconception: "Superposition does not mean the qubit is a tiny classical object visibly switching between 0 and 1.",
    nextAction: "Use the amplitude explorer to vary the state and predict its measurement distribution.",
  },
  "measurement": {
    pathId: "quantum-foundations", order: 3, level: "curious", estimatedMinutes: 9, prerequisites: ["what-is-a-qubit", "superposition"],
    objectives: [
      { id: "one-shot", label: "Explain why one shot gives one outcome", checkFor: "A measurement samples one classical result." },
      { id: "many-shots", label: "Explain why experiments are repeated", checkFor: "Repeated shots estimate the probability distribution." },
    ],
    keyTerms: ["measurement", "shot", "probability", "frequency"],
    misconception: "A 50/50 state does not return half of a bit in one run. Each run returns either 0 or 1.",
    nextAction: "Run 10, 100, and 1,000 simulated shots and compare the frequencies.",
  },
  "entanglement": {
    pathId: "quantum-connections", order: 4, level: "practitioner", estimatedMinutes: 12, prerequisites: ["what-is-a-qubit", "superposition", "measurement"],
    objectives: [
      { id: "joint-state", label: "Describe a joint quantum state", checkFor: "The complete two-qubit system has one joint state vector." },
      { id: "bell-pair", label: "Identify a Bell state", checkFor: "Phi-plus is (|00⟩ + |11⟩)/√2." },
      { id: "no-signalling", label: "Reject faster-than-light messaging", checkFor: "Entanglement correlations cannot transmit a controllable message faster than light." },
    ],
    keyTerms: ["entanglement", "tensor product", "Bell state", "correlation"],
    misconception: "The braid is a storytelling metaphor. Ordinary hair braids do not create quantum entanglement.",
    nextAction: "Build H(Q1) followed by CNOT(Q1 → Q2), then measure repeatedly.",
  },
  "gates": {
    pathId: "quantum-connections", order: 5, level: "practitioner", estimatedMinutes: 14, prerequisites: ["what-is-a-qubit", "superposition"],
    objectives: [
      { id: "unitary", label: "Explain why ideal gates are unitary", checkFor: "Unitary operations preserve inner products and normalization." },
      { id: "order", label: "Explain why gate order matters", checkFor: "Quantum operations generally do not commute." },
      { id: "controlled", label: "Identify control and target qubits", checkFor: "A controlled gate acts on a target depending on the control state." },
    ],
    keyTerms: ["unitary", "gate", "circuit", "control", "target"],
    misconception: "A quantum gate is not a measurement; a unitary gate transforms amplitudes coherently.",
    nextAction: "Build H → CNOT and reverse the order. Compare the final states.",
  },
  "interference": {
    pathId: "quantum-connections", order: 6, level: "practitioner", estimatedMinutes: 12, prerequisites: ["superposition", "gates"],
    objectives: [
      { id: "relative-phase", label: "Distinguish global and relative phase", checkFor: "Relative phase can affect interference; global phase is unobservable." },
      { id: "amplitude-addition", label: "Explain amplitude addition", checkFor: "Amplitudes combine before probabilities are calculated." },
    ],
    keyTerms: ["interference", "relative phase", "global phase", "rotation"],
    misconception: "Phase is not always irrelevant. Relative phase can affect future measurement probabilities.",
    nextAction: "Change the phase between two Hadamard gates and observe the output probability.",
  },
  "decoherence": {
    pathId: "quantum-engineering", order: 7, level: "researcher", estimatedMinutes: 13, prerequisites: ["measurement", "gates"],
    objectives: [
      { id: "environment", label: "Describe environmental interaction", checkFor: "A system becomes correlated with unobserved environmental degrees of freedom." },
      { id: "noise-types", label: "Name distinct error sources", checkFor: "Decoherence, gate errors, readout errors, and leakage are not identical." },
    ],
    keyTerms: ["decoherence", "noise", "coherence", "readout error"],
    misconception: "Decoherence is not simply a coding bug; it is related to physical interactions and loss of accessible phase coherence.",
    nextAction: "Compare ideal and noisy circuit outcomes in the Noise Lab.",
  },
  "bell-test": {
    pathId: "quantum-engineering", order: 8, level: "researcher", estimatedMinutes: 16, prerequisites: ["entanglement", "measurement"],
    objectives: [
      { id: "correlations", label: "Interpret a correlation experiment", checkFor: "Correlations are estimated from repeated paired measurements." },
      { id: "chsh-bounds", label: "Recall the CHSH bounds", checkFor: "Local hidden-variable bound 2; quantum maximum 2√2." },
    ],
    keyTerms: ["Bell inequality", "CHSH", "correlation", "local hidden variable"],
    misconception: "A Bell inequality violation does not allow faster-than-light communication.",
    nextAction: "Use the Bell Test Lab and compare a finite-shot estimate with the theoretical value.",
  },
  "grover": {
    pathId: "quantum-engineering", order: 9, level: "researcher", estimatedMinutes: 17, prerequisites: ["superposition", "gates", "interference"],
    objectives: [
      { id: "oracle", label: "Describe the role of an oracle", checkFor: "The oracle marks a target by a phase change." },
      { id: "diffusion", label: "Describe amplitude amplification", checkFor: "The diffusion operation reflects amplitudes about their mean." },
      { id: "complexity", label: "Interpret the query scaling", checkFor: "Grover uses O(√N) oracle queries for unstructured search." },
    ],
    keyTerms: ["oracle", "diffusion", "amplitude amplification", "query complexity"],
    misconception: "A quantum algorithm does not simply try all answers at once and read them all out.",
    nextAction: "Choose a marked item and run a Grover iteration in the Algorithms Lab.",
  },
  "topological": {
    pathId: "quantum-frontiers", order: 10, level: "researcher", estimatedMinutes: 18, prerequisites: ["entanglement", "gates"],
    objectives: [
      { id: "braid-group", label: "Describe braid-group operations", checkFor: "Exchanges of anyons correspond to braid-group elements in certain models." },
      { id: "distinction", label: "Distinguish metaphor from mechanism", checkFor: "Hair braiding is a visual analogy, not a quantum operation." },
    ],
    keyTerms: ["topological quantum computing", "anyon", "braid group", "non-Abelian"],
    misconception: "Mathematical braids in topological quantum computing are not ordinary hair braids and not a synonym for entanglement.",
    nextAction: "Explore the braid mathematics panel and identify each strand exchange.",
  },
};

export const LESSON_METADATA: LessonMetadata[] = LESSONS.map((lesson) => ({
  lessonId: lesson.id,
  ...META[lesson.id],
}));

export function getLessonMetadata(lessonId: string): LessonMetadata | undefined {
  return LESSON_METADATA.find((item) => item.lessonId === lessonId);
}

export function getPathById(pathId: string): LearningPath | undefined {
  return LEARNING_PATHS.find((path) => path.id === pathId);
}

export function getPathForLesson(lessonId: string): LearningPath | undefined {
  return LEARNING_PATHS.find((path) => path.lessonIds.includes(lessonId));
}

export function getLevelLabel(level: LearningLevel): string {
  return level === "curious" ? "First steps" : level === "practitioner" ? "Building intuition" : "Going deeper";
}
