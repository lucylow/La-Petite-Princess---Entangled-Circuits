// @ts-nocheck
import { describe, expect, it } from "vitest";
import { getAcademyQuestion } from "./questionBank";
import {
  completeLesson,
  createInitialProgress,
  currentStreak,
  getDueReviewCards,
  gradeReview,
  recommendLessons,
  recordAnswer,
  scheduleReview,
  updateBayesianKnowledge,
} from "./learningEngine";
import { sanitizeProgress } from "./storage";

const fixedNow = new Date("2026-11-03T12:00:00.000Z");

describe("Quantum Academy learning engine", () => {
  it("updates Bayesian mastery upward after a correct answer", () => {
    const next = updateBayesianKnowledge(0.2, true);
    expect(next).toBeGreaterThan(0.2);
    expect(next).toBeLessThanOrEqual(1);
  });

  it("updates Bayesian mastery downward after an incorrect answer", () => {
    const next = updateBayesianKnowledge(0.8, false);
    expect(next).toBeLessThan(0.8);
    expect(next).toBeGreaterThanOrEqual(0);
  });

  it("keeps invalid prior probabilities inside the valid interval", () => {
    expect(updateBayesianKnowledge(-4, true)).toBeGreaterThanOrEqual(0);
    expect(updateBayesianKnowledge(9, true)).toBeLessThanOrEqual(1);
  });

  it("records a practice attempt, topic mastery, a review card, and XP", () => {
    const progress = createInitialProgress(fixedNow);
    const question = getAcademyQuestion("academy-q13-normalization");
    expect(question).toBeTruthy();
    const result = recordAnswer(progress, {
      question: question!, selectedOptionId: question!.correctOptionId,
      confidence: "confident", usedHint: false, responseMs: 23000, now: fixedNow,
    });
    expect(result.outcome.correct).toBe(true);
    expect(result.progress.attempts).toHaveLength(1);
    expect(result.progress.profile.xp).toBeGreaterThan(0);
    expect(Object.keys(result.progress.reviewCards)).toHaveLength(1);
    expect(getDueReviewCards(result.progress, fixedNow)).toHaveLength(1);
  });

  it("records misconception feedback when a learner selects a wrong option", () => {
    const progress = createInitialProgress(fixedNow);
    const question = getAcademyQuestion("academy-q14-phase")!;
    const wrong = question.options.find((option) => option.id !== question.correctOptionId)!;
    const result = recordAnswer(progress, {
      question, selectedOptionId: wrong.id, confidence: "unsure", usedHint: true,
      responseMs: 12000, now: fixedNow,
    });
    expect(result.outcome.correct).toBe(false);
    expect(result.outcome.misconceptionFeedback).toContain("Phase");
    expect(result.progress.attempts[0].correct).toBe(false);
  });

  it("schedules an again card for a short retry", () => {
    const question = getAcademyQuestion("academy-q16-bell")!;
    const progress = recordAnswer(createInitialProgress(fixedNow), {
      question, selectedOptionId: question.correctOptionId, confidence: "confident", usedHint: false, responseMs: 9000, now: fixedNow,
    }).progress;
    const next = gradeReview(progress, question.id, "again", fixedNow);
    const card = next.reviewCards[question.id];
    expect(card.repetitions).toBe(0);
    expect(card.lapses).toBe(1);
    expect(new Date(card.dueAt).getTime() - fixedNow.getTime()).toBe(10 * 60 * 1000);
  });

  it("increases review interval after successful recall", () => {
    const base = {
      id: "card", questionId: "q", dueAt: fixedNow.toISOString(), intervalDays: 1,
      easeFactor: 2.5, repetitions: 1, lapses: 0, lastRating: null,
    };
    const next = scheduleReview(base, "good", fixedNow);
    expect(next.repetitions).toBe(2);
    expect(next.intervalDays).toBe(3);
    expect(new Date(next.dueAt).getTime()).toBeGreaterThan(fixedNow.getTime());
  });

  it("keeps lessons with missing prerequisites behind completed prerequisites", () => {
    const progress = createInitialProgress(fixedNow);
    const recommendation = recommendLessons(progress);
    const qubit = recommendation.find((item) => item.lessonId === "what-is-a-qubit");
    const entanglement = recommendation.find((item) => item.lessonId === "entanglement");
    expect(qubit?.blockedBy).toHaveLength(0);
    expect(entanglement?.blockedBy.length).toBeGreaterThan(0);
  });

  it("unlocks the next lesson after the prerequisite is completed", () => {
    let progress = createInitialProgress(fixedNow);
    progress = completeLesson(progress, "what-is-a-qubit", fixedNow);
    const recommendation = recommendLessons(progress).find((item) => item.lessonId === "superposition");
    expect(recommendation?.blockedBy).toHaveLength(0);
  });

  it("counts a streak across consecutive UTC calendar days", () => {
    const days = ["2026-11-01", "2026-11-02", "2026-11-03"];
    expect(currentStreak(days, fixedNow)).toBe(3);
    expect(currentStreak(["2026-11-01"], fixedNow)).toBe(0);
  });

  it("sanitizes malformed and unsupported progress records", () => {
    const malformed = sanitizeProgress({ schemaVersion: 99, profile: { xp: -999 } });
    expect(malformed.schemaVersion).toBe(2);
    expect(malformed.profile.xp).toBe(0);
    expect(malformed.lessonProgress).toEqual({});
  });
});
