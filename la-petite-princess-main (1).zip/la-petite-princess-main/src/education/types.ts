// @ts-nocheck
export type LearningLevel = "curious" | "practitioner" | "researcher";
export type ConfidenceLevel = "guessing" | "unsure" | "confident";
export type ReviewRating = "again" | "hard" | "good" | "easy";
export type LearningTab = "overview" | "pathways" | "lesson" | "practice" | "review" | "notebook" | "glossary" | "educator";

export interface LearningObjective {
  id: string;
  label: string;
  checkFor: string;
}

export interface LessonMetadata {
  lessonId: string;
  pathId: string;
  order: number;
  level: LearningLevel;
  estimatedMinutes: number;
  prerequisites: string[];
  objectives: LearningObjective[];
  keyTerms: string[];
  misconception: string;
  nextAction: string;
}

export interface LearningPath {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  level: LearningLevel;
  estimatedHours: number;
  accent: "rose" | "violet" | "blue" | "gold";
  lessonIds: string[];
  outcome: string;
  icon: string;
}

export interface AcademyQuestion {
  id: string;
  lessonId: string;
  topic: string;
  level: LearningLevel;
  prompt: string;
  options: { id: string; label: string }[];
  correctOptionId: string;
  explanation: string;
  hint: string;
  misconceptionId: string;
  misconceptionFeedback: string;
  whyItMatters: string;
  estimatedSeconds: number;
}

export interface MasteryState {
  probabilityKnown: number;
  attempts: number;
  correct: number;
  lastPracticedAt: string | null;
  lastOutcome: "correct" | "incorrect" | null;
  confidenceTrend: number;
}

export interface LessonProgress {
  startedAt: string | null;
  completedAt: string | null;
  completedObjectives: string[];
  lastStep: number;
  revisitCount: number;
}

export interface ReviewCard {
  id: string;
  questionId: string;
  dueAt: string;
  intervalDays: number;
  easeFactor: number;
  repetitions: number;
  lapses: number;
  lastRating: ReviewRating | null;
}

export interface QuizAttempt {
  id: string;
  questionId: string;
  selectedOptionId: string;
  correct: boolean;
  confidence: ConfidenceLevel;
  usedHint: boolean;
  answeredAt: string;
  responseMs: number;
}

export interface NotebookEntry {
  id: string;
  lessonId: string | null;
  title: string;
  body: string;
  tags: string[];
  createdAt: string;
  updatedAt: string;
}

export interface LearningEvent {
  id: string;
  type: "lesson-started" | "lesson-completed" | "quiz-answered" | "review-completed" | "activity-completed";
  label: string;
  at: string;
  xp: number;
}

export interface LearnerProfile {
  displayName: string;
  xp: number;
  level: number;
  activeDays: string[];
  createdAt: string;
  lastActiveAt: string | null;
}

export interface LearningProgress {
  schemaVersion: 2;
  profile: LearnerProfile;
  lessonProgress: Record<string, LessonProgress>;
  mastery: Record<string, MasteryState>;
  reviewCards: Record<string, ReviewCard>;
  attempts: QuizAttempt[];
  notebook: NotebookEntry[];
  events: LearningEvent[];
  earnedBadges: string[];
}

export interface AnswerInput {
  question: AcademyQuestion;
  selectedOptionId: string;
  confidence: ConfidenceLevel;
  usedHint: boolean;
  responseMs: number;
  now?: Date;
}

export interface AnswerOutcome {
  correct: boolean;
  explanation: string;
  misconceptionFeedback: string | null;
  masteryBefore: number;
  masteryAfter: number;
  xpEarned: number;
  reviewDueAt: string;
}

export interface RecommendedLesson {
  lessonId: string;
  reason: string;
  readiness: number;
  blockedBy: string[];
}
