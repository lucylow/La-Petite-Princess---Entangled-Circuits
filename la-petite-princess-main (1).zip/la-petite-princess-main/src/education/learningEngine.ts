// @ts-nocheck
import { LESSONS } from "../data/lessons";
import { LESSON_METADATA } from "./curriculum";
import type {
  AnswerInput, AnswerOutcome, LearningEvent, LearningProgress, MasteryState,
  RecommendedLesson, ReviewCard, ReviewRating, ReviewRating as ReviewRatingType,
} from "./types";

export const BKT_DEFAULTS = {
  initialKnowledge: 0.18,
  learn: 0.14,
  guess: 0.20,
  slip: 0.10,
};

const XP = { correct: 12, incorrect: 3, hintBonus: 0, lesson: 35, review: 7, activity: 15 };
const DAY_MS = 24 * 60 * 60 * 1000;
const MINUTE_MS = 60 * 1000;

export function topicKey(topic: string): string {
  return topic.trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}

export function clamp(value: number, min = 0, max = 1): number {
  return Math.min(max, Math.max(min, value));
}

export function emptyMastery(): MasteryState {
  return {
    probabilityKnown: BKT_DEFAULTS.initialKnowledge,
    attempts: 0,
    correct: 0,
    lastPracticedAt: null,
    lastOutcome: null,
    confidenceTrend: 0,
  };
}

export function createInitialProgress(now = new Date()): LearningProgress {
  return {
    schemaVersion: 2,
    profile: {
      displayName: "Curious scientist",
      xp: 0,
      level: 1,
      activeDays: [],
      createdAt: now.toISOString(),
      lastActiveAt: null,
    },
    lessonProgress: {},
    mastery: {},
    reviewCards: {},
    attempts: [],
    notebook: [],
    events: [],
    earnedBadges: [],
  };
}

export function updateBayesianKnowledge(
  prior: number,
  correct: boolean,
  parameters = BKT_DEFAULTS,
): number {
  const p = clamp(prior);
  const likelihoodKnown = correct ? 1 - parameters.slip : parameters.slip;
  const likelihoodUnknown = correct ? parameters.guess : 1 - parameters.guess;
  const denominator = likelihoodKnown * p + likelihoodUnknown * (1 - p);
  const posterior = denominator <= 0 ? p : (likelihoodKnown * p) / denominator;
  return clamp(posterior + (1 - posterior) * parameters.learn);
}

export function masteryFor(progress: LearningProgress, topic: string): MasteryState {
  return progress.mastery[topicKey(topic)] ?? emptyMastery();
}

export function isLessonCompleted(progress: LearningProgress, lessonId: string): boolean {
  return Boolean(progress.lessonProgress[lessonId]?.completedAt);
}

export function getLessonCompletionPercent(progress: LearningProgress): number {
  const total = LESSONS.length;
  if (!total) return 0;
  const completed = LESSONS.filter((lesson) => isLessonCompleted(progress, lesson.id)).length;
  return Math.round((completed / total) * 100);
}

function addActiveDay(progress: LearningProgress, now: Date): string[] {
  const day = now.toISOString().slice(0, 10);
  return [...new Set([...progress.profile.activeDays, day])].sort();
}

function eventId(prefix: string, now: Date): string {
  return `${prefix}-${now.getTime()}-${Math.random().toString(36).slice(2, 8)}`;
}

function withEvent(progress: LearningProgress, event: Omit<LearningEvent, "id" | "at">, now: Date): LearningProgress {
  const record: LearningEvent = { ...event, id: eventId(event.type, now), at: now.toISOString() };
  const activeDays = addActiveDay(progress, now);
  const xp = Math.max(0, event.xp);
  const totalXp = progress.profile.xp + xp;
  return {
    ...progress,
    profile: {
      ...progress.profile,
      xp: totalXp,
      level: Math.floor(totalXp / 150) + 1,
      activeDays,
      lastActiveAt: now.toISOString(),
    },
    events: [record, ...progress.events].slice(0, 500),
  };
}

export function startLesson(progress: LearningProgress, lessonId: string, now = new Date()): LearningProgress {
  const existing = progress.lessonProgress[lessonId];
  const lessonProgress = {
    ...progress.lessonProgress,
    [lessonId]: {
      startedAt: existing?.startedAt ?? now.toISOString(),
      completedAt: existing?.completedAt ?? null,
      completedObjectives: existing?.completedObjectives ?? [],
      lastStep: existing?.lastStep ?? 0,
      revisitCount: (existing?.revisitCount ?? 0) + 1,
    },
  };
  return withEvent({ ...progress, lessonProgress }, { type: "lesson-started", label: `Opened ${lessonId}`, xp: 0 }, now);
}

export function setLessonStep(progress: LearningProgress, lessonId: string, step: number): LearningProgress {
  const existing = progress.lessonProgress[lessonId] ?? {
    startedAt: new Date().toISOString(), completedAt: null, completedObjectives: [], lastStep: 0, revisitCount: 0,
  };
  return {
    ...progress,
    lessonProgress: {
      ...progress.lessonProgress,
      [lessonId]: { ...existing, lastStep: Math.max(0, Math.floor(step)) },
    },
  };
}

export function completeObjective(progress: LearningProgress, lessonId: string, objectiveId: string): LearningProgress {
  const existing = progress.lessonProgress[lessonId] ?? {
    startedAt: new Date().toISOString(), completedAt: null, completedObjectives: [], lastStep: 0, revisitCount: 0,
  };
  return {
    ...progress,
    lessonProgress: {
      ...progress.lessonProgress,
      [lessonId]: {
        ...existing,
        completedObjectives: [...new Set([...existing.completedObjectives, objectiveId])],
      },
    },
  };
}

export function completeLesson(progress: LearningProgress, lessonId: string, now = new Date()): LearningProgress {
  if (isLessonCompleted(progress, lessonId)) return progress;
  const metadata = LESSON_METADATA.find((item) => item.lessonId === lessonId);
  const existing = progress.lessonProgress[lessonId] ?? {
    startedAt: now.toISOString(), completedAt: null, completedObjectives: [], lastStep: 0, revisitCount: 1,
  };
  const next = {
    ...progress,
    lessonProgress: {
      ...progress.lessonProgress,
      [lessonId]: {
        ...existing,
        startedAt: existing.startedAt ?? now.toISOString(),
        completedAt: now.toISOString(),
        completedObjectives: metadata
          ? [...new Set([...existing.completedObjectives, ...metadata.objectives.map((item) => item.id)])]
          : existing.completedObjectives,
      },
    },
  };
  const updated = withEvent(next, { type: "lesson-completed", label: `Completed ${lessonId}`, xp: XP.lesson }, now);
  return awardEligibleBadges(updated);
}

export function makeReviewCard(questionId: string, existing: ReviewCard | undefined, now: Date): ReviewCard {
  if (existing) return existing;
  return {
    id: `review-${questionId}`,
    questionId,
    dueAt: now.toISOString(),
    intervalDays: 0,
    easeFactor: 2.5,
    repetitions: 0,
    lapses: 0,
    lastRating: null,
  };
}

export function recordAnswer(progress: LearningProgress, input: AnswerInput): { progress: LearningProgress; outcome: AnswerOutcome } {
  const now = input.now ?? new Date();
  const correct = input.selectedOptionId === input.question.correctOptionId;
  const key = topicKey(input.question.topic);
  const before = progress.mastery[key] ?? emptyMastery();
  const afterProbability = updateBayesianKnowledge(before.probabilityKnown, correct);
  const confidenceValue = input.confidence === "confident" ? 1 : input.confidence === "unsure" ? 0.5 : 0;
  const confidenceTrend = before.attempts === 0
    ? confidenceValue
    : before.confidenceTrend * 0.7 + confidenceValue * 0.3;
  const after: MasteryState = {
    probabilityKnown: afterProbability,
    attempts: before.attempts + 1,
    correct: before.correct + (correct ? 1 : 0),
    lastPracticedAt: now.toISOString(),
    lastOutcome: correct ? "correct" : "incorrect",
    confidenceTrend,
  };
  const attempt = {
    id: eventId("attempt", now),
    questionId: input.question.id,
    selectedOptionId: input.selectedOptionId,
    correct,
    confidence: input.confidence,
    usedHint: input.usedHint,
    answeredAt: now.toISOString(),
    responseMs: Math.max(0, input.responseMs),
  };
  const reviewCard = makeReviewCard(input.question.id, progress.reviewCards[input.question.id], now);
  const xpEarned = correct ? XP.correct + (input.confidence === "confident" ? 2 : 0) : XP.incorrect;
  let next: LearningProgress = {
    ...progress,
    mastery: { ...progress.mastery, [key]: after },
    reviewCards: { ...progress.reviewCards, [input.question.id]: reviewCard },
    attempts: [...progress.attempts, attempt].slice(-1000),
  };
  next = withEvent(next, { type: "quiz-answered", label: `${correct ? "Correct" : "Practiced"}: ${input.question.topic}`, xp: xpEarned }, now);
  next = awardEligibleBadges(next);
  return {
    progress: next,
    outcome: {
      correct,
      explanation: input.question.explanation,
      misconceptionFeedback: correct ? null : input.question.misconceptionFeedback,
      masteryBefore: before.probabilityKnown,
      masteryAfter: afterProbability,
      xpEarned,
      reviewDueAt: reviewCard.dueAt,
    },
  };
}

function ratingToQuality(rating: ReviewRatingType): number {
  return rating === "again" ? 1 : rating === "hard" ? 3 : rating === "good" ? 4 : 5;
}

export function scheduleReview(card: ReviewCard, rating: ReviewRating, now = new Date()): ReviewCard {
  const quality = ratingToQuality(rating);
  const easeFactor = Math.max(1.3, card.easeFactor + (0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02)));
  let repetitions = card.repetitions;
  let intervalDays = card.intervalDays;
  let lapses = card.lapses;
  let dueAt: Date;

  if (quality < 3) {
    repetitions = 0;
    intervalDays = 0;
    lapses += 1;
    dueAt = new Date(now.getTime() + 10 * MINUTE_MS);
  } else {
    repetitions += 1;
    if (repetitions === 1) intervalDays = rating === "easy" ? 3 : 1;
    else if (repetitions === 2) intervalDays = rating === "easy" ? 7 : 3;
    else intervalDays = Math.max(1, card.intervalDays * easeFactor * (rating === "hard" ? 0.85 : rating === "easy" ? 1.25 : 1));
    dueAt = new Date(now.getTime() + intervalDays * DAY_MS);
  }

  return {
    ...card,
    dueAt: dueAt.toISOString(),
    intervalDays,
    easeFactor,
    repetitions,
    lapses,
    lastRating: rating,
  };
}

export function gradeReview(progress: LearningProgress, questionId: string, rating: ReviewRating, now = new Date()): LearningProgress {
  const current = progress.reviewCards[questionId];
  if (!current) return progress;
  const updatedCard = scheduleReview(current, rating, now);
  return withEvent(
    { ...progress, reviewCards: { ...progress.reviewCards, [questionId]: updatedCard } },
    { type: "review-completed", label: `Reviewed ${questionId} (${rating})`, xp: XP.review },
    now,
  );
}

export function getDueReviewCards(progress: LearningProgress, now = new Date()): ReviewCard[] {
  const timestamp = now.getTime();
  return Object.values(progress.reviewCards)
    .filter((card) => new Date(card.dueAt).getTime() <= timestamp)
    .sort((a, b) => new Date(a.dueAt).getTime() - new Date(b.dueAt).getTime());
}

export function recommendLessons(progress: LearningProgress): RecommendedLesson[] {
  return LESSON_METADATA
    .filter((metadata) => !isLessonCompleted(progress, metadata.lessonId))
    .map((metadata) => {
      const blockedBy = metadata.prerequisites.filter((prerequisite) => !isLessonCompleted(progress, prerequisite));
      const completedPrerequisites = metadata.prerequisites.length - blockedBy.length;
      const readiness = metadata.prerequisites.length ? completedPrerequisites / metadata.prerequisites.length : 1;
      return {
        lessonId: metadata.lessonId,
        reason: blockedBy.length
          ? `Complete ${blockedBy.length} prerequisite lesson${blockedBy.length > 1 ? "s" : ""} first`
          : "Ready to explore",
        readiness: clamp(readiness),
        blockedBy,
      };
    })
    .sort((a, b) => Number(a.blockedBy.length > 0) - Number(b.blockedBy.length > 0) || b.readiness - a.readiness);
}

export function currentStreak(activeDays: string[], now = new Date()): number {
  const unique = new Set(activeDays);
  const today = new Date(now);
  today.setHours(0, 0, 0, 0);
  let cursor = today;
  if (!unique.has(cursor.toISOString().slice(0, 10))) {
    cursor = new Date(cursor.getTime() - DAY_MS);
    if (!unique.has(cursor.toISOString().slice(0, 10))) return 0;
  }
  let streak = 0;
  while (unique.has(cursor.toISOString().slice(0, 10))) {
    streak += 1;
    cursor = new Date(cursor.getTime() - DAY_MS);
  }
  return streak;
}

export function awardEligibleBadges(progress: LearningProgress): LearningProgress {
  const earned = new Set(progress.earnedBadges);
  const completed = LESSONS.filter((lesson) => isLessonCompleted(progress, lesson.id)).length;
  const correct = progress.attempts.filter((attempt) => attempt.correct).length;
  const dueReviewed = progress.events.filter((event) => event.type === "review-completed").length;
  if (completed >= 1) earned.add("first-discovery");
  if (completed >= 5) earned.add("curiosity-streak");
  if (completed === LESSONS.length) earned.add("quantum-cartographer");
  if (correct >= 10) earned.add("careful-thinker");
  if (dueReviewed >= 5) earned.add("memory-weaver");
  if (progress.profile.xp >= 250) earned.add("lab-notebook-star");
  return { ...progress, earnedBadges: [...earned] };
}

export function buildLearningSummary(progress: LearningProgress, now = new Date()) {
  const completedLessons = LESSONS.filter((lesson) => isLessonCompleted(progress, lesson.id)).length;
  const totalAttempts = progress.attempts.length;
  const correctAttempts = progress.attempts.filter((attempt) => attempt.correct).length;
  const topics = Object.entries(progress.mastery).map(([topic, mastery]) => ({
    topic,
    mastery: Math.round(mastery.probabilityKnown * 100),
    attempts: mastery.attempts,
  })).sort((a, b) => b.mastery - a.mastery);
  return {
    completedLessons,
    totalLessons: LESSONS.length,
    completionPercent: getLessonCompletionPercent(progress),
    totalAttempts,
    correctAttempts,
    accuracy: totalAttempts ? Math.round((correctAttempts / totalAttempts) * 100) : 0,
    dueReviews: getDueReviewCards(progress, now).length,
    currentStreak: currentStreak(progress.profile.activeDays, now),
    topics,
    xp: progress.profile.xp,
    learnerLevel: progress.profile.level,
    badges: progress.earnedBadges,
  };
}

export function markActivityCompleted(progress: LearningProgress, activityLabel: string, now = new Date()): LearningProgress {
  return withEvent(progress, { type: "activity-completed", label: activityLabel, xp: XP.activity }, now);
}

export function renameLearner(progress: LearningProgress, displayName: string): LearningProgress {
  const clean = displayName.trim().slice(0, 36);
  return { ...progress, profile: { ...progress.profile, displayName: clean || "Curious scientist" } };
}

export function getLearningInsights(progress: LearningProgress): string[] {
  const insights: string[] = [];
  const weakest = Object.entries(progress.mastery).sort((a, b) => a[1].probabilityKnown - b[1].probabilityKnown)[0];
  const strongest = Object.entries(progress.mastery).sort((a, b) => b[1].probabilityKnown - a[1].probabilityKnown)[0];
  if (weakest && weakest[1].attempts >= 2) insights.push(`Spend a little more time on ${weakest[0].replace(/-/g, " ")}; it is currently your least secure topic.`);
  if (strongest && strongest[1].attempts >= 2) insights.push(`You are building confidence in ${strongest[0].replace(/-/g, " ")}. Try a more challenging question next.`);
  if (getDueReviewCards(progress).length > 0) insights.push(`${getDueReviewCards(progress).length} review card${getDueReviewCards(progress).length === 1 ? " is" : "s are"} ready when you are.`);
  if (insights.length === 0) insights.push("Start with the first pathway. Your progress will help the academy suggest what to practice next.");
  return insights;
}
