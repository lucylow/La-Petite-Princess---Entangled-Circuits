// @ts-nocheck
import type { LearningProgress, NotebookEntry } from "./types";
import { createInitialProgress } from "./learningEngine";

const STORAGE_KEY = "lpp.quantum.academy.progress.v2";

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}

export function sanitizeProgress(input: unknown): LearningProgress {
  const fallback = createInitialProgress();
  if (!isRecord(input)) return fallback;
  const schemaVersion = Number(input.schemaVersion ?? 0);
  if (schemaVersion !== 2) return fallback;
  const profile = isRecord(input.profile) ? input.profile : {};
  return {
    schemaVersion: 2,
    profile: {
      displayName: typeof profile.displayName === "string" ? profile.displayName.slice(0, 36) : fallback.profile.displayName,
      xp: Math.max(0, Number(profile.xp) || 0),
      level: Math.max(1, Number(profile.level) || 1),
      activeDays: Array.isArray(profile.activeDays) ? profile.activeDays.filter((value): value is string => typeof value === "string").slice(-365) : [],
      createdAt: typeof profile.createdAt === "string" ? profile.createdAt : fallback.profile.createdAt,
      lastActiveAt: typeof profile.lastActiveAt === "string" ? profile.lastActiveAt : null,
    },
    lessonProgress: isRecord(input.lessonProgress) ? input.lessonProgress as LearningProgress["lessonProgress"] : {},
    mastery: isRecord(input.mastery) ? input.mastery as LearningProgress["mastery"] : {},
    reviewCards: isRecord(input.reviewCards) ? input.reviewCards as LearningProgress["reviewCards"] : {},
    attempts: Array.isArray(input.attempts) ? input.attempts.slice(-1000) as LearningProgress["attempts"] : [],
    notebook: Array.isArray(input.notebook) ? input.notebook.slice(-200) as NotebookEntry[] : [],
    events: Array.isArray(input.events) ? input.events.slice(0, 500) as LearningProgress["events"] : [],
    earnedBadges: Array.isArray(input.earnedBadges) ? input.earnedBadges.filter((value): value is string => typeof value === "string") : [],
  };
}

export function loadProgress(): LearningProgress {
  if (typeof window === "undefined") return createInitialProgress();
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    return raw ? sanitizeProgress(JSON.parse(raw) as unknown) : createInitialProgress();
  } catch {
    return createInitialProgress();
  }
}

export function saveProgress(progress: LearningProgress): boolean {
  if (typeof window === "undefined") return false;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
    return true;
  } catch {
    return false;
  }
}

export function clearProgress(): void {
  if (typeof window === "undefined") return;
  window.localStorage.removeItem(STORAGE_KEY);
}

export function exportProgress(progress: LearningProgress): string {
  return JSON.stringify({
    product: "La Petite Princesse · Quantum Academy",
    exportedAt: new Date().toISOString(),
    privacy: "This export contains only the local demo learning record on this device.",
    progress,
  }, null, 2);
}

export function importProgress(text: string): LearningProgress {
  const parsed: unknown = JSON.parse(text);
  if (!isRecord(parsed)) throw new Error("The selected file is not a valid academy export.");
  const candidate = "progress" in parsed ? parsed.progress : parsed;
  if (!isRecord(candidate) || Number(candidate.schemaVersion) !== 2) {
    throw new Error("This progress file uses an unsupported version.");
  }
  const sanitized = sanitizeProgress(candidate);
  if (sanitized.schemaVersion !== 2) throw new Error("This progress file uses an unsupported version.");
  return sanitized;
}
