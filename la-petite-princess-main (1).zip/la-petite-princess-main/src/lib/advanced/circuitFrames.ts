import { applyOperation, createZeroState, type CircuitOperation } from "./quantumAdvanced";

export function circuitFrames(operations: CircuitOperation[]) {
  const frames = [createZeroState(2)];
  let state = frames[0] ?? createZeroState(2);
  for (const operation of operations) {
    state = applyOperation(state, 2, operation);
    frames.push(state);
  }
  return frames;
}

export const CIRCUIT_PRESETS: { id: string; title: string; operations: CircuitOperation[] }[] = [
  { id: "bell", title: "Bell pair", operations: [{ id: "bell-h", gate: "H", target: 0 }, { id: "bell-cx", gate: "CNOT", control: 0, target: 1 }] },
  { id: "interference", title: "Phase interference", operations: [{ id: "phase-h1", gate: "H", target: 0 }, { id: "phase-rz", gate: "RZ", target: 0, angle: Math.PI }, { id: "phase-h2", gate: "H", target: 0 }] },
  { id: "swap", title: "State transfer", operations: [{ id: "swap-x", gate: "X", target: 0 }, { id: "swap-s", gate: "SWAP", control: 0, target: 1 }] },
  { id: "phase", title: "Complex amplitudes", operations: [{ id: "complex-h1", gate: "H", target: 0 }, { id: "complex-h2", gate: "H", target: 1 }, { id: "complex-s", gate: "S", target: 0 }, { id: "complex-t", gate: "T", target: 1 }] },
];