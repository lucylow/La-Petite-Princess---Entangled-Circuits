/** Local-only, versioned progress storage. No account, analytics, or personal data. */
export const PROGRESS_STORAGE_KEY = "lpp-entangled-progress-v1";
export interface LocalProgress {
  schemaVersion: 1;
  completedLessons: string[];
  bestQuizPercent: number;
  quizAttempts: number;
  completedChallenges: string[];
  labRuns: number;
  updatedAt: string;
}

export function emptyProgress(): LocalProgress {
  return {
    schemaVersion: 1,
    completedLessons: [],
    bestQuizPercent: 0,
    quizAttempts: 0,
    completedChallenges: [],
    labRuns: 0,
    updatedAt: new Date(0).toISOString(),
  };
}

function isStringArray(value: unknown): value is string[] {
  return Array.isArray(value) && value.every((entry) => typeof entry === "string");
}

export function validateProgress(value: unknown): LocalProgress {
  if (!value || typeof value !== "object") return emptyProgress();
  const record = value as Record<string, unknown>;
  if (record["schemaVersion"] !== 1) return emptyProgress();
  return {
    schemaVersion: 1,
    completedLessons: isStringArray(record["completedLessons"]) ? [...new Set(record["completedLessons"])] : [],
    bestQuizPercent: typeof record["bestQuizPercent"] === "number" && Number.isFinite(record["bestQuizPercent"])
      ? Math.min(100, Math.max(0, record["bestQuizPercent"])) : 0,
    quizAttempts: typeof record["quizAttempts"] === "number" && Number.isFinite(record["quizAttempts"])
      ? Math.max(0, Math.floor(record["quizAttempts"])) : 0,
    completedChallenges: isStringArray(record["completedChallenges"]) ? [...new Set(record["completedChallenges"])] : [],
    labRuns: typeof record["labRuns"] === "number" && Number.isFinite(record["labRuns"])
      ? Math.max(0, Math.floor(record["labRuns"])) : 0,
    updatedAt: typeof record["updatedAt"] === "string" ? record["updatedAt"] : new Date(0).toISOString(),
  };
}

export function loadProgress(storage?: Pick<Storage, "getItem">): LocalProgress {
  try {
    const target = storage ?? (typeof window !== "undefined" ? window.localStorage : undefined);
    if (!target) return emptyProgress();
    const raw = target.getItem(PROGRESS_STORAGE_KEY);
    return raw ? validateProgress(JSON.parse(raw) as unknown) : emptyProgress();
  } catch {
    return emptyProgress();
  }
}

export function saveProgress(progress: LocalProgress, storage?: Pick<Storage, "setItem">): boolean {
  try {
    const target = storage ?? (typeof window !== "undefined" ? window.localStorage : undefined);
    if (!target) return false;
    target.setItem(PROGRESS_STORAGE_KEY, JSON.stringify({ ...progress, updatedAt: new Date().toISOString() }));
    return true;
  } catch {
    return false;
  }
}

export function clearProgress(storage?: Pick<Storage, "removeItem">): boolean {
  try {
    const target = storage ?? (typeof window !== "undefined" ? window.localStorage : undefined);
    if (!target) return false;
    target.removeItem(PROGRESS_STORAGE_KEY);
    return true;
  } catch {
    return false;
  }
}

export function markLessonComplete(progress: LocalProgress, lessonId: string): LocalProgress {
  return { ...progress, completedLessons: [...new Set([...progress.completedLessons, lessonId])] };
}

export function recordQuizAttempt(progress: LocalProgress, percentage: number): LocalProgress {
  const safeScore = Math.min(100, Math.max(0, Math.round(percentage)));
  return { ...progress, quizAttempts: progress.quizAttempts + 1, bestQuizPercent: Math.max(progress.bestQuizPercent, safeScore) };
}

export function markChallengeComplete(progress: LocalProgress, challengeId: string): LocalProgress {
  return { ...progress, completedChallenges: [...new Set([...progress.completedChallenges, challengeId])] };
}

export function recordLabRun(progress: LocalProgress): LocalProgress {
  return { ...progress, labRuns: progress.labRuns + 1 };
}
