import { describe, expect, it } from "vitest";
import {
  PROGRESS_STORAGE_KEY,
  clearProgress,
  emptyProgress,
  loadProgress,
  markChallengeComplete,
  markLessonComplete,
  recordLabRun,
  recordQuizAttempt,
  saveProgress,
  validateProgress,
} from "./progressStore";

function createMemoryStorage() {
  const values = new Map<string, string>();
  return {
    getItem: (key: string) => values.get(key) ?? null,
    setItem: (key: string, value: string) => values.set(key, value),
    removeItem: (key: string) => values.delete(key),
    values,
  };
}

describe("local learning progress", () => {
  it("starts with an empty record", () => {
    expect(emptyProgress().completedLessons).toEqual([]);
    expect(emptyProgress().bestQuizPercent).toBe(0);
  });

  it("deduplicates completed lessons and challenges", () => {
    const first = markLessonComplete(emptyProgress(), "lesson-1");
    const second = markLessonComplete(first, "lesson-1");
    const third = markChallengeComplete(second, "challenge-1");
    const fourth = markChallengeComplete(third, "challenge-1");
    expect(fourth.completedLessons).toEqual(["lesson-1"]);
    expect(fourth.completedChallenges).toEqual(["challenge-1"]);
  });

  it("retains the best quiz score and counts attempts", () => {
    const first = recordQuizAttempt(emptyProgress(), 80);
    const second = recordQuizAttempt(first, 60);
    expect(second.bestQuizPercent).toBe(80);
    expect(second.quizAttempts).toBe(2);
  });

  it("safely clamps malformed values", () => {
    const result = validateProgress({ schemaVersion: 1, bestQuizPercent: 150, quizAttempts: -3, labRuns: 2.8 });
    expect(result.bestQuizPercent).toBe(100);
    expect(result.quizAttempts).toBe(0);
    expect(result.labRuns).toBe(2);
  });

  it("round-trips a record through browser-like storage", () => {
    const storage = createMemoryStorage();
    const progress = recordLabRun(recordQuizAttempt(emptyProgress(), 90));
    expect(saveProgress(progress, storage)).toBe(true);
    expect(storage.values.has(PROGRESS_STORAGE_KEY)).toBe(true);
    expect(loadProgress(storage).labRuns).toBe(1);
    expect(loadProgress(storage).bestQuizPercent).toBe(90);
  });

  it("clears browser-like storage", () => {
    const storage = createMemoryStorage();
    saveProgress(emptyProgress(), storage);
    expect(clearProgress(storage)).toBe(true);
    expect(loadProgress(storage).quizAttempts).toBe(0);
  });

  it("handles invalid JSON without crashing", () => {
    const storage = { getItem: () => "not-json" };
    expect(loadProgress(storage).completedLessons).toEqual([]);
  });
});
