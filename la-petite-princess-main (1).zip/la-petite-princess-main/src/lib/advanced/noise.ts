import { probabilityDistribution } from "./quantumAdvanced";
import type { StateVector } from "./quantumAdvanced";

export interface ReadoutNoiseResult {
  ideal: number[];
  observed: number[];
  flipRates: number[];
  qubitCount: number;
}

function validateRates(rates: number[], qubitCount: number): void {
  if (rates.length !== qubitCount) throw new Error("Provide exactly one readout flip rate per qubit.");
  if (rates.some((rate) => !Number.isFinite(rate) || rate < 0 || rate > 0.5)) {
    throw new RangeError("Readout flip rates must be between 0 and 0.5.");
  }
}

/**
 * Applies a classical independent bit-flip readout channel to an ideal
 * computational-basis distribution. This models readout misclassification,
 * not gate noise or quantum decoherence.
 *
 * rates[0] is Q1 (least-significant bit); rates[1] is Q2, etc.
 */
export function applyReadoutNoiseToDistribution(ideal: number[], qubitCount: number, rates: number[]): number[] {
  if (!Number.isInteger(qubitCount) || qubitCount < 1 || ideal.length !== 2 ** qubitCount) {
    throw new Error("Distribution length must equal 2 raised to the qubit count.");
  }
  validateRates(rates, qubitCount);
  const observed = Array.from({ length: ideal.length }, () => 0);
  ideal.forEach((probability, trueIndex) => {
    if (!Number.isFinite(probability) || probability < 0) throw new Error("Ideal probabilities must be finite and non-negative.");
    for (let observedIndex = 0; observedIndex < ideal.length; observedIndex += 1) {
      let conditional = 1;
      for (let qubit = 0; qubit < qubitCount; qubit += 1) {
        const trueBit = (trueIndex >> qubit) & 1;
        const observedBit = (observedIndex >> qubit) & 1;
        const rate = rates[qubit] ?? 0;
        conditional *= trueBit === observedBit ? 1 - rate : rate;
      }
      observed[observedIndex] = (observed[observedIndex] ?? 0) + probability * conditional;
    }
  });
  const total = observed.reduce((sum, value) => sum + value, 0);
  return observed.map((value) => value / total);
}

export function applyReadoutNoiseToState(state: StateVector, qubitCount: number, rates: number[]): ReadoutNoiseResult {
  const ideal = probabilityDistribution(state);
  return { ideal, observed: applyReadoutNoiseToDistribution(ideal, qubitCount, rates), flipRates: [...rates], qubitCount };
}

export function estimateReadoutCounts(distribution: number[], shots: number): number[] {
  if (!Number.isInteger(shots) || shots < 1 || shots > 1_000_000) throw new RangeError("Shots must be between 1 and 1,000,000.");
  const exact = distribution.map((probability) => probability * shots);
  const counts = exact.map(Math.floor);
  let remaining = shots - counts.reduce((sum, value) => sum + value, 0);
  const order = exact.map((value, index) => ({ index, remainder: value - Math.floor(value) })).sort((a, b) => b.remainder - a.remainder);
  for (let index = 0; index < remaining; index += 1) {
    const slot = order[index];
    if (!slot) continue;
    counts[slot.index] = (counts[slot.index] ?? 0) + 1;
  }
  return counts;
}
