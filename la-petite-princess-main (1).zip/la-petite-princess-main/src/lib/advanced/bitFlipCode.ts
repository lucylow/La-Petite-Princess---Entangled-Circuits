import { complex } from "./complex";
import {
  applyOperation,
  createZeroState,
  probabilityDistribution,
  stateFidelity,
  type StateVector,
} from "./quantumAdvanced";

export type LogicalErrorQubit = 0 | 1 | 2 | null;
export interface BitFlipExperiment {
  theta: number;
  errorQubit: LogicalErrorQubit;
  inputState: StateVector;
  encodedState: StateVector;
  corruptedState: StateVector;
  correctedState: StateVector;
  syndrome: string;
  correctionQubit: LogicalErrorQubit;
  fidelityAfterCorrection: number;
  probabilitiesBeforeCorrection: number[];
  probabilitiesAfterCorrection: number[];
  explanation: string;
}

function applyRYToData(theta: number): StateVector {
  return applyOperation(createZeroState(3), 3, { id: "prepare-logical-state", gate: "RY", target: 0, angle: theta });
}

export function encodeThreeQubitBitFlip(theta: number): { inputState: StateVector; encodedState: StateVector } {
  const inputState = applyRYToData(theta);
  // Encode α|0> + β|1> as α|000> + β|111>, using Q1 as control twice.
  let encodedState = applyOperation(inputState, 3, { id: "encode-q2", gate: "CNOT", control: 0, target: 1 });
  encodedState = applyOperation(encodedState, 3, { id: "encode-q3", gate: "CNOT", control: 0, target: 2 });
  return { inputState, encodedState };
}

export function injectBitFlip(state: StateVector, errorQubit: LogicalErrorQubit): StateVector {
  if (errorQubit === null) return state.map((amplitude) => complex(amplitude.re, amplitude.im));
  return applyOperation(state, 3, { id: `x-error-q${errorQubit + 1}`, gate: "X", target: errorQubit });
}

/** Syndrome convention: s12 = q1 XOR q2, s23 = q2 XOR q3. */
export function syndromeForBasisLabel(label: string): string {
  if (!/^[01]{3}$/.test(label)) throw new Error("Expected a three-bit basis label |q3 q2 q1>.");
  const q3 = Number(label[0]);
  const q2 = Number(label[1]);
  const q1 = Number(label[2]);
  return `${q1 ^ q2}${q2 ^ q3}`;
}

export function syndromeFromState(state: StateVector): string {
  if (state.length !== 8) throw new Error("Syndrome extraction requires a three-qubit state.");
  const probabilities = probabilityDistribution(state);
  const syndromeWeights = new Map<string, number>();
  probabilities.forEach((probability, index) => {
    if (probability < 1e-10) return;
    const label = index.toString(2).padStart(3, "0");
    const syndrome = syndromeForBasisLabel(label);
    syndromeWeights.set(syndrome, (syndromeWeights.get(syndrome) ?? 0) + probability);
  });
  const sorted = [...syndromeWeights.entries()].sort((a, b) => b[1] - a[1]);
  if (sorted.length > 1 && Math.abs((sorted[0]?.[1] ?? 0) - (sorted[1]?.[1] ?? 0)) < 1e-8) {
    throw new Error("The simplified decoder expects one identifiable single-bit error syndrome.");
  }
  return sorted[0]?.[0] ?? "00";
}

export function decodeSyndrome(syndrome: string): LogicalErrorQubit {
  switch (syndrome) {
    case "00": return null;
    case "10": return 0;
    case "11": return 1;
    case "01": return 2;
    default: throw new Error(`Unknown two-bit syndrome: ${syndrome}`);
  }
}

export function correctBitFlip(state: StateVector, syndrome: string): StateVector {
  const correctionQubit = decodeSyndrome(syndrome);
  if (correctionQubit === null) return state.map((amplitude) => complex(amplitude.re, amplitude.im));
  return applyOperation(state, 3, { id: `correct-q${correctionQubit + 1}`, gate: "X", target: correctionQubit });
}

export function runBitFlipCodeExperiment(theta: number, errorQubit: LogicalErrorQubit): BitFlipExperiment {
  if (!Number.isFinite(theta)) throw new RangeError("State preparation angle must be finite.");
  const { inputState, encodedState } = encodeThreeQubitBitFlip(theta);
  const corruptedState = injectBitFlip(encodedState, errorQubit);
  const syndrome = syndromeFromState(corruptedState);
  const correctionQubit = decodeSyndrome(syndrome);
  const correctedState = correctBitFlip(corruptedState, syndrome);
  const fidelityAfterCorrection = stateFidelity(encodedState, correctedState);
  const explanation = errorQubit === null
    ? "No bit-flip error was added. The parity checks return syndrome 00, so the decoder leaves the encoded state unchanged."
    : `A bit flip on Q${errorQubit + 1} changes the two parity checks to syndrome ${syndrome}. The decoder identifies Q${(correctionQubit ?? 0) + 1} and applies a correcting X operation.`;
  return {
    theta,
    errorQubit,
    inputState,
    encodedState,
    corruptedState,
    correctedState,
    syndrome,
    correctionQubit,
    fidelityAfterCorrection,
    probabilitiesBeforeCorrection: probabilityDistribution(corruptedState),
    probabilitiesAfterCorrection: probabilityDistribution(correctedState),
    explanation,
  };
}
