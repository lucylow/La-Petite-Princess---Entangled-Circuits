/**
 * Story-journey tracking: which chapters a reader has discovered and where
 * they left off. Stored locally in this browser only — no account, no
 * analytics, no personal data.
 */

export const STORY_JOURNEY_KEY = "lpp-story-journey-v1";

export interface StoryJourney {
  discoveredChapters: string[];
  lastChapterIndex: number;
  lastSection: string;
}

export function emptyJourney(): StoryJourney {
  return { discoveredChapters: [], lastChapterIndex: 0, lastSection: "home" };
}

export function validateJourney(value: unknown, chapterCount: number, chapterNumbers: string[]): StoryJourney {
  if (!value || typeof value !== "object") return emptyJourney();
  const record = value as Record<string, unknown>;
  const discovered = Array.isArray(record["discoveredChapters"])
    ? [...new Set(record["discoveredChapters"].filter((entry): entry is string => typeof entry === "string" && chapterNumbers.includes(entry)))]
    : [];
  const lastChapter = record["lastChapterIndex"];
  const lastSection = record["lastSection"];
  return {
    discoveredChapters: discovered,
    lastChapterIndex:
      typeof lastChapter === "number" && Number.isFinite(lastChapter)
        ? Math.min(Math.max(0, Math.floor(lastChapter)), Math.max(0, chapterCount - 1))
        : 0,
    lastSection: typeof lastSection === "string" && lastSection.length > 0 ? lastSection : "home",
  };
}

export function loadJourney(
  chapterCount: number,
  chapterNumbers: string[],
  storage?: Pick<Storage, "getItem">,
): StoryJourney {
  try {
    const target = storage ?? (typeof window !== "undefined" ? window.localStorage : undefined);
    if (!target) return emptyJourney();
    const raw = target.getItem(STORY_JOURNEY_KEY);
    return raw ? validateJourney(JSON.parse(raw) as unknown, chapterCount, chapterNumbers) : emptyJourney();
  } catch {
    return emptyJourney();
  }
}

export function saveJourney(journey: StoryJourney, storage?: Pick<Storage, "setItem">): boolean {
  try {
    const target = storage ?? (typeof window !== "undefined" ? window.localStorage : undefined);
    if (!target) return false;
    target.setItem(STORY_JOURNEY_KEY, JSON.stringify(journey));
    return true;
  } catch {
    return false;
  }
}

/** Records a chapter visit. Dedupes discoveries and remembers the position. */
export function markChapterDiscovered(journey: StoryJourney, chapterNumber: string, chapterIndex: number): StoryJourney {
  return {
    ...journey,
    discoveredChapters: [...new Set([...journey.discoveredChapters, chapterNumber])],
    lastChapterIndex: Math.max(0, Math.floor(chapterIndex)),
  };
}

/** Records which section of the experience the reader visited last. */
export function markSectionVisited(journey: StoryJourney, section: string): StoryJourney {
  return { ...journey, lastSection: section };
}
