export interface BellAngles {
  a: number;
  aPrime: number;
  b: number;
  bPrime: number;
}

export interface CorrelationSample {
  label: string;
  angleA: number;
  angleB: number;
  expectedCorrelation: number;
  observedCorrelation: number;
  same: number;
  different: number;
  shots: number;
}

export interface BellExperimentResult {
  correlations: [CorrelationSample, CorrelationSample, CorrelationSample, CorrelationSample];
  theoreticalS: number;
  observedS: number;
  classicalBound: number;
  quantumTsirelsonBound: number;
  shotsPerSetting: number;
}

const toRadians = (degrees: number) => degrees * Math.PI / 180;

/**
 * Ideal correlation for |Phi+> = (|00> + |11>)/sqrt(2) with real X-Z plane
 * analyzer directions. This model uses E(a,b)=cos(a-b), and all outcomes are
 * ±1 with unbiased local marginals. Angles are pedagogical analyzer settings.
 */
export function bellCorrelation(angleA: number, angleB: number): number {
  return Math.cos(toRadians(angleA - angleB));
}

export function chshValue(angles: BellAngles): number {
  const eAB = bellCorrelation(angles.a, angles.b);
  const eABp = bellCorrelation(angles.a, angles.bPrime);
  const eApB = bellCorrelation(angles.aPrime, angles.b);
  const eApBp = bellCorrelation(angles.aPrime, angles.bPrime);
  return eAB + eABp + eApB - eApBp;
}

function sampleBinary(rng: () => number): 0 | 1 {
  return rng() < 0.5 ? 0 : 1;
}

export function simulateBellSetting(
  label: string,
  angleA: number,
  angleB: number,
  shots: number,
  rng: () => number = Math.random,
): CorrelationSample {
  if (!Number.isInteger(shots) || shots < 1 || shots > 100_000) {
    throw new RangeError("Shots must be between 1 and 100,000.");
  }
  const expected = bellCorrelation(angleA, angleB);
  const sameProbability = (1 + expected) / 2;
  let same = 0;
  let different = 0;
  for (let index = 0; index < shots; index += 1) {
    const first = sampleBinary(rng);
    const isSame = rng() < sameProbability;
    const second = isSame ? first : (first === 0 ? 1 : 0);
    if (first === second) same += 1;
    else different += 1;
  }
  return {
    label,
    angleA,
    angleB,
    expectedCorrelation: expected,
    observedCorrelation: (same - different) / shots,
    same,
    different,
    shots,
  };
}

export function runBellExperiment(
  angles: BellAngles = { a: 0, aPrime: 90, b: 45, bPrime: -45 },
  shotsPerSetting = 500,
  rng: () => number = Math.random,
): BellExperimentResult {
  const correlations: BellExperimentResult["correlations"] = [
    simulateBellSetting("A · B", angles.a, angles.b, shotsPerSetting, rng),
    simulateBellSetting("A · B′", angles.a, angles.bPrime, shotsPerSetting, rng),
    simulateBellSetting("A′ · B", angles.aPrime, angles.b, shotsPerSetting, rng),
    simulateBellSetting("A′ · B′", angles.aPrime, angles.bPrime, shotsPerSetting, rng),
  ];
  const values = correlations.map((sample) => sample.observedCorrelation);
  const expected = correlations.map((sample) => sample.expectedCorrelation);
  return {
    correlations,
    theoreticalS: (expected[0] ?? 0) + (expected[1] ?? 0) + (expected[2] ?? 0) - (expected[3] ?? 0),
    observedS: (values[0] ?? 0) + (values[1] ?? 0) + (values[2] ?? 0) - (values[3] ?? 0),
    classicalBound: 2,
    quantumTsirelsonBound: 2 * Math.SQRT2,
    shotsPerSetting,
  };
}

export const OPTIMAL_CHSH_ANGLES: BellAngles = { a: 0, aPrime: 90, b: 45, bPrime: -45 };

export function isQuantumChshViolation(value: number): boolean {
  return Math.abs(value) > 2;
}

export function describeChshValue(value: number): string {
  if (Math.abs(value) > 2 + 1e-9) return "This ideal quantum prediction exceeds the local-hidden-variable CHSH bound.";
  if (Math.abs(value) >= 1.9) return "This value is close to the classical CHSH boundary.";
  return "These settings do not show a CHSH violation in this run.";
}
