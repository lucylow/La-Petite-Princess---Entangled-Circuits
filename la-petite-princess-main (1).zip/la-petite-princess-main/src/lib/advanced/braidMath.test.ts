import { describe, expect, it } from "vitest";
import {
  braidPermutation,
  braidRelationPermutationCheck,
  buildBraidTraces,
  composeBraidWords,
  inverseBraidWord,
  reduceBraidWord,
  validateBraidWord,
  YOUNG_BRAID_RELATION_LEFT,
  YOUNG_BRAID_RELATION_RIGHT,
} from "./braidMath";

describe("braid-group diagram helpers", () => {
  it("cancels adjacent inverse generators", () => {
    expect(reduceBraidWord([{ index: 1, sign: 1 }, { index: 1, sign: -1 }])).toEqual([]);
  });

  it("constructs the inverse word in reverse order", () => {
    const word = [{ index: 1, sign: 1 as const }, { index: 2, sign: -1 as const }];
    expect(inverseBraidWord(word)).toEqual([{ index: 2, sign: 1 }, { index: 1, sign: -1 }]);
  });

  it("reduces a word followed by its inverse to identity", () => {
    const word = [{ index: 1, sign: 1 as const }, { index: 2, sign: -1 as const }, { index: 1, sign: 1 as const }];
    expect(composeBraidWords(word, inverseBraidWord(word))).toEqual([]);
  });

  it("validates allowed generator indices", () => {
    expect(validateBraidWord(3, [{ index: 3, sign: 1 }])).toHaveLength(1);
    expect(validateBraidWord(3, [{ index: 1, sign: -1 }])).toEqual([]);
  });

  it("shows the Yang-Baxter braid relation has the same endpoint permutation", () => {
    expect(braidRelationPermutationCheck()).toBe(true);
    expect(braidPermutation(3, YOUNG_BRAID_RELATION_LEFT)).toEqual(braidPermutation(3, YOUNG_BRAID_RELATION_RIGHT));
  });

  it("produces one diagram trace per strand", () => {
    const traces = buildBraidTraces(3, YOUNG_BRAID_RELATION_LEFT);
    expect(traces).toHaveLength(3);
    expect(traces.every((trace) => trace.path.includes("M"))).toBe(true);
  });
});
