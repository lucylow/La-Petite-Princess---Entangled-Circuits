/** Complex-number helpers used by the educational state-vector simulator. */
export interface Complex {
  re: number;
  im: number;
}

export const complex = (re = 0, im = 0): Complex => ({ re, im });
export const C_ZERO = (): Complex => complex(0, 0);
export const C_ONE = (): Complex => complex(1, 0);

export function cAdd(a: Complex, b: Complex): Complex {
  return complex(a.re + b.re, a.im + b.im);
}

export function cSub(a: Complex, b: Complex): Complex {
  return complex(a.re - b.re, a.im - b.im);
}

export function cMul(a: Complex, b: Complex): Complex {
  return complex(a.re * b.re - a.im * b.im, a.re * b.im + a.im * b.re);
}

export function cScale(a: Complex, scalar: number): Complex {
  return complex(a.re * scalar, a.im * scalar);
}

export function cConjugate(a: Complex): Complex {
  return complex(a.re, -a.im);
}

export function cMagnitudeSquared(a: Complex): number {
  return a.re * a.re + a.im * a.im;
}

export function cMagnitude(a: Complex): number {
  return Math.sqrt(cMagnitudeSquared(a));
}

export function cPhase(a: Complex): number {
  return Math.atan2(a.im, a.re);
}

export function cExpI(angle: number): Complex {
  return complex(Math.cos(angle), Math.sin(angle));
}

export function cDivide(a: Complex, b: Complex): Complex {
  const denominator = cMagnitudeSquared(b);
  if (denominator === 0) throw new Error("Cannot divide by a zero complex number.");
  return complex(
    (a.re * b.re + a.im * b.im) / denominator,
    (a.im * b.re - a.re * b.im) / denominator,
  );
}

export function cAlmostEqual(a: Complex, b: Complex, tolerance = 1e-9): boolean {
  return Math.abs(a.re - b.re) <= tolerance && Math.abs(a.im - b.im) <= tolerance;
}

export function cFormat(a: Complex, digits = 3): string {
  const epsilon = 10 ** -(digits + 1);
  const re = Math.abs(a.re) < epsilon ? 0 : a.re;
  const im = Math.abs(a.im) < epsilon ? 0 : a.im;
  if (im === 0) return re.toFixed(digits).replace(/\.0+$/, "").replace(/(\.\d*?)0+$/, "$1");
  if (re === 0) return `${im.toFixed(digits).replace(/\.0+$/, "")}i`;
  const sign = im < 0 ? "−" : "+";
  return `${re.toFixed(digits)} ${sign} ${Math.abs(im).toFixed(digits)}i`;
}
