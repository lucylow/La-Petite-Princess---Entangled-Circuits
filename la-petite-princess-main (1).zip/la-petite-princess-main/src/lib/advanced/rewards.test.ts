import { describe, expect, it } from "vitest";
import { emptyProgress } from "./progressStore";
import { getRewards } from "./rewards";

describe("discovery rewards", () => {
  it("awards 50 points per unique catalogue lesson, ignoring duplicates and unknown ids", () => {
    expect(getRewards({ ...emptyProgress(), completedLessons: ["what-is-a-qubit", "what-is-a-qubit", "unknown"] }).points).toBe(50);
  });
  it("awards 100 points per completed challenge", () => {
    expect(getRewards({ ...emptyProgress(), completedChallenges: ["first-superposition"] }).points).toBe(100);
  });
  it("caps composer points at ten runs", () => {
    expect(getRewards({ ...emptyProgress(), labRuns: 11 }).points).toBe(100);
  });
  it("caps quiz participation at five rounds and adds the best score", () => {
    expect(getRewards({ ...emptyProgress(), quizAttempts: 6, bestQuizPercent: 80 }).points).toBe(180);
  });
  it("unlocks the next rank at exactly 100 points", () => {
    expect(getRewards({ ...emptyProgress(), labRuns: 9 }).rankIndex).toBe(0);
    expect(getRewards({ ...emptyProgress(), labRuns: 10 }).rankIndex).toBe(1);
  });
  it("unlocks sharp mind at 80%, not 79%", () => {
    expect(getRewards({ ...emptyProgress(), bestQuizPercent: 79 }).badges.find((badge) => badge.id === "quiz")?.earned).toBe(false);
    expect(getRewards({ ...emptyProgress(), bestQuizPercent: 80 }).badges.find((badge) => badge.id === "quiz")?.earned).toBe(true);
  });
});