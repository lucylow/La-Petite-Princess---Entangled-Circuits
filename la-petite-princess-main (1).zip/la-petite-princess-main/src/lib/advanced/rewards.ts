import { LESSONS } from "../../data/lessons";
import { CHALLENGES } from "../../data/challenges";
import type { LocalProgress } from "./progressStore";

export const REWARD_POINTS = { lesson: 50, challenge: 100, lab: 10, quiz: 20 } as const;
export const RANKS = [
  { name: "Curious mind", threshold: 0 },
  { name: "Qubit explorer", threshold: 100 },
  { name: "Quantum adventurer", threshold: 300 },
  { name: "Lab trailblazer", threshold: 600 },
  { name: "Quantum luminary", threshold: 1000 },
] as const;

export function getRewards(progress: LocalProgress) {
  const lessons = LESSONS.filter((lesson) => progress.completedLessons.includes(lesson.id)).length;
  const challenges = CHALLENGES.filter((challenge) => progress.completedChallenges.includes(challenge.id)).length;
  const points = lessons * REWARD_POINTS.lesson + challenges * REWARD_POINTS.challenge
    + Math.min(progress.labRuns, 10) * REWARD_POINTS.lab
    + Math.min(progress.quizAttempts, 5) * REWARD_POINTS.quiz + Math.round(progress.bestQuizPercent);
  const rankIndex = RANKS.reduce((current, rank, index) => points >= rank.threshold ? index : current, 0);
  const rank = RANKS[rankIndex] ?? RANKS[0];
  const nextRank = RANKS[rankIndex + 1];
  const rankPercent = nextRank ? Math.min(100, (points - rank.threshold) / (nextRank.threshold - rank.threshold) * 100) : 100;
  const badges = [
    { id: "spark", name: "First spark", goal: "Complete one lesson", earned: lessons >= 1, current: Math.min(lessons, 1), target: 1 },
    { id: "builder", name: "Circuit builder", goal: "Run five composer experiments", earned: progress.labRuns >= 5, current: Math.min(progress.labRuns, 5), target: 5 },
    { id: "explorer", name: "Field explorer", goal: "Complete three lessons", earned: lessons >= 3, current: Math.min(lessons, 3), target: 3 },
    { id: "challenger", name: "Challenge accepted", goal: "Complete one challenge", earned: challenges >= 1, current: Math.min(challenges, 1), target: 1 },
    { id: "quiz", name: "Sharp mind", goal: "Reach 80% in a quiz", earned: progress.bestQuizPercent >= 80, current: Math.min(progress.bestQuizPercent, 80), target: 80 },
    { id: "scholar", name: "Quantum scholar", goal: "Complete all ten lessons", earned: lessons >= 10, current: lessons, target: 10 },
  ];
  return { points, rank, rankIndex, nextRank, rankPercent, badges };
}