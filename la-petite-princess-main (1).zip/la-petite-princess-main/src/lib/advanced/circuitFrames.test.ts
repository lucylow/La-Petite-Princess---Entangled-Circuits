import { describe, expect, it } from "vitest";
import { CIRCUIT_PRESETS, circuitFrames } from "./circuitFrames";
import { probabilityDistribution, pureTwoQubitConcurrence } from "./quantumAdvanced";

describe("visual circuit frames", () => {
  it("includes the zero state followed by a state after each gate", () => {
    const frames = circuitFrames([{ id: "h", gate: "H", target: 0 }]);
    expect(frames).toHaveLength(2);
    expect(probabilityDistribution(frames[0] ?? [])).toEqual([1, 0, 0, 0]);
    expect(probabilityDistribution(frames[1] ?? [])[1]).toBeCloseTo(0.5);
  });
  it("prepares a maximally entangled Bell pair", () => {
    const preset = CIRCUIT_PRESETS.find((item) => item.id === "bell");
    const frames = circuitFrames(preset?.operations ?? []);
    expect(pureTwoQubitConcurrence(frames.at(-1) ?? [])).toBeCloseTo(1);
  });
  it("turns phase interference into outcome 01", () => {
    const frames = circuitFrames(CIRCUIT_PRESETS.find((item) => item.id === "interference")?.operations ?? []);
    expect(probabilityDistribution(frames.at(-1) ?? [])[1]).toBeCloseTo(1);
  });
  it("transfers the excitation from Q1 to Q2", () => {
    const frames = circuitFrames(CIRCUIT_PRESETS.find((item) => item.id === "swap")?.operations ?? []);
    expect(probabilityDistribution(frames.at(-1) ?? [])[2]).toBeCloseTo(1);
  });
});