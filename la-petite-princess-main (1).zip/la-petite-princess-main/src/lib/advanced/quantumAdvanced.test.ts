import { describe, expect, it } from "vitest";
import {
  applyGlobalPhase,
  applyOperation,
  basisLabel,
  blochVectorForQubit,
  createBasisState,
  createZeroState,
  formatStateVector,
  isProductStateTwoQubit,
  isStateNormalized,
  measureState,
  probabilityDistribution,
  pureTwoQubitConcurrence,
  pureTwoQubitEntanglementEntropy,
  runCircuit,
  runShots,
  stateFidelity,
  stateNormSquared,
  validateCircuit,
} from "./quantumAdvanced";
import { cAlmostEqual } from "./complex";

describe("advanced state-vector simulator", () => {
  it("creates normalized all-zero basis states", () => {
    for (let qubits = 1; qubits <= 5; qubits += 1) {
      const state = createZeroState(qubits);
      expect(state.length).toBe(2 ** qubits);
      expect(isStateNormalized(state)).toBe(true);
      expect(probabilityDistribution(state)[0]).toBe(1);
    }
  });

  it("uses the documented most-significant-bit-first display ordering", () => {
    expect(basisLabel(0, 2)).toBe("00");
    expect(basisLabel(1, 2)).toBe("01");
    expect(basisLabel(2, 2)).toBe("10");
    expect(basisLabel(3, 2)).toBe("11");
    expect(probabilityDistribution(createBasisState(2, "10"))).toEqual([0, 0, 1, 0]);
  });

  it("applies H twice to return to the initial state", () => {
    const state = runCircuit(1, [
      { id: "h1", gate: "H", target: 0 },
      { id: "h2", gate: "H", target: 0 },
    ]);
    expect(probabilityDistribution(state)).toEqual([1, 0]);
  });

  it("creates the Bell state with H(Q1) followed by CNOT(Q1→Q2)", () => {
    const state = runCircuit(2, [
      { id: "h", gate: "H", target: 0 },
      { id: "cx", gate: "CNOT", control: 0, target: 1 },
    ]);
    const probabilities = probabilityDistribution(state);
    expect(probabilities[0]).toBeCloseTo(0.5);
    expect(probabilities[1]).toBeCloseTo(0);
    expect(probabilities[2]).toBeCloseTo(0);
    expect(probabilities[3]).toBeCloseTo(0.5);
    expect(formatStateVector(state, 2)).toContain("|00⟩");
    expect(formatStateVector(state, 2)).toContain("|11⟩");
    expect(isStateNormalized(state)).toBe(true);
  });

  it("computes zero local Bloch vectors for the Bell pair", () => {
    const bell = runCircuit(2, [
      { id: "h", gate: "H", target: 0 },
      { id: "cx", gate: "CNOT", control: 0, target: 1 },
    ]);
    const q1 = blochVectorForQubit(bell, 2, 0);
    const q2 = blochVectorForQubit(bell, 2, 1);
    expect(q1.x).toBeCloseTo(0);
    expect(q1.y).toBeCloseTo(0);
    expect(q1.z).toBeCloseTo(0);
    expect(q1.purity).toBeCloseTo(0.5);
    expect(q2.purity).toBeCloseTo(0.5);
  });

  it("computes the concurrence and entropy of product and Bell states", () => {
    const product = runCircuit(2, [{ id: "h", gate: "H", target: 0 }]);
    const bell = runCircuit(2, [
      { id: "h", gate: "H", target: 0 },
      { id: "cx", gate: "CNOT", control: 0, target: 1 },
    ]);
    expect(isProductStateTwoQubit(product)).toBe(true);
    expect(pureTwoQubitConcurrence(product)).toBeCloseTo(0);
    expect(pureTwoQubitEntanglementEntropy(product)).toBeCloseTo(0);
    expect(pureTwoQubitConcurrence(bell)).toBeCloseTo(1);
    expect(pureTwoQubitEntanglementEntropy(bell)).toBeCloseTo(1);
  });

  it("supports Y, Z, S and T phase gates without losing normalization", () => {
    for (const gate of ["Y", "Z", "S", "T"] as const) {
      const state = applyOperation(createZeroState(1), 1, { id: gate, gate, target: 0 });
      expect(isStateNormalized(state)).toBe(true);
    }
    const yState = applyOperation(createZeroState(1), 1, { id: "y", gate: "Y", target: 0 });
    expect(cAlmostEqual(yState[1]!, { re: 0, im: 1 })).toBe(true);
  });

  it("supports RX, RY and RZ rotations", () => {
    const rx = runCircuit(1, [{ id: "rx", gate: "RX", target: 0, angle: Math.PI }]);
    const ry = runCircuit(1, [{ id: "ry", gate: "RY", target: 0, angle: Math.PI }]);
    const rz = runCircuit(1, [{ id: "rz", gate: "RZ", target: 0, angle: Math.PI }]);
    expect(probabilityDistribution(rx)[1]).toBeCloseTo(1);
    expect(probabilityDistribution(ry)[1]).toBeCloseTo(1);
    expect(probabilityDistribution(rz)[0]).toBeCloseTo(1);
  });

  it("supports controlled-Z and SWAP", () => {
    const input = createBasisState(2, "11");
    const cz = applyOperation(input, 2, { id: "cz", gate: "CZ", control: 0, target: 1 });
    expect(cz[3]!.re).toBeCloseTo(-1);
    const swapped = applyOperation(createBasisState(2, "01"), 2, { id: "swap", gate: "SWAP", control: 0, target: 1 });
    expect(probabilityDistribution(swapped)).toEqual([0, 0, 1, 0]);
  });

  it("samples only outcomes with nonzero probability", () => {
    const state = createBasisState(2, "10");
    expect(measureState(state, 2, () => 0).label).toBe("10");
    expect(measureState(state, 2, () => 0.999).label).toBe("10");
  });

  it("counts repeated shots and keeps a complete basis histogram", () => {
    const state = runCircuit(2, [{ id: "h", gate: "H", target: 0 }]);
    const result = runShots(state, 2, 50, () => 0.1);
    expect(result.totalShots).toBe(50);
    expect(Object.keys(result.counts).sort()).toEqual(["00", "01", "10", "11"]);
    expect(result.counts["00"]).toBe(50);
    expect(result.counts["01"]).toBe(0);
  });

  it("treats global phase as physically equivalent for fidelity", () => {
    const state = runCircuit(2, [{ id: "h", gate: "H", target: 0 }]);
    const shifted = applyGlobalPhase(state, Math.PI / 3);
    expect(stateFidelity(state, shifted)).toBeCloseTo(1);
  });

  it("flags invalid multi-qubit circuit operations", () => {
    const errors = validateCircuit(2, [{ id: "bad", gate: "CNOT", control: 0, target: 0 }]);
    expect(errors.length).toBeGreaterThan(0);
    expect(() => applyOperation(createZeroState(2), 2, { id: "bad", gate: "CNOT", control: 0, target: 0 })).toThrow();
  });

  it("throws when state and register dimensions disagree", () => {
    expect(() => applyOperation(createZeroState(1), 2, { id: "x", gate: "X", target: 0 })).toThrow();
    expect(stateNormSquared(createZeroState(2))).toBeCloseTo(1);
  });
});
