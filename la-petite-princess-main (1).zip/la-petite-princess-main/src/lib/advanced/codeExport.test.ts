import { describe, expect, it } from "vitest";
import { circuitToOpenQasm, circuitToQiskitPython } from "./codeExport";

const operations = [
  { id: "h", gate: "H" as const, target: 0 },
  { id: "cx", gate: "CNOT" as const, control: 0, target: 1 },
  { id: "rz", gate: "RZ" as const, target: 1, angle: Math.PI / 2 },
];

describe("quantum code export", () => {
  it("exports an OpenQASM 2 header, gates, and measurements", () => {
    const qasm = circuitToOpenQasm(2, operations);
    expect(qasm).toContain("OPENQASM 2.0;");
    expect(qasm).toContain("h q[0];");
    expect(qasm).toContain("cx q[0], q[1];");
    expect(qasm).toContain("measure q[1] -> c[1];");
  });

  it("decomposes CZ and SWAP into qelib-compatible gates", () => {
    const qasm = circuitToOpenQasm(2, [
      { id: "cz", gate: "CZ", control: 0, target: 1 },
      { id: "swap", gate: "SWAP", control: 0, target: 1 },
    ], false);
    expect(qasm.match(/cx q\[0\], q\[1\];/g)).toHaveLength(3);
    expect(qasm).toContain("h q[1];");
  });

  it("exports readable Qiskit Python", () => {
    const python = circuitToQiskitPython(2, operations);
    expect(python).toContain("from qiskit import QuantumCircuit");
    expect(python).toContain("qc.h(0)");
    expect(python).toContain("qc.cx(0, 1)");
    expect(python).toContain("qc.measure(range(2), range(2))");
  });

  it("can omit measurements", () => {
    expect(circuitToOpenQasm(2, operations, false)).not.toContain("measure q[");
    expect(circuitToQiskitPython(2, operations, false)).not.toContain("qc.measure");
  });

  it("rejects malformed circuits", () => {
    expect(() => circuitToOpenQasm(2, [{ id: "cx", gate: "CNOT", control: 0, target: 0 }])).toThrow();
    expect(() => circuitToQiskitPython(9, [])).toThrow();
  });
});
