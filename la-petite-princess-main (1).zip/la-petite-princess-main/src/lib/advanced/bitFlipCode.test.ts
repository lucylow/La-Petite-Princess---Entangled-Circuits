import { describe, expect, it } from "vitest";
import { decodeSyndrome, runBitFlipCodeExperiment, syndromeForBasisLabel } from "./bitFlipCode";

describe("three-qubit bit-flip code teaching model", () => {
  it("maps each basis-state parity to the expected syndrome", () => {
    expect(syndromeForBasisLabel("000")).toBe("00");
    expect(syndromeForBasisLabel("001")).toBe("10");
    expect(syndromeForBasisLabel("010")).toBe("11");
    expect(syndromeForBasisLabel("100")).toBe("01");
  });

  it("decodes the syndrome to the flipped physical qubit", () => {
    expect(decodeSyndrome("00")).toBeNull();
    expect(decodeSyndrome("10")).toBe(0);
    expect(decodeSyndrome("11")).toBe(1);
    expect(decodeSyndrome("01")).toBe(2);
  });

  it("corrects no error or any one physical bit-flip error", () => {
    for (const error of [null, 0, 1, 2] as const) {
      const result = runBitFlipCodeExperiment(Math.PI / 3, error);
      expect(result.fidelityAfterCorrection).toBeCloseTo(1);
      expect(result.syndrome).toBe(error === null ? "00" : error === 0 ? "10" : error === 1 ? "11" : "01");
    }
  });

  it("does not claim to correct a phase-flip channel", () => {
    const result = runBitFlipCodeExperiment(Math.PI / 2, null);
    expect(result.fidelityAfterCorrection).toBeCloseTo(1);
  });
});
