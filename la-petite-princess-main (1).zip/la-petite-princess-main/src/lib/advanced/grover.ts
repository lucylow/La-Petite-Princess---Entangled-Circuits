import {
  createZeroState,
  probabilityDistribution,
  type StateVector,
} from "./quantumAdvanced";
import { C_ONE, cScale, type Complex } from "./complex";

export interface GroverResult {
  initialState: StateVector;
  afterOracle: StateVector;
  finalState: StateVector;
  target: string;
  probabilities: number[];
  successProbability: number;
  iterations: number;
}

function uniformSuperposition(qubitCount: number): StateVector {
  const size = 2 ** qubitCount;
  const amplitude = 1 / Math.sqrt(size);
  return Array.from({ length: size }, () => ({ re: amplitude, im: 0 }));
}

/** A phase oracle flips the sign of exactly one marked basis state. */
export function applyGroverOracle(state: StateVector, markedIndex: number): StateVector {
  if (!Number.isInteger(markedIndex) || markedIndex < 0 || markedIndex >= state.length) {
    throw new RangeError("Marked item is outside the search space.");
  }
  return state.map((amplitude, index) => index === markedIndex
    ? cScale(amplitude, -1)
    : { re: amplitude.re, im: amplitude.im });
}

/** Grover diffusion: reflect every amplitude about their arithmetic mean. */
export function applyGroverDiffusion(state: StateVector): StateVector {
  if (state.length < 2 || (state.length & (state.length - 1)) !== 0) {
    throw new Error("Grover diffusion expects a power-of-two state vector.");
  }
  const meanRe = state.reduce((sum, amplitude) => sum + amplitude.re, 0) / state.length;
  const meanIm = state.reduce((sum, amplitude) => sum + amplitude.im, 0) / state.length;
  return state.map((amplitude) => ({ re: 2 * meanRe - amplitude.re, im: 2 * meanIm - amplitude.im }));
}

export function groverIteration(state: StateVector, markedIndex: number): StateVector {
  return applyGroverDiffusion(applyGroverOracle(state, markedIndex));
}

/**
 * Simulates a single-marked-item Grover search using an ideal state vector.
 * For four items, one iteration amplifies the marked state's probability to 1.
 */
export function runGroverSearch(qubitCount: number, target: string, iterations = 1): GroverResult {
  if (!Number.isInteger(qubitCount) || qubitCount < 2 || qubitCount > 6) {
    throw new RangeError("This teaching demo supports 2 to 6 search qubits.");
  }
  if (!new RegExp(`^[01]{${qubitCount}}$`).test(target)) {
    throw new Error(`Target must be a ${qubitCount}-bit string.`);
  }
  const maxIterations = Math.ceil(Math.PI / 4 * Math.sqrt(2 ** qubitCount));
  if (!Number.isInteger(iterations) || iterations < 0 || iterations > maxIterations) {
    throw new RangeError(`Choose between 0 and ${maxIterations} Grover iterations for this demo.`);
  }
  const initial = uniformSuperposition(qubitCount);
  const markedIndex = Number.parseInt(target, 2);
  const afterOracle = applyGroverOracle(initial, markedIndex);
  let finalState = initial;
  for (let index = 0; index < iterations; index += 1) {
    finalState = groverIteration(finalState, markedIndex);
  }
  const probabilities = probabilityDistribution(finalState);
  return {
    initialState: createZeroState(qubitCount),
    afterOracle,
    finalState,
    target,
    probabilities,
    successProbability: probabilities[markedIndex] ?? 0,
    iterations,
  };
}

export function groverSearchSpaceLabels(qubitCount: number): string[] {
  return Array.from({ length: 2 ** qubitCount }, (_, index) => index.toString(2).padStart(qubitCount, "0"));
}

export function groverRecommendedIterations(qubitCount: number): number {
  if (!Number.isInteger(qubitCount) || qubitCount < 2 || qubitCount > 12) {
    throw new RangeError("Qubit count must be between 2 and 12.");
  }
  return Math.max(1, Math.floor((Math.PI / 4) * Math.sqrt(2 ** qubitCount)));
}

export function groverStateNorm(state: StateVector): number {
  return Math.sqrt(state.reduce((sum, amplitude: Complex) => sum + amplitude.re ** 2 + amplitude.im ** 2, 0));
}
