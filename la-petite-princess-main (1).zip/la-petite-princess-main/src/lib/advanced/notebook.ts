export interface NotebookEntry {
  title: string;
  question: string;
  prediction: string;
  method: string;
  observation: string;
  explanation: string;
  nextQuestion: string;
  createdAt: string;
}

export function createEmptyNotebookEntry(): NotebookEntry {
  return { title: "My quantum experiment", question: "", prediction: "", method: "", observation: "", explanation: "", nextQuestion: "", createdAt: new Date().toISOString() };
}

function markdownSafe(value: string): string {
  return value.trim() || "_Not recorded._";
}

export function notebookEntryToMarkdown(entry: NotebookEntry): string {
  return [
    `# ${markdownSafe(entry.title)}`,
    "",
    `Created: ${new Date(entry.createdAt).toLocaleString()}`,
    "",
    "## Research question", markdownSafe(entry.question), "",
    "## Prediction", markdownSafe(entry.prediction), "",
    "## Method", markdownSafe(entry.method), "",
    "## Observation", markdownSafe(entry.observation), "",
    "## Explanation", markdownSafe(entry.explanation), "",
    "## Next question", markdownSafe(entry.nextQuestion), "",
    "---", "Created with La Petite Princesse · Entangled: The Quantum Universe",
    "This notebook is an educational record, not a claim of physical quantum-hardware execution.",
  ].join("\n");
}

export function downloadTextFile(filename: string, content: string, mimeType = "text/markdown;charset=utf-8"): void {
  if (typeof document === "undefined" || typeof URL === "undefined") return;
  const blob = new Blob([content], { type: mimeType });
  const objectUrl = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = objectUrl;
  anchor.download = filename;
  anchor.click();
  URL.revokeObjectURL(objectUrl);
}

export function slugify(value: string): string {
  return value.normalize("NFKD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "") || "quantum-notebook";
}
