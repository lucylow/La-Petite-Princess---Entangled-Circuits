import { C_ZERO, C_ONE, cExpI, cMul, complex } from "./complex";
import {
  applyOperation,
  basisLabel,
  createBasisState,
  createZeroState,
  probabilityDistribution,
  type StateVector,
} from "./quantumAdvanced";

export interface AlgorithmResult {
  algorithm: string;
  qubitCount: number;
  state: StateVector;
  outcomes: { label: string; probability: number }[];
  explanation: string;
  oracleQueries: number;
}

function applyHadamards(state: StateVector, qubitCount: number, targets: number[]): StateVector {
  return targets.reduce((current, target) => applyOperation(current, qubitCount, { id: `h-${target}`, gate: "H", target }), state);
}

function applyParityOracle(state: StateVector, inputQubits: number, secret: string): StateVector {
  const totalQubits = inputQubits + 1;
  const ancillaMask = 1 << inputQubits;
  const result = state.map((amplitude) => complex(amplitude.re, amplitude.im));
  for (let index = 0; index < state.length; index += 1) {
    if ((index & ancillaMask) !== 0) continue;
    let parity = 0;
    for (let qubit = 0; qubit < inputQubits; qubit += 1) {
      const secretBit = Number(secret[inputQubits - 1 - qubit]);
      const inputBit = (index >> qubit) & 1;
      parity ^= secretBit & inputBit;
    }
    if (parity === 1) {
      const partner = index | ancillaMask;
      result[index] = state[partner] ?? complex(0, 0);
      result[partner] = state[index] ?? complex(0, 0);
    }
  }
  if (result.length !== 2 ** totalQubits) throw new Error("Oracle register dimension mismatch.");
  return result;
}

function marginalInputDistribution(state: StateVector, inputQubits: number): number[] {
  const full = probabilityDistribution(state);
  const result = Array.from({ length: 2 ** inputQubits }, () => 0);
  full.forEach((probability, fullIndex) => {
    const inputIndex = fullIndex & (2 ** inputQubits - 1);
    result[inputIndex] = (result[inputIndex] ?? 0) + probability;
  });
  return result;
}

/** Bernstein–Vazirani: one phase-oracle query reveals a promised bit string. */
export function runBernsteinVazirani(secret: string): AlgorithmResult {
  if (!/^[01]{1,5}$/.test(secret)) throw new Error("Secret must contain between 1 and 5 binary digits.");
  const inputQubits = secret.length;
  const totalQubits = inputQubits + 1;
  let state = createBasisState(totalQubits, `1${"0".repeat(inputQubits)}`);
  state = applyHadamards(state, totalQubits, Array.from({ length: totalQubits }, (_, index) => index));
  state = applyParityOracle(state, inputQubits, secret);
  state = applyHadamards(state, totalQubits, Array.from({ length: inputQubits }, (_, index) => index));
  const distribution = marginalInputDistribution(state, inputQubits);
  return {
    algorithm: "Bernstein–Vazirani",
    qubitCount: totalQubits,
    state,
    outcomes: distribution.map((probability, index) => ({ label: basisLabel(index, inputQubits), probability })),
    explanation: `The hidden string is ${secret}. Under the promise oracle f(x) = s · x (mod 2), one quantum oracle query concentrates the input register on that string in the ideal circuit.`,
    oracleQueries: 1,
  };
}

/** Deutsch–Jozsa with a constant-zero or balanced f(x)=x₀ oracle. */
export function runDeutschJozsa(inputQubits: number, kind: "constant" | "balanced"): AlgorithmResult {
  if (!Number.isInteger(inputQubits) || inputQubits < 1 || inputQubits > 5) throw new RangeError("Choose 1 to 5 input qubits.");
  const totalQubits = inputQubits + 1;
  let state = createBasisState(totalQubits, `1${"0".repeat(inputQubits)}`);
  state = applyHadamards(state, totalQubits, Array.from({ length: totalQubits }, (_, index) => index));
  if (kind === "balanced") {
    // The balanced promise function is f(x)=x₀, so flip the ancilla when Q1=1.
    const ancillaMask = 1 << inputQubits;
    const result = state.map((amplitude) => complex(amplitude.re, amplitude.im));
    for (let index = 0; index < state.length; index += 1) {
      if ((index & ancillaMask) !== 0 || (index & 1) === 0) continue;
      const partner = index | ancillaMask;
      result[index] = state[partner] ?? complex(0, 0);
      result[partner] = state[index] ?? complex(0, 0);
    }
    state = result;
  }
  state = applyHadamards(state, totalQubits, Array.from({ length: inputQubits }, (_, index) => index));
  const distribution = marginalInputDistribution(state, inputQubits);
  return {
    algorithm: "Deutsch–Jozsa",
    qubitCount: totalQubits,
    state,
    outcomes: distribution.map((probability, index) => ({ label: basisLabel(index, inputQubits), probability })),
    explanation: kind === "constant"
      ? "The constant-zero oracle leaves the input register at all zeros after the final Hadamards."
      : "The balanced oracle f(x)=x₀ produces a nonzero input result after the final Hadamards, identifying the balanced promise case.",
    oracleQueries: 1,
  };
}

/** Controlled phase rotation used in the QFT circuit. */
export function applyControlledPhase(state: StateVector, qubitCount: number, control: number, target: number, angle: number): StateVector {
  if (!Number.isInteger(control) || !Number.isInteger(target) || control < 0 || target < 0 || control >= qubitCount || target >= qubitCount || control === target) {
    throw new RangeError("Controlled phase requires two distinct valid qubits.");
  }
  if (!Number.isFinite(angle)) throw new RangeError("Phase angle must be finite.");
  const phase = cExpI(angle);
  return state.map((amplitude, index) => {
    const bothOne = (index & (1 << control)) !== 0 && (index & (1 << target)) !== 0;
    return bothOne ? cMul(amplitude, phase) : complex(amplitude.re, amplitude.im);
  });
}

/** Standard QFT circuit with final bit-reversal swaps, using Q1 as bit 0. */
export function runQuantumFourierTransform(input: StateVector, qubitCount: number): StateVector {
  if (!Number.isInteger(qubitCount) || qubitCount < 1 || qubitCount > 6 || input.length !== 2 ** qubitCount) {
    throw new Error("QFT expects a state vector for 1 to 6 qubits.");
  }
  let state = input.map((amplitude) => complex(amplitude.re, amplitude.im));
  // With Q1 as the least-significant bit, process the most-significant
  // target first, then reverse the bit order with pairwise SWAP gates.
  for (let target = qubitCount - 1; target >= 0; target -= 1) {
    state = applyOperation(state, qubitCount, { id: `qft-h-${target}`, gate: "H", target });
    for (let control = target - 1; control >= 0; control -= 1) {
      const angle = Math.PI / (2 ** (target - control));
      state = applyControlledPhase(state, qubitCount, control, target, angle);
    }
  }
  for (let low = 0; low < Math.floor(qubitCount / 2); low += 1) {
    const high = qubitCount - 1 - low;
    state = applyOperation(state, qubitCount, { id: `qft-swap-${low}-${high}`, gate: "SWAP", control: low, target: high });
  }
  return state;
}

/** The inverse QFT is the adjoint circuit: reverse order and negate phases. */
export function runInverseQuantumFourierTransform(input: StateVector, qubitCount: number): StateVector {
  if (!Number.isInteger(qubitCount) || qubitCount < 1 || qubitCount > 6 || input.length !== 2 ** qubitCount) {
    throw new Error("Inverse QFT expects a state vector for 1 to 6 qubits.");
  }
  let state = input.map((amplitude) => complex(amplitude.re, amplitude.im));
  for (let low = 0; low < Math.floor(qubitCount / 2); low += 1) {
    const high = qubitCount - 1 - low;
    state = applyOperation(state, qubitCount, { id: `iqft-swap-${low}-${high}`, gate: "SWAP", control: low, target: high });
  }
  for (let target = 0; target < qubitCount; target += 1) {
    for (let control = 0; control < target; control += 1) {
      const angle = -Math.PI / (2 ** (target - control));
      state = applyControlledPhase(state, qubitCount, control, target, angle);
    }
    state = applyOperation(state, qubitCount, { id: `iqft-h-${target}`, gate: "H", target });
  }
  return state;
}

export function qftBasisStateProbabilities(inputIndex: number, qubitCount: number): number[] {
  if (!Number.isInteger(inputIndex) || inputIndex < 0 || inputIndex >= 2 ** qubitCount) throw new RangeError("Basis index is out of range.");
  const result = runQuantumFourierTransform(createBasisState(qubitCount, inputIndex.toString(2).padStart(qubitCount, "0")), qubitCount);
  return probabilityDistribution(result);
}

export function zeroRegisterState(qubitCount: number): StateVector {
  return createZeroState(qubitCount);
}
