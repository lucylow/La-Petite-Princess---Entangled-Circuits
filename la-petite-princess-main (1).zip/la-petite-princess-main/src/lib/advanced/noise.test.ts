import { describe, expect, it } from "vitest";
import { applyReadoutNoiseToDistribution, estimateReadoutCounts } from "./noise";

describe("readout noise model", () => {
  it("leaves probabilities unchanged when rates are zero", () => {
    const ideal = [0.5, 0, 0, 0.5];
    expect(applyReadoutNoiseToDistribution(ideal, 2, [0, 0])).toEqual(ideal);
  });

  it("preserves normalization", () => {
    const observed = applyReadoutNoiseToDistribution([0.5, 0, 0, 0.5], 2, [0.13, 0.07]);
    expect(observed.reduce((sum, value) => sum + value, 0)).toBeCloseTo(1);
    expect(observed.every((value) => value >= 0)).toBe(true);
  });

  it("produces a uniform distribution at a 50% readout flip rate", () => {
    const observed = applyReadoutNoiseToDistribution([1, 0, 0, 0], 2, [0.5, 0.5]);
    observed.forEach((value) => expect(value).toBeCloseTo(0.25));
  });

  it("allocates integer shot counts that sum to the requested shots", () => {
    const counts = estimateReadoutCounts([0.5, 0, 0, 0.5], 101);
    expect(counts.reduce((sum, value) => sum + value, 0)).toBe(101);
    expect(counts.every(Number.isInteger)).toBe(true);
  });

  it("rejects bad error rates", () => {
    expect(() => applyReadoutNoiseToDistribution([1, 0], 1, [0.6])).toThrow();
    expect(() => applyReadoutNoiseToDistribution([1, 0, 0, 0], 2, [0.1])).toThrow();
  });
});
