/**
 * Extensible educational state-vector simulator.
 *
 * Bit convention: qubit 0 is Q1, the least-significant bit. For display,
 * basis labels are printed most-significant bit first: |qN ... q2 q1>.
 * For two qubits, array index 0..3 therefore maps to |00>, |01>, |10>, |11>.
 * This is an ideal, noiseless simulator; it is not a quantum-hardware backend.
 */
import {
  C_ONE,
  C_ZERO,
  cAdd,
  cConjugate,
  cExpI,
  cMagnitudeSquared,
  cMul,
  cScale,
  complex,
  type Complex,
} from "./complex";

export type QuantumGateName =
  | "H" | "X" | "Y" | "Z" | "S" | "T"
  | "RX" | "RY" | "RZ" | "CNOT" | "CZ" | "SWAP";

export interface CircuitOperation {
  id: string;
  gate: QuantumGateName;
  target: number;
  control?: number;
  angle?: number;
}

export interface ShotCounts {
  totalShots: number;
  counts: Record<string, number>;
  probabilities: Record<string, number>;
}

export interface BlochVector {
  x: number;
  y: number;
  z: number;
  purity: number;
}

export type StateVector = Complex[];
export type Matrix2 = [[Complex, Complex], [Complex, Complex]];

const EPSILON = 1e-10;
const SQRT_HALF = 1 / Math.sqrt(2);
const MAX_QUBITS = 8;

function matrix(a: Complex, b: Complex, c: Complex, d: Complex): Matrix2 {
  return [[a, b], [c, d]];
}

function gateMatrix(gate: QuantumGateName, angle = 0): Matrix2 {
  switch (gate) {
    case "H":
      return matrix(complex(SQRT_HALF), complex(SQRT_HALF), complex(SQRT_HALF), complex(-SQRT_HALF));
    case "X":
      return matrix(C_ZERO(), C_ONE(), C_ONE(), C_ZERO());
    case "Y":
      return matrix(C_ZERO(), complex(0, -1), complex(0, 1), C_ZERO());
    case "Z":
      return matrix(C_ONE(), C_ZERO(), C_ZERO(), complex(-1));
    case "S":
      return matrix(C_ONE(), C_ZERO(), C_ZERO(), complex(0, 1));
    case "T":
      return matrix(C_ONE(), C_ZERO(), C_ZERO(), cExpI(Math.PI / 4));
    case "RX": {
      const cosine = Math.cos(angle / 2);
      const sine = Math.sin(angle / 2);
      return matrix(complex(cosine), complex(0, -sine), complex(0, -sine), complex(cosine));
    }
    case "RY": {
      const cosine = Math.cos(angle / 2);
      const sine = Math.sin(angle / 2);
      return matrix(complex(cosine), complex(-sine), complex(sine), complex(cosine));
    }
    case "RZ":
      return matrix(cExpI(-angle / 2), C_ZERO(), C_ZERO(), cExpI(angle / 2));
    default:
      throw new Error(`${gate} is a multi-qubit gate and has no single-qubit matrix.`);
  }
}

function validateQubitCount(qubitCount: number): void {
  if (!Number.isInteger(qubitCount) || qubitCount < 1 || qubitCount > MAX_QUBITS) {
    throw new RangeError(`Qubit count must be an integer from 1 to ${MAX_QUBITS}.`);
  }
}

function validateQubitIndex(qubit: number, qubitCount: number): void {
  if (!Number.isInteger(qubit) || qubit < 0 || qubit >= qubitCount) {
    throw new RangeError(`Qubit index ${qubit} is outside a ${qubitCount}-qubit register.`);
  }
}

export function basisLabel(index: number, qubitCount: number): string {
  validateQubitCount(qubitCount);
  if (!Number.isInteger(index) || index < 0 || index >= 2 ** qubitCount) {
    throw new RangeError("Basis index is outside the state vector.");
  }
  return index.toString(2).padStart(qubitCount, "0");
}

export function createZeroState(qubitCount = 2): StateVector {
  validateQubitCount(qubitCount);
  const state = Array.from({ length: 2 ** qubitCount }, () => C_ZERO());
  state[0] = C_ONE();
  return state;
}

export function createBasisState(qubitCount: number, label: string): StateVector {
  validateQubitCount(qubitCount);
  if (!new RegExp(`^[01]{${qubitCount}}$`).test(label)) {
    throw new Error(`Expected a ${qubitCount}-bit basis label.`);
  }
  const state = createZeroState(qubitCount);
  state[Number.parseInt(label, 2)] = C_ONE();
  state[0] = label === "0".repeat(qubitCount) ? C_ONE() : C_ZERO();
  return state;
}

export function cloneState(state: StateVector): StateVector {
  return state.map((amplitude) => complex(amplitude.re, amplitude.im));
}

export function stateNormSquared(state: StateVector): number {
  return state.reduce((sum, amplitude) => sum + cMagnitudeSquared(amplitude), 0);
}

export function isStateNormalized(state: StateVector, tolerance = 1e-8): boolean {
  return state.length > 0 && Math.abs(stateNormSquared(state) - 1) < tolerance;
}

export function normalizeState(state: StateVector): StateVector {
  const norm = Math.sqrt(stateNormSquared(state));
  if (!Number.isFinite(norm) || norm < EPSILON) throw new Error("Cannot normalize a zero or invalid state.");
  return state.map((amplitude) => cScale(amplitude, 1 / norm));
}

export function probabilityDistribution(state: StateVector): number[] {
  const raw = state.map(cMagnitudeSquared);
  const total = raw.reduce((sum, value) => sum + value, 0);
  if (!Number.isFinite(total) || total < EPSILON) throw new Error("State has no measurable probability mass.");
  return raw.map((value) => value / total);
}

function applySingleQubitMatrix(state: StateVector, qubitCount: number, target: number, op: Matrix2): StateVector {
  validateQubitIndex(target, qubitCount);
  if (state.length !== 2 ** qubitCount) throw new Error("State vector length does not match qubit count.");
  const bitMask = 1 << target;
  const result = Array.from({ length: state.length }, () => C_ZERO());
  for (let index = 0; index < state.length; index += 1) {
    if ((index & bitMask) !== 0) continue;
    const partner = index | bitMask;
    const zeroAmplitude = state[index] ?? C_ZERO();
    const oneAmplitude = state[partner] ?? C_ZERO();
    result[index] = cAdd(cMul(op[0][0] ?? C_ZERO(), zeroAmplitude), cMul(op[0][1] ?? C_ZERO(), oneAmplitude));
    result[partner] = cAdd(cMul(op[1][0] ?? C_ZERO(), zeroAmplitude), cMul(op[1][1] ?? C_ZERO(), oneAmplitude));
  }
  return result;
}

function applyControlledX(state: StateVector, qubitCount: number, control: number, target: number): StateVector {
  validateQubitIndex(control, qubitCount);
  validateQubitIndex(target, qubitCount);
  if (control === target) throw new Error("Control and target qubits must be different.");
  const result = cloneState(state);
  const controlMask = 1 << control;
  const targetMask = 1 << target;
  for (let index = 0; index < state.length; index += 1) {
    if ((index & controlMask) !== 0 && (index & targetMask) === 0) {
      const partner = index | targetMask;
      result[index] = state[partner] ?? C_ZERO();
      result[partner] = state[index] ?? C_ZERO();
    }
  }
  return result;
}

function applyControlledZ(state: StateVector, qubitCount: number, control: number, target: number): StateVector {
  validateQubitIndex(control, qubitCount);
  validateQubitIndex(target, qubitCount);
  if (control === target) throw new Error("Control and target qubits must be different.");
  return state.map((amplitude, index) =>
    (index & (1 << control)) !== 0 && (index & (1 << target)) !== 0
      ? cScale(amplitude, -1)
      : complex(amplitude.re, amplitude.im),
  );
}

function applySwap(state: StateVector, qubitCount: number, first: number, second: number): StateVector {
  validateQubitIndex(first, qubitCount);
  validateQubitIndex(second, qubitCount);
  if (first === second) return cloneState(state);
  const result = cloneState(state);
  const firstMask = 1 << first;
  const secondMask = 1 << second;
  for (let index = 0; index < state.length; index += 1) {
    const firstBit = (index & firstMask) !== 0;
    const secondBit = (index & secondMask) !== 0;
    if (firstBit || !secondBit) continue;
    const partner = index ^ firstMask ^ secondMask;
    result[index] = state[partner] ?? C_ZERO();
    result[partner] = state[index] ?? C_ZERO();
  }
  return result;
}

export function applyOperation(state: StateVector, qubitCount: number, operation: CircuitOperation): StateVector {
  validateQubitCount(qubitCount);
  if (state.length !== 2 ** qubitCount) throw new Error("State vector length does not match qubit count.");
  const { gate, target } = operation;
  if (gate === "CNOT" || gate === "CZ") {
    if (operation.control === undefined) throw new Error(`${gate} requires a control qubit.`);
    return gate === "CNOT"
      ? applyControlledX(state, qubitCount, operation.control, target)
      : applyControlledZ(state, qubitCount, operation.control, target);
  }
  if (gate === "SWAP") {
    if (operation.control === undefined) throw new Error("SWAP uses control as its second qubit in this editor.");
    return applySwap(state, qubitCount, operation.control, target);
  }
  return applySingleQubitMatrix(state, qubitCount, target, gateMatrix(gate, operation.angle ?? 0));
}

export function runCircuit(qubitCount: number, operations: CircuitOperation[], start?: StateVector): StateVector {
  let state = start ? cloneState(start) : createZeroState(qubitCount);
  for (const operation of operations) state = applyOperation(state, qubitCount, operation);
  return state;
}

export function formatStateVector(state: StateVector, qubitCount: number, digits = 3): string {
  const terms: string[] = [];
  state.forEach((amplitude, index) => {
    if (cMagnitudeSquared(amplitude) < EPSILON) return;
    const value = formatComplexForEquation(amplitude, digits);
    terms.push(`${value}|${basisLabel(index, qubitCount)}⟩`);
  });
  return terms.length ? terms.join("  +  ") : "0";
}

function formatComplexForEquation(value: Complex, digits: number): string {
  const real = Math.abs(value.re) < EPSILON ? 0 : value.re;
  const imaginary = Math.abs(value.im) < EPSILON ? 0 : value.im;
  if (imaginary === 0) return real.toFixed(digits);
  if (real === 0) return `${imaginary.toFixed(digits)}i`;
  return `${real.toFixed(digits)} ${imaginary < 0 ? "−" : "+"} ${Math.abs(imaginary).toFixed(digits)}i`;
}

export function sampleBasisIndex(state: StateVector, rng: () => number = Math.random): number {
  const probabilities = probabilityDistribution(state);
  const roll = Math.min(Math.max(rng(), 0), 1 - Number.EPSILON);
  let cumulative = 0;
  for (let index = 0; index < probabilities.length; index += 1) {
    cumulative += probabilities[index] ?? 0;
    if (roll < cumulative || index === probabilities.length - 1) return index;
  }
  return 0;
}

export function measureState(state: StateVector, qubitCount: number, rng: () => number = Math.random): {
  index: number;
  label: string;
  collapsedState: StateVector;
} {
  const index = sampleBasisIndex(state, rng);
  const collapsedState = Array.from({ length: state.length }, () => C_ZERO());
  collapsedState[index] = C_ONE();
  return { index, label: basisLabel(index, qubitCount), collapsedState };
}

export function runShots(state: StateVector, qubitCount: number, shots: number, rng: () => number = Math.random): ShotCounts {
  if (!Number.isInteger(shots) || shots < 1 || shots > 100_000) {
    throw new RangeError("Shot count must be an integer between 1 and 100,000.");
  }
  const probabilities = probabilityDistribution(state);
  const counts: Record<string, number> = {};
  const probabilityMap: Record<string, number> = {};
  probabilities.forEach((probability, index) => {
    const label = basisLabel(index, qubitCount);
    counts[label] = 0;
    probabilityMap[label] = probability;
  });
  for (let shot = 0; shot < shots; shot += 1) {
    const index = sampleBasisIndex(state, rng);
    const label = basisLabel(index, qubitCount);
    counts[label] = (counts[label] ?? 0) + 1;
  }
  return { totalShots: shots, counts, probabilities: probabilityMap };
}

/** Reduced single-qubit density matrix, followed by its Bloch vector. */
export function blochVectorForQubit(state: StateVector, qubitCount: number, target: number): BlochVector {
  validateQubitCount(qubitCount);
  validateQubitIndex(target, qubitCount);
  if (state.length !== 2 ** qubitCount) throw new Error("State vector length does not match qubit count.");
  const mask = 1 << target;
  let rho00 = 0;
  let rho11 = 0;
  let rho01 = complex(0, 0);
  for (let index = 0; index < state.length; index += 1) {
    if ((index & mask) !== 0) continue;
    const partner = index | mask;
    rho00 += cMagnitudeSquared(state[index] ?? C_ZERO());
    rho11 += cMagnitudeSquared(state[partner] ?? C_ZERO());
    rho01 = cAdd(rho01, cMul(state[index] ?? C_ZERO(), cConjugate(state[partner] ?? C_ZERO())));
  }
  const x = 2 * rho01.re;
  const y = -2 * rho01.im;
  const z = rho00 - rho11;
  const lengthSquared = x * x + y * y + z * z;
  return { x, y, z, purity: (1 + lengthSquared) / 2 };
}

/** Concurrence is defined here only for pure two-qubit state vectors. */
export function pureTwoQubitConcurrence(state: StateVector): number {
  if (state.length !== 4) throw new Error("Concurrence helper requires exactly two qubits.");
  const determinant = cAdd(
    cMul(state[0] ?? C_ZERO(), state[3] ?? C_ZERO()),
    cScale(cMul(state[1] ?? C_ZERO(), state[2] ?? C_ZERO()), -1),
  );
  return Math.min(1, 2 * Math.sqrt(cMagnitudeSquared(determinant)));
}

/** Entanglement entropy in bits for a pure two-qubit state. */
export function pureTwoQubitEntanglementEntropy(state: StateVector): number {
  const concurrence = pureTwoQubitConcurrence(state);
  const discriminant = Math.sqrt(Math.max(0, 1 - concurrence * concurrence));
  const lambdaPlus = (1 + discriminant) / 2;
  const lambdaMinus = (1 - discriminant) / 2;
  const entropyTerm = (value: number) => value <= EPSILON ? 0 : -value * Math.log2(value);
  return entropyTerm(lambdaPlus) + entropyTerm(lambdaMinus);
}

export function stateFidelity(a: StateVector, b: StateVector): number {
  if (a.length !== b.length) throw new Error("State vectors must have the same dimension.");
  let overlap = complex(0, 0);
  for (let index = 0; index < a.length; index += 1) {
    overlap = cAdd(overlap, cMul(cConjugate(a[index] ?? C_ZERO()), b[index] ?? C_ZERO()));
  }
  return Math.min(1, cMagnitudeSquared(overlap));
}

export function stateDistance(a: StateVector, b: StateVector): number {
  if (a.length !== b.length) throw new Error("State vectors must have the same dimension.");
  const squared = a.reduce((sum, amplitude, index) => {
    const other = b[index] ?? C_ZERO();
    const delta = complex(amplitude.re - other.re, amplitude.im - other.im);
    return sum + cMagnitudeSquared(delta);
  }, 0);
  return Math.sqrt(squared);
}

export function applyGlobalPhase(state: StateVector, phase: number): StateVector {
  const factor = cExpI(phase);
  return state.map((amplitude) => cMul(amplitude, factor));
}

export function probabilityOfBitstring(state: StateVector, qubitCount: number, label: string): number {
  if (!new RegExp(`^[01]{${qubitCount}}$`).test(label)) throw new Error("Invalid bitstring for this register.");
  return probabilityDistribution(state)[Number.parseInt(label, 2)] ?? 0;
}

export function isProductStateTwoQubit(state: StateVector, tolerance = 1e-8): boolean {
  return pureTwoQubitConcurrence(state) < tolerance;
}

export function operationLabel(operation: CircuitOperation): string {
  const q = (index: number) => `Q${index + 1}`;
  switch (operation.gate) {
    case "CNOT": return `CNOT ${q(operation.control ?? 0)} → ${q(operation.target)}`;
    case "CZ": return `CZ ${q(operation.control ?? 0)} → ${q(operation.target)}`;
    case "SWAP": return `SWAP ${q(operation.control ?? 0)} ↔ ${q(operation.target)}`;
    case "RX": case "RY": case "RZ": return `${operation.gate}(${(operation.angle ?? 0).toFixed(2)}) · ${q(operation.target)}`;
    default: return `${operation.gate} · ${q(operation.target)}`;
  }
}

export function createOperation(
  gate: QuantumGateName,
  target: number,
  control?: number,
  angle?: number,
  id = `${gate}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
): CircuitOperation {
  return { id, gate, target, ...(control === undefined ? {} : { control }), ...(angle === undefined ? {} : { angle }) };
}

export function validateCircuit(qubitCount: number, operations: CircuitOperation[]): string[] {
  const errors: string[] = [];
  try { validateQubitCount(qubitCount); } catch (error) { return [error instanceof Error ? error.message : "Invalid qubit count."]; }
  for (const [index, operation] of operations.entries()) {
    try {
      validateQubitIndex(operation.target, qubitCount);
      if (["CNOT", "CZ", "SWAP"].includes(operation.gate)) {
        if (operation.control === undefined) throw new Error(`${operation.gate} needs a second qubit.`);
        validateQubitIndex(operation.control, qubitCount);
        if (operation.control === operation.target) throw new Error("Two-qubit gate needs two different qubits.");
      }
      if (["RX", "RY", "RZ"].includes(operation.gate) && !Number.isFinite(operation.angle)) {
        throw new Error(`${operation.gate} needs a finite rotation angle.`);
      }
    } catch (error) {
      errors.push(`Operation ${index + 1}: ${error instanceof Error ? error.message : "Invalid operation."}`);
    }
  }
  return errors;
}
