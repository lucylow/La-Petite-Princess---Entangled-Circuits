export interface BraidGenerator {
  index: number; // one-based σ_i exchanges strands at positions i and i+1
  sign: 1 | -1;
}

export interface BraidTrace {
  strand: number;
  path: string;
  finalPosition: number;
}

export function validateBraidWord(strandCount: number, word: BraidGenerator[]): string[] {
  const errors: string[] = [];
  if (!Number.isInteger(strandCount) || strandCount < 2 || strandCount > 8) {
    errors.push("Use between 2 and 8 strands.");
    return errors;
  }
  word.forEach((generator, index) => {
    if (!Number.isInteger(generator.index) || generator.index < 1 || generator.index >= strandCount) errors.push(`Generator ${index + 1} must be between σ1 and σ${strandCount - 1}.`);
    if (generator.sign !== 1 && generator.sign !== -1) errors.push(`Generator ${index + 1} needs sign +1 or -1.`);
  });
  return errors;
}

export function reduceBraidWord(word: BraidGenerator[]): BraidGenerator[] {
  const stack: BraidGenerator[] = [];
  for (const generator of word) {
    const last = stack[stack.length - 1];
    if (last && last.index === generator.index && last.sign === -generator.sign) stack.pop();
    else stack.push({ ...generator });
  }
  return stack;
}

export function inverseBraidWord(word: BraidGenerator[]): BraidGenerator[] {
  return [...word].reverse().map((generator) => ({ index: generator.index, sign: generator.sign === 1 ? -1 : 1 }));
}

export function composeBraidWords(first: BraidGenerator[], second: BraidGenerator[]): BraidGenerator[] {
  return reduceBraidWord([...first, ...second]);
}

export function braidWordLabel(word: BraidGenerator[]): string {
  if (word.length === 0) return "identity";
  return word.map((generator) => `σ${generator.index}${generator.sign < 0 ? "⁻¹" : ""}`).join(" · ");
}

export function braidPermutation(strandCount: number, word: BraidGenerator[]): number[] {
  const errors = validateBraidWord(strandCount, word);
  if (errors.length) throw new Error(errors.join(" "));
  const order = Array.from({ length: strandCount }, (_, index) => index + 1);
  for (const generator of word) {
    const left = generator.index - 1;
    const leftValue = order[left] ?? 0;
    const rightValue = order[left + 1] ?? 0;
    order[left] = rightValue;
    order[left + 1] = leftValue;
  }
  return order;
}

export function sameBraidPermutation(strandCount: number, first: BraidGenerator[], second: BraidGenerator[]): boolean {
  const a = braidPermutation(strandCount, first);
  const b = braidPermutation(strandCount, second);
  return a.every((strand, index) => strand === b[index]);
}

/** SVG path commands for a mathematical braid diagram; no anyon physics is simulated. */
export function buildBraidTraces(strandCount: number, word: BraidGenerator[], width = 360, rowHeight = 54): BraidTrace[] {
  const errors = validateBraidWord(strandCount, word);
  if (errors.length) throw new Error(errors.join(" "));
  const margin = 30;
  const spacing = (width - margin * 2) / (strandCount - 1);
  const positions = new Map<number, number>();
  const paths = new Map<number, string>();
  for (let strand = 1; strand <= strandCount; strand += 1) {
    positions.set(strand, strand - 1);
    paths.set(strand, `M ${margin + (strand - 1) * spacing} 18`);
  }
  const order = Array.from({ length: strandCount }, (_, index) => index + 1);
  word.forEach((generator, step) => {
    const leftPosition = generator.index - 1;
    const rightPosition = generator.index;
    const leftStrand = order[leftPosition] ?? 0;
    const rightStrand = order[rightPosition] ?? 0;
    const yMiddle = 18 + step * rowHeight + rowHeight / 2;
    const yBottom = 18 + (step + 1) * rowHeight;
    const xLeft = margin + leftPosition * spacing;
    const xRight = margin + rightPosition * spacing;
    const xMiddle = (xLeft + xRight) / 2;
    const crest = generator.sign * Math.min(8, spacing * 0.14);
    paths.set(leftStrand, `${paths.get(leftStrand)} Q ${xMiddle + crest} ${yMiddle} ${xRight} ${yBottom}`);
    paths.set(rightStrand, `${paths.get(rightStrand)} Q ${xMiddle - crest} ${yMiddle} ${xLeft} ${yBottom}`);
    const nextLeft = order[rightPosition] ?? 0;
    const nextRight = order[leftPosition] ?? 0;
    order[leftPosition] = nextLeft;
    order[rightPosition] = nextRight;
    positions.set(leftStrand, rightPosition);
    positions.set(rightStrand, leftPosition);
    for (const strand of order) {
      if (strand === leftStrand || strand === rightStrand) continue;
      const slot = positions.get(strand) ?? order.indexOf(strand);
      const x = margin + slot * spacing;
      paths.set(strand, `${paths.get(strand)} L ${x} ${yBottom}`);
    }
  });
  if (word.length === 0) {
    for (let strand = 1; strand <= strandCount; strand += 1) paths.set(strand, `M ${margin + (strand - 1) * spacing} 18 L ${margin + (strand - 1) * spacing} 18`);
  }
  return Array.from({ length: strandCount }, (_, index) => {
    const strand = index + 1;
    return { strand, path: paths.get(strand) ?? "", finalPosition: positions.get(strand) ?? index };
  });
}

export const YOUNG_BRAID_RELATION_LEFT: BraidGenerator[] = [
  { index: 1, sign: 1 }, { index: 2, sign: 1 }, { index: 1, sign: 1 },
];
export const YOUNG_BRAID_RELATION_RIGHT: BraidGenerator[] = [
  { index: 2, sign: 1 }, { index: 1, sign: 1 }, { index: 2, sign: 1 },
];

export function braidRelationPermutationCheck(): boolean {
  return sameBraidPermutation(3, YOUNG_BRAID_RELATION_LEFT, YOUNG_BRAID_RELATION_RIGHT);
}
