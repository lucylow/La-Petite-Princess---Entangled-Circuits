import { describe, expect, it } from "vitest";
import { applyGroverDiffusion, applyGroverOracle, runGroverSearch } from "./grover";
import { probabilityDistribution, stateNormSquared } from "./quantumAdvanced";

describe("Grover search teaching model", () => {
  it("flips only the marked amplitude in the oracle", () => {
    const state = [0, 1, 2, 3].map(() => ({ re: 0.5, im: 0 }));
    const result = applyGroverOracle(state, 2);
    expect(result[0]!.re).toBeCloseTo(0.5);
    expect(result[1]!.re).toBeCloseTo(0.5);
    expect(result[2]!.re).toBeCloseTo(-0.5);
    expect(result[3]!.re).toBeCloseTo(0.5);
  });

  it("amplifies each possible marked two-bit target after one iteration", () => {
    for (const target of ["00", "01", "10", "11"]) {
      const result = runGroverSearch(2, target, 1);
      expect(result.successProbability).toBeCloseTo(1);
      expect(stateNormSquared(result.finalState)).toBeCloseTo(1);
      const markedIndex = Number.parseInt(target, 2);
      expect(probabilityDistribution(result.finalState)[markedIndex]).toBeCloseTo(1);
    }
  });

  it("diffusion leaves a uniform vector unchanged", () => {
    const uniform = Array.from({ length: 4 }, () => ({ re: 0.5, im: 0 }));
    const result = applyGroverDiffusion(uniform);
    result.forEach((amplitude) => expect(amplitude.re).toBeCloseTo(0.5));
  });

  it("rejects malformed targets and invalid dimensions", () => {
    expect(() => runGroverSearch(2, "2", 1)).toThrow();
    expect(() => runGroverSearch(1, "0", 1)).toThrow();
    expect(() => runGroverSearch(2, "10", 99)).toThrow();
  });
});
