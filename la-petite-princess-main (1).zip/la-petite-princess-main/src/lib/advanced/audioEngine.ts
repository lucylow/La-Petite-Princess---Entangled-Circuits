/**
 * Synthesized audio engine for the story experience.
 *
 * All sound is generated with the Web Audio API — no media files are needed.
 * Audio never autostarts: the AudioContext is created and resumed only after
 * an explicit user action (toggling ambient sound or unmuting). Preferences
 * persist locally in this browser only.
 */

export const AUDIO_PREFS_KEY = "lpp-audio-prefs-v1";

export interface AudioPrefs {
  masterVolume: number; // 0..1
  ambientEnabled: boolean;
  sfxEnabled: boolean;
  muted: boolean;
}

export const DEFAULT_AUDIO_PREFS: AudioPrefs = {
  masterVolume: 0.7,
  ambientEnabled: false,
  sfxEnabled: true,
  muted: false,
};

export function validateAudioPrefs(value: unknown): AudioPrefs {
  if (!value || typeof value !== "object") return { ...DEFAULT_AUDIO_PREFS };
  const record = value as Record<string, unknown>;
  const volume = record["masterVolume"];
  return {
    masterVolume:
      typeof volume === "number" && Number.isFinite(volume)
        ? Math.min(1, Math.max(0, volume))
        : DEFAULT_AUDIO_PREFS.masterVolume,
    ambientEnabled: record["ambientEnabled"] === true,
    sfxEnabled: record["sfxEnabled"] !== false,
    muted: record["muted"] === true,
  };
}

export function loadAudioPrefs(storage?: Pick<Storage, "getItem">): AudioPrefs {
  try {
    const target = storage ?? (typeof window !== "undefined" ? window.localStorage : undefined);
    if (!target) return { ...DEFAULT_AUDIO_PREFS };
    const raw = target.getItem(AUDIO_PREFS_KEY);
    return raw ? validateAudioPrefs(JSON.parse(raw) as unknown) : { ...DEFAULT_AUDIO_PREFS };
  } catch {
    return { ...DEFAULT_AUDIO_PREFS };
  }
}

export function saveAudioPrefs(prefs: AudioPrefs, storage?: Pick<Storage, "setItem">): boolean {
  try {
    const target = storage ?? (typeof window !== "undefined" ? window.localStorage : undefined);
    if (!target) return false;
    target.setItem(AUDIO_PREFS_KEY, JSON.stringify(prefs));
    return true;
  } catch {
    return false;
  }
}

export type SfxName = "click" | "chime" | "sparkle" | "success" | "whoosh" | "measure";

interface AmbientNodes {
  gain: GainNode;
  oscillators: OscillatorNode[];
  lfo: OscillatorNode;
}

class AudioEngine {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private ambient: AmbientNodes | null = null;
  private prefs: AudioPrefs;
  private listeners = new Set<() => void>();

  constructor() {
    this.prefs = loadAudioPrefs();
  }

  getPrefs = (): AudioPrefs => this.prefs;

  subscribe = (listener: () => void): (() => void) => {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  };

  private notify() {
    this.listeners.forEach((listener) => listener());
  }

  private update(next: Partial<AudioPrefs>) {
    this.prefs = { ...this.prefs, ...next };
    saveAudioPrefs(this.prefs);
    this.applyMasterGain();
    this.notify();
  }

  /** Creates/resumes the context. Must only be called from a user gesture. */
  private ensureContext(): AudioContext | null {
    if (typeof window === "undefined") return null;
    const Ctor = window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctor) return null;
    if (!this.ctx) {
      this.ctx = new Ctor();
      this.master = this.ctx.createGain();
      this.master.connect(this.ctx.destination);
      this.applyMasterGain();
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
    return this.ctx;
  }

  private applyMasterGain() {
    if (!this.master || !this.ctx) return;
    const target = this.prefs.muted ? 0 : this.prefs.masterVolume;
    this.master.gain.setTargetAtTime(target, this.ctx.currentTime, 0.05);
  }

  setMasterVolume(volume: number) {
    this.update({ masterVolume: Math.min(1, Math.max(0, volume)) });
  }

  toggleMute() {
    this.ensureContext();
    this.update({ muted: !this.prefs.muted });
  }

  toggleSfx() {
    this.update({ sfxEnabled: !this.prefs.sfxEnabled });
  }

  toggleAmbient() {
    const next = !this.prefs.ambientEnabled;
    this.update({ ambientEnabled: next });
    if (next) this.startAmbient();
    else this.stopAmbient();
  }

  /** Gentle two-oscillator pad with a slow filter sweep — the observatory at night. */
  private startAmbient() {
    const ctx = this.ensureContext();
    if (!ctx || !this.master || this.ambient) return;
    const gain = ctx.createGain();
    gain.gain.value = 0;
    const filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = 520;
    filter.Q.value = 0.6;
    const oscA = ctx.createOscillator();
    oscA.type = "triangle";
    oscA.frequency.value = 110; // A2
    const oscB = ctx.createOscillator();
    oscB.type = "sine";
    oscB.frequency.value = 165.2; // ~E3, a gentle fifth
    const lfo = ctx.createOscillator();
    lfo.type = "sine";
    lfo.frequency.value = 0.07;
    const lfoGain = ctx.createGain();
    lfoGain.gain.value = 160;
    lfo.connect(lfoGain);
    lfoGain.connect(filter.frequency);
    oscA.connect(filter);
    oscB.connect(filter);
    filter.connect(gain);
    gain.connect(this.master);
    oscA.start();
    oscB.start();
    lfo.start();
    gain.gain.setTargetAtTime(0.055, ctx.currentTime, 1.8);
    this.ambient = { gain, oscillators: [oscA, oscB], lfo };
  }

  private stopAmbient() {
    if (!this.ctx || !this.ambient) return;
    const { gain, oscillators, lfo } = this.ambient;
    this.ambient = null;
    gain.gain.setTargetAtTime(0, this.ctx.currentTime, 0.4);
    window.setTimeout(() => {
      oscillators.forEach((osc) => { try { osc.stop(); } catch { /* already stopped */ } });
      try { lfo.stop(); } catch { /* already stopped */ }
      gain.disconnect();
    }, 1400);
  }

  private tone(freq: number, start: number, duration: number, peak: number, type: OscillatorType = "sine") {
    const ctx = this.ctx;
    if (!ctx || !this.master) return;
    const osc = ctx.createOscillator();
    osc.type = type;
    osc.frequency.value = freq;
    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0, start);
    gain.gain.linearRampToValueAtTime(peak, start + 0.012);
    gain.gain.exponentialRampToValueAtTime(0.0001, start + duration);
    osc.connect(gain);
    gain.connect(this.master);
    osc.start(start);
    osc.stop(start + duration + 0.05);
  }

  private noiseSweep(start: number, duration: number, from: number, to: number, peak: number) {
    const ctx = this.ctx;
    if (!ctx || !this.master) return;
    const length = Math.max(1, Math.floor(ctx.sampleRate * duration));
    const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < length; i += 1) data[i] = (Math.random() * 2 - 1) * (1 - i / length);
    const source = ctx.createBufferSource();
    source.buffer = buffer;
    const filter = ctx.createBiquadFilter();
    filter.type = "bandpass";
    filter.frequency.setValueAtTime(from, start);
    filter.frequency.exponentialRampToValueAtTime(to, start + duration);
    filter.Q.value = 1.1;
    const gain = ctx.createGain();
    gain.gain.setValueAtTime(peak, start);
    gain.gain.exponentialRampToValueAtTime(0.0001, start + duration);
    source.connect(filter);
    filter.connect(gain);
    gain.connect(this.master);
    source.start(start);
  }

  /** Plays a synthesized UI sound. Silent when SFX are off or muted. */
  playSfx(name: SfxName) {
    if (!this.prefs.sfxEnabled || this.prefs.muted) return;
    const ctx = this.ensureContext();
    if (!ctx) return;
    const t = ctx.currentTime;
    switch (name) {
      case "click":
        this.tone(660, t, 0.07, 0.05, "triangle");
        break;
      case "chime":
        this.tone(523.25, t, 0.35, 0.08);
        this.tone(783.99, t + 0.09, 0.45, 0.07);
        break;
      case "sparkle":
        this.tone(1046.5, t, 0.22, 0.06);
        this.tone(1318.5, t + 0.07, 0.25, 0.055);
        this.tone(1568, t + 0.14, 0.3, 0.05);
        break;
      case "success":
        this.tone(392, t, 0.28, 0.08, "triangle");
        this.tone(523.25, t + 0.1, 0.3, 0.08, "triangle");
        this.tone(659.25, t + 0.2, 0.42, 0.08, "triangle");
        break;
      case "whoosh":
        this.noiseSweep(t, 0.5, 320, 1400, 0.06);
        break;
      case "measure":
        this.tone(880, t, 0.12, 0.07, "square");
        this.tone(587.33, t + 0.1, 0.2, 0.06, "square");
        break;
    }
  }
}

let instance: AudioEngine | null = null;

/** Browser-safe singleton; on the server it carries default prefs and stays silent. */
export function getAudioEngine(): AudioEngine {
  if (!instance) instance = new AudioEngine();
  return instance;
}
