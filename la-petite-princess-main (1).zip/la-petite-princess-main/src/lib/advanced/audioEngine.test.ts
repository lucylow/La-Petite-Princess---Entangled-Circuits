import { describe, expect, it } from "vitest";
import {
  AUDIO_PREFS_KEY,
  DEFAULT_AUDIO_PREFS,
  loadAudioPrefs,
  saveAudioPrefs,
  validateAudioPrefs,
} from "./audioEngine";

function memoryStorage(initial: Record<string, string> = {}) {
  const map = new Map(Object.entries(initial));
  return {
    getItem: (key: string) => map.get(key) ?? null,
    setItem: (key: string, value: string) => { map.set(key, value); },
  };
}

describe("validateAudioPrefs", () => {
  it("returns defaults for missing or malformed input", () => {
    expect(validateAudioPrefs(null)).toEqual(DEFAULT_AUDIO_PREFS);
    expect(validateAudioPrefs("loud")).toEqual(DEFAULT_AUDIO_PREFS);
    expect(validateAudioPrefs(42)).toEqual(DEFAULT_AUDIO_PREFS);
  });

  it("clamps master volume into the 0..1 range", () => {
    expect(validateAudioPrefs({ masterVolume: 4 }).masterVolume).toBe(1);
    expect(validateAudioPrefs({ masterVolume: -0.5 }).masterVolume).toBe(0);
    expect(validateAudioPrefs({ masterVolume: Number.NaN }).masterVolume).toBe(DEFAULT_AUDIO_PREFS.masterVolume);
  });

  it("never enables ambient sound by default, so audio cannot autoplay", () => {
    expect(validateAudioPrefs({}).ambientEnabled).toBe(false);
    expect(validateAudioPrefs({ ambientEnabled: true }).ambientEnabled).toBe(true);
  });

  it("keeps sound effects on unless explicitly disabled", () => {
    expect(validateAudioPrefs({}).sfxEnabled).toBe(true);
    expect(validateAudioPrefs({ sfxEnabled: false }).sfxEnabled).toBe(false);
  });
});

describe("audio prefs persistence", () => {
  it("round-trips preferences through storage", () => {
    const storage = memoryStorage();
    const prefs = { masterVolume: 0.25, ambientEnabled: true, sfxEnabled: false, muted: true };
    expect(saveAudioPrefs(prefs, storage)).toBe(true);
    expect(loadAudioPrefs(storage)).toEqual(prefs);
  });

  it("falls back to defaults when stored JSON is broken", () => {
    const storage = memoryStorage({ [AUDIO_PREFS_KEY]: "{not json" });
    expect(loadAudioPrefs(storage)).toEqual(DEFAULT_AUDIO_PREFS);
  });
});
