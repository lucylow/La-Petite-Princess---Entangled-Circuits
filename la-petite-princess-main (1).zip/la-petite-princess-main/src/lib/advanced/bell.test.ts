import { describe, expect, it } from "vitest";
import { bellCorrelation, chshValue, OPTIMAL_CHSH_ANGLES, runBellExperiment, simulateBellSetting } from "./bell";

describe("Bell and CHSH teaching model", () => {
  it("predicts perfect correlation for equal measurement settings", () => {
    expect(bellCorrelation(10, 10)).toBeCloseTo(1);
    expect(bellCorrelation(0, 180)).toBeCloseTo(-1);
  });

  it("reaches the Tsirelson bound with the optimal angle preset", () => {
    expect(chshValue(OPTIMAL_CHSH_ANGLES)).toBeCloseTo(2 * Math.SQRT2);
  });

  it("returns four correlations for the four CHSH setting pairs", () => {
    const result = runBellExperiment(OPTIMAL_CHSH_ANGLES, 1000, () => 0.25);
    expect(result.correlations).toHaveLength(4);
    expect(result.theoreticalS).toBeCloseTo(2 * Math.SQRT2);
    expect(result.classicalBound).toBe(2);
  });

  it("uses finite samples whose observed correlation is within the allowed range", () => {
    const sample = simulateBellSetting("A/B", 0, 45, 100, () => 0.1);
    expect(sample.same + sample.different).toBe(100);
    expect(sample.observedCorrelation).toBeGreaterThanOrEqual(-1);
    expect(sample.observedCorrelation).toBeLessThanOrEqual(1);
  });
});
