import { describe, expect, it } from "vitest";
import { createBasisState, probabilityDistribution, stateFidelity } from "./quantumAdvanced";
import { runBernsteinVazirani, runDeutschJozsa, runInverseQuantumFourierTransform, runQuantumFourierTransform } from "./algorithms";

describe("educational quantum algorithms", () => {
  it("Bernstein–Vazirani recovers each selected secret string", () => {
    for (const secret of ["0", "1", "00", "01", "10", "11", "101", "01101"]) {
      const result = runBernsteinVazirani(secret);
      const mostLikely = [...result.outcomes].sort((a, b) => b.probability - a.probability)[0]!;
      expect(mostLikely.label).toBe(secret);
      expect(mostLikely.probability).toBeCloseTo(1);
      expect(result.oracleQueries).toBe(1);
    }
  });

  it("Deutsch–Jozsa distinguishes constant and balanced promise cases", () => {
    const constant = runDeutschJozsa(3, "constant");
    const balanced = runDeutschJozsa(3, "balanced");
    expect(constant.outcomes[0]!.probability).toBeCloseTo(1);
    expect(balanced.outcomes[0]!.probability).toBeCloseTo(0);
    expect(balanced.outcomes.find((outcome) => outcome.label === "001")?.probability).toBeCloseTo(1);
  });

  it("QFT preserves normalization and distributes a basis input uniformly in probability", () => {
    const input = createBasisState(3, "101");
    const output = runQuantumFourierTransform(input, 3);
    expect(probabilityDistribution(output).reduce((sum, value) => sum + value, 0)).toBeCloseTo(1);
    probabilityDistribution(output).forEach((probability) => expect(probability).toBeCloseTo(1 / 8));
  });

  it("inverse QFT returns each basis state up to numerical precision", () => {
    for (const label of ["00", "01", "10", "11", "001", "101"]) {
      const qubits = label.length;
      const input = createBasisState(qubits, label);
      const transformed = runQuantumFourierTransform(input, qubits);
      const restored = runInverseQuantumFourierTransform(transformed, qubits);
      expect(stateFidelity(input, restored)).toBeCloseTo(1, 8);
    }
  });

  it("rejects malformed Bernstein–Vazirani inputs", () => {
    expect(() => runBernsteinVazirani("102")).toThrow();
    expect(() => runBernsteinVazirani("")).toThrow();
  });
});
