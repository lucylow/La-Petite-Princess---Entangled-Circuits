import { describe, expect, it } from "vitest";
import {
  STORY_JOURNEY_KEY,
  emptyJourney,
  loadJourney,
  markChapterDiscovered,
  markSectionVisited,
  saveJourney,
  validateJourney,
} from "./storyJourney";

const NUMBERS = ["01", "02", "03", "04", "05"];

function memoryStorage(initial: Record<string, string> = {}) {
  const map = new Map(Object.entries(initial));
  return {
    getItem: (key: string) => map.get(key) ?? null,
    setItem: (key: string, value: string) => { map.set(key, value); },
  };
}

describe("validateJourney", () => {
  it("returns an empty journey for missing or malformed input", () => {
    expect(validateJourney(null, 5, NUMBERS)).toEqual(emptyJourney());
    expect(validateJourney("chapter", 5, NUMBERS)).toEqual(emptyJourney());
  });

  it("drops chapter numbers that do not exist in the story", () => {
    const journey = validateJourney({ discoveredChapters: ["01", "99", "03"] }, 5, NUMBERS);
    expect(journey.discoveredChapters).toEqual(["01", "03"]);
  });

  it("clamps the last chapter index into the valid range", () => {
    expect(validateJourney({ lastChapterIndex: 42 }, 5, NUMBERS).lastChapterIndex).toBe(4);
    expect(validateJourney({ lastChapterIndex: -3 }, 5, NUMBERS).lastChapterIndex).toBe(0);
  });
});

describe("markChapterDiscovered", () => {
  it("records each chapter once and remembers the position", () => {
    let journey = emptyJourney();
    journey = markChapterDiscovered(journey, "02", 1);
    journey = markChapterDiscovered(journey, "02", 1);
    journey = markChapterDiscovered(journey, "04", 3);
    expect(journey.discoveredChapters).toEqual(["02", "04"]);
    expect(journey.lastChapterIndex).toBe(3);
  });
});

describe("journey persistence", () => {
  it("round-trips through storage", () => {
    const storage = memoryStorage();
    const journey = markSectionVisited(markChapterDiscovered(emptyJourney(), "01", 0), "story");
    expect(saveJourney(journey, storage)).toBe(true);
    expect(loadJourney(5, NUMBERS, storage)).toEqual(journey);
  });

  it("falls back to an empty journey when stored JSON is broken", () => {
    const storage = memoryStorage({ [STORY_JOURNEY_KEY]: "oops" });
    expect(loadJourney(5, NUMBERS, storage)).toEqual(emptyJourney());
  });
});
