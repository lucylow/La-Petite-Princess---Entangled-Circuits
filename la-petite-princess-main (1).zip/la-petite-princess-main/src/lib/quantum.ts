/**
 * Tiny ideal two-qubit state-vector simulator.
 *
 * Basis ordering in the state array is |q2 q1>:
 *   index 0 = |00>, index 1 = |01>, index 2 = |10>, index 3 = |11>
 * Q1 is the least-significant bit; Q2 is the most-significant bit.
 */

export type Complex = { re: number; im: number };
export type QuantumState = [Complex, Complex, Complex, Complex];
export type Gate = "H_Q1" | "H_Q2" | "X_Q1" | "X_Q2" | "CNOT_Q1_TO_Q2";

const C = (re: number, im = 0): Complex => ({ re, im });
const ZERO = () => C(0, 0);
const ONE = () => C(1, 0);
const INV_SQRT2 = 1 / Math.sqrt(2);
const EPSILON = 1e-10;

export function initialState(): QuantumState {
  return [ONE(), ZERO(), ZERO(), ZERO()];
}

function add(a: Complex, b: Complex): Complex {
  return C(a.re + b.re, a.im + b.im);
}
function scale(a: Complex, factor: number): Complex {
  return C(a.re * factor, a.im * factor);
}
function magnitudeSquared(a: Complex): number {
  return a.re * a.re + a.im * a.im;
}

function applySingleQubitGate(
  state: QuantumState,
  qubit: 1 | 2,
  matrix: [[number, number], [number, number]],
): QuantumState {
  // Pair basis indices that differ only in the selected qubit's bit.
  const bit = qubit === 1 ? 0 : 1;
  const result: QuantumState = [C(0), C(0), C(0), C(0)];
  for (let base = 0; base < 4; base += 1) {
    if ((base & (1 << bit)) !== 0) continue;
    const partner = base | (1 << bit);
    const a = state[base] ?? ZERO();
    const b = state[partner] ?? ZERO();
    result[base] = add(scale(a, matrix[0][0]), scale(b, matrix[0][1]));
    result[partner] = add(scale(a, matrix[1][0]), scale(b, matrix[1][1]));
  }
  return result;
}

const H: [[number, number], [number, number]] = [
  [INV_SQRT2, INV_SQRT2],
  [INV_SQRT2, -INV_SQRT2],
];
const X: [[number, number], [number, number]] = [
  [0, 1],
  [1, 0],
];

export function applyGate(state: QuantumState, gate: Gate): QuantumState {
  switch (gate) {
    case "H_Q1":
      return applySingleQubitGate(state, 1, H);
    case "H_Q2":
      return applySingleQubitGate(state, 2, H);
    case "X_Q1":
      return applySingleQubitGate(state, 1, X);
    case "X_Q2":
      return applySingleQubitGate(state, 2, X);
    case "CNOT_Q1_TO_Q2": {
      // Q1 is the control (least-significant bit); Q2 is the target.
      const result: QuantumState = [C(0), C(0), C(0), C(0)];
      for (let index = 0; index < 4; index += 1) {
        const q1 = index & 1;
        const destination = q1 === 1 ? index ^ 2 : index;
        result[destination] = state[index] ?? ZERO();
      }
      return result;
    }
  }
}

export function probabilities(state: QuantumState): number[] {
  const raw = state.map(magnitudeSquared);
  const total = raw.reduce((sum, value) => sum + value, 0);
  if (total < EPSILON) return [1, 0, 0, 0];
  return raw.map((value) => value / total);
}

export function sampleMeasurement(state: QuantumState): string {
  const p = probabilities(state);
  const roll = Math.random();
  let cumulative = 0;
  for (let index = 0; index < p.length; index += 1) {
    cumulative += p[index] ?? 0;
    if (roll < cumulative || index === p.length - 1) {
      return index.toString(2).padStart(2, "0");
    }
  }
  return "00";
}

function formatAmplitude(a: Complex): string {
  if (Math.abs(a.im) < EPSILON) return a.re.toFixed(3).replace(/\.000$/, "");
  if (Math.abs(a.re) < EPSILON) return `${a.im.toFixed(3)}i`;
  const sign = a.im >= 0 ? "+" : "−";
  return `${a.re.toFixed(3)} ${sign} ${Math.abs(a.im).toFixed(3)}i`;
}

export function formatState(state: QuantumState): string {
  const terms = state
    .map((amplitude, index) => ({ amplitude, label: `|${index.toString(2).padStart(2, "0")}⟩` }))
    .filter(({ amplitude }) => magnitudeSquared(amplitude) > EPSILON)
    .map(({ amplitude, label }) => `${formatAmplitude(amplitude)}${label}`);
  return terms.length ? terms.join("  +  ") : "0";
}

export function isNormalized(state: QuantumState): boolean {
  const norm = state.reduce((sum, amplitude) => sum + magnitudeSquared(amplitude), 0);
  return Math.abs(norm - 1) < 1e-8;
}

// Development sanity check for H(Q1) then CNOT(Q1 → Q2) = Bell state.
export function bellStateSelfCheck(): boolean {
  const afterH = applyGate(initialState(), "H_Q1");
  const bell = applyGate(afterH, "CNOT_Q1_TO_Q2");
  const [p0 = 0, p1 = 0, p2 = 0, p3 = 0] = probabilities(bell);
  return (
    isNormalized(bell) &&
    Math.abs(p0 - 0.5) < 1e-8 &&
    Math.abs(p1) < 1e-8 &&
    Math.abs(p2) < 1e-8 &&
    Math.abs(p3 - 0.5) < 1e-8
  );
}

/** Collapse a state after a computational-basis measurement. */
export function collapseToOutcome(state: QuantumState, outcome: string): QuantumState {
  const index = Number.parseInt(outcome, 2);
  if (!Number.isInteger(index) || index < 0 || index > 3) {
    throw new Error(`Invalid two-qubit measurement outcome: ${outcome}`);
  }
  const collapsed: QuantumState = [C(0), C(0), C(0), C(0)];
  collapsed[index] = ONE();
  return collapsed;
}
