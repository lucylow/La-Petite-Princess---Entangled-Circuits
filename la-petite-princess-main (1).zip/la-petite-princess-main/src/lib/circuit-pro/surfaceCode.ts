// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
/** CSS stabilizer-code tools for interactive error-correction lessons.
 * This module models Pauli errors and syndrome extraction classically; it does
 * not claim to simulate a full fault-tolerant surface-code hardware cycle.
 */
export type Pauli = "I" | "X" | "Y" | "Z";
export interface StabilizerCheck { id: string; basis: "X" | "Z"; support: number[]; label: string; }
export interface CssCodeDefinition { id: string; name: string; qubitCount: number; xStabilizers: StabilizerCheck[]; zStabilizers: StabilizerCheck[]; logicalX: number[]; logicalZ: number[]; description: string; }
export interface Syndrome { xChecks: number[]; zChecks: number[]; bitString: string; }
export interface PauliErrorModel { errors: Pauli[]; probability?: number; label?: string; }
export interface DecodeResult { syndrome: Syndrome; correction: Pauli[]; correctedErrors: Pauli[]; corrected: boolean; explanation: string; }
const parity = (values: number[]) => values.reduce((sum, value) => sum ^ value, 0);
function validateSupport(support: number[], qubitCount: number, label: string): void {
  if (!support.length || new Set(support).size !== support.length || support.some((q) => !Number.isInteger(q) || q < 0 || q >= qubitCount)) throw new Error(`${label} has an invalid support set.`);
}
export function validateCssCode(code: CssCodeDefinition): string[] {
  const errors: string[] = [];
  if (!Number.isInteger(code.qubitCount) || code.qubitCount < 1 || code.qubitCount > 31) errors.push("CSS code must contain 1..31 data qubits.");
  for (const check of [...code.xStabilizers, ...code.zStabilizers]) {
    try { validateSupport(check.support, code.qubitCount, check.id); } catch (error) { errors.push(error instanceof Error ? error.message : "Invalid check support."); }
    if (check.basis !== "X" && check.basis !== "Z") errors.push(`${check.id} must be an X- or Z-type stabilizer.`);
  }
  for (const x of code.xStabilizers) for (const z of code.zStabilizers) {
    const overlap = x.support.filter((q) => z.support.includes(q)).length;
    if (overlap % 2 !== 0) errors.push(`${x.id} and ${z.id} anticommute; CSS checks must commute.`);
  }
  validateLogicalSupport(code.logicalX, code.qubitCount, "logicalX", errors);
  validateLogicalSupport(code.logicalZ, code.qubitCount, "logicalZ", errors);
  return errors;
}
function validateLogicalSupport(support: number[], n: number, label: string, errors: string[]): void {
  if (!support.length || support.some((q) => !Number.isInteger(q) || q < 0 || q >= n) || new Set(support).size !== support.length) errors.push(`${label} has invalid support.`);
}
function check(id: string, basis: "X" | "Z", support: number[], label: string): StabilizerCheck { return { id, basis, support: [...support], label }; }
export function steaneCode(): CssCodeDefinition {
  const rows = [[0, 2, 4, 6], [1, 2, 5, 6], [3, 4, 5, 6]];
  const code: CssCodeDefinition = {
    id: "steane-7", name: "Steane [[7,1,3]] CSS code", qubitCount: 7,
    xStabilizers: rows.map((support, index) => check(`X${index + 1}`, "X", support, `X-check ${index + 1}`)),
    zStabilizers: rows.map((support, index) => check(`Z${index + 1}`, "Z", support, `Z-check ${index + 1}`)),
    logicalX: [0, 1, 2, 3, 4, 5, 6], logicalZ: [0, 1, 2, 3, 4, 5, 6],
    description: "Seven data qubits, six commuting CSS checks, one encoded logical qubit, and distance three.",
  };
  const errors = validateCssCode(code); if (errors.length) throw new Error(errors.join(" ")); return code;
}
export function repetitionCssCode(length = 3): CssCodeDefinition {
  if (!Number.isInteger(length) || length < 3 || length > 15 || length % 2 === 0) throw new RangeError("Repetition CSS code length must be odd and between 3 and 15.");
  return {
    id: `repetition-${length}`, name: `${length}-qubit repetition code`, qubitCount: length,
    xStabilizers: Array.from({ length: length - 1 }, (_, index) => check(`X${index}`, "X", [index, index + 1], `Adjacent X parity ${index + 1}`)),
    zStabilizers: Array.from({ length: length - 1 }, (_, index) => check(`Z${index}`, "Z", [index, index + 1], `Adjacent Z parity ${index + 1}`)),
    logicalX: Array.from({ length }, (_, index) => index), logicalZ: Array.from({ length }, (_, index) => index),
    description: "Teaching model with adjacent parity checks; useful for demonstrating syndrome logic, not a full 2D surface code.",
  };
}
export function validatePauliError(error: Pauli[], qubitCount: number): void {
  if (error.length !== qubitCount || error.some((pauli) => !["I", "X", "Y", "Z"].includes(pauli))) throw new Error(`Pauli error must contain exactly ${qubitCount} I/X/Y/Z symbols.`);
}
function anticommutesWithCheck(error: Pauli[], stabilizer: StabilizerCheck): number {
  return parity(stabilizer.support.map((q) => {
    const pauli = error[q]; return Number(stabilizer.basis === "X" ? pauli === "Z" || pauli === "Y" : pauli === "X" || pauli === "Y");
  }));
}
export function extractSyndrome(code: CssCodeDefinition, error: Pauli[]): Syndrome {
  const errors = validateCssCode(code); if (errors.length) throw new Error(errors.join(" ")); validatePauliError(error, code.qubitCount);
  const xChecks = code.xStabilizers.map((item) => anticommutesWithCheck(error, item));
  const zChecks = code.zStabilizers.map((item) => anticommutesWithCheck(error, item));
  return { xChecks, zChecks, bitString: [...zChecks, ...xChecks].join("") };
}
export function syndromeKey(syndrome: Syndrome): string { return `${syndrome.xChecks.join("")}|${syndrome.zChecks.join("")}`; }
export function singleQubitErrorSyndromeTable(code: CssCodeDefinition): Map<string, { qubit: number; pauli: "X" | "Y" | "Z" }> {
  const table = new Map<string, { qubit: number; pauli: "X" | "Y" | "Z" }>();
  for (let qubit = 0; qubit < code.qubitCount; qubit += 1) for (const pauli of ["X", "Y", "Z"] as const) {
    const error = Array.from({ length: code.qubitCount }, (_, index) => index === qubit ? pauli : "I" as Pauli);
    const syndrome = extractSyndrome(code, error); const key = syndromeKey(syndrome);
    if (!table.has(key)) table.set(key, { qubit, pauli });
  }
  return table;
}
export function decodeSingleQubitPauliError(code: CssCodeDefinition, error: Pauli[]): DecodeResult {
  const syndrome = extractSyndrome(code, error); const key = syndromeKey(syndrome); const correction = Array.from({ length: code.qubitCount }, () => "I" as Pauli);
  if (syndrome.xChecks.every((bit) => bit === 0) && syndrome.zChecks.every((bit) => bit === 0)) {
    return { syndrome, correction, correctedErrors: [...error], corrected: error.every((pauli) => pauli === "I"), explanation: "The syndrome is zero. The error is either absent or logically/stabilizer equivalent and cannot be distinguished by these checks." };
  }
  const match = singleQubitErrorSyndromeTable(code).get(key);
  if (!match) return { syndrome, correction, correctedErrors: [...error], corrected: false, explanation: "No unique single-qubit Pauli correction matches this syndrome. The error may exceed the code's correction capability." };
  correction[match.qubit] = match.pauli;
  const correctedErrors = error.map((pauli, index) => multiplyPaulis(pauli, correction[index]));
  const remainingSyndrome = extractSyndrome(code, correctedErrors);
  const corrected = remainingSyndrome.xChecks.every((bit) => bit === 0) && remainingSyndrome.zChecks.every((bit) => bit === 0);
  return { syndrome, correction, correctedErrors, corrected, explanation: `Apply ${match.pauli} to data qubit ${match.qubit}. ${corrected ? "The syndrome is cleared." : "A residual syndrome remains."}` };
}
export function multiplyPaulis(a: Pauli, b: Pauli): Pauli {
  if (a === "I") return b; if (b === "I") return a; if (a === b) return "I";
  // Pauli phase is intentionally omitted: this helper tracks the Pauli frame modulo global phase.
  if ((a === "X" && b === "Y") || (a === "Y" && b === "X")) return "Z";
  if ((a === "Y" && b === "Z") || (a === "Z" && b === "Y")) return "X";
  return "Y";
}
export function applyPauliFrame(error: Pauli[], correction: Pauli[]): Pauli[] {
  if (error.length !== correction.length) throw new Error("Pauli frames must have the same number of qubits.");
  return error.map((pauli, index) => multiplyPaulis(pauli, correction[index]));
}
export function samplePauliError(qubitCount: number, probabilities: { x: number; y: number; z: number }, random: () => number = Math.random): PauliErrorModel {
  const { x, y, z } = probabilities;
  if ([x, y, z].some((value) => !Number.isFinite(value) || value < 0) || x + y + z > 1 + 1e-12) throw new RangeError("Pauli probabilities must be non-negative and sum to at most one.");
  const errors: Pauli[] = Array.from({ length: qubitCount }, () => { const value = random(); return value < x ? "X" : value < x + y ? "Y" : value < x + y + z ? "Z" : "I"; });
  return { errors, probability: x + y + z, label: "Independent Pauli noise" };
}
export function runSyndromeExperiment(code: CssCodeDefinition, error: Pauli[]): DecodeResult {
  return decodeSingleQubitPauliError(code, error);
}
export function steaneSingleErrorCoverage(): { total: number; uniqueSyndromes: number; collisions: string[] } {
  const code = steaneCode(); const table = singleQubitErrorSyndromeTable(code); const total = code.qubitCount * 3;
  const collisions: string[] = [];
  for (let q = 0; q < code.qubitCount; q += 1) for (const p of ["X", "Y", "Z"] as const) {
    const error = Array.from({ length: code.qubitCount }, (_, index) => index === q ? p : "I" as Pauli); const key = syndromeKey(extractSyndrome(code, error));
    if (!table.has(key)) collisions.push(`${p}${q}`);
  }
  return { total, uniqueSyndromes: table.size, collisions };
}
