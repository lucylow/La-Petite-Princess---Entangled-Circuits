// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { createOperation } from "./circuit";
import type { CircuitOperation, GateName, OperationParameters } from "./types";

export interface DecompositionStep { gate: GateName; targets: number[]; controls?: number[]; params?: OperationParameters; note: string; }
function step(gate: GateName, target: number | number[], controls: number[] = [], theta?: number, note = ""): DecompositionStep {
  return { gate, targets: Array.isArray(target) ? target : [target], ...(controls.length ? { controls } : {}), ...(theta === undefined ? {} : { params: { theta } }), note };
}
function rotation(gate: "RX" | "RY" | "RZ", target: number, theta: number, note: string): DecompositionStep { return step(gate, target, [], theta, note); }

/**
 * Exact algebraic identities, up to an explicitly documented global phase.
 * A global phase is physically unobservable for an isolated circuit, but may
 * matter if the circuit is later controlled as a subroutine.
 */
export function decomposeOperation(operation: CircuitOperation): { steps: DecompositionStep[]; globalPhase: number; exactUpToGlobalPhase: boolean; notes: string[] } {
  const gate = operation.gate; const target = operation.targets[0]; const control = operation.controls?.[0];
  const theta = operation.params?.theta ?? 0; const notes: string[] = [];
  if (gate === "SWAP") {
    const [a, b] = operation.targets;
    return { steps: [step("CX", b, [a]), step("CX", a, [b]), step("CX", b, [a])], globalPhase: 0, exactUpToGlobalPhase: true, notes: ["SWAP decomposes into three CNOT gates."] };
  }
  if (gate === "CZ") {
    return { steps: [step("H", target), step("CX", target, operation.controls ?? []), step("H", target)], globalPhase: 0, exactUpToGlobalPhase: true, notes: ["CZ = H(target) · CX · H(target)."] };
  }
  if (gate === "CY") {
    return { steps: [step("SDG", target), step("CX", target, [control!]), step("S", target)], globalPhase: 0, exactUpToGlobalPhase: true, notes: ["CY is obtained by conjugating CX with S gates on its target."] };
  }
  if (gate === "H") {
    return { steps: [rotation("RZ", target, Math.PI / 2, "Hadamard Euler decomposition"), step("SX", target), rotation("RZ", target, Math.PI / 2, "Hadamard Euler decomposition")], globalPhase: Math.PI / 4, exactUpToGlobalPhase: true, notes: ["H is RZ(π/2) · SX · RZ(π/2), up to a global phase of −π/4."] };
  }
  if (gate === "RX") {
    return { steps: [step("H", target), rotation("RZ", target, theta, "RX via basis change"), step("H", target)], globalPhase: 0, exactUpToGlobalPhase: true, notes: ["RX(θ) = H RZ(θ) H."] };
  }
  if (gate === "RY") {
    return { steps: [step("SDG", target), step("H", target), rotation("RZ", target, theta, "RY via basis change"), step("H", target), step("S", target)], globalPhase: 0, exactUpToGlobalPhase: true, notes: ["RY is synthesized using Z-axis rotations and basis changes."] };
  }
  if (gate === "SXDG") {
    return { steps: [step("X", target), step("SX", target)], globalPhase: 0, exactUpToGlobalPhase: true, notes: ["SX† = X·SX, since SX² = X."] };
  }
  if (gate === "ISWAP") {
    const [a, b] = operation.targets;
    return { steps: [step("CZ", b, [a]), step("SWAP", [a, b]), step("S", a), step("S", b)], globalPhase: 0, exactUpToGlobalPhase: true, notes: ["iSWAP = (S⊗S)·SWAP·CZ; local S rotations may be represented by RZ plus global phase."] };
  }
  if (gate === "CP") {
    const c = control!; const half = theta / 2;
    return { steps: [rotation("RZ", c, half, "controlled phase · control"), rotation("RZ", target, half, "controlled phase · target"), step("CX", target, [c]), rotation("RZ", target, -half, "controlled phase · uncompute"), step("CX", target, [c])], globalPhase: theta / 4, exactUpToGlobalPhase: true, notes: ["Controlled phase is decomposed into local Z rotations and two CNOTs.", "The listed global phase is omitted by this compiler unless phase tracking is enabled."] };
  }
  if (gate === "CRZ") {
    const c = control!;
    return { steps: [rotation("RZ", target, theta / 2, "controlled RZ"), step("CX", target, [c]), rotation("RZ", target, -theta / 2, "controlled RZ"), step("CX", target, [c])], globalPhase: 0, exactUpToGlobalPhase: true, notes: ["Controlled RZ uses the standard two-CNOT decomposition."] };
  }
  if (gate === "CRX") {
    const c = control!;
    return { steps: [step("H", target), rotation("RZ", target, theta / 2, "controlled RX via CRZ"), step("CX", target, [c]), rotation("RZ", target, -theta / 2, "controlled RX via CRZ"), step("CX", target, [c]), step("H", target)], globalPhase: 0, exactUpToGlobalPhase: true, notes: ["CRX is obtained by conjugating CRZ with Hadamard gates on the target."] };
  }
  if (gate === "CRY") {
    const c = control!;
    return { steps: [rotation("RY", target, theta / 2, "controlled RY"), step("CX", target, [c]), rotation("RY", target, -theta / 2, "controlled RY"), step("CX", target, [c])], globalPhase: 0, exactUpToGlobalPhase: true, notes: ["Controlled RY uses a pair of CNOT gates and half-angle rotations."] };
  }
  if (gate === "CCX") {
    const [a, b] = operation.controls ?? []; const t = target;
    return { steps: [
      step("H", t), step("CX", t, [b]), step("TDG", t), step("CX", t, [a]), step("T", t),
      step("CX", t, [b]), step("TDG", t), step("CX", t, [a]), step("T", b), step("T", t),
      step("H", t), step("CX", b, [a]), step("T", a), step("TDG", b), step("CX", b, [a]),
    ], globalPhase: 0, exactUpToGlobalPhase: true, notes: ["Toffoli decomposition into Clifford+T gates; this is a standard exact construction up to global phase."] };
  }
  if (gate === "CSWAP") {
    const [a, b] = operation.targets; const c = control!;
    return { steps: [step("CX", a, [b]), step("CCX", b, [c, a]), step("CX", a, [b])], globalPhase: 0, exactUpToGlobalPhase: true, notes: ["Fredkin gate decomposes into CNOT–Toffoli–CNOT."] };
  }
  if (gate === "U3") {
    const phi = operation.params?.phi ?? 0; const lambda = operation.params?.lambda ?? 0;
    return { steps: [rotation("RZ", target, lambda, "U3 Euler angle λ"), rotation("RY", target, theta, "U3 Euler angle θ"), rotation("RZ", target, phi, "U3 Euler angle φ")], globalPhase: 0, exactUpToGlobalPhase: true, notes: ["U3 = RZ(φ) RY(θ) RZ(λ), with operations listed in application order."] };
  }
  if (gate === "S") return { steps: [rotation("RZ", target, Math.PI / 2, "S phase")], globalPhase: Math.PI / 4, exactUpToGlobalPhase: true, notes: ["S differs from RZ(π/2) by a global phase."] };
  if (gate === "SDG") return { steps: [rotation("RZ", target, -Math.PI / 2, "S dagger phase")], globalPhase: -Math.PI / 4, exactUpToGlobalPhase: true, notes: ["S† differs from RZ(-π/2) by a global phase."] };
  if (gate === "T") return { steps: [rotation("RZ", target, Math.PI / 4, "T phase")], globalPhase: Math.PI / 8, exactUpToGlobalPhase: true, notes: ["T differs from RZ(π/4) by a global phase."] };
  if (gate === "TDG") return { steps: [rotation("RZ", target, -Math.PI / 4, "T dagger phase")], globalPhase: -Math.PI / 8, exactUpToGlobalPhase: true, notes: ["T† differs from RZ(-π/4) by a global phase."] };
  if (gate === "Z") return { steps: [rotation("RZ", target, Math.PI, "Z rotation")], globalPhase: Math.PI / 2, exactUpToGlobalPhase: true, notes: ["Z differs from RZ(π) by a global phase."] };
  if (gate === "I" || gate === "X" || gate === "Y" || gate === "SX" || gate === "CX" || gate === "CH" || gate === "BARRIER" || gate === "MEASURE") {
    notes.push(`${gate} is retained as a native or directive operation.`);
    return { steps: [{ gate, targets: [...operation.targets], ...(operation.controls ? { controls: [...operation.controls] } : {}), ...(operation.params ? { params: { ...operation.params } } : {}), note: operation.note ?? "native operation" }], globalPhase: 0, exactUpToGlobalPhase: true, notes };
  }
  throw new Error(`No decomposition registered for gate ${gate}.`);
}
export function materializeDecomposition(steps: DecompositionStep[], prefix = "decomp"): CircuitOperation[] {
  return steps.map((item, index) => ({ id: `${prefix}-${index + 1}`, gate: item.gate, targets: [...item.targets], ...(item.controls ? { controls: [...item.controls] } : {}), ...(item.params ? { params: { ...item.params } } : {}), ...(item.note ? { note: item.note } : {}) }));
}
export function decomposeMany(operations: CircuitOperation[]): CircuitOperation[] {
  return operations.flatMap((operation, index) => materializeDecomposition(decomposeOperation(operation).steps, `${operation.id}-expanded-${index}`));
}
