// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import type { CircuitDefinition, NoiseParameters } from "./types";
import { runNoisyShots } from "./noise";
import { createSeededRandom } from "./random";
import { confidenceIntervalForMean, totalVariationDistance } from "./statistics";

export interface NoiseSweepPoint { probability: number; totalVariation: number; dominantOutcome: string; dominantFrequency: number; entropy: number; }
export interface NoiseSweepResult { channel: "depolarizing" | "amplitudeDamping" | "phaseDamping" | "readoutFlip"; points: NoiseSweepPoint[]; referenceSeed: number; shotsPerPoint: number; }
export interface RepeatedRunSummary { repetitions: number; meanDominantFrequency: number; standardError: number; lower95: number; upper95: number; values: number[]; }
function entropy(counts: Record<string, number>, shots: number): number {
  return -Object.values(counts).filter((value) => value > 0).reduce((sum, count) => { const p = count / shots; return sum + p * Math.log2(p); }, 0);
}
export function sweepNoiseStrength(circuit: CircuitDefinition, channel: NoiseSweepResult["channel"], probabilities: number[], shots = 2000, seed = 10): NoiseSweepResult {
  if (probabilities.some((p) => !Number.isFinite(p) || p < 0 || p > 1)) throw new RangeError("Noise probabilities must be between 0 and 1.");
  const baseline = runNoisyShots(circuit, shots, {}, seed).frequencies;
  const points = probabilities.map((probability) => {
    const noise: NoiseParameters = { [channel]: probability };
    const result = runNoisyShots(circuit, shots, noise, seed + Math.round(probability * 100_000));
    const dominant = Object.entries(result.counts).sort((a, b) => b[1] - a[1])[0] ?? ["", 0];
    return { probability, totalVariation: totalVariationDistance(baseline, result.frequencies), dominantOutcome: dominant[0], dominantFrequency: dominant[1] / shots, entropy: entropy(result.counts, shots) };
  });
  return { channel, points, referenceSeed: seed, shotsPerPoint: shots };
}
export function repeatedNoisyRuns(circuit: CircuitDefinition, noise: NoiseParameters, repetitions = 20, shots = 1000, seed = 1): RepeatedRunSummary {
  if (!Number.isInteger(repetitions) || repetitions < 2 || repetitions > 500) throw new RangeError("repetitions must be 2..500.");
  const values = Array.from({ length: repetitions }, (_, index) => {
    const result = runNoisyShots(circuit, shots, noise, seed + index * 7919);
    return Math.max(...Object.values(result.frequencies));
  });
  const summary = confidenceIntervalForMean(values);
  return { repetitions, meanDominantFrequency: summary.mean, standardError: summary.standardError, lower95: summary.lower95, upper95: summary.upper95, values };
}
export function noiseSweepCsv(result: NoiseSweepResult): string {
  return ["probability,total_variation,dominant_outcome,dominant_frequency,entropy_bits", ...result.points.map((point) => [point.probability, point.totalVariation, point.dominantOutcome, point.dominantFrequency, point.entropy].join(","))].join("\n") + "\n";
}
export function bootstrapMean(values: number[], resamples = 1000, seed = 42): { mean: number; lower95: number; upper95: number } {
  if (values.length < 2 || values.some((value) => !Number.isFinite(value)) || !Number.isInteger(resamples) || resamples < 100) throw new Error("Bootstrap requires 2+ finite values and at least 100 resamples.");
  const rng = createSeededRandom(seed); const means = Array.from({ length: resamples }, () => {
    let sum = 0; for (let i = 0; i < values.length; i += 1) sum += values[Math.floor(rng() * values.length)];
    return sum / values.length;
  }).sort((a, b) => a - b);
  const mean = values.reduce((sum, value) => sum + value, 0) / values.length;
  return { mean, lower95: means[Math.floor(0.025 * (resamples - 1))], upper95: means[Math.ceil(0.975 * (resamples - 1))] };
}
