// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import type { CircuitDefinition, GateName } from "./types";
import { assertValidCircuit, validateCircuit } from "./circuit";
import { optimizeCircuit } from "./optimizer";
import { transpileCircuit, type TranspileOptions } from "./transpiler";
import { routeCircuitToConnectivity, type CouplingMap, type RoutingOptions } from "./connectivity";
import { scheduleCircuit } from "./scheduler";
import { circuitMetrics } from "./metrics";
import { estimateCircuitResources, type ResourceEstimate } from "./resourceEstimate";
import { lintCircuit } from "./circuitLint";

export interface CompilerOptions {
  optimize?: boolean;
  transpile?: boolean;
  basis?: GateName[];
  couplingMap?: CouplingMap;
  routing?: RoutingOptions;
  preserveBarriers?: boolean;
  maxQubits?: number;
  strict?: boolean;
}
export interface CompilerPassReport { name: string; changed: boolean; before: number; after: number; notes: string[]; }
export interface CompiledCircuitReport {
  circuit: CircuitDefinition;
  passes: CompilerPassReport[];
  initialMetrics: ReturnType<typeof circuitMetrics>;
  finalMetrics: ReturnType<typeof circuitMetrics>;
  resources: ResourceEstimate;
  schedule: ReturnType<typeof scheduleCircuit>;
  warnings: string[];
  errors: string[];
  layout?: { initial: number[]; final: number[] };
  successful: boolean;
}
/** Deterministic local compilation pipeline. No vendor hardware is contacted. */
export function compileCircuitPro(input: CircuitDefinition, options: CompilerOptions = {}): CompiledCircuitReport {
  const maxQubits = options.maxQubits ?? 10; const errors = validateCircuit(input, maxQubits).filter((issue) => issue.severity === "error").map((issue) => issue.message);
  if (errors.length) {
    if (options.strict !== false) throw new Error(`Circuit validation failed:\n${errors.join("\n")}`);
    return emptyFailure(input, errors);
  }
  assertValidCircuit(input, maxQubits);
  const initialMetrics = circuitMetrics(input); let circuit = input; const passes: CompilerPassReport[] = []; const warnings: string[] = [];
  if (options.optimize !== false) {
    const result = optimizeCircuit(circuit); circuit = result.circuit;
    passes.push({ name: "Local simplification", changed: result.removedOperations > 0 || result.optimizedOperationCount !== result.originalOperationCount, before: result.originalOperationCount, after: result.optimizedOperationCount, notes: result.notes });
  }
  if (options.transpile !== false) {
    const result = transpileCircuit(circuit, { basis: options.basis, preserveBarriers: options.preserveBarriers }); circuit = result.circuit; warnings.push(...result.warnings);
    passes.push({ name: "Basis translation", changed: result.originalGateCount !== result.outputGateCount || result.warnings.length > 0, before: result.originalGateCount, after: result.outputGateCount, notes: [`Global phase: ${result.globalPhaseRadians.toFixed(8)} rad`, ...result.warnings] });
  }
  let layout: { initial: number[]; final: number[] } | undefined;
  if (options.couplingMap) {
    const before = circuit.operations.length; const routed = routeCircuitToConnectivity(circuit, options.couplingMap, options.routing); circuit = routed.circuit;
    layout = { initial: routed.initialLayout, final: routed.finalLayout }; warnings.push(...routed.warnings);
    passes.push({ name: "Connectivity routing", changed: routed.insertedSwaps > 0 || circuit.qubitCount !== input.qubitCount, before, after: circuit.operations.length, notes: [`Inserted ${routed.insertedSwaps} SWAP gates`, `Final layout: ${routed.finalLayout.map((value) => value + 1).join(", ")}`] });
  }
  const finalIssues = validateCircuit(circuit, Math.max(maxQubits, circuit.qubitCount));
  const finalErrors = finalIssues.filter((issue) => issue.severity === "error").map((issue) => issue.message);
  const lint = lintCircuit(circuit); warnings.push(...finalIssues.filter((issue) => issue.severity === "warning").map((issue) => issue.message));
  warnings.push(...lint.issues.filter((issue) => issue.severity === "warning").map((issue) => issue.message));
  const finalMetrics = circuitMetrics(circuit); const resources = estimateCircuitResources(circuit); const schedule = scheduleCircuit(circuit);
  return { circuit, passes, initialMetrics, finalMetrics, resources, schedule, warnings: [...new Set(warnings)], errors: finalErrors, ...(layout ? { layout } : {}), successful: finalErrors.length === 0 };
}
function emptyFailure(input: CircuitDefinition, errors: string[]): CompiledCircuitReport {
  return { circuit: input, passes: [], initialMetrics: circuitMetrics(input), finalMetrics: circuitMetrics(input), resources: estimateCircuitResources(input), schedule: [], warnings: [], errors, successful: false };
}
export function summarizeCompilation(report: CompiledCircuitReport): string[] {
  const reduction = report.initialMetrics.operationCount - report.finalMetrics.operationCount;
  return [
    report.successful ? "Compilation completed." : "Compilation failed validation.",
    `${report.initialMetrics.operationCount} → ${report.finalMetrics.operationCount} operations (${reduction >= 0 ? `${reduction} removed` : `${-reduction} added`}).`,
    `${report.initialMetrics.depth} → ${report.finalMetrics.depth} scheduled layers.`,
    `${report.finalMetrics.entanglingGateCount} entangling operations in the compiled circuit.`,
    `${report.warnings.length} warning(s), ${report.errors.length} error(s).`,
  ];
}
export function defaultCompilationBasis(): GateName[] { return ["H", "X", "SX", "RZ", "CX", "MEASURE", "BARRIER"]; }
