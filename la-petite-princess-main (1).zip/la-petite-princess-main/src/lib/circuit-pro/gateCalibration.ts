// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { complex } from "../advanced/complex";
import type { CircuitOperation } from "./types";
import { singleQubitMatrix } from "./gates";
import { createCircuit, createOperation } from "./circuit";
import { circuitUnitary, processFidelity } from "./unitary";
import { isUnitary, fromRows } from "./matrix";

export interface GateCalibrationPoint { gate: string; targetTheta: number; observedTheta: number; angleError: number; processFidelity: number; unitary: boolean; }
export interface CalibrationProfile { label: string; singleQubitAngleOffset: number; depolarizingProbability: number; readoutFlipProbability: number; }
export function calibrateRotationGate(gate: "RX" | "RY" | "RZ", targetTheta: number, observedTheta: number): GateCalibrationPoint {
  if (![targetTheta, observedTheta].every(Number.isFinite)) throw new Error("Calibration angles must be finite.");
  const target = fromRows(singleQubitMatrix(gate, { theta: targetTheta })); const observed = fromRows(singleQubitMatrix(gate, { theta: observedTheta }));
  const circuitTarget = createCircuit(`ideal ${gate}`, 1, 1, [createOperation(gate, 0, [], { theta: targetTheta })]);
  const circuitObserved = createCircuit(`observed ${gate}`, 1, 1, [createOperation(gate, 0, [], { theta: observedTheta })]);
  const fidelity = processFidelity(circuitUnitary(circuitTarget), circuitUnitary(circuitObserved));
  return { gate, targetTheta, observedTheta, angleError: observedTheta - targetTheta, processFidelity: fidelity, unitary: isUnitary(observed) };
}
export function applyCalibration(operation: CircuitOperation, profile: CalibrationProfile): CircuitOperation {
  if (!Number.isFinite(profile.singleQubitAngleOffset)) throw new Error("Calibration offset must be finite.");
  const parameters = operation.params ? { ...operation.params } : undefined;
  if (parameters && ["RX", "RY", "RZ", "CRX", "CRY", "CRZ", "CP"].includes(operation.gate)) parameters.theta = (parameters.theta ?? 0) + profile.singleQubitAngleOffset;
  return { ...operation, ...(parameters ? { params: parameters } : {}) };
}
export function validateCalibrationProfile(profile: CalibrationProfile): string[] {
  const errors: string[] = [];
  if (!profile.label.trim()) errors.push("Calibration profile needs a label.");
  if (!Number.isFinite(profile.singleQubitAngleOffset)) errors.push("Angle offset must be finite.");
  for (const [key, value] of [["depolarizingProbability", profile.depolarizingProbability], ["readoutFlipProbability", profile.readoutFlipProbability]] as const) if (!Number.isFinite(value) || value < 0 || value > 1) errors.push(`${key} must lie between 0 and 1.`);
  return errors;
}
export function calibrationToMarkdown(profile: CalibrationProfile): string {
  const errors = validateCalibrationProfile(profile);
  return [`# Calibration profile: ${profile.label}`, "", `- Rotation-angle offset: ${profile.singleQubitAngleOffset} rad`, `- Depolarizing probability: ${(profile.depolarizingProbability * 100).toFixed(2)}%`, `- Readout flip probability: ${(profile.readoutFlipProbability * 100).toFixed(2)}%`, "", errors.length ? `Validation errors:\n${errors.map((error) => `- ${error}`).join("\n")}` : "Profile validation: passed", "", "This is a user-defined educational noise profile, not a hardware calibration certificate."].join("\n");
}
export function calibrationMatrix(probability: number): ReturnType<typeof fromRows> {
  if (!Number.isFinite(probability) || probability < 0 || probability > 1) throw new RangeError("probability must be 0..1.");
  return fromRows([[complex(1 - probability), complex(probability)], [complex(probability), complex(1 - probability)]]);
}
