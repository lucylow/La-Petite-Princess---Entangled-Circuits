// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import type { CircuitDefinition, CircuitOperation } from "./types";
import { touchedQubits } from "./metrics";

export interface ScheduledOperation { operation: CircuitOperation; layer: number; column: number; }
export interface CircuitLayer { index: number; operations: CircuitOperation[]; occupiedQubits: number[]; }
export function scheduleCircuit(circuit: CircuitDefinition): CircuitLayer[] {
  const layers: CircuitLayer[] = []; const lastLayerForQubit = Array.from({ length: circuit.qubitCount }, () => -1);
  for (const operation of circuit.operations) {
    const qubits = touchedQubits(operation);
    const minimumLayer = qubits.reduce((max, qubit) => Math.max(max, lastLayerForQubit[qubit] + 1), 0);
    let selected = minimumLayer;
    while (layers[selected] && qubits.some((qubit) => layers[selected].occupiedQubits.includes(qubit))) selected += 1;
    if (!layers[selected]) layers[selected] = { index: selected, operations: [], occupiedQubits: [] };
    layers[selected].operations.push(operation);
    layers[selected].occupiedQubits.push(...qubits);
    qubits.forEach((qubit) => { lastLayerForQubit[qubit] = selected; });
  }
  return layers.filter(Boolean);
}
export function scheduledDepth(circuit: CircuitDefinition): number { return scheduleCircuit(circuit).length; }
export function parallelOperationCount(circuit: CircuitDefinition): number { return scheduleCircuit(circuit).reduce((sum, layer) => sum + layer.operations.length, 0); }
export function layersToText(layers: CircuitLayer[]): string {
  return layers.map((layer) => `Layer ${layer.index + 1}: ${layer.operations.map((operation) => operation.gate).join(" · ")}`).join("\n");
}
export function canScheduleTogether(first: CircuitOperation, second: CircuitOperation): boolean {
  const firstWires = new Set(touchedQubits(first));
  return touchedQubits(second).every((qubit) => !firstWires.has(qubit));
}
