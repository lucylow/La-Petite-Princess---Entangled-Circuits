// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { createCircuit, createOperation } from "./circuit";
import type { CircuitDefinition, CircuitOperation, GateName } from "./types";

export interface QasmDiagnostic { line: number; severity: "warning" | "error"; message: string; }
export interface QasmParseResult { circuit: CircuitDefinition; diagnostics: QasmDiagnostic[]; sourceVersion: string; }
function parseAngle(source: string): number {
  const value = source.trim().toLowerCase().replace(/\s+/g, "");
  if (/^-?\d+(\.\d+)?$/.test(value)) return Number(value);
  const normalized = value.replace(/\*pi/g, "pi");
  const match = normalized.match(/^(-?\d+(?:\.\d+)?)?(?:pi)(?:\/(\d+(?:\.\d+)?))?$/);
  if (match) return (match[1] ? Number(match[1]) : 1) * Math.PI / (match[2] ? Number(match[2]) : 1);
  const expression = normalized.match(/^(-?\d+(?:\.\d+)?)\*pi\/(\d+(?:\.\d+)?)$/);
  if (expression) return Number(expression[1]) * Math.PI / Number(expression[2]);
  throw new Error(`Unsupported angle expression: ${source}`);
}
function parseQubit(token: string): number {
  const match = token.trim().match(/^(?:q|qubits)\[(\d+)\]$/i);
  if (!match) throw new Error(`Expected a q[index] register reference, received ${token}.`);
  return Number(match[1]);
}
function parseParameters(source: string): number[] { return source.split(",").map(parseAngle); }
function operationForGate(name: string, operands: string[], parameters: number[], ordinal: number): CircuitOperation {
  const gate = (name.toUpperCase() === "U" ? "U3" : name.toUpperCase()) as GateName;
  const allowed = new Set<GateName>(["I", "X", "Y", "Z", "H", "S", "SDG", "T", "TDG", "SX", "SXDG", "RX", "RY", "RZ", "U3", "CX", "CY", "CZ", "CH", "CP", "CRX", "CRY", "CRZ", "SWAP", "ISWAP", "CCX", "CSWAP", "BARRIER"]);
  if (!allowed.has(gate)) throw new Error(`Unsupported gate ${name}.`);
  const qubits = operands.map(parseQubit); let targets: number[]; let controls: number[] = [];
  if (["CX", "CY", "CZ", "CH", "CP", "CRX", "CRY", "CRZ"].includes(gate)) { if (qubits.length !== 2) throw new Error(`${gate} expects control and target operands.`); controls = [qubits[0]]; targets = [qubits[1]]; }
  else if (gate === "CCX") { if (qubits.length !== 3) throw new Error("CCX expects three operands."); controls = qubits.slice(0, 2); targets = [qubits[2]]; }
  else if (gate === "CSWAP") { if (qubits.length !== 3) throw new Error("CSWAP expects three operands."); controls = [qubits[0]]; targets = qubits.slice(1); }
  else if (gate === "SWAP" || gate === "ISWAP") { if (qubits.length !== 2) throw new Error(`${gate} expects two operands.`); targets = qubits; }
  else { if (qubits.length !== 1) throw new Error(`${gate} expects one operand.`); targets = qubits; }
  let params: { theta?: number; phi?: number; lambda?: number } | undefined;
  if (["RX", "RY", "RZ", "CP", "CRX", "CRY", "CRZ"].includes(gate)) { if (parameters.length !== 1) throw new Error(`${gate} expects one angle.`); params = { theta: parameters[0] }; }
  if (gate === "U3") { if (parameters.length !== 3) throw new Error("U expects three angles."); params = { theta: parameters[0], phi: parameters[1], lambda: parameters[2] }; }
  return createOperation(gate, targets, controls, params, `Imported from OpenQASM 3 line ${ordinal}`);
}
/** Imports the OpenQASM 3 subset emitted by circuitToOpenQasm3. */
export function parseOpenQasm3(source: string, options: { strict?: boolean; maxQubits?: number } = {}): QasmParseResult {
  const diagnostics: QasmDiagnostic[] = []; const clean = source.split(/\r?\n/).map((raw, index) => ({ line: index + 1, text: raw.replace(/\/\/.*$/, "").trim() })).filter((item) => item.text.length > 0);
  const header = clean.find((item) => /^OPENQASM\s+3(?:\.0)?\s*;$/i.test(item.text));
  if (!header) throw new Error("Source must declare OPENQASM 3.0;.");
  const qreg = clean.map((item) => ({ ...item, match: item.text.match(/^qubit\[(\d+)\]\s+q\s*;$/i) })).find((item) => item.match);
  if (!qreg?.match) throw new Error("A single qubit[n] q register is required.");
  const qubitCount = Number(qreg.match[1]); const maxQubits = options.maxQubits ?? 10;
  if (!Number.isInteger(qubitCount) || qubitCount < 1 || qubitCount > maxQubits) throw new RangeError(`Qubit register must contain 1..${maxQubits} qubits.`);
  const creg = clean.map((item) => ({ ...item, match: item.text.match(/^bit\[(\d+)\]\s+c\s*;$/i) })).find((item) => item.match);
  const classicalBitCount = creg?.match ? Number(creg.match[1]) : 0; const operations: CircuitOperation[] = [];
  for (const item of clean) {
    const line = item.text;
    if (/^OPENQASM\s+/i.test(line) || /^include\s+/i.test(line) || /^qubit\[/i.test(line) || /^bit\[/i.test(line)) continue;
    if (/^barrier(?:\s+q)?\s*;$/i.test(line)) { operations.push(createOperation("BARRIER", Array.from({ length: qubitCount }, (_, index) => index), [], undefined, `Imported from line ${item.line}`)); continue; }
    const measure = line.match(/^c\[(\d+)\]\s*=\s*measure\s+q\[(\d+)\]\s*;$/i);
    if (measure) {
      const classicalBit = Number(measure[1]); const target = Number(measure[2]);
      if (classicalBit >= classicalBitCount || target >= qubitCount) throw new Error(`Measurement on line ${item.line} references an out-of-range register index.`);
      operations.push({ ...createOperation("MEASURE", target, [], undefined, `Imported from line ${item.line}`), classicalBit }); continue;
    }
    const gate = line.match(/^([a-z][a-z0-9_]*)(?:\((.*)\))?\s+(.+)\s*;$/i);
    if (!gate) { const message = `Unsupported or malformed statement: ${line}`; diagnostics.push({ line: item.line, severity: options.strict ? "error" : "warning", message }); continue; }
    const name = gate[1].toLowerCase(); const params = gate[2] === undefined ? [] : parseParameters(gate[2]);
    const operands = gate[3].split(",").map((part) => part.trim());
    try {
      const operation = operationForGate(name, operands, params, item.line);
      if ([...operation.targets, ...(operation.controls ?? [])].some((qubit) => qubit >= qubitCount)) throw new Error("Gate references a qubit outside the declared register.");
      operations.push(operation);
    } catch (error) { diagnostics.push({ line: item.line, severity: "error", message: error instanceof Error ? error.message : "Unable to parse operation." }); }
  }
  const errors = diagnostics.filter((diagnostic) => diagnostic.severity === "error");
  if (errors.length) throw new Error(errors.map((item) => `Line ${item.line}: ${item.message}`).join("\n"));
  const circuit = createCircuit("Imported OpenQASM 3 circuit", qubitCount, classicalBitCount, operations);
  return { circuit, diagnostics, sourceVersion: "3.0" };
}
export function isOpenQasm3(source: string): boolean { return /^\s*OPENQASM\s+3(?:\.0)?\s*;/im.test(source); }
