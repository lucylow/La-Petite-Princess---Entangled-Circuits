// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { createCircuit, createOperation } from "./circuit";
import { expectHamiltonian } from "./observables";
import { simulateCircuit } from "./simulator";
import type { CircuitDefinition, PauliTerm } from "./types";

export interface VariationalPoint { iteration: number; parameters: number[]; energy: number; gradientNorm: number; }
export interface VariationalResult { bestParameters: number[]; bestEnergy: number; history: VariationalPoint[]; converged: boolean; }
export interface GradientDescentOptions { learningRate?: number; iterations?: number; tolerance?: number; seedParameters?: number[]; }
export function singleQubitAnsatz(theta: number, phi = 0): CircuitDefinition {
  const operations = [createOperation("RY", 0, [], { theta }), createOperation("RZ", 0, [], { theta: phi })];
  return { ...createCircuit("Single-qubit variational ansatz", 1), operations, description: "A two-parameter one-qubit ansatz used for variational algorithm demonstrations." };
}
export function estimateEnergy(parameters: number[], hamiltonian: PauliTerm[]): number {
  if (parameters.length < 1 || parameters.length > 2) throw new Error("This educational ansatz uses one or two parameters.");
  const state = simulateCircuit(singleQubitAnsatz(parameters[0], parameters[1] ?? 0)).state;
  return expectHamiltonian(state, 1, hamiltonian).total;
}
export function parameterShiftGradient(parameters: number[], hamiltonian: PauliTerm[]): number[] {
  return parameters.map((_, index) => {
    const plus = [...parameters]; const minus = [...parameters];
    plus[index] += Math.PI / 2; minus[index] -= Math.PI / 2;
    return (estimateEnergy(plus, hamiltonian) - estimateEnergy(minus, hamiltonian)) / 2;
  });
}
export function optimizeVariational(parameters: number[], hamiltonian: PauliTerm[], options: GradientDescentOptions = {}): VariationalResult {
  const learningRate = options.learningRate ?? 0.12; const iterations = options.iterations ?? 100; const tolerance = options.tolerance ?? 1e-6;
  if (!Number.isFinite(learningRate) || learningRate <= 0) throw new RangeError("Learning rate must be positive and finite.");
  if (!Number.isInteger(iterations) || iterations < 1 || iterations > 5000) throw new RangeError("Iterations must be from 1 to 5,000.");
  if (parameters.length < 1 || parameters.length > 2) throw new Error("This optimizer supports one or two variational parameters.");
  let current = [...parameters]; let energy = estimateEnergy(current, hamiltonian); const history: VariationalPoint[] = [];
  let converged = false;
  for (let iteration = 0; iteration < iterations; iteration += 1) {
    const gradient = parameterShiftGradient(current, hamiltonian);
    const gradientNorm = Math.sqrt(gradient.reduce((sum, value) => sum + value * value, 0));
    history.push({ iteration, parameters: [...current], energy, gradientNorm });
    if (gradientNorm <= tolerance) { converged = true; break; }
    const candidate = current.map((value, index) => value - learningRate * gradient[index]);
    const candidateEnergy = estimateEnergy(candidate, hamiltonian);
    // Small deterministic backtracking keeps simple educational runs stable.
    if (candidateEnergy <= energy) { current = candidate; energy = candidateEnergy; }
    else {
      const halfStep = current.map((value, index) => value - learningRate * 0.25 * gradient[index]);
      const halfEnergy = estimateEnergy(halfStep, hamiltonian);
      if (halfEnergy < energy) { current = halfStep; energy = halfEnergy; }
      else if (gradientNorm <= tolerance * 10) { converged = true; break; }
    }
  }
  return { bestParameters: current, bestEnergy: energy, history, converged };
}
export function transverseFieldHamiltonian(x = 1, z = 0.5): PauliTerm[] {
  return [{ coefficient: x, paulis: "X" }, { coefficient: z, paulis: "Z" }];
}
export function analyticOneQubitGroundEnergy(coefficients: { x: number; y?: number; z: number }): number {
  const y = coefficients.y ?? 0;
  return -Math.sqrt(coefficients.x ** 2 + y ** 2 + coefficients.z ** 2);
}
