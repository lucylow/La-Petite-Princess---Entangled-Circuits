// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import type { CircuitDefinition, CircuitOperation, PauliTerm } from "./types";
import { cloneCircuit } from "./circuit";
import { expectHamiltonian } from "./observables";
import { simulateCircuit } from "./simulator";

export interface GradientEstimate { operationId: string; parameter: "theta" | "phi" | "lambda"; value: number; method: "parameter-shift" | "finite-difference"; }
export function circuitEnergy(circuit: CircuitDefinition, hamiltonian: PauliTerm[]): number {
  if (circuit.operations.some((operation) => operation.gate === "MEASURE")) throw new Error("Energy gradients require a unitary ansatz without measurement directives.");
  return expectHamiltonian(simulateCircuit(circuit).state, circuit.qubitCount, hamiltonian).total;
}
export function parameterShiftGradient(circuit: CircuitDefinition, operationId: string, hamiltonian: PauliTerm[], parameter: "theta" | "phi" | "lambda" = "theta"): GradientEstimate {
  const operation = circuit.operations.find((item) => item.id === operationId);
  if (!operation) throw new Error(`Operation ${operationId} was not found.`);
  if (!["RX", "RY", "RZ"].includes(operation.gate) || parameter !== "theta") throw new Error("The two-point parameter-shift rule is implemented for RX, RY and RZ theta parameters.");
  const shift = Math.PI / 2;
  const evaluate = (delta: number) => {
    const copy = cloneCircuit(circuit);
    copy.operations = copy.operations.map((item) => item.id === operationId ? { ...item, params: { ...item.params, theta: (item.params?.theta ?? 0) + delta } } : item);
    return circuitEnergy(copy, hamiltonian);
  };
  return { operationId, parameter, value: (evaluate(shift) - evaluate(-shift)) / 2, method: "parameter-shift" };
}
export function finiteDifferenceGradient(circuit: CircuitDefinition, operationId: string, hamiltonian: PauliTerm[], parameter: "theta" | "phi" | "lambda" = "theta", epsilon = 1e-5): GradientEstimate {
  if (!Number.isFinite(epsilon) || epsilon <= 0) throw new RangeError("Finite-difference step must be positive.");
  if (!circuit.operations.some((item) => item.id === operationId)) throw new Error(`Operation ${operationId} was not found.`);
  const evaluate = (delta: number) => {
    const copy = cloneCircuit(circuit);
    copy.operations = copy.operations.map((item) => item.id === operationId ? { ...item, params: { ...item.params, [parameter]: (item.params?.[parameter] ?? 0) + delta } } : item);
    return circuitEnergy(copy, hamiltonian);
  };
  return { operationId, parameter, value: (evaluate(epsilon) - evaluate(-epsilon)) / (2 * epsilon), method: "finite-difference" };
}
export function gradientForOperations(circuit: CircuitDefinition, operationIds: string[], hamiltonian: PauliTerm[]): GradientEstimate[] {
  return operationIds.map((operationId) => parameterShiftGradient(circuit, operationId, hamiltonian));
}
