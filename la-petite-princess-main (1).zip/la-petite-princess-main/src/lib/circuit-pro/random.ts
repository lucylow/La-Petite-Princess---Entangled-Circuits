// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
/** Deterministic 32-bit Mulberry32 generator; use only for reproducible demos/tests. */
export function createSeededRandom(seed: number): () => number {
  let state = seed >>> 0;
  return () => {
    state += 0x6D2B79F5;
    let value = state;
    value = Math.imul(value ^ (value >>> 15), value | 1);
    value ^= value + Math.imul(value ^ (value >>> 7), value | 61);
    return ((value ^ (value >>> 14)) >>> 0) / 4_294_967_296;
  };
}
export function resolveRandom(seed?: number): () => number { return seed === undefined ? Math.random : createSeededRandom(seed); }
export function clampProbability(value: number, name = "probability"): number {
  if (!Number.isFinite(value) || value < 0 || value > 1) throw new RangeError(`${name} must be between 0 and 1.`);
  return value;
}
