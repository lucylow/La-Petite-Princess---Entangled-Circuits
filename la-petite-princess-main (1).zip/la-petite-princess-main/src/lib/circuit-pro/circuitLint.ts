// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import type { CircuitDefinition, CircuitOperation, CircuitValidationIssue } from "./types";
import { validateCircuit } from "./circuit";
import { circuitMetrics } from "./metrics";

export interface LintRule { code: string; title: string; description: string; severity: "error" | "warning" | "info"; }
export type CircuitLintIssue = Omit<CircuitValidationIssue, "severity"> & { severity: "error" | "warning" | "info"; suggestion?: string };
export interface CircuitLintReport { issues: CircuitLintIssue[]; score: number; passed: boolean; summary: string; }
export const CIRCUIT_LINT_RULES: LintRule[] = [
  { code: "MEASURED_EARLY", title: "Measurement before final unitary layer", description: "Measurements collapse quantum state and prevent later coherent processing on that wire.", severity: "warning" },
  { code: "UNUSED_QUBIT", title: "Unused register wire", description: "A declared qubit is never acted on or measured.", severity: "info" },
  { code: "BARRIER_REDUNDANT", title: "Redundant barrier", description: "Adjacent barriers do not change ideal circuit semantics.", severity: "info" },
  { code: "IDENTITY_GATE", title: "Identity operation", description: "Identity gates are usually unnecessary unless they mark a teaching or timing location.", severity: "info" },
  { code: "ROTATION_ZERO", title: "Zero-angle rotation", description: "A rotation by a multiple of 2π may be reducible to identity up to global phase.", severity: "info" },
  { code: "REPEATED_H", title: "Adjacent Hadamards", description: "H followed by H on the same qubit cancels exactly.", severity: "info" },
  { code: "DENSE_DENSITY", title: "Density-matrix memory warning", description: "Density-matrix memory grows as 4^n.", severity: "warning" },
  { code: "HIGH_DEPTH", title: "Deep circuit", description: "Deep circuits are more sensitive to noise and execution cost.", severity: "warning" },
];
function issue(code: string, title: string, severity: CircuitLintIssue["severity"], message: string, operation?: CircuitOperation, index?: number, suggestion?: string) {
  return { code, severity, message: `${title}: ${message}`, ...(operation ? { operationId: operation.id, operationIndex: index } : {}), ...(suggestion ? { suggestion } : {}) };
}
export function lintCircuit(circuit: CircuitDefinition): CircuitLintReport {
  const issues: CircuitLintReport["issues"] = validateCircuit(circuit).map((item) => ({ ...item }));
  const metrics = circuitMetrics(circuit); const touched = new Set<number>();
  circuit.operations.forEach((operation, index) => {
    [...operation.targets, ...(operation.controls ?? [])].forEach((q) => touched.add(q));
    if (operation.gate === "I") issues.push(issue("IDENTITY_GATE", "Identity operation", "info", "This operation has no observable effect.", operation, index, "Remove it, or retain it with a note if it is pedagogically meaningful."));
    if (["RX", "RY", "RZ", "CRX", "CRY", "CRZ", "CP"].includes(operation.gate) && Math.abs((operation.params?.theta ?? 0) % (2 * Math.PI)) < 1e-12) issues.push(issue("ROTATION_ZERO", "Zero-angle rotation", "info", "The angle is a multiple of 2π.", operation, index, "Remove the operation when global phase is irrelevant."));
    if (operation.gate === "MEASURE" && circuit.operations.slice(index + 1).some((later) => later.targets.includes(operation.targets[0]) || later.controls?.includes(operation.targets[0]))) issues.push(issue("MEASURED_EARLY", "Measurement before final unitary layer", "warning", `Q${operation.targets[0] + 1} is used after measurement.`, operation, index, "Move measurement to the end, or use a dynamic circuit when classical feed-forward is intended."));
    const previous = circuit.operations[index - 1];
    if (previous?.gate === operation.gate && operation.gate === "H" && previous.targets[0] === operation.targets[0]) issues.push(issue("REPEATED_H", "Adjacent Hadamards", "info", "Two adjacent Hadamards on the same wire cancel.", operation, index, "Remove both operations."));
    if (previous?.gate === "BARRIER" && operation.gate === "BARRIER") issues.push(issue("BARRIER_REDUNDANT", "Redundant barrier", "info", "Two consecutive barriers can be merged.", operation, index, "Keep only one barrier on the union of affected wires."));
  });
  for (let q = 0; q < circuit.qubitCount; q += 1) if (!touched.has(q)) issues.push(issue("UNUSED_QUBIT", "Unused register wire", "info", `Q${q + 1} has no operations.`, undefined, undefined, "Reduce the register or add the intended experiment."));
  if (metrics.depth > 100) issues.push(issue("HIGH_DEPTH", "Deep circuit", "warning", `Estimated depth is ${metrics.depth}.`, undefined, undefined, "Try commuting-gate scheduling or optimize repeated rotations."));
  const densityBytes = 16 * (4 ** circuit.qubitCount);
  if (densityBytes > 256 * 1024 * 1024) issues.push(issue("DENSE_DENSITY", "Density-matrix memory warning", "warning", `A complex density matrix may need roughly ${(densityBytes / 1024 ** 2).toFixed(0)} MiB.`, undefined, undefined, "Use state-vector simulation where the state is pure."));
  const errors = issues.filter((item) => item.severity === "error").length;
  const warnings = issues.filter((item) => item.severity === "warning").length;
  const score = Math.max(0, Math.round(100 - errors * 25 - warnings * 8 - issues.filter((item) => item.severity === "info").length * 1.5));
  return { issues, score, passed: errors === 0, summary: errors ? `${errors} error(s), ${warnings} warning(s)` : warnings ? `Valid with ${warnings} warning(s)` : "No structural issues detected" };
}
export function lintRuleByCode(code: string): LintRule | undefined { return CIRCUIT_LINT_RULES.find((rule) => rule.code === code); }
export function formatLintReport(report: CircuitLintReport): string {
  const lines = [`Circuit lint score: ${report.score}/100`, report.summary, ""];
  report.issues.forEach((item) => { lines.push(`[${item.severity.toUpperCase()}] ${item.code}: ${item.message}`); if (item.suggestion) lines.push(`  Suggestion: ${item.suggestion}`); });
  return lines.join("\n");
}
