// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import type { CircuitDefinition, CircuitOperation, PauliTerm } from "./types";
import { createCircuit, createOperation } from "./circuit";
import { simulateCircuit } from "./simulator";
import { expectHamiltonian } from "./observables";

export interface TrotterOptions { time: number; steps?: number; order?: 1 | 2; }
export interface EvolutionReport { circuit: CircuitDefinition; time: number; steps: number; order: 1 | 2; energyBefore: number; energyAfter: number; energyDrift: number; }
function validateTerms(terms: PauliTerm[], qubitCount: number): void {
  if (!terms.length) throw new Error("Hamiltonian must contain at least one Pauli term.");
  for (const term of terms) {
    if (term.paulis.length !== qubitCount || /[^IXYZ]/.test(term.paulis)) throw new Error(`Pauli term ${term.paulis} must have ${qubitCount} characters from I, X, Y, Z.`);
    if (!Number.isFinite(term.coefficient)) throw new Error("Hamiltonian coefficients must be finite.");
  }
}
function appendPauliEvolution(operations: CircuitOperation[], paulis: string, angle: number, prefix: string): void {
  const active = Array.from({ length: paulis.length }, (_, q) => ({ q, pauli: paulis[paulis.length - 1 - q] })).filter((entry) => entry.pauli !== "I");
  if (!active.length || Math.abs(angle) < 1e-15) return;
  const pivot = active[active.length - 1].q;
  for (const { q, pauli } of active) {
    if (pauli === "X") operations.push(createOperation("H", q, [], undefined, `${prefix}: X-to-Z basis`));
    if (pauli === "Y") { operations.push(createOperation("SDG", q, [], undefined, `${prefix}: Y-to-Z basis`)); operations.push(createOperation("H", q)); }
  }
  for (const { q } of active) if (q !== pivot) operations.push(createOperation("CX", pivot, [q], undefined, `${prefix}: parity compute`));
  operations.push(createOperation("RZ", pivot, [], { theta: 2 * angle }, `${prefix}: exp(-i angle P)`));
  for (const { q } of [...active].reverse()) if (q !== pivot) operations.push(createOperation("CX", pivot, [q], undefined, `${prefix}: parity uncompute`));
  for (const { q, pauli } of [...active].reverse()) {
    if (pauli === "X") operations.push(createOperation("H", q));
    if (pauli === "Y") { operations.push(createOperation("H", q)); operations.push(createOperation("S", q)); }
  }
}
function appendFirstOrder(operations: CircuitOperation[], terms: PauliTerm[], coefficient: number, prefix: string): void {
  terms.forEach((term, index) => appendPauliEvolution(operations, term.paulis, term.coefficient * coefficient, `${prefix} term ${index + 1}`));
}
/** Builds a product-formula approximation to exp(-i H t). Pauli strings use display order. */
export function trotterizeHamiltonian(terms: PauliTerm[], qubitCount: number, options: TrotterOptions): CircuitDefinition {
  validateTerms(terms, qubitCount);
  const steps = options.steps ?? 1; const order = options.order ?? 1;
  if (!Number.isFinite(options.time) || !Number.isInteger(steps) || steps < 1 || steps > 10_000) throw new RangeError("Time must be finite and steps must be 1..10000.");
  const operations: CircuitOperation[] = [];
  for (let step = 0; step < steps; step += 1) {
    if (order === 1) appendFirstOrder(operations, terms, options.time / steps, `Trotter ${step + 1}`);
    else {
      appendFirstOrder(operations, terms, options.time / (2 * steps), `Trotter ${step + 1} forward`);
      appendFirstOrder(operations, [...terms].reverse(), options.time / (2 * steps), `Trotter ${step + 1} reverse`);
    }
  }
  const circuit = createCircuit(`Hamiltonian evolution · order ${order}`, qubitCount, qubitCount, operations);
  circuit.description = `Approximate exp(−iHt), t=${options.time}, steps=${steps}, product-formula order=${order}.`;
  return circuit;
}
export function evolveAndMeasureEnergy(initialCircuit: CircuitDefinition, hamiltonian: PauliTerm[], options: TrotterOptions): EvolutionReport {
  if (initialCircuit.operations.some((operation) => operation.gate === "MEASURE")) throw new Error("Initial state preparation cannot contain measurements for this report.");
  const evolution = trotterizeHamiltonian(hamiltonian, initialCircuit.qubitCount, options);
  const combined = createCircuit(`${initialCircuit.name} + evolution`, initialCircuit.qubitCount, initialCircuit.classicalBitCount, [...initialCircuit.operations, ...evolution.operations]);
  const initialState = simulateCircuit(initialCircuit).state;
  const finalState = simulateCircuit(combined).state;
  const before = expectHamiltonian(initialState, initialCircuit.qubitCount, hamiltonian).total;
  const after = expectHamiltonian(finalState, initialCircuit.qubitCount, hamiltonian).total;
  return { circuit: combined, time: options.time, steps: options.steps ?? 1, order: options.order ?? 1, energyBefore: before, energyAfter: after, energyDrift: after - before };
}
export function identityTerm(qubitCount: number, coefficient: number): PauliTerm { return { paulis: "I".repeat(qubitCount), coefficient }; }
