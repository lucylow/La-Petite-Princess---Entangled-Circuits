// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import type { Complex } from "../advanced/complex";

/** Circuit Pro domain model. Qubit zero is the least-significant bit. */
export type SingleQubitGate =
  | "I" | "X" | "Y" | "Z" | "H" | "S" | "SDG" | "T" | "TDG"
  | "SX" | "SXDG" | "RX" | "RY" | "RZ" | "U3";
export type ControlledGate = "CX" | "CY" | "CZ" | "CH" | "CP" | "CRX" | "CRY" | "CRZ";
export type MultiQubitGate = "SWAP" | "ISWAP" | "CCX" | "CSWAP";
export type CircuitDirective = "BARRIER" | "MEASURE";
export type GateName = SingleQubitGate | ControlledGate | MultiQubitGate | CircuitDirective;

export interface OperationParameters { theta?: number; phi?: number; lambda?: number; }
export interface CircuitOperation {
  id: string;
  gate: GateName;
  targets: number[];
  controls?: number[];
  params?: OperationParameters;
  note?: string;
  classicalBit?: number;
}
export interface CircuitDefinition {
  id: string;
  name: string;
  qubitCount: number;
  classicalBitCount: number;
  operations: CircuitOperation[];
  description?: string;
  version: 1;
}
export interface CircuitValidationIssue {
  severity: "error" | "warning";
  code: string;
  message: string;
  operationId?: string;
  operationIndex?: number;
}
export interface SimulationOptions { maxQubits?: number; normalizeInput?: boolean; throwOnInvalid?: boolean; }
export interface MeasurementRecord {
  qubit: number; classicalBit: number; outcome: 0 | 1;
  probabilityZero: number; probabilityOne: number; operationId: string;
}
export interface SimulationResult {
  state: Complex[]; qubitCount: number; classicalBits: number[];
  measurements: MeasurementRecord[]; operationCount: number; elapsedMs: number; normalized: boolean;
}
export interface ShotResult {
  shots: number; counts: Record<string, number>; frequencies: Record<string, number>;
  idealProbabilities: Record<string, number>; seed?: number;
}
export interface CircuitMetrics {
  qubitCount: number; operationCount: number; singleQubitGateCount: number;
  twoQubitGateCount: number; multiQubitGateCount: number; measurementCount: number;
  barrierCount: number; entanglingGateCount: number; depth: number;
  criticalPath: string[]; gateCounts: Record<string, number>;
}
export interface ComplexMatrix { rows: number; cols: number; data: Complex[][]; }
export interface DensityMatrixResult {
  matrix: ComplexMatrix; purity: number; trace: number; vonNeumannEntropy: number;
}
export interface PauliTerm { coefficient: number; paulis: string; }
export interface PauliExpectation {
  paulis: string; expectation: number; coefficient: number; contribution: number;
}
export interface NoiseParameters {
  depolarizing?: number; amplitudeDamping?: number; phaseDamping?: number;
  readoutFlip?: number; afterEachGate?: boolean;
}
export interface CircuitRunOptions { shots?: number; seed?: number; noise?: NoiseParameters; measureAll?: boolean; }
export interface CircuitRunReport {
  circuit: CircuitDefinition; metrics: CircuitMetrics; idealState: Complex[];
  idealProbabilities: Record<string, number>; shots?: ShotResult; warnings: string[];
}
export interface CircuitPreset {
  id: string; title: string; subtitle: string;
  level: "introductory" | "intermediate" | "advanced";
  qubitCount: number; circuit: CircuitDefinition; learningObjectives: string[];
}
export const DEFAULT_MAX_QUBITS = 10;
export const MAX_DENSITY_QUBITS = 5;
export const MAX_SHOTS = 100_000;
export const NUMERICAL_EPSILON = 1e-10;
