// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { cMagnitudeSquared, complex, type Complex } from "../advanced/complex";
import type { ComplexMatrix } from "./types";
import { measureInBasis } from "./measurement";
import { resolveRandom } from "./random";
import { zeros } from "./matrix";
import { densityFromState, reducedDensityMatrix } from "./density";

export interface TomographyAxisResult { axis: "X" | "Y" | "Z"; shots: number; zeroCount: number; oneCount: number; expectation: number; }
export interface SingleQubitTomographyResult {
  qubit: number; axes: TomographyAxisResult[]; bloch: { x: number; y: number; z: number };
  reconstructedDensity: ComplexMatrix; purity: number; entropyBits: number;
}
export function reconstructSingleQubitDensity(bloch: { x: number; y: number; z: number }): ComplexMatrix {
  const { x, y, z } = bloch;
  if ([x, y, z].some((value) => !Number.isFinite(value) || Math.abs(value) > 1 + 1e-8)) throw new Error("Bloch components must be finite and within the physical unit ball.");
  const matrix = zeros(2, 2);
  matrix.data[0][0] = complex((1 + z) / 2);
  matrix.data[1][1] = complex((1 - z) / 2);
  matrix.data[0][1] = complex(x / 2, -y / 2);
  matrix.data[1][0] = complex(x / 2, y / 2);
  return matrix;
}
export function runSingleQubitTomography(state: Complex[], qubitCount: number, qubit: number, shotsPerAxis = 1000, seed?: number): SingleQubitTomographyResult {
  if (!Number.isInteger(shotsPerAxis) || shotsPerAxis < 1 || shotsPerAxis > 100_000) throw new RangeError("Tomography shots must be between 1 and 100,000 per axis.");
  if (!Number.isInteger(qubit) || qubit < 0 || qubit >= qubitCount) throw new RangeError("Tomography target is outside the register.");
  const baseRng = resolveRandom(seed); const axes: TomographyAxisResult[] = [];
  for (const axis of ["X", "Y", "Z"] as const) {
    const rng = () => baseRng(); let zeroCount = 0; let oneCount = 0;
    for (let shot = 0; shot < shotsPerAxis; shot += 1) {
      const result = measureInBasis(state, qubitCount, qubit, axis, rng);
      if (result.outcome === 0) zeroCount += 1; else oneCount += 1;
    }
    axes.push({ axis, shots: shotsPerAxis, zeroCount, oneCount, expectation: (zeroCount - oneCount) / shotsPerAxis });
  }
  const bloch = { x: axes[0].expectation, y: axes[1].expectation, z: axes[2].expectation };
  const reconstructedDensity = reconstructSingleQubitDensity(bloch);
  const purity = (1 + bloch.x ** 2 + bloch.y ** 2 + bloch.z ** 2) / 2;
  const radius = Math.sqrt(bloch.x ** 2 + bloch.y ** 2 + bloch.z ** 2);
  const eigenvalues = [(1 + Math.min(1, radius)) / 2, (1 - Math.min(1, radius)) / 2];
  const entropyBits = eigenvalues.reduce((sum, value) => value < 1e-14 ? sum : sum - value * Math.log2(value), 0);
  return { qubit, axes, bloch, reconstructedDensity, purity, entropyBits };
}
export function tomographyFidelity(estimate: ComplexMatrix, idealState: Complex[]): number {
  const ideal = densityFromState(idealState);
  if (estimate.rows !== ideal.rows || estimate.cols !== ideal.cols) throw new Error("Tomography and reference dimensions do not match.");
  let fidelity = 0;
  for (let row = 0; row < estimate.rows; row += 1) for (let col = 0; col < estimate.cols; col += 1) fidelity += estimate.data[row][col].re * ideal.data[col][row].re - estimate.data[row][col].im * ideal.data[col][row].im;
  return Math.max(0, Math.min(1, fidelity));
}
export function tomographyError(estimate: ComplexMatrix, reference: ComplexMatrix): number {
  if (estimate.rows !== reference.rows || estimate.cols !== reference.cols) throw new Error("Matrix dimensions must match.");
  let sum = 0;
  for (let r = 0; r < estimate.rows; r += 1) for (let c = 0; c < estimate.cols; c += 1) {
    const deltaReal = estimate.data[r][c].re - reference.data[r][c].re;
    const deltaImag = estimate.data[r][c].im - reference.data[r][c].im;
    sum += deltaReal * deltaReal + deltaImag * deltaImag;
  }
  return Math.sqrt(sum);
}
export function compareTomographyToIdeal(state: Complex[], qubitCount: number, qubit: number, result: SingleQubitTomographyResult): number {
  const ideal = reducedDensityMatrix(state, qubitCount, [qubit]);
  return tomographyError(result.reconstructedDensity, ideal);
}
export function tomographyPurityFromMatrix(matrix: ComplexMatrix): number {
  let purity = 0;
  for (let r = 0; r < matrix.rows; r += 1) for (let c = 0; c < matrix.cols; c += 1) purity += cMagnitudeSquared(matrix.data[r][c]);
  return purity;
}
