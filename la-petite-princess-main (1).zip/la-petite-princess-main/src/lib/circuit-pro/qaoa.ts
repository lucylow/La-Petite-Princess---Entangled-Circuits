// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { cAdd, cConjugate, cMagnitudeSquared, cMul, complex, type Complex } from "../advanced/complex";
import { createCircuit, createOperation } from "./circuit";
import { expectPauli } from "./observables";
import { probabilities } from "./statevector";
import type { CircuitDefinition, CircuitOperation } from "./types";

export interface GraphEdge { a: number; b: number; weight?: number; }
export interface WeightedGraph { vertexCount: number; edges: GraphEdge[]; }
export interface QaoaParameters { gammas: number[]; betas: number[]; }
export interface QaoaEvaluation { expectedCut: number; expectedEnergy: number; bitstringScores: Record<string, number>; }
export function validateGraph(graph: WeightedGraph): string[] {
  const errors: string[] = [];
  if (!Number.isInteger(graph.vertexCount) || graph.vertexCount < 2 || graph.vertexCount > 10) errors.push("Graph vertexCount must be an integer from 2 to 10.");
  graph.edges.forEach((edge, index) => {
    if (!Number.isInteger(edge.a) || !Number.isInteger(edge.b) || edge.a < 0 || edge.b < 0 || edge.a >= graph.vertexCount || edge.b >= graph.vertexCount) errors.push(`Edge ${index + 1} has an invalid vertex.`);
    if (edge.a === edge.b) errors.push(`Edge ${index + 1} cannot connect a vertex to itself.`);
    if (edge.weight !== undefined && !Number.isFinite(edge.weight)) errors.push(`Edge ${index + 1} weight must be finite.`);
  });
  return errors;
}
export function qaoaMaxCutCircuit(graph: WeightedGraph, parameters: QaoaParameters): CircuitDefinition {
  const errors = validateGraph(graph);
  if (errors.length) throw new Error(errors.join(" "));
  if (!parameters.gammas.length || parameters.gammas.length !== parameters.betas.length) throw new Error("QAOA needs equally sized, non-empty gamma and beta arrays.");
  if ([...parameters.gammas, ...parameters.betas].some((value) => !Number.isFinite(value))) throw new Error("QAOA angles must be finite.");
  const operations: CircuitOperation[] = [];
  for (let q = 0; q < graph.vertexCount; q += 1) operations.push(createOperation("H", q));
  parameters.gammas.forEach((gamma, layer) => {
    graph.edges.forEach((edge) => {
      const weight = edge.weight ?? 1;
      // CX-RZ(-2γw)-CX implements exp(+iγw ZZ), equivalent up to a global phase to the MaxCut cost unitary.
      operations.push(createOperation("CX", edge.b, [edge.a]));
      operations.push(createOperation("RZ", edge.b, [], { theta: -2 * gamma * weight }));
      operations.push(createOperation("CX", edge.b, [edge.a]));
    });
    for (let q = 0; q < graph.vertexCount; q += 1) operations.push(createOperation("RX", q, [], { theta: 2 * parameters.betas[layer] }));
  });
  return { ...createCircuit(`QAOA MaxCut · p=${parameters.gammas.length}`, graph.vertexCount), operations, description: "A parameterized Quantum Approximate Optimization Algorithm ansatz for weighted MaxCut." };
}
export function cutValue(bitstring: string, graph: WeightedGraph): number {
  if (bitstring.length !== graph.vertexCount || /[^01]/.test(bitstring)) throw new Error("Bitstring length must match graph vertex count.");
  return graph.edges.reduce((sum, edge) => sum + (bitstring[graph.vertexCount - edge.a - 1] !== bitstring[graph.vertexCount - edge.b - 1] ? edge.weight ?? 1 : 0), 0);
}
export function evaluateQaoaState(state: Complex[], graph: WeightedGraph): QaoaEvaluation {
  if (state.length !== 2 ** graph.vertexCount) throw new Error("State dimension does not match graph vertex count.");
  const distribution = probabilities(state); const bitstringScores: Record<string, number> = {};
  let expectedCut = 0;
  distribution.forEach((probability, index) => {
    const label = index.toString(2).padStart(graph.vertexCount, "0");
    const score = cutValue(label, graph); bitstringScores[label] = score; expectedCut += probability * score;
  });
  return { expectedCut, expectedEnergy: -expectedCut, bitstringScores };
}
export function bruteForceMaxCut(graph: WeightedGraph): { bestValue: number; bitstrings: string[] } {
  const errors = validateGraph(graph); if (errors.length) throw new Error(errors.join(" "));
  let bestValue = -Infinity; const bitstrings: string[] = [];
  for (let index = 0; index < 2 ** graph.vertexCount; index += 1) {
    const label = index.toString(2).padStart(graph.vertexCount, "0"); const value = cutValue(label, graph);
    if (value > bestValue + 1e-10) { bestValue = value; bitstrings.splice(0, bitstrings.length, label); }
    else if (Math.abs(value - bestValue) <= 1e-10) bitstrings.push(label);
  }
  return { bestValue, bitstrings };
}
export function cycleGraph(vertexCount: number): WeightedGraph {
  if (!Number.isInteger(vertexCount) || vertexCount < 3 || vertexCount > 10) throw new RangeError("Cycle graph requires 3–10 vertices.");
  return { vertexCount, edges: Array.from({ length: vertexCount }, (_, index) => ({ a: index, b: (index + 1) % vertexCount, weight: 1 })) };
}
export function triangleGraph(): WeightedGraph { return { vertexCount: 3, edges: [{ a: 0, b: 1 }, { a: 1, b: 2 }, { a: 2, b: 0 }] }; }
