// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { cAdd, cConjugate, cMul, complex } from "../advanced/complex";
import type { Complex } from "../advanced/complex";
import type { ComplexMatrix, PauliTerm } from "./types";
import { zeros, isHermitian } from "./matrix";
import { applyPauliString } from "./observables";
import { hermitianEigenvalues } from "./density";

export function validateHamiltonian(terms: PauliTerm[], qubitCount: number): string[] {
  const errors: string[] = [];
  if (!terms.length) errors.push("Hamiltonian must contain at least one Pauli term.");
  terms.forEach((term, index) => {
    if (!Number.isFinite(term.coefficient)) errors.push(`Term ${index + 1} has a non-finite coefficient.`);
    if (term.paulis.length !== qubitCount || /[^IXYZ]/.test(term.paulis)) errors.push(`Term ${index + 1} must be a ${qubitCount}-character Pauli string.`);
  });
  return errors;
}
export function hamiltonianMatrix(terms: PauliTerm[], qubitCount: number, maximumQubits = 5): ComplexMatrix {
  if (!Number.isInteger(qubitCount) || qubitCount < 1 || qubitCount > maximumQubits) throw new RangeError(`Dense Hamiltonian matrix supports 1–${maximumQubits} qubits.`);
  const errors = validateHamiltonian(terms, qubitCount); if (errors.length) throw new Error(errors.join(" "));
  const dimension = 2 ** qubitCount; const result = zeros(dimension, dimension);
  for (let column = 0; column < dimension; column += 1) {
    const basis: Complex[] = Array.from({ length: dimension }, (_, row) => row === column ? complex(1) : complex());
    for (const term of terms) {
      const transformed = applyPauliString(basis, qubitCount, term.paulis);
      for (let row = 0; row < dimension; row += 1) result.data[row][column] = cAdd(result.data[row][column], complex(term.coefficient * transformed[row].re, term.coefficient * transformed[row].im));
    }
  }
  if (!isHermitian(result)) throw new Error("Pauli Hamiltonian matrix failed its Hermiticity check.");
  return result;
}
export function exactGroundEnergy(terms: PauliTerm[], qubitCount: number): number {
  const matrix = hamiltonianMatrix(terms, qubitCount);
  return hermitianEigenvalues(matrix)[hermitianEigenvalues(matrix).length - 1];
}
export function hamiltonianPauliString(operators: string[]): string {
  if (!operators.length || operators.some((operator) => !["I", "X", "Y", "Z"].includes(operator))) throw new Error("Hamiltonian Pauli factors must be I, X, Y or Z.");
  return operators.join("");
}
export function combineLikePauliTerms(terms: PauliTerm[], qubitCount: number, tolerance = 1e-12): PauliTerm[] {
  const errors = validateHamiltonian(terms, qubitCount); if (errors.length) throw new Error(errors.join(" "));
  const sums = new Map<string, number>();
  terms.forEach((term) => sums.set(term.paulis, (sums.get(term.paulis) ?? 0) + term.coefficient));
  return [...sums.entries()].filter(([, coefficient]) => Math.abs(coefficient) > tolerance).map(([paulis, coefficient]) => ({ paulis, coefficient }));
}
export function energyVariance(terms: PauliTerm[], state: Complex[], qubitCount: number): number {
  const matrix = hamiltonianMatrix(terms, qubitCount); const dimension = state.length;
  const apply = (vector: Complex[]) => matrix.data.map((row) => row.reduce((sum, value, column) => cAdd(sum, cMul(value, vector[column])), complex()));
  const hPsi = apply(state); const mean = state.reduce((sum, amplitude, index) => cAdd(sum, cMul(cConjugate(amplitude), hPsi[index])), complex()).re;
  const hSquaredPsi = apply(hPsi); const secondMoment = state.reduce((sum, amplitude, index) => cAdd(sum, cMul(cConjugate(amplitude), hSquaredPsi[index])), complex()).re;
  if (dimension !== matrix.rows) throw new Error("State dimension does not match Hamiltonian.");
  return Math.max(0, secondMoment - mean * mean);
}
