// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import type { ShotResult } from "./types";
import { estimateBernoulli, histogramFromShots } from "./statistics";

export interface ParityResult { parity: 0 | 1; evenCount: number; oddCount: number; evenProbability: number; oddProbability: number; }
export interface MarginalDistribution { qubit: number; probabilityZero: number; probabilityOne: number; countsZero?: number; countsOne?: number; }
export interface CorrelationResult { qubitA: number; qubitB: number; correlation: number; sameProbability: number; differentProbability: number; }
export function parityFromBitstring(bitstring: string): 0 | 1 {
  if (!/^[01]+$/.test(bitstring)) throw new Error("Parity requires a non-empty binary string.");
  let parity = 0; for (const bit of bitstring) parity ^= Number(bit); return parity as 0 | 1;
}
export function parityStatistics(counts: Record<string, number>): ParityResult {
  let evenCount = 0; let oddCount = 0;
  for (const [bitstring, count] of Object.entries(counts)) {
    if (!Number.isInteger(count) || count < 0) throw new Error("Counts must be non-negative integers.");
    if (parityFromBitstring(bitstring)) oddCount += count; else evenCount += count;
  }
  const total = evenCount + oddCount;
  if (!total) throw new Error("Parity statistics require at least one shot.");
  return { parity: oddCount > evenCount ? 1 : 0, evenCount, oddCount, evenProbability: evenCount / total, oddProbability: oddCount / total };
}
export function marginalFromCounts(counts: Record<string, number>, qubitCount: number): MarginalDistribution[] {
  if (!Number.isInteger(qubitCount) || qubitCount < 1) throw new RangeError("qubitCount must be positive.");
  const result = Array.from({ length: qubitCount }, (_, qubit) => ({ qubit, probabilityZero: 0, probabilityOne: 0, countsZero: 0, countsOne: 0 }));
  for (const [bitstring, count] of Object.entries(counts)) {
    if (bitstring.length !== qubitCount || !/^[01]+$/.test(bitstring) || !Number.isInteger(count) || count < 0) throw new Error("Invalid counts map for the specified qubit count.");
    for (let qubit = 0; qubit < qubitCount; qubit += 1) {
      const bit = Number(bitstring[qubitCount - qubit - 1]);
      if (bit) result[qubit].countsOne! += count; else result[qubit].countsZero! += count;
    }
  }
  const total = Object.values(counts).reduce((sum, value) => sum + value, 0);
  if (!total) throw new Error("Counts cannot be empty.");
  return result.map((item) => ({ ...item, probabilityZero: item.countsZero! / total, probabilityOne: item.countsOne! / total }));
}
export function pairCorrelation(counts: Record<string, number>, qubitA: number, qubitB: number): CorrelationResult {
  const keys = Object.keys(counts); if (!keys.length) throw new Error("No counts supplied.");
  const qubitCount = keys[0].length;
  if (qubitA === qubitB || [qubitA, qubitB].some((q) => !Number.isInteger(q) || q < 0 || q >= qubitCount)) throw new RangeError("Choose two different valid qubits.");
  let same = 0; let different = 0;
  for (const [bitstring, count] of Object.entries(counts)) {
    const a = bitstring[qubitCount - qubitA - 1]; const b = bitstring[qubitCount - qubitB - 1];
    if (a === b) same += count; else different += count;
  }
  const total = same + different;
  if (!total) throw new Error("No shots are present.");
  return { qubitA, qubitB, correlation: (same - different) / total, sameProbability: same / total, differentProbability: different / total };
}
export function summarizeShotResult(result: ShotResult) {
  const histogram = histogramFromShots(result);
  const total = histogram.reduce((sum, bin) => sum + bin.count, 0);
  const entropy = -histogram.filter((bin) => bin.frequency > 0).reduce((sum, bin) => sum + bin.frequency * Math.log2(bin.frequency), 0);
  const mode = [...histogram].sort((a, b) => b.count - a.count)[0];
  return { shots: result.shots, observedTotal: total, mode: mode?.label ?? "", modeCount: mode?.count ?? 0, entropyBits: entropy, distinctOutcomes: histogram.filter((bin) => bin.count > 0).length };
}
export function estimateOutcomeProbability(result: ShotResult, predicate: (bitstring: string) => boolean) {
  const successes = Object.entries(result.counts).reduce((sum, [bitstring, count]) => sum + (predicate(bitstring) ? count : 0), 0);
  return estimateBernoulli(successes, result.shots);
}
export function shotResultToCsv(result: ShotResult): string {
  const lines = ["bitstring,count,frequency,ideal_probability"];
  Object.keys(result.counts).sort().forEach((label) => lines.push([label, result.counts[label], (result.counts[label] / result.shots).toFixed(8), result.idealProbabilities[label] ?? ""].join(",")));
  return `${lines.join("\n")}\n`;
}
