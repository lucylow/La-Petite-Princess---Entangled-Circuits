// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { cAdd, cMagnitudeSquared, cMul, cScale, complex, type Complex } from "../advanced/complex";
import { createOperation, assertValidCircuit } from "./circuit";
import { singleQubitMatrix, applyGateOperation, type Matrix2 } from "./gates";
import { createSeededRandom, resolveRandom } from "./random";
import { createZeroState, probabilities } from "./statevector";
import type { CircuitDefinition, CircuitOperation, NoiseParameters, ShotResult } from "./types";

export interface KrausTrajectoryResult { state: Complex[]; selectedOperator: number; probability: number; }
export interface NoiseChannelDescription { id: string; label: string; parameter: string; interpretation: string; }
export const NOISE_CHANNELS: NoiseChannelDescription[] = [
  { id: "depolarizing", label: "Depolarizing", parameter: "p", interpretation: "Random Pauli disturbance with total probability p." },
  { id: "amplitudeDamping", label: "Amplitude damping", parameter: "γ", interpretation: "Models energy relaxation from |1⟩ toward |0⟩." },
  { id: "phaseDamping", label: "Phase damping", parameter: "λ", interpretation: "Reduces off-diagonal coherence without changing computational populations." },
  { id: "readoutFlip", label: "Readout bit flip", parameter: "r", interpretation: "Flips a reported classical measurement bit with probability r." },
];
function localApply(state: Complex[], qubitCount: number, target: number, matrix: Matrix2): Complex[] {
  if (!Number.isInteger(target) || target < 0 || target >= qubitCount) throw new RangeError("Noise target is outside the register.");
  const mask = 1 << target; const result = state.map((v) => complex(v.re, v.im));
  for (let index = 0; index < state.length; index += 1) {
    if (index & mask) continue;
    const partner = index | mask; const a = state[index]; const b = state[partner];
    result[index] = cAdd(cMul(matrix[0][0], a), cMul(matrix[0][1], b));
    result[partner] = cAdd(cMul(matrix[1][0], a), cMul(matrix[1][1], b));
  }
  return result;
}
export function applyKrausTrajectory(state: Complex[], qubitCount: number, target: number, kraus: Matrix2[], rng: () => number = Math.random): KrausTrajectoryResult {
  if (!kraus.length) throw new Error("A Kraus channel needs at least one operator.");
  const candidates = kraus.map((operator) => localApply(state, qubitCount, target, operator));
  const weights = candidates.map((candidate) => candidate.reduce((sum, value) => sum + cMagnitudeSquared(value), 0));
  const total = weights.reduce((sum, value) => sum + value, 0);
  if (Math.abs(total - 1) > 1e-7) throw new Error(`Kraus operators are not trace-preserving on this state (sum=${total}).`);
  const roll = rng() * total; let cumulative = 0; let selected = weights.length - 1;
  for (let index = 0; index < weights.length; index += 1) { cumulative += weights[index]; if (roll < cumulative) { selected = index; break; } }
  const probability = weights[selected];
  if (probability <= 1e-14) throw new Error("Selected Kraus trajectory has zero probability.");
  return { state: candidates[selected].map((value) => cScale(value, 1 / Math.sqrt(probability))), selectedOperator: selected, probability };
}
export function amplitudeDampingKraus(gamma: number): Matrix2[] {
  validateNoiseProbability(gamma, "gamma");
  return [
    [[complex(1), complex()], [complex(), complex(Math.sqrt(1 - gamma))]],
    [[complex(), complex(Math.sqrt(gamma))], [complex(), complex()]],
  ];
}
export function phaseDampingKraus(lambda: number): Matrix2[] {
  validateNoiseProbability(lambda, "lambda");
  return [
    [[complex(1), complex()], [complex(), complex(Math.sqrt(1 - lambda))]],
    [[complex(), complex()], [complex(), complex(Math.sqrt(lambda))]],
  ];
}
export function depolarizingPauli(state: Complex[], qubitCount: number, target: number, probability: number, rng: () => number = Math.random): Complex[] {
  validateNoiseProbability(probability, "depolarizing probability");
  if (rng() >= probability) return state.map((v) => complex(v.re, v.im));
  const choice = Math.floor(rng() * 3);
  return applyGateOperation(state, qubitCount, createOperation((["X", "Y", "Z"] as const)[choice], target));
}
export function applyNoiseToQubit(state: Complex[], qubitCount: number, target: number, noise: NoiseParameters, rng: () => number): Complex[] {
  let current = state;
  const depolarizing = noise.depolarizing ?? 0;
  const amplitude = noise.amplitudeDamping ?? 0;
  const phase = noise.phaseDamping ?? 0;
  if (depolarizing > 0) current = depolarizingPauli(current, qubitCount, target, depolarizing, rng);
  if (amplitude > 0) current = applyKrausTrajectory(current, qubitCount, target, amplitudeDampingKraus(amplitude), rng).state;
  if (phase > 0) current = applyKrausTrajectory(current, qubitCount, target, phaseDampingKraus(phase), rng).state;
  return current;
}
export function runNoisyShot(circuit: CircuitDefinition, noise: NoiseParameters, rng: () => number): { bitstring: string; finalState: Complex[] } {
  assertValidCircuit(circuit);
  let state = createZeroState(circuit.qubitCount);
  for (const operation of circuit.operations) {
    if (operation.gate === "BARRIER") continue;
    if (operation.gate === "MEASURE") {
      // Measurement operations are deferred to a final basis sample in this simple noise runner.
      continue;
    }
    state = applyGateOperation(state, circuit.qubitCount, operation);
    if (noise.afterEachGate !== false) {
      const touched = [...operation.targets, ...(operation.controls ?? [])];
      for (const qubit of new Set(touched)) state = applyNoiseToQubit(state, circuit.qubitCount, qubit, noise, rng);
    }
  }
  const distribution = probabilities(state); const roll = rng(); let cumulative = 0; let selected = distribution.length - 1;
  for (let index = 0; index < distribution.length; index += 1) { cumulative += distribution[index]; if (roll < cumulative) { selected = index; break; } }
  let bitstring = selected.toString(2).padStart(circuit.qubitCount, "0");
  const readoutFlip = noise.readoutFlip ?? 0; validateNoiseProbability(readoutFlip, "readoutFlip");
  if (readoutFlip > 0) bitstring = bitstring.split("").map((bit) => rng() < readoutFlip ? (bit === "0" ? "1" : "0") : bit).join("");
  return { bitstring, finalState: state };
}
export function runNoisyShots(circuit: CircuitDefinition, shots: number, noise: NoiseParameters, seed?: number): ShotResult {
  if (!Number.isInteger(shots) || shots < 1 || shots > 100_000) throw new RangeError("Shots must be between 1 and 100,000.");
  const rng = resolveRandom(seed); const counts: Record<string, number> = {};
  for (let i = 0; i < shots; i += 1) { const result = runNoisyShot(circuit, noise, rng); counts[result.bitstring] = (counts[result.bitstring] ?? 0) + 1; }
  const frequencies = Object.fromEntries(Object.entries(counts).map(([key, value]) => [key, value / shots]));
  return { shots, counts, frequencies, idealProbabilities: {}, seed };
}
export function validateNoise(noise: NoiseParameters): string[] {
  const errors: string[] = [];
  for (const [key, value] of Object.entries(noise)) if (typeof value === "number" && (!Number.isFinite(value) || value < 0 || value > 1)) errors.push(`${key} must be between 0 and 1.`);
  return errors;
}
function validateNoiseProbability(value: number, name: string): void {
  if (!Number.isFinite(value) || value < 0 || value > 1) throw new RangeError(`${name} must be between 0 and 1.`);
}
