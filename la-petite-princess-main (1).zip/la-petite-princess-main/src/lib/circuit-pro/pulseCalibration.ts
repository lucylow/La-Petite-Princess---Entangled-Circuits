// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { complex } from "../advanced/complex";
import { createOperation } from "./circuit";
import { simulateCircuit } from "./simulator";
import { samplePulse, evolveQubitWithPulse, type PulseSpec, type SampledPulse } from "./pulseControl";

export interface CalibrationPoint { control: number; measurement: number; shots?: number; standardError?: number; }
export interface RabiFit { angularFrequency: number; phase: number; offset: number; amplitude: number; rmse: number; period: number; }
export interface ExponentialFit { initial: number; decayTime: number; offset: number; rmse: number; rSquared: number; }
export interface RamseyResult { detuningRadPerNs: number; freeEvolutionNs: number; excitedProbability: number; contrast: number; }
export interface CalibrationReport { rabi: RabiFit; piAmplitude: number; piOverTwoAmplitude: number; points: CalibrationPoint[]; warnings: string[]; }
function validatePoints(points: CalibrationPoint[]): void {
  if (points.length < 4 || points.some((point) => !Number.isFinite(point.control) || !Number.isFinite(point.measurement))) throw new Error("Calibration requires at least four finite data points.");
}
function mean(values: number[]): number { return values.reduce((sum, value) => sum + value, 0) / values.length; }
function linearFit(x: number[], y: number[]): { slope: number; intercept: number; rSquared: number } {
  const xMean = mean(x); const yMean = mean(y); const denominator = x.reduce((sum, value) => sum + (value - xMean) ** 2, 0);
  if (denominator < 1e-14) throw new Error("Calibration x-values do not span a useful range.");
  const slope = x.reduce((sum, value, index) => sum + (value - xMean) * (y[index] - yMean), 0) / denominator; const intercept = yMean - slope * xMean;
  const residual = y.reduce((sum, value, index) => sum + (value - (slope * x[index] + intercept)) ** 2, 0); const total = y.reduce((sum, value) => sum + (value - yMean) ** 2, 0);
  return { slope, intercept, rSquared: total > 1e-14 ? 1 - residual / total : 1 };
}
/** Grid-search sinusoidal fit for a Rabi oscillation measurement curve. */
export function fitRabiOscillation(points: CalibrationPoint[], options: { minimumFrequency?: number; maximumFrequency?: number; frequencySteps?: number } = {}): RabiFit {
  validatePoints(points); const sorted = [...points].sort((a, b) => a.control - b.control); const x = sorted.map((point) => point.control); const y = sorted.map((point) => point.measurement);
  const min = options.minimumFrequency ?? 2 * Math.PI / (4 * (Math.max(...x) - Math.min(...x)));
  const max = options.maximumFrequency ?? 2 * Math.PI / Math.max(2 * (x[1] - x[0]), 1e-9);
  const steps = options.frequencySteps ?? 4000;
  if (!(min > 0) || !(max > min) || !Number.isInteger(steps) || steps < 10) throw new Error("Invalid Rabi frequency search range.");
  let best = { error: Infinity, frequency: min, phase: 0, offset: 0, amplitude: 0 };
  for (let index = 0; index <= steps; index += 1) {
    const frequency = min + (max - min) * index / steps;
    const c = x.map((value) => Math.cos(frequency * value)); const s = x.map((value) => Math.sin(frequency * value));
    const cc = c.reduce((sum, value) => sum + value * value, 0); const ss = s.reduce((sum, value) => sum + value * value, 0); const cs = c.reduce((sum, value, i) => sum + value * s[i], 0);
    const cy = c.reduce((sum, value, i) => sum + value * y[i], 0); const sy = s.reduce((sum, value, i) => sum + value * y[i], 0);
    const det = cc * ss - cs * cs; if (Math.abs(det) < 1e-14) continue;
    const a = (cy * ss - sy * cs) / det; const b = (sy * cc - cy * cs) / det; const offset = mean(y) - a * mean(c) - b * mean(s);
    const predictions = x.map((value) => offset + a * Math.cos(frequency * value) + b * Math.sin(frequency * value));
    const error = Math.sqrt(predictions.reduce((sum, value, i) => sum + (value - y[i]) ** 2, 0) / y.length);
    if (error < best.error) best = { error, frequency, phase: Math.atan2(-b, a), offset, amplitude: Math.hypot(a, b) };
  }
  return { angularFrequency: best.frequency, phase: best.phase, offset: best.offset, amplitude: best.amplitude, rmse: best.error, period: 2 * Math.PI / best.frequency };
}
export function fitExponentialDecay(points: CalibrationPoint[]): ExponentialFit {
  validatePoints(points);
  const sorted = [...points].sort((a, b) => a.control - b.control); const floor = Math.min(...sorted.map((point) => point.measurement));
  let best: ExponentialFit | null = null;
  const offsetCandidates = Array.from({ length: 40 }, (_, index) => floor - 0.02 + index * 0.001);
  for (const offset of offsetCandidates) {
    const valid = sorted.filter((point) => point.measurement - offset > 1e-9);
    if (valid.length < 4) continue;
    const fit = linearFit(valid.map((point) => point.control), valid.map((point) => Math.log(point.measurement - offset)));
    if (fit.slope >= 0) continue;
    const decayTime = -1 / fit.slope; const initial = Math.exp(fit.intercept);
    const predictions = sorted.map((point) => offset + initial * Math.exp(-point.control / decayTime));
    const rmse = Math.sqrt(predictions.reduce((sum, value, index) => sum + (value - sorted[index].measurement) ** 2, 0) / sorted.length);
    if (!best || rmse < best.rmse) best = { initial, decayTime, offset, rmse, rSquared: fit.rSquared };
  }
  if (!best) throw new Error("Could not fit a decaying exponential to these observations.");
  return best;
}
export function simulateRabiSweep(amplitudes: number[], durationNs: number, sampleCount = 256, base: Omit<PulseSpec, "id" | "amplitude" | "durationNs" | "sampleCount"> = { channel: "drive0", shape: "gaussian", sigmaNs: durationNs / 6 }): CalibrationPoint[] {
  if (!amplitudes.length || amplitudes.some((value) => !Number.isFinite(value))) throw new Error("Rabi sweep amplitudes must be finite.");
  return amplitudes.map((amplitude) => {
    const pulse: PulseSpec = { id: `rabi-${amplitude}`, ...base, durationNs, sampleCount, amplitude };
    const state = evolveQubitWithPulse([complex(1), complex(0)], samplePulse(pulse)).state;
    return { control: amplitude, measurement: state[1].re ** 2 + state[1].im ** 2 };
  });
}
export function runRabiCalibration(points: CalibrationPoint[]): CalibrationReport {
  const rabi = fitRabiOscillation(points); const piAmplitude = Math.PI / Math.max(rabi.angularFrequency, 1e-12);
  const warnings = rabi.rmse > 0.08 ? ["The sinusoidal fit residual is high; collect more points or check detuning and leakage."] : [];
  return { rabi, piAmplitude, piOverTwoAmplitude: piAmplitude / 2, points: [...points], warnings };
}
export function simulateRamsey(detunings: number[], freeEvolutionNs: number, phase = 0): RamseyResult[] {
  if (!(freeEvolutionNs >= 0) || !Number.isFinite(freeEvolutionNs)) throw new Error("Free-evolution time must be non-negative.");
  return detunings.map((detuningRadPerNs) => {
    const circuit = { id: "ramsey", name: "Ramsey experiment", qubitCount: 1, classicalBitCount: 1, version: 1 as const, operations: [
      createOperation("RY", 0, [], { theta: Math.PI / 2 }), createOperation("RZ", 0, [], { theta: detuningRadPerNs * freeEvolutionNs + phase }), createOperation("RY", 0, [], { theta: Math.PI / 2 }),
    ] };
    const state = simulateCircuit(circuit).state; const excitedProbability = state[1].re ** 2 + state[1].im ** 2;
    return { detuningRadPerNs, freeEvolutionNs, excitedProbability, contrast: Math.abs(2 * excitedProbability - 1) };
  });
}
export function simulateT1Decay(timesNs: number[], t1Ns: number, initialExcited = 1, offset = 0): CalibrationPoint[] {
  if (!(t1Ns > 0) || initialExcited < 0 || initialExcited > 1 || offset < 0 || offset > 1) throw new Error("Invalid T1 model parameters.");
  return timesNs.map((time) => {
    if (!(time >= 0) || !Number.isFinite(time)) throw new Error("T1 times must be non-negative and finite.");
    return { control: time, measurement: offset + initialExcited * Math.exp(-time / t1Ns) };
  });
}
export function simulateRamseyDecay(timesNs: number[], t2StarNs: number, detuning = 0): CalibrationPoint[] {
  if (!(t2StarNs > 0)) throw new Error("T2* must be positive.");
  return timesNs.map((time) => ({ control: time, measurement: 0.5 * (1 + Math.exp(-time / t2StarNs) * Math.cos(detuning * time)) }));
}
export function fitT2Star(points: CalibrationPoint[]): ExponentialFit {
  const envelope = points.map((point) => ({ ...point, measurement: Math.max(1e-8, 2 * Math.abs(point.measurement - 0.5)) }));
  return fitExponentialDecay(envelope);
}
export function verifyPiPulse(pulse: SampledPulse, tolerance = 0.02): { passed: boolean; excitedProbability: number; error: number } {
  const state = evolveQubitWithPulse([complex(1), complex(0)], pulse).state; const excitedProbability = state[1].re ** 2 + state[1].im ** 2;
  const error = Math.abs(excitedProbability - 1); return { passed: error <= tolerance, excitedProbability, error };
}
