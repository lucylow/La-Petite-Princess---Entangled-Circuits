// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { gateCategory, isEntanglingGate } from "./gates";
import type { CircuitDefinition, CircuitMetrics, CircuitOperation } from "./types";

export function touchedQubits(operation: CircuitOperation): number[] { return [...new Set([...operation.targets, ...(operation.controls ?? [])])]; }
export function circuitMetrics(circuit: CircuitDefinition): CircuitMetrics {
  const gateCounts: Record<string, number> = {};
  let singleQubitGateCount = 0; let twoQubitGateCount = 0; let multiQubitGateCount = 0;
  let measurementCount = 0; let barrierCount = 0; let entanglingGateCount = 0;
  const wireDepth = Array.from({ length: circuit.qubitCount }, () => 0);
  const wireLastOperation = Array.from({ length: circuit.qubitCount }, () => -1);
  const operations = circuit.operations;
  const predecessors: number[][] = operations.map(() => []);
  let depth = 0;
  operations.forEach((operation, index) => {
    gateCounts[operation.gate] = (gateCounts[operation.gate] ?? 0) + 1;
    const category = gateCategory(operation.gate);
    if (category === "single") singleQubitGateCount += 1;
    else if (category === "controlled") twoQubitGateCount += 1;
    else if (category === "multi") multiQubitGateCount += 1;
    if (operation.gate === "MEASURE") measurementCount += 1;
    if (operation.gate === "BARRIER") barrierCount += 1;
    if (isEntanglingGate(operation.gate)) entanglingGateCount += 1;
    const wires = touchedQubits(operation);
    const layer = wires.reduce((value, qubit) => Math.max(value, wireDepth[qubit]), 0);
    depth = Math.max(depth, layer + (operation.gate === "BARRIER" ? 0 : 1));
    for (const qubit of wires) {
      const previous = wireLastOperation[qubit];
      if (previous >= 0 && !predecessors[index].includes(previous)) predecessors[index].push(previous);
      wireDepth[qubit] = layer + (operation.gate === "BARRIER" ? 0 : 1);
      wireLastOperation[qubit] = index;
    }
  });
  const criticalPath = findCriticalPath(operations, predecessors);
  return { qubitCount: circuit.qubitCount, operationCount: operations.length, singleQubitGateCount, twoQubitGateCount, multiQubitGateCount, measurementCount, barrierCount, entanglingGateCount, depth, criticalPath, gateCounts };
}
function findCriticalPath(operations: CircuitOperation[], predecessors: number[][]): string[] {
  const distances: number[] = []; const parent: number[] = [];
  operations.forEach((_, index) => {
    const previous = predecessors[index];
    if (!previous.length) { distances[index] = 1; parent[index] = -1; return; }
    const best = previous.reduce((max, candidate) => distances[candidate] > distances[max] ? candidate : max, previous[0]);
    distances[index] = distances[best] + 1; parent[index] = best;
  });
  if (!operations.length) return [];
  let end = distances.reduce((best, value, index) => value > distances[best] ? index : best, 0);
  const path: string[] = [];
  while (end >= 0) { path.push(operations[end].id); end = parent[end]; }
  return path.reverse();
}
export function estimateTwoQubitCost(circuit: CircuitDefinition, weights: Partial<Record<string, number>> = {}): number {
  const defaultWeight = (gate: string) => gate === "CX" || gate === "CZ" ? 10 : gate === "CCX" ? 30 : gate === "SWAP" ? 30 : 1;
  return circuit.operations.reduce((sum, operation) => sum + (weights[operation.gate] ?? defaultWeight(operation.gate)), 0);
}
export function operationDepths(circuit: CircuitDefinition): number[] {
  const wireDepth = Array.from({ length: circuit.qubitCount }, () => 0);
  return circuit.operations.map((operation) => {
    const wires = touchedQubits(operation); const layer = wires.reduce((max, q) => Math.max(max, wireDepth[q]), 0);
    if (operation.gate !== "BARRIER") wires.forEach((q) => { wireDepth[q] = layer + 1; });
    return layer;
  });
}
