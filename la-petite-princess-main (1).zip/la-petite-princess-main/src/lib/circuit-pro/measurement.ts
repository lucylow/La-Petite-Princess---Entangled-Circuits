// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { cScale, complex, type Complex } from "../advanced/complex";
import { basisLabel, bitProbability, probabilities } from "./statevector";
import { resolveRandom } from "./random";
import { MAX_SHOTS } from "./types";

export interface QubitMeasurement {
  outcome: 0 | 1;
  probabilityZero: number;
  probabilityOne: number;
  collapsedState: Complex[];
}
export function measureQubit(state: Complex[], qubitCount: number, qubit: number, rng: () => number = Math.random): QubitMeasurement {
  const p0 = bitProbability(state, qubitCount, qubit, 0);
  const p1 = bitProbability(state, qubitCount, qubit, 1);
  const outcome: 0 | 1 = rng() < p0 ? 0 : 1;
  const selectedProbability = outcome === 0 ? p0 : p1;
  if (selectedProbability < 1e-14) throw new Error("The sampled measurement outcome has zero probability.");
  const mask = 1 << qubit;
  const collapsed = state.map((amplitude, index) => {
    const actual = (index & mask) === 0 ? 0 : 1;
    return actual === outcome ? cScale(amplitude, 1 / Math.sqrt(selectedProbability)) : complex();
  });
  return { outcome, probabilityZero: p0, probabilityOne: p1, collapsedState: collapsed };
}
export function measureAll(state: Complex[], qubitCount: number, rng: () => number = Math.random): { index: number; bitstring: string; collapsedState: Complex[] } {
  const distribution = probabilities(state);
  const roll = Math.min(Math.max(rng(), 0), 1 - Number.EPSILON);
  let cumulative = 0;
  let selected = distribution.length - 1;
  for (let i = 0; i < distribution.length; i += 1) {
    cumulative += distribution[i];
    if (roll < cumulative) { selected = i; break; }
  }
  const collapsed = state.map((_, index) => index === selected ? complex(1) : complex());
  return { index: selected, bitstring: basisLabel(selected, qubitCount), collapsedState: collapsed };
}
export function measureInBasis(state: Complex[], qubitCount: number, qubit: number, basis: "X" | "Y" | "Z", rng: () => number = Math.random): QubitMeasurement {
  // Rotate the requested basis into the computational Z basis, measure, and undo the rotation.
  const rotated = applyBasisRotation(state, qubitCount, qubit, basis);
  const result = measureQubit(rotated, qubitCount, qubit, rng);
  const collapsed = undoBasisRotation(result.collapsedState, qubitCount, qubit, basis);
  return { ...result, collapsedState: collapsed };
}
function applyBasisRotation(state: Complex[], qubitCount: number, qubit: number, basis: "X" | "Y" | "Z"): Complex[] {
  if (basis === "Z") return state.map((v) => complex(v.re, v.im));
  // H for X measurement; H·S† for Y measurement, applied right-to-left.
  const gates = basis === "X" ? ["H"] : ["SDG", "H"];
  return applySmallGateSequence(state, qubitCount, qubit, gates);
}
function undoBasisRotation(state: Complex[], qubitCount: number, qubit: number, basis: "X" | "Y" | "Z"): Complex[] {
  if (basis === "Z") return state.map((v) => complex(v.re, v.im));
  const gates = basis === "X" ? ["H"] : ["H", "S"];
  return applySmallGateSequence(state, qubitCount, qubit, gates);
}
function applySmallGateSequence(state: Complex[], qubitCount: number, qubit: number, gates: string[]): Complex[] {
  // Local import is avoided to keep the measurement kernel dependency graph acyclic.
  let current = state.map((v) => complex(v.re, v.im));
  for (const gate of gates) {
    const mask = 1 << qubit; const next = current.map((v) => complex(v.re, v.im));
    for (let index = 0; index < current.length; index += 1) {
      if (index & mask) continue;
      const partner = index | mask; const a = current[index]; const b = current[partner];
      if (gate === "H") {
        const half = 1 / Math.sqrt(2);
        next[index] = complex((a.re + b.re) * half, (a.im + b.im) * half);
        next[partner] = complex((a.re - b.re) * half, (a.im - b.im) * half);
      } else if (gate === "S" || gate === "SDG") {
        next[partner] = gate === "S" ? complex(-b.im, b.re) : complex(b.im, -b.re);
      }
    }
    current = next;
  }
  if (state.length !== 2 ** qubitCount) throw new Error("State vector length does not match qubit count.");
  return current;
}
export function sampleShots(state: Complex[], qubitCount: number, shots: number, seed?: number): {
  shots: number; counts: Record<string, number>; frequencies: Record<string, number>; probabilities: Record<string, number>;
} {
  if (!Number.isInteger(shots) || shots < 1 || shots > MAX_SHOTS) throw new RangeError(`Shots must be from 1 to ${MAX_SHOTS}.`);
  const rng = resolveRandom(seed); const distribution = probabilities(state);
  const counts: Record<string, number> = Object.fromEntries(distribution.map((_, index) => [basisLabel(index, qubitCount), 0]));
  for (let shot = 0; shot < shots; shot += 1) {
    const measured = measureAll(state, qubitCount, rng);
    counts[measured.bitstring] += 1;
  }
  const frequencies = Object.fromEntries(Object.entries(counts).map(([label, count]) => [label, count / shots]));
  const probabilityMap = Object.fromEntries(distribution.map((p, index) => [basisLabel(index, qubitCount), p]));
  return { shots, counts, frequencies, probabilities: probabilityMap };
}
