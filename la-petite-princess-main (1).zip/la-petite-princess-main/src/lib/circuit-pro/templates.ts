// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import type { CircuitDefinition } from "./types";
import type { DynamicCircuit } from "./dynamic";
import { createCircuit, createOperation } from "./circuit";
import { quantumTeleportationDemo } from "./advancedAlgorithms";

export interface CircuitTemplate { id: string; title: string; level: "beginner" | "intermediate" | "advanced"; description: string; qubitCount: number; circuit: CircuitDefinition; concepts: string[]; }
export function bellStateTemplate(variant: "phi-plus" | "phi-minus" | "psi-plus" | "psi-minus" = "phi-plus"): CircuitDefinition {
  const operations = [createOperation("H", 0), createOperation("CX", 1, [0])];
  if (variant === "phi-minus" || variant === "psi-minus") operations.push(createOperation("Z", 0));
  if (variant === "psi-plus" || variant === "psi-minus") operations.push(createOperation("X", 1));
  return createCircuit(`Bell state · ${variant}`, 2, 2, operations);
}
export function ghzStateTemplate(qubitCount = 3): CircuitDefinition {
  if (!Number.isInteger(qubitCount) || qubitCount < 2 || qubitCount > 10) throw new RangeError("GHZ template supports 2..10 qubits.");
  const operations = [createOperation("H", 0)];
  for (let q = 1; q < qubitCount; q += 1) operations.push(createOperation("CX", q, [0]));
  return createCircuit(`${qubitCount}-qubit GHZ state`, qubitCount, qubitCount, operations);
}
export function graphStateTemplate(qubitCount: number, edges: Array<[number, number]>): CircuitDefinition {
  if (!Number.isInteger(qubitCount) || qubitCount < 1 || qubitCount > 10) throw new RangeError("Graph-state template supports 1..10 qubits.");
  const operations = Array.from({ length: qubitCount }, (_, q) => createOperation("H", q));
  const seen = new Set<string>();
  for (const [a, b] of edges) {
    if (![a, b].every((q) => Number.isInteger(q) && q >= 0 && q < qubitCount) || a === b) throw new Error(`Invalid graph-state edge (${a}, ${b}).`);
    const key = [a, b].sort((x, y) => x - y).join(":"); if (seen.has(key)) throw new Error(`Duplicate graph-state edge ${key}.`); seen.add(key);
    operations.push(createOperation("CZ", b, [a]));
  }
  return createCircuit("Graph state", qubitCount, qubitCount, operations);
}
export function linearClusterState(qubitCount = 4): CircuitDefinition {
  if (!Number.isInteger(qubitCount) || qubitCount < 2 || qubitCount > 10) throw new RangeError("Cluster state supports 2..10 qubits.");
  return graphStateTemplate(qubitCount, Array.from({ length: qubitCount - 1 }, (_, index) => [index, index + 1] as [number, number]));
}
export function starGraphState(qubitCount = 4): CircuitDefinition {
  if (!Number.isInteger(qubitCount) || qubitCount < 2 || qubitCount > 10) throw new RangeError("Star state supports 2..10 qubits.");
  return graphStateTemplate(qubitCount, Array.from({ length: qubitCount - 1 }, (_, index) => [0, index + 1] as [number, number]));
}
export function parityMeasurementTemplate(qubitCount = 3): CircuitDefinition {
  if (!Number.isInteger(qubitCount) || qubitCount < 2 || qubitCount > 10) throw new RangeError("Parity template supports 2..10 qubits.");
  const operations = [];
  for (let q = 1; q < qubitCount; q += 1) operations.push(createOperation("CX", 0, [q], undefined, "Accumulate parity onto Q1"));
  operations.push(createOperation("MEASURE", 0, [], undefined, "Measure parity bit"));
  operations[operations.length - 1].classicalBit = 0;
  return createCircuit("Parity measurement", qubitCount, 1, operations);
}
export function quantumTeleportationTemplate(theta = Math.PI / 3, phi = 0, lambda = 0): DynamicCircuit {
  return quantumTeleportationDemo({ theta, phi, lambda }).circuit;
}
export function textbookCircuitTemplates(): CircuitTemplate[] {
  return [
    { id: "bell", title: "Bell pair", level: "beginner", description: "Create a maximally entangled pair and inspect correlations.", qubitCount: 2, circuit: bellStateTemplate(), concepts: ["Hadamard", "CNOT", "entanglement"] },
    { id: "ghz", title: "GHZ state", level: "intermediate", description: "Create a three-qubit Greenberger–Horne–Zeilinger state.", qubitCount: 3, circuit: ghzStateTemplate(), concepts: ["multipartite entanglement", "correlations"] },
    { id: "cluster", title: "Linear cluster", level: "intermediate", description: "Create a one-dimensional graph state.", qubitCount: 4, circuit: linearClusterState(), concepts: ["graph states", "CZ", "measurement-based computing"] },
    { id: "star", title: "Star graph state", level: "advanced", description: "Create a central-qubit graph state.", qubitCount: 4, circuit: starGraphState(), concepts: ["graph states", "entanglement topology"] },
  ];
}
