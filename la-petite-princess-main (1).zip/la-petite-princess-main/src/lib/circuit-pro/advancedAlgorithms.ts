// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { complex } from "../advanced/complex";
import type { CircuitDefinition } from "./types";
import { createCircuit, createOperation } from "./circuit";
import type { DynamicCircuit } from "./dynamic";
import { simulateCircuit } from "./simulator";
import { probabilityMap } from "./statevector";

export interface TeleportationOptions { theta: number; phi?: number; lambda?: number; }
export interface TeleportationDemo { circuit: DynamicCircuit; description: string[]; expectedInput: { theta: number; phi: number; lambda: number }; }
/**
 * A three-qubit dynamic teleportation circuit. Q0 is prepared with U3(theta, phi, lambda),
 * Q1-Q2 share a Bell pair, and classical feed-forward applies X/Z to Q2.
 */
export function quantumTeleportationDemo(options: TeleportationOptions): TeleportationDemo {
  const { theta, phi = 0, lambda = 0 } = options;
  if (![theta, phi, lambda].every(Number.isFinite)) throw new Error("Teleportation state parameters must be finite.");
  return {
    circuit: {
      id: "quantum-teleportation-demo", name: "Quantum teleportation", qubitCount: 3, classicalBitCount: 2,
      instructions: [
        { kind: "gate", operation: createOperation("U3", 0, [], { theta, phi, lambda }, "Prepare the unknown input state") },
        { kind: "gate", operation: createOperation("H", 1) },
        { kind: "gate", operation: createOperation("CX", 2, [1], undefined, "Create shared Bell pair") },
        { kind: "gate", operation: createOperation("CX", 1, [0]) },
        { kind: "gate", operation: createOperation("H", 0) },
        { kind: "measure", qubit: 0, classicalBit: 0, id: "alice-measure-0" },
        { kind: "measure", qubit: 1, classicalBit: 1, id: "alice-measure-1" },
        { kind: "if", classicalBit: 1, equals: 1, then: [{ kind: "gate", operation: createOperation("X", 2, [], undefined, "Bob's X correction") }], id: "feed-forward-x" },
        { kind: "if", classicalBit: 0, equals: 1, then: [{ kind: "gate", operation: createOperation("Z", 2, [], undefined, "Bob's Z correction") }], id: "feed-forward-z" },
      ],
    },
    description: ["Prepare an arbitrary pure qubit on Q0.", "Create an entangled Bell pair shared by Q1 and Q2.", "Perform a Bell-basis measurement on Q0 and Q1.", "Send two classical bits to Bob.", "Conditionally apply Pauli corrections to Q2.", "The original quantum state is reconstructed on Q2; no quantum information travels faster than light."],
    expectedInput: { theta, phi, lambda },
  };
}
export function bernsteinVaziraniCircuit(secret: string): CircuitDefinition {
  if (!/^[01]{1,8}$/.test(secret)) throw new Error("Secret string must contain 1..8 binary digits.");
  const n = secret.length; const operations = [];
  // Ancilla is the most-significant wire; input register starts in |+…+>.
  operations.push(createOperation("X", n)); operations.push(createOperation("H", n));
  for (let q = 0; q < n; q += 1) operations.push(createOperation("H", q));
  for (let q = 0; q < n; q += 1) if (secret[n - 1 - q] === "1") operations.push(createOperation("CX", n, [q]));
  for (let q = 0; q < n; q += 1) operations.push(createOperation("H", q));
  return createCircuit(`Bernstein–Vazirani · ${secret}`, n + 1, n + 1, operations);
}
export function randomCircuit(qubitCount: number, depth: number, seed = 1): CircuitDefinition {
  if (!Number.isInteger(qubitCount) || qubitCount < 1 || qubitCount > 8 || !Number.isInteger(depth) || depth < 1 || depth > 200) throw new RangeError("Random circuit requires 1..8 qubits and 1..200 layers.");
  let state = seed >>> 0; const random = () => { state = (Math.imul(state, 1664525) + 1013904223) >>> 0; return state / 4294967296; };
  const oneQubit = ["H", "X", "Y", "Z", "S", "T", "RX", "RY", "RZ"] as const;
  const operations = [];
  for (let layer = 0; layer < depth; layer += 1) {
    const used = new Set<number>();
    for (let q = 0; q < qubitCount; q += 1) {
      if (used.has(q)) continue;
      if (qubitCount > 1 && random() < 0.28) {
        const candidates = Array.from({ length: qubitCount }, (_, index) => index).filter((candidate) => candidate !== q && !used.has(candidate));
        if (candidates.length) { const target = candidates[Math.floor(random() * candidates.length)]; operations.push(createOperation("CX", target, [q])); used.add(q); used.add(target); continue; }
      }
      const gate = oneQubit[Math.floor(random() * oneQubit.length)];
      operations.push(createOperation(gate, q, [], ["RX", "RY", "RZ"].includes(gate) ? { theta: (random() * 2 - 1) * Math.PI } : undefined));
      used.add(q);
    }
  }
  return createCircuit(`Random circuit (${seed})`, qubitCount, qubitCount, operations);
}
export function circuitProbabilityPreview(circuit: CircuitDefinition): Record<string, number> { return probabilityMap(simulateCircuit(circuit).state, circuit.qubitCount, false); }
export function preparePlusStateCircuit(qubitCount: number): CircuitDefinition {
  if (!Number.isInteger(qubitCount) || qubitCount < 1 || qubitCount > 10) throw new RangeError("qubitCount must be 1..10.");
  return createCircuit("Uniform superposition", qubitCount, qubitCount, Array.from({ length: qubitCount }, (_, q) => createOperation("H", q)));
}
export function prepareProductStateCircuit(bits: string): CircuitDefinition {
  if (!/^[01]{1,10}$/.test(bits)) throw new Error("bits must contain 1..10 binary digits.");
  const n = bits.length; const operations = [];
  for (let q = 0; q < n; q += 1) if (bits[n - 1 - q] === "1") operations.push(createOperation("X", q));
  return createCircuit(`Basis state |${bits}⟩`, n, n, operations);
}
export function singleQubitStateParametersFromBloch(theta: number, phi: number): { alpha: ReturnType<typeof complex>; beta: ReturnType<typeof complex> } {
  return { alpha: complex(Math.cos(theta / 2)), beta: complex(Math.sin(theta / 2) * Math.cos(phi), Math.sin(theta / 2) * Math.sin(phi)) };
}
