// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { cAdd, cConjugate, cMagnitudeSquared, cMul, complex, type Complex } from "../advanced/complex";
import type { ComplexMatrix } from "./types";
export type { Complex };

export function zeros(rows: number, cols: number): ComplexMatrix {
  assertDimensions(rows, cols);
  return { rows, cols, data: Array.from({ length: rows }, () => Array.from({ length: cols }, () => complex())) };
}
export function identity(size: number): ComplexMatrix {
  const result = zeros(size, size);
  for (let i = 0; i < size; i += 1) result.data[i][i] = complex(1);
  return result;
}
export function fromRows(rows: Complex[][]): ComplexMatrix {
  if (!rows.length || !rows[0].length) throw new Error("A matrix cannot be empty.");
  const width = rows[0].length;
  if (rows.some((row) => row.length !== width)) throw new Error("Matrix rows must have equal length.");
  return { rows: rows.length, cols: width, data: rows.map((row) => row.map((v) => complex(v.re, v.im))) };
}
export function cloneMatrix(matrix: ComplexMatrix): ComplexMatrix { return fromRows(matrix.data); }
export function assertDimensions(rows: number, cols: number): void {
  if (!Number.isInteger(rows) || rows < 1 || !Number.isInteger(cols) || cols < 1) throw new RangeError("Matrix dimensions must be positive integers.");
}
export function addMatrices(a: ComplexMatrix, b: ComplexMatrix): ComplexMatrix {
  assertSameShape(a, b);
  return fromRows(a.data.map((row, i) => row.map((value, j) => cAdd(value, b.data[i][j]))));
}
export function multiplyMatrices(a: ComplexMatrix, b: ComplexMatrix): ComplexMatrix {
  if (a.cols !== b.rows) throw new Error(`Cannot multiply ${a.rows}×${a.cols} by ${b.rows}×${b.cols}.`);
  const result = zeros(a.rows, b.cols);
  for (let i = 0; i < a.rows; i += 1) for (let k = 0; k < a.cols; k += 1) for (let j = 0; j < b.cols; j += 1) {
    result.data[i][j] = cAdd(result.data[i][j], cMul(a.data[i][k], b.data[k][j]));
  }
  return result;
}
export function tensorProduct(a: ComplexMatrix, b: ComplexMatrix): ComplexMatrix {
  const result = zeros(a.rows * b.rows, a.cols * b.cols);
  for (let ar = 0; ar < a.rows; ar += 1) for (let ac = 0; ac < a.cols; ac += 1)
    for (let br = 0; br < b.rows; br += 1) for (let bc = 0; bc < b.cols; bc += 1)
      result.data[ar * b.rows + br][ac * b.cols + bc] = cMul(a.data[ar][ac], b.data[br][bc]);
  return result;
}
export function adjoint(matrix: ComplexMatrix): ComplexMatrix {
  const result = zeros(matrix.cols, matrix.rows);
  for (let r = 0; r < matrix.rows; r += 1) for (let c = 0; c < matrix.cols; c += 1) result.data[c][r] = cConjugate(matrix.data[r][c]);
  return result;
}
export function trace(matrix: ComplexMatrix): Complex {
  if (matrix.rows !== matrix.cols) throw new Error("Trace is defined only for square matrices.");
  let result = complex();
  for (let i = 0; i < matrix.rows; i += 1) result = cAdd(result, matrix.data[i][i]);
  return result;
}
export function matrixNormFrobenius(matrix: ComplexMatrix): number {
  return Math.sqrt(matrix.data.flat().reduce((sum, value) => sum + cMagnitudeSquared(value), 0));
}
export function isHermitian(matrix: ComplexMatrix, tolerance = 1e-9): boolean {
  if (matrix.rows !== matrix.cols) return false;
  const dagger = adjoint(matrix);
  return matrix.data.every((row, i) => row.every((v, j) => Math.hypot(v.re - dagger.data[i][j].re, v.im - dagger.data[i][j].im) <= tolerance));
}
export function isUnitary(matrix: ComplexMatrix, tolerance = 1e-9): boolean {
  return matrix.rows === matrix.cols && matrixClose(multiplyMatrices(adjoint(matrix), matrix), identity(matrix.rows), tolerance);
}
export function matrixClose(a: ComplexMatrix, b: ComplexMatrix, tolerance = 1e-9): boolean {
  if (a.rows !== b.rows || a.cols !== b.cols) return false;
  return a.data.every((row, i) => row.every((v, j) => Math.hypot(v.re - b.data[i][j].re, v.im - b.data[i][j].im) <= tolerance));
}
export function partialTrace(matrix: ComplexMatrix, keepIndices: number[], qubitCount: number): ComplexMatrix {
  if (matrix.rows !== matrix.cols || matrix.rows !== 2 ** qubitCount) throw new Error("Density matrix dimension does not match qubit count.");
  const keep = [...new Set(keepIndices)].sort((a, b) => a - b);
  if (!keep.length || keep.some((q) => !Number.isInteger(q) || q < 0 || q >= qubitCount)) throw new Error("At least one valid qubit index must be retained.");
  const traced = Array.from({ length: qubitCount }, (_, q) => q).filter((q) => !keep.includes(q));
  const outDimension = 2 ** keep.length;
  const result = zeros(outDimension, outDimension);
  const extract = (index: number, positions: number[]) => positions.reduce((value, qubit, bit) => value | ((((index >> qubit) & 1) << bit)), 0);
  for (let row = 0; row < matrix.rows; row += 1) for (let col = 0; col < matrix.cols; col += 1) {
    if (extract(row, traced) !== extract(col, traced)) continue;
    const outRow = extract(row, keep); const outCol = extract(col, keep);
    result.data[outRow][outCol] = cAdd(result.data[outRow][outCol], matrix.data[row][col]);
  }
  return result;
}
export function assertSameShape(a: ComplexMatrix, b: ComplexMatrix): void {
  if (a.rows !== b.rows || a.cols !== b.cols) throw new Error("Matrix shapes must match.");
}
export function matrixToText(matrix: ComplexMatrix, digits = 3): string {
  return matrix.data.map((row) => `[ ${row.map((v) => `${v.re.toFixed(digits)}${v.im < 0 ? "−" : "+"}${Math.abs(v.im).toFixed(digits)}i`).join("  ")} ]`).join("\n");
}
