// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { cMagnitudeSquared } from "../advanced/complex";
import type { Complex } from "../advanced/complex";
import type { CircuitDefinition, CircuitOperation, CircuitValidationIssue } from "./types";
import { validateCircuit } from "./circuit";
import { circuitMetrics } from "./metrics";
import { isNormalized, stateNormSquared } from "./statevector";

export interface StateDiagnostics {
  dimension: number; normSquared: number; normalized: boolean; nonZeroAmplitudes: number;
  largestProbability: number; largestBasisIndex: number; probabilityMassError: number;
  finite: boolean; warnings: string[];
}
export interface CircuitDiagnostics {
  issues: CircuitValidationIssue[]; metrics: ReturnType<typeof circuitMetrics>;
  unusedQubits: number[]; repeatedMeasurements: number[]; warnings: string[];
}
export function diagnoseState(state: Complex[], tolerance = 1e-8): StateDiagnostics {
  const normSquared = stateNormSquared(state); const warnings: string[] = [];
  const finite = state.every((value) => Number.isFinite(value.re) && Number.isFinite(value.im));
  if (!finite) warnings.push("State vector contains non-finite amplitudes.");
  if (Math.abs(normSquared - 1) > tolerance) warnings.push(`State norm differs from one by ${Math.abs(normSquared - 1).toExponential(2)}.`);
  let largestProbability = -1; let largestBasisIndex = 0; let nonZeroAmplitudes = 0;
  state.forEach((amplitude, index) => {
    const probability = cMagnitudeSquared(amplitude);
    if (probability > tolerance) nonZeroAmplitudes += 1;
    if (probability > largestProbability) { largestProbability = probability; largestBasisIndex = index; }
  });
  return { dimension: state.length, normSquared, normalized: isNormalized(state, tolerance), nonZeroAmplitudes, largestProbability, largestBasisIndex, probabilityMassError: Math.abs(normSquared - 1), finite, warnings };
}
export function diagnoseCircuit(circuit: CircuitDefinition): CircuitDiagnostics {
  const issues = validateCircuit(circuit); const metrics = circuitMetrics(circuit);
  const touched = new Set<number>(); const measured = new Set<number>(); const repeatedMeasurements: number[] = [];
  for (const operation of circuit.operations) {
    [...operation.targets, ...(operation.controls ?? [])].forEach((qubit) => touched.add(qubit));
    if (operation.gate === "MEASURE") {
      const qubit = operation.targets[0]; if (measured.has(qubit)) repeatedMeasurements.push(qubit); measured.add(qubit);
    }
  }
  const unusedQubits = Array.from({ length: circuit.qubitCount }, (_, qubit) => qubit).filter((qubit) => !touched.has(qubit));
  const warnings = [...issues.filter((issue) => issue.severity === "warning").map((issue) => issue.message)];
  if (unusedQubits.length) warnings.push(`Unused qubit wires: ${unusedQubits.map((q) => `Q${q + 1}`).join(", ")}.`);
  if (repeatedMeasurements.length) warnings.push("Some qubits are measured more than once; later measurements act on the collapsed state.");
  if (metrics.entanglingGateCount === 0 && circuit.qubitCount > 1) warnings.push("No explicit multi-qubit interaction gate appears in this circuit.");
  return { issues, metrics, unusedQubits, repeatedMeasurements, warnings };
}
export function normalizeAmplitudeDisplay(amplitude: Complex, digits = 4): string {
  const round = (value: number) => Math.abs(value) < 10 ** -digits ? 0 : value;
  const real = round(amplitude.re); const imaginary = round(amplitude.im);
  if (imaginary === 0) return real.toFixed(digits);
  if (real === 0) return `${imaginary.toFixed(digits)}i`;
  return `${real.toFixed(digits)} ${imaginary < 0 ? "−" : "+"} ${Math.abs(imaginary).toFixed(digits)}i`;
}
export function complexityEstimate(qubitCount: number, operationCount: number): { stateVectorAmplitudes: number; approximateComplexValues: number; roughMemoryBytes: number } {
  if (!Number.isInteger(qubitCount) || qubitCount < 1 || qubitCount > 30) throw new RangeError("Complexity estimate supports 1–30 qubits.");
  const stateVectorAmplitudes = 2 ** qubitCount;
  return { stateVectorAmplitudes, approximateComplexValues: stateVectorAmplitudes * Math.max(1, operationCount), roughMemoryBytes: stateVectorAmplitudes * 16 };
}
export function circuitReadabilityScore(operations: CircuitOperation[]): number {
  if (!operations.length) return 100;
  let score = 100;
  if (operations.length > 80) score -= Math.min(30, (operations.length - 80) / 3);
  const labels = operations.map((operation) => operation.note?.trim()).filter(Boolean).length;
  if (labels / operations.length < 0.2) score -= 10;
  const longRotations = operations.filter((operation) => operation.params?.theta !== undefined && Math.abs(operation.params.theta) > 8 * Math.PI).length;
  score -= Math.min(15, longRotations * 2);
  return Math.max(0, Math.round(score));
}
