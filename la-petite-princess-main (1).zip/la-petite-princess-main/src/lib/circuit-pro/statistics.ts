// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { clampProbability } from "./random";
import type { ShotResult } from "./types";

export interface Estimate { estimate: number; standardError: number; lower95: number; upper95: number; shots: number; }
export interface HistogramBin { label: string; count: number; frequency: number; probability?: number; residual?: number; }
export interface GoodnessOfFit { chiSquared: number; degreesOfFreedom: number; reducedChiSquared: number; binsUsed: number; }

/** Wilson score interval; remains well behaved at 0 and 100% observed frequency. */
export function wilsonInterval(successes: number, trials: number, z = 1.959963984540054): { lower: number; upper: number } {
  validateCounts(successes, trials);
  if (!Number.isFinite(z) || z <= 0) throw new RangeError("z must be positive and finite.");
  const p = successes / trials;
  const z2 = z * z;
  const denominator = 1 + z2 / trials;
  const center = (p + z2 / (2 * trials)) / denominator;
  const half = z * Math.sqrt((p * (1 - p) + z2 / (4 * trials)) / trials) / denominator;
  return { lower: Math.max(0, center - half), upper: Math.min(1, center + half) };
}
export function estimateBernoulli(successes: number, trials: number): Estimate {
  validateCounts(successes, trials);
  const estimate = successes / trials;
  const standardError = Math.sqrt(estimate * (1 - estimate) / trials);
  const interval = wilsonInterval(successes, trials);
  return { estimate, standardError, lower95: interval.lower, upper95: interval.upper, shots: trials };
}
export function histogramFromShots(result: ShotResult, ideal?: Record<string, number>): HistogramBin[] {
  const keys = new Set([...Object.keys(result.counts), ...Object.keys(ideal ?? {})]);
  return [...keys].sort().map((label) => {
    const count = result.counts[label] ?? 0;
    const frequency = count / result.shots;
    const probability = ideal?.[label];
    return { label, count, frequency, ...(probability === undefined ? {} : { probability, residual: frequency - probability }) };
  });
}
export function totalVariationDistance(a: Record<string, number>, b: Record<string, number>): number {
  const keys = new Set([...Object.keys(a), ...Object.keys(b)]);
  return 0.5 * [...keys].reduce((sum, key) => sum + Math.abs((a[key] ?? 0) - (b[key] ?? 0)), 0);
}
export function normalizedEntropy(distribution: Record<string, number>): number {
  const entries = Object.values(distribution).filter((value) => value > 0);
  if (entries.length <= 1) return 0;
  const total = entries.reduce((a, b) => a + b, 0);
  const entropy = entries.reduce((sum, value) => { const p = value / total; return sum - p * Math.log2(p); }, 0);
  return entropy / Math.log2(entries.length);
}
export function confidenceIntervalForMean(values: number[], z = 1.959963984540054): { mean: number; standardError: number; lower95: number; upper95: number; count: number } {
  if (!values.length || values.some((v) => !Number.isFinite(v))) throw new Error("Provide at least one finite observation.");
  const mean = values.reduce((sum, value) => sum + value, 0) / values.length;
  const variance = values.length > 1 ? values.reduce((sum, value) => sum + (value - mean) ** 2, 0) / (values.length - 1) : 0;
  const standardError = Math.sqrt(variance / values.length);
  return { mean, standardError, lower95: mean - z * standardError, upper95: mean + z * standardError, count: values.length };
}
export function chiSquaredGoodnessOfFit(observed: Record<string, number>, expected: Record<string, number>, minExpected = 5): GoodnessOfFit {
  if (!Number.isFinite(minExpected) || minExpected <= 0) throw new RangeError("minExpected must be positive.");
  let chiSquared = 0; let binsUsed = 0;
  for (const label of new Set([...Object.keys(observed), ...Object.keys(expected)])) {
    const actual = observed[label] ?? 0; const target = expected[label] ?? 0;
    if (target < minExpected) continue;
    chiSquared += (actual - target) ** 2 / target;
    binsUsed += 1;
  }
  const degreesOfFreedom = Math.max(0, binsUsed - 1);
  return { chiSquared, degreesOfFreedom, reducedChiSquared: degreesOfFreedom ? chiSquared / degreesOfFreedom : 0, binsUsed };
}
export function shotNoiseBand(probability: number, shots: number, z = 1.96): { lower: number; upper: number; sigma: number } {
  clampProbability(probability);
  if (!Number.isInteger(shots) || shots < 1) throw new RangeError("shots must be a positive integer.");
  const sigma = Math.sqrt(probability * (1 - probability) / shots);
  return { lower: Math.max(0, probability - z * sigma), upper: Math.min(1, probability + z * sigma), sigma };
}
function validateCounts(successes: number, trials: number): void {
  if (!Number.isInteger(trials) || trials < 1 || !Number.isInteger(successes) || successes < 0 || successes > trials) throw new RangeError("Counts must satisfy integer 0 ≤ successes ≤ trials.");
}
