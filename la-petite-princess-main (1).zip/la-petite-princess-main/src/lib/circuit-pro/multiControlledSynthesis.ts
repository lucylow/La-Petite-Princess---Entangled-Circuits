// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { createCircuit, createOperation } from "./circuit";
import type { CircuitOperation } from "./types";

export interface MultiControlPlan { controls: number[]; target: number; ancillas: number[]; operations: CircuitOperation[]; cleanAncillasRequired: number; depthEstimate: number; }
function validateWires(controls: number[], target: number, qubitCount: number, ancillas: number[]): void {
  const all = [...controls, target, ...ancillas];
  if (all.some((q) => !Number.isInteger(q) || q < 0 || q >= qubitCount)) throw new RangeError("Every control, target and ancilla must be a valid circuit qubit.");
  if (new Set(all).size !== all.length) throw new Error("Controls, target and ancillas must be pairwise distinct.");
  if (!controls.length) throw new Error("At least one control is required.");
}
/** Exact MCX decomposition using clean ancillas and a compute / apply / uncompute ladder. */
export function synthesizeMultiControlledX(controls: number[], target: number, qubitCount: number, ancillas: number[] = []): MultiControlPlan {
  validateWires(controls, target, qubitCount, ancillas);
  const needed = Math.max(0, controls.length - 2);
  if (ancillas.length < needed) throw new Error(`MCX with ${controls.length} controls needs ${needed} clean ancilla qubits for this linear-depth construction.`);
  const scratch = ancillas.slice(0, needed); const operations: CircuitOperation[] = [];
  if (controls.length === 1) operations.push(createOperation("CX", target, [controls[0]], undefined, "Single-control X"));
  else if (controls.length === 2) operations.push(createOperation("CCX", target, controls, undefined, "Toffoli / two-control X"));
  else {
    operations.push(createOperation("CCX", scratch[0], controls.slice(0, 2), undefined, "MCX compute control conjunction"));
    for (let index = 2; index < controls.length - 1; index += 1) {
      operations.push(createOperation("CCX", scratch[index - 1], [scratch[index - 2], controls[index]], undefined, `MCX compute control ${index + 1}`));
    }
    operations.push(createOperation("CCX", target, [scratch[needed - 1], controls[controls.length - 1]], undefined, "MCX target flip"));
    for (let index = controls.length - 2; index >= 2; index -= 1) {
      operations.push(createOperation("CCX", scratch[index - 1], [scratch[index - 2], controls[index]], undefined, `MCX uncompute control ${index + 1}`));
    }
    operations.push(createOperation("CCX", scratch[0], controls.slice(0, 2), undefined, "MCX uncompute control conjunction"));
  }
  return { controls: [...controls], target, ancillas: scratch, operations, cleanAncillasRequired: needed, depthEstimate: operations.length };
}
export function multiControlledXCircuit(controls: number[], target: number, qubitCount: number, ancillas: number[] = []) {
  const plan = synthesizeMultiControlledX(controls, target, qubitCount, ancillas);
  const circuit = createCircuit(`MCX · ${controls.length} controls`, qubitCount, qubitCount, plan.operations);
  circuit.description = `Multi-controlled X decomposed into CCX gates. Ancillas must start in |0⟩ and are uncomputed at the end.`;
  return { circuit, plan };
}
export function multiControlledZCircuit(controls: number[], target: number, qubitCount: number, ancillas: number[] = []) {
  const plan = synthesizeMultiControlledX(controls, target, qubitCount, ancillas);
  const operations = [createOperation("H", target), ...plan.operations, createOperation("H", target)];
  const circuit = createCircuit(`MCZ · ${controls.length + 1} wires`, qubitCount, qubitCount, operations);
  circuit.description = "Multi-controlled phase flip, decomposed through H–MCX–H.";
  return { circuit, plan: { ...plan, operations } };
}
export function mcxResourceTable(maxControls = 8): Array<{ controls: number; cleanAncillas: number; ccxCount: number; totalOperations: number }> {
  if (!Number.isInteger(maxControls) || maxControls < 1 || maxControls > 20) throw new RangeError("maxControls must be 1..20.");
  return Array.from({ length: maxControls }, (_, index) => {
    const controls = index + 1; const cleanAncillas = Math.max(0, controls - 2);
    const ccxCount = controls <= 2 ? 1 : 2 * cleanAncillas + 1;
    return { controls, cleanAncillas, ccxCount, totalOperations: ccxCount };
  });
}
/** Creates a native-control representation when the simulator supports arbitrary control lists. */
export function directMultiControlledX(controls: number[], target: number): CircuitOperation {
  if (!controls.length || new Set([...controls, target]).size !== controls.length + 1) throw new Error("Direct MCX requires unique controls and a distinct target.");
  return createOperation("CX", target, controls, undefined, "Direct simulator multi-control instruction; decompose for a restricted basis.");
}
