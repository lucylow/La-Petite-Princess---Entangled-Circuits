// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import type { CircuitOperation } from "./types";

/** Kept separate so dynamic-circuit metadata helpers can be reused by the editor. */
export function applyOperationDepths(operations: CircuitOperation[]): number[] {
  const wireDepth = new Map<number, number>();
  return operations.map((operation) => {
    const wires = [...operation.targets, ...(operation.controls ?? [])];
    const next = Math.max(0, ...wires.map((wire) => wireDepth.get(wire) ?? 0)) + 1;
    wires.forEach((wire) => wireDepth.set(wire, next));
    return next;
  });
}
