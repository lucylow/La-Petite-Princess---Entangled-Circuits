// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { cMagnitudeSquared, cScale, complex, type Complex } from "../advanced/complex";
import { NUMERICAL_EPSILON } from "./types";

export function createZeroState(qubitCount: number): Complex[] {
  validateQubitCount(qubitCount);
  const state = Array.from({ length: 2 ** qubitCount }, () => complex());
  state[0] = complex(1);
  return state;
}
export function createBasisState(qubitCount: number, bitstring: string): Complex[] {
  validateQubitCount(qubitCount);
  if (!new RegExp(`^[01]{${qubitCount}}$`).test(bitstring)) throw new Error(`Expected a ${qubitCount}-bit basis string.`);
  const state = createZeroState(qubitCount);
  state[0] = complex();
  state[Number.parseInt(bitstring, 2)] = complex(1);
  return state;
}
export function validateQubitCount(qubitCount: number, maxQubits = 10): void {
  if (!Number.isInteger(qubitCount) || qubitCount < 1 || qubitCount > maxQubits) throw new RangeError(`Qubit count must be an integer from 1 to ${maxQubits}.`);
}
export function basisLabel(index: number, qubitCount: number): string {
  if (!Number.isInteger(index) || index < 0 || index >= 2 ** qubitCount) throw new RangeError("Basis-state index is out of range.");
  return index.toString(2).padStart(qubitCount, "0");
}
export function stateNormSquared(state: Complex[]): number { return state.reduce((sum, amplitude) => sum + cMagnitudeSquared(amplitude), 0); }
export function isNormalized(state: Complex[], tolerance = 1e-9): boolean { return Math.abs(stateNormSquared(state) - 1) <= tolerance; }
export function normalizeState(state: Complex[]): Complex[] {
  const norm = Math.sqrt(stateNormSquared(state));
  if (!Number.isFinite(norm) || norm < NUMERICAL_EPSILON) throw new Error("Cannot normalize a zero or invalid state vector.");
  return state.map((amplitude) => cScale(amplitude, 1 / norm));
}
export function probabilities(state: Complex[]): number[] {
  const total = stateNormSquared(state);
  if (!Number.isFinite(total) || total < NUMERICAL_EPSILON) throw new Error("State vector has no valid probability mass.");
  return state.map((amplitude) => cMagnitudeSquared(amplitude) / total);
}
export function probabilityMap(state: Complex[], qubitCount: number, includeZeros = true): Record<string, number> {
  const values = probabilities(state);
  return Object.fromEntries(values.flatMap((value, index) => includeZeros || value > NUMERICAL_EPSILON ? [[basisLabel(index, qubitCount), value]] : []));
}
export function formatState(state: Complex[], qubitCount: number, digits = 3): string {
  const terms = state.flatMap((amplitude, index) => {
    if (cMagnitudeSquared(amplitude) < NUMERICAL_EPSILON) return [];
    const real = Math.abs(amplitude.re) < 10 ** -digits ? 0 : amplitude.re;
    const imaginary = Math.abs(amplitude.im) < 10 ** -digits ? 0 : amplitude.im;
    const coefficient = imaginary === 0 ? real.toFixed(digits) : real === 0 ? `${imaginary.toFixed(digits)}i` : `${real.toFixed(digits)} ${imaginary < 0 ? "−" : "+"} ${Math.abs(imaginary).toFixed(digits)}i`;
    return [`${coefficient}|${basisLabel(index, qubitCount)}⟩`];
  });
  return terms.length ? terms.join(" + ") : "0";
}
export function bitProbability(state: Complex[], qubitCount: number, qubit: number, bit: 0 | 1): number {
  validateQubitCount(qubitCount);
  if (!Number.isInteger(qubit) || qubit < 0 || qubit >= qubitCount) throw new RangeError("Invalid qubit index.");
  const mask = 1 << qubit;
  return probabilities(state).reduce((sum, probability, index) => sum + (((index & mask) !== 0) === (bit === 1) ? probability : 0), 0);
}
export function tensorState(a: Complex[], b: Complex[]): Complex[] {
  const result: Complex[] = [];
  for (const left of a) for (const right of b) result.push(complex(left.re * right.re - left.im * right.im, left.re * right.im + left.im * right.re));
  return result;
}
