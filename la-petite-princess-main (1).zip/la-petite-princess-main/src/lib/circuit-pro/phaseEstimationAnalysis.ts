// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import type { ShotResult } from "./types";

export interface PhaseEstimate { phase: number; circularStandardDeviation: number; shots: number; mostLikelyBitstring: string; modalFrequency: number; uncertaintyFromResolution: number; }
export function phaseFromCountingBitstring(bitstring: string): number {
  if (!/^[01]+$/.test(bitstring)) throw new Error("Counting register must be a non-empty binary string.");
  return Number.parseInt(bitstring, 2) / 2 ** bitstring.length;
}
export function summarizePhaseEstimation(result: ShotResult, countingBits: number): PhaseEstimate {
  if (!Number.isInteger(countingBits) || countingBits < 1 || countingBits > 20) throw new RangeError("countingBits must be 1..20.");
  const counts = Object.entries(result.counts).filter(([label, count]) => label.length === countingBits && /^[01]+$/.test(label) && count > 0);
  if (!counts.length) throw new Error("No valid counting-register outcomes were found.");
  let real = 0; let imaginary = 0; let total = 0;
  for (const [label, count] of counts) {
    const phase = phaseFromCountingBitstring(label); const angle = 2 * Math.PI * phase;
    real += count * Math.cos(angle); imaginary += count * Math.sin(angle); total += count;
  }
  const phase = ((Math.atan2(imaginary, real) / (2 * Math.PI)) + 1) % 1;
  const resultant = Math.sqrt(real * real + imaginary * imaginary) / total;
  const circularStandardDeviation = Math.sqrt(Math.max(0, -2 * Math.log(Math.max(resultant, 1e-12)))) / (2 * Math.PI);
  const modal = [...counts].sort((a, b) => b[1] - a[1])[0];
  return { phase, circularStandardDeviation, shots: total, mostLikelyBitstring: modal[0], modalFrequency: modal[1] / total, uncertaintyFromResolution: 1 / (2 ** countingBits) };
}
export function phaseEstimateToDegrees(phase: number): number { if (!Number.isFinite(phase)) throw new Error("phase must be finite."); return ((phase % 1) + 1) % 1 * 360; }
export function phaseEstimateConfidenceBand(estimate: PhaseEstimate, z = 1.96): { lower: number; upper: number } {
  return { lower: ((estimate.phase - z * estimate.circularStandardDeviation) % 1 + 1) % 1, upper: ((estimate.phase + z * estimate.circularStandardDeviation) % 1 + 1) % 1 };
}
