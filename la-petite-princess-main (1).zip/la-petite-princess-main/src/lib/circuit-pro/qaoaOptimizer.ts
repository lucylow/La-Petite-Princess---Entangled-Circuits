// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import type { WeightedGraph, QaoaParameters, QaoaEvaluation } from "./qaoa";
import { qaoaMaxCutCircuit, evaluateQaoaState, bruteForceMaxCut } from "./qaoa";
import { simulateCircuit } from "./simulator";

export interface QaoaSearchOptions { layers?: number; gridPoints?: number; gammaRange?: [number, number]; betaRange?: [number, number]; }
export interface QaoaSearchPoint { parameters: QaoaParameters; expectedCut: number; approximationRatio: number; }
export interface QaoaSearchResult { best: QaoaSearchPoint; evaluations: number; history: QaoaSearchPoint[]; exactMaxCut: number; }
export function evaluateQaoaParameters(graph: WeightedGraph, parameters: QaoaParameters): QaoaEvaluation {
  const circuit = qaoaMaxCutCircuit(graph, parameters);
  return evaluateQaoaState(simulateCircuit(circuit).state, graph);
}
/** Deterministic coarse grid search for small p=1/p=2 pedagogical MaxCut instances. */
export function gridSearchQaoa(graph: WeightedGraph, options: QaoaSearchOptions = {}): QaoaSearchResult {
  const layers = options.layers ?? 1; const gridPoints = options.gridPoints ?? 9;
  const gammaRange = options.gammaRange ?? [0, Math.PI]; const betaRange = options.betaRange ?? [0, Math.PI / 2];
  if (!Number.isInteger(layers) || layers < 1 || layers > 2) throw new RangeError("Grid search supports one or two QAOA layers to keep browser computation bounded.");
  if (!Number.isInteger(gridPoints) || gridPoints < 2 || gridPoints > 20) throw new RangeError("gridPoints must be 2..20.");
  if (graph.vertexCount > 12 || gridPoints ** (2 * layers) > 5000) throw new RangeError("This grid would be too large for an interactive browser run; reduce graph size, layers, or gridPoints.");
  const linspace = ([start, stop]: [number, number]) => Array.from({ length: gridPoints }, (_, index) => start + (stop - start) * index / (gridPoints - 1));
  const gammaValues = linspace(gammaRange); const betaValues = linspace(betaRange); const history: QaoaSearchPoint[] = [];
  const exactMaxCut = bruteForceMaxCut(graph).bestValue; let best: QaoaSearchPoint | null = null;
  const visit = (gammas: number[], betas: number[], depth: number) => {
    if (depth === layers) {
      const parameters = { gammas: [...gammas], betas: [...betas] };
      const expectedCut = evaluateQaoaParameters(graph, parameters).expectedCut;
      const point = { parameters, expectedCut, approximationRatio: exactMaxCut === 0 ? 1 : expectedCut / exactMaxCut };
      history.push(point); if (!best || point.expectedCut > best.expectedCut) best = point;
      return;
    }
    for (const gamma of gammaValues) for (const beta of betaValues) visit([...gammas, gamma], [...betas, beta], depth + 1);
  };
  visit([], [], 0);
  return { best: best!, evaluations: history.length, history, exactMaxCut };
}
export function qaoaHistoryCsv(result: QaoaSearchResult): string {
  const header = ["evaluation", "expected_cut", "approximation_ratio", ...Array.from({ length: result.best.parameters.gammas.length }, (_, i) => `gamma_${i + 1}`), ...Array.from({ length: result.best.parameters.betas.length }, (_, i) => `beta_${i + 1}`)].join(",");
  const rows = result.history.map((point, index) => [index + 1, point.expectedCut, point.approximationRatio, ...point.parameters.gammas, ...point.parameters.betas].join(","));
  return `${[header, ...rows].join("\n")}\n`;
}
