// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { complex } from "../advanced/complex";
import type { CircuitDefinition } from "./types";
import { createBasisState } from "./statevector";
import { applyGateSequence } from "./gates";
import { expectPauli } from "./observables";

export interface BlochInputOutput { input: [number, number, number]; output: [number, number, number]; label: string; }
export interface ProcessTomographyReport { transferMatrix: number[][]; translation: number[]; samples: BlochInputOutput[]; unital: boolean; tracePreservingByConstruction: true; }
function prepareBlochEigenstate(axis: "X" | "Y" | "Z", sign: 1 | -1) {
  if (axis === "Z") return sign === 1 ? createBasisState(1, "0") : createBasisState(1, "1");
  if (axis === "X") return [complex(1 / Math.sqrt(2)), complex(sign / Math.sqrt(2))];
  return [complex(1 / Math.sqrt(2)), complex(0, sign / Math.sqrt(2))];
}
function blochOf(state: ReturnType<typeof createBasisState>): [number, number, number] {
  return [expectPauli(state, 1, "X"), expectPauli(state, 1, "Y"), expectPauli(state, 1, "Z")];
}
/** Single-qubit process tomography from the six cardinal pure-state inputs. */
export function singleQubitProcessTomography(circuit: CircuitDefinition): ProcessTomographyReport {
  if (circuit.qubitCount !== 1) throw new Error("This process tomography routine is for single-qubit circuits.");
  if (circuit.operations.some((operation) => operation.gate === "MEASURE")) throw new Error("Process tomography requires a coherent circuit without measurements.");
  const samples: BlochInputOutput[] = [];
  const axes = ["X", "Y", "Z"] as const;
  for (const axis of axes) for (const sign of [1, -1] as const) {
    const inputState = prepareBlochEigenstate(axis, sign);
    const outputState = applyGateSequence(inputState, 1, circuit.operations);
    const input = blochOf(inputState); const output = blochOf(outputState);
    samples.push({ input, output, label: `${sign > 0 ? "+" : "−"}${axis}` });
  }
  const transferMatrix = Array.from({ length: 3 }, (_, outputAxis) => Array.from({ length: 3 }, (_, inputAxis) => {
    const positive = samples.find((sample) => sample.label === `+${axes[inputAxis]}`)!;
    const negative = samples.find((sample) => sample.label === `−${axes[inputAxis]}`)!;
    return (positive.output[outputAxis] - negative.output[outputAxis]) / 2;
  }));
  const translation = Array.from({ length: 3 }, (_, outputAxis) => axes.reduce((sum, axis) => {
    const positive = samples.find((sample) => sample.label === `+${axis}`)!;
    const negative = samples.find((sample) => sample.label === `−${axis}`)!;
    return sum + (positive.output[outputAxis] + negative.output[outputAxis]) / 6;
  }, 0));
  return { transferMatrix, translation, samples, unital: translation.every((value) => Math.abs(value) < 1e-8), tracePreservingByConstruction: true };
}
export function applyBlochTransfer(report: ProcessTomographyReport, input: [number, number, number]): [number, number, number] {
  return report.transferMatrix.map((row, index) => row.reduce((sum, value, column) => sum + value * input[column], report.translation[index])) as [number, number, number];
}
export function averageGateFidelityFromTransfer(report: ProcessTomographyReport): number {
  const traceLinear = report.transferMatrix[0][0] + report.transferMatrix[1][1] + report.transferMatrix[2][2];
  return Math.max(0, Math.min(1, (3 + traceLinear) / 6));
}
export function processTomographyMarkdown(report: ProcessTomographyReport): string {
  return ["# Single-qubit process tomography", "", "Transfer matrix (Bloch representation):", ...report.transferMatrix.map((row) => `- [${row.map((v) => v.toFixed(6)).join(", ")}]`), "", `Translation: [${report.translation.map((v) => v.toFixed(6)).join(", ")}]`, `Unital: ${report.unital ? "yes" : "no"}`, `Average gate fidelity to identity (unadjusted): ${averageGateFidelityFromTransfer(report).toFixed(6)}`, "", "This report is a numerical ideal-simulator characterization, not hardware process tomography."].join("\n");
}
