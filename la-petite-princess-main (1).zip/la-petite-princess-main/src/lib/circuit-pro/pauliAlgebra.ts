// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
export type PauliSymbol = "I" | "X" | "Y" | "Z";
export interface PauliProduct { paulis: string; phase: 1 | -1 | "i" | "-i"; }
export interface SymplecticPauli { x: number[]; z: number[]; phase: 1 | -1 | "i" | "-i"; }
const PRODUCT: Record<PauliSymbol, Record<PauliSymbol, PauliProduct["phase"]>> = {
  I: { I: 1, X: 1, Y: 1, Z: 1 },
  X: { I: 1, X: 1, Y: "i", Z: "-i" },
  Y: { I: 1, X: "-i", Y: 1, Z: "i" },
  Z: { I: 1, X: "i", Y: "-i", Z: 1 },
};
function phaseMultiply(a: PauliProduct["phase"], b: PauliProduct["phase"]): PauliProduct["phase"] {
  const map: Record<string, [number, number]> = { "1": [1, 0], "-1": [-1, 0], i: [0, 1], "-i": [0, -1] };
  const first = map[String(a)]; const second = map[String(b)]; const re = first[0] * second[0] - first[1] * second[1]; const im = first[0] * second[1] + first[1] * second[0];
  if (re === 1 && im === 0) return 1; if (re === -1 && im === 0) return -1; if (re === 0 && im === 1) return "i"; return "-i";
}
function validatePauliString(value: string): asserts value is string { if (!value.length || /[^IXYZ]/.test(value)) throw new Error("Pauli strings must be non-empty and contain only I, X, Y or Z."); }
export function multiplyPauliStrings(first: string, second: string): PauliProduct {
  validatePauliString(first); validatePauliString(second); if (first.length !== second.length) throw new Error("Pauli strings must have equal lengths.");
  let phase: PauliProduct["phase"] = 1; let paulis = "";
  for (let index = 0; index < first.length; index += 1) { const a = first[index] as PauliSymbol; const b = second[index] as PauliSymbol; phase = phaseMultiply(phase, PRODUCT[a][b]);
    if (a === "I") paulis += b; else if (b === "I" || a === b) paulis += a === b ? "I" : a; else paulis += ({ XY: "Z", XZ: "Y", YX: "Z", YZ: "X", ZX: "Y", ZY: "X" } as Record<string, string>)[a + b];
  }
  return { paulis, phase };
}
export function pauliStringsCommuteSymplectic(first: string, second: string): boolean {
  validatePauliString(first); validatePauliString(second); if (first.length !== second.length) throw new Error("Pauli strings must have equal lengths.");
  let parity = 0; for (let index = 0; index < first.length; index += 1) if (first[index] !== "I" && second[index] !== "I" && first[index] !== second[index]) parity ^= 1;
  return parity === 0;
}
export function pauliToSymplectic(paulis: string, phase: SymplecticPauli["phase"] = 1): SymplecticPauli {
  validatePauliString(paulis); const x: number[] = []; const z: number[] = [];
  for (const pauli of paulis) { x.push(Number(pauli === "X" || pauli === "Y")); z.push(Number(pauli === "Z" || pauli === "Y")); }
  return { x, z, phase };
}
export function symplecticToPauli(value: SymplecticPauli): PauliProduct {
  if (value.x.length !== value.z.length || !value.x.length || [...value.x, ...value.z].some((bit) => bit !== 0 && bit !== 1)) throw new Error("Invalid binary symplectic vector.");
  const paulis = value.x.map((x, index) => x ? (value.z[index] ? "Y" : "X") : (value.z[index] ? "Z" : "I")).join("");
  return { paulis, phase: value.phase };
}
export function symplecticProduct(first: SymplecticPauli, second: SymplecticPauli): 0 | 1 {
  if (first.x.length !== second.x.length || first.z.length !== second.z.length || first.x.length !== first.z.length) throw new Error("Symplectic vectors must have equal dimensions.");
  return (first.x.reduce((sum, bit, index) => sum ^ (bit & second.z[index]), 0) ^ first.z.reduce((sum, bit, index) => sum ^ (bit & second.x[index]), 0)) as 0 | 1;
}
export function pauliWeight(paulis: string): number { validatePauliString(paulis); return [...paulis].filter((symbol) => symbol !== "I").length; }
export function pauliSupport(paulis: string): number[] { validatePauliString(paulis); return [...paulis].flatMap((symbol, index) => symbol === "I" ? [] : [index]); }
export function enumeratePauliStrings(qubitCount: number, maximumWeight = qubitCount): string[] {
  if (!Number.isInteger(qubitCount) || qubitCount < 1 || qubitCount > 8 || !Number.isInteger(maximumWeight) || maximumWeight < 0 || maximumWeight > qubitCount) throw new RangeError("Pauli enumeration supports 1..8 qubits and a valid weight bound.");
  const output: string[] = []; const alphabet: PauliSymbol[] = ["I", "X", "Y", "Z"];
  const visit = (prefix: string) => { if (prefix.length === qubitCount) { if (pauliWeight(prefix) <= maximumWeight) output.push(prefix); return; } for (const symbol of alphabet) visit(prefix + symbol); };
  visit(""); return output;
}
export function commutationMatrix(paulis: string[]): number[][] {
  if (!paulis.length) return [];
  return paulis.map((first) => paulis.map((second) => Number(!pauliStringsCommuteSymplectic(first, second))));
}
export function pauliGroupProduct(factors: string[]): PauliProduct {
  if (!factors.length) throw new Error("At least one Pauli factor is required.");
  let product: PauliProduct = { paulis: "I".repeat(factors[0].length), phase: 1 };
  for (const factor of factors) { const next = multiplyPauliStrings(product.paulis, factor); product = { paulis: next.paulis, phase: phaseMultiply(product.phase, next.phase) }; }
  return product;
}
