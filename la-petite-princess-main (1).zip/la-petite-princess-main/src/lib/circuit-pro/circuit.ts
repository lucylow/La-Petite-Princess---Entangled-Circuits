// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import type { CircuitDefinition, CircuitOperation, CircuitValidationIssue, GateName, OperationParameters } from "./types";

let nextId = 1;
export function createOperation(
  gate: GateName,
  targets: number | number[],
  controls: number[] = [],
  params?: OperationParameters,
  note?: string,
): CircuitOperation {
  const targetList = Array.isArray(targets) ? [...targets] : [targets];
  return { id: `op-${nextId++}`, gate, targets: targetList, ...(controls.length ? { controls: [...controls] } : {}), ...(params ? { params: { ...params } } : {}), ...(note ? { note } : {}) };
}
export function createCircuit(name: string, qubitCount: number, classicalBitCount = qubitCount, operations: CircuitOperation[] = []): CircuitDefinition {
  return { id: `circuit-${nextId++}`, name, qubitCount, classicalBitCount, operations: operations.map(cloneOperation), version: 1 };
}
export function cloneOperation(operation: CircuitOperation): CircuitOperation {
  return { ...operation, targets: [...operation.targets], ...(operation.controls ? { controls: [...operation.controls] } : {}), ...(operation.params ? { params: { ...operation.params } } : {}) };
}
export function cloneCircuit(circuit: CircuitDefinition): CircuitDefinition {
  return { ...circuit, operations: circuit.operations.map(cloneOperation) };
}
export function appendOperation(circuit: CircuitDefinition, operation: CircuitOperation): CircuitDefinition {
  return { ...circuit, operations: [...circuit.operations, cloneOperation(operation)] };
}
export function removeOperation(circuit: CircuitDefinition, operationId: string): CircuitDefinition {
  return { ...circuit, operations: circuit.operations.filter((operation) => operation.id !== operationId) };
}
export function moveOperation(circuit: CircuitDefinition, operationId: string, destinationIndex: number): CircuitDefinition {
  const operations = [...circuit.operations];
  const sourceIndex = operations.findIndex((operation) => operation.id === operationId);
  if (sourceIndex < 0) throw new Error(`Operation ${operationId} does not exist.`);
  if (!Number.isInteger(destinationIndex) || destinationIndex < 0 || destinationIndex >= operations.length) throw new RangeError("Destination index is outside the operation list.");
  const [item] = operations.splice(sourceIndex, 1);
  operations.splice(destinationIndex, 0, item);
  return { ...circuit, operations };
}
export function replaceOperation(circuit: CircuitDefinition, operationId: string, replacement: CircuitOperation): CircuitDefinition {
  if (!circuit.operations.some((operation) => operation.id === operationId)) throw new Error(`Operation ${operationId} does not exist.`);
  return { ...circuit, operations: circuit.operations.map((operation) => operation.id === operationId ? cloneOperation(replacement) : operation) };
}

const SINGLE = new Set<GateName>(["I", "X", "Y", "Z", "H", "S", "SDG", "T", "TDG", "SX", "SXDG", "RX", "RY", "RZ", "U3"]);
const CONTROLLED = new Set<GateName>(["CX", "CY", "CZ", "CH", "CP", "CRX", "CRY", "CRZ"]);
const MULTI = new Set<GateName>(["SWAP", "ISWAP", "CCX", "CSWAP"]);
const DIRECTIVES = new Set<GateName>(["BARRIER", "MEASURE"]);
function issue(severity: CircuitValidationIssue["severity"], code: string, message: string, operation: CircuitOperation, operationIndex: number): CircuitValidationIssue {
  return { severity, code, message, operationId: operation.id, operationIndex };
}

export function validateCircuit(circuit: CircuitDefinition, maxQubits = 10): CircuitValidationIssue[] {
  const issues: CircuitValidationIssue[] = [];
  if (!Number.isInteger(circuit.qubitCount) || circuit.qubitCount < 1 || circuit.qubitCount > maxQubits) {
    issues.push({ severity: "error", code: "INVALID_QUBIT_COUNT", message: `Qubit count must be between 1 and ${maxQubits}.` });
    return issues;
  }
  if (!Number.isInteger(circuit.classicalBitCount) || circuit.classicalBitCount < 0 || circuit.classicalBitCount > 64) {
    issues.push({ severity: "error", code: "INVALID_CLASSICAL_COUNT", message: "Classical bit count must be an integer from 0 to 64." });
  }
  const ids = new Set<string>();
  circuit.operations.forEach((operation, index) => {
    if (!operation.id.trim()) issues.push(issue("error", "MISSING_OPERATION_ID", "Every operation needs a stable ID.", operation, index));
    if (ids.has(operation.id)) issues.push(issue("error", "DUPLICATE_OPERATION_ID", `Duplicate operation ID: ${operation.id}.`, operation, index));
    ids.add(operation.id);
    if (!Array.isArray(operation.targets)) { issues.push(issue("error", "INVALID_TARGETS", "Targets must be an array.", operation, index)); return; }
    const targets = operation.targets;
    const controls = operation.controls ?? [];
    const wires = [...targets, ...controls];
    if (wires.some((wire) => !Number.isInteger(wire) || wire < 0 || wire >= circuit.qubitCount)) {
      issues.push(issue("error", "QUBIT_OUT_OF_RANGE", "An operation references a qubit outside the circuit.", operation, index));
    }
    if (new Set(wires).size !== wires.length) issues.push(issue("error", "DUPLICATE_WIRE", "An operation cannot use the same qubit as multiple controls or targets.", operation, index));
    if (SINGLE.has(operation.gate) && (targets.length !== 1 || controls.length !== 0)) issues.push(issue("error", "INVALID_GATE_ARITY", `${operation.gate} requires one target and no controls.`, operation, index));
    if (CONTROLLED.has(operation.gate) && (targets.length !== 1 || controls.length < 1)) issues.push(issue("error", "INVALID_GATE_ARITY", `${operation.gate} requires one target and at least one control.`, operation, index));
    if (operation.gate === "CCX" && (targets.length !== 1 || controls.length !== 2)) issues.push(issue("error", "INVALID_GATE_ARITY", "CCX requires two controls and one target.", operation, index));
    if (operation.gate === "CSWAP" && (targets.length !== 2 || controls.length !== 1)) issues.push(issue("error", "INVALID_GATE_ARITY", "CSWAP requires one control and two targets.", operation, index));
    if ((operation.gate === "SWAP" || operation.gate === "ISWAP") && (targets.length !== 2 || controls.length !== 0)) issues.push(issue("error", "INVALID_GATE_ARITY", `${operation.gate} requires two targets and no controls.`, operation, index));
    if (operation.gate === "BARRIER" && targets.length === 0) issues.push(issue("warning", "EMPTY_BARRIER", "A barrier with no target wires has no visible effect.", operation, index));
    if (operation.gate === "MEASURE") {
      if (targets.length !== 1 || controls.length) issues.push(issue("error", "INVALID_MEASUREMENT", "MEASURE requires exactly one target and no controls.", operation, index));
      if (operation.classicalBit === undefined || !Number.isInteger(operation.classicalBit) || operation.classicalBit < 0 || operation.classicalBit >= circuit.classicalBitCount) issues.push(issue("error", "INVALID_CLASSICAL_TARGET", "Measurement needs a valid classical-bit destination.", operation, index));
    }
    const params = operation.params;
    if (["RX", "RY", "RZ", "CRX", "CRY", "CRZ", "CP"].includes(operation.gate) && !Number.isFinite(params?.theta)) issues.push(issue("error", "MISSING_ROTATION", `${operation.gate} requires a finite theta parameter in radians.`, operation, index));
    if (operation.gate === "U3" && [params?.theta, params?.phi, params?.lambda].some((value) => !Number.isFinite(value))) issues.push(issue("error", "MISSING_U3_PARAMETERS", "U3 requires finite theta, phi and lambda parameters.", operation, index));
  });
  if (circuit.operations.filter((operation) => operation.gate === "MEASURE").length > circuit.classicalBitCount) issues.push({ severity: "warning", code: "MANY_MEASUREMENTS", message: "There are more measurement operations than classical bits; destinations may be reused." });
  return issues;
}
export function hasCircuitErrors(issues: CircuitValidationIssue[]): boolean { return issues.some((item) => item.severity === "error"); }
export function assertValidCircuit(circuit: CircuitDefinition, maxQubits = 10): void {
  const errors = validateCircuit(circuit, maxQubits).filter((item) => item.severity === "error");
  if (errors.length) throw new Error(errors.map((item) => item.message).join("\n"));
}
