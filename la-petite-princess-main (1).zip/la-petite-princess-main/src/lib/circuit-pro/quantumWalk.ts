// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import type { CircuitDefinition, CircuitOperation } from "./types";
import { createCircuit, createOperation } from "./circuit";
import { simulateCircuit } from "./simulator";
import { probabilityMap } from "./statevector";

export interface WalkPositionProbability { position: number; bitstring: string; probability: number; }
export interface WalkSummary { positions: WalkPositionProbability[]; meanPosition: number; variance: number; mostLikelyPosition: number; }
function appendControlledFlip(operations: CircuitOperation[], target: number, controls: number[], note?: string): void {
  operations.push(controls.length ? createOperation("CX", target, controls, undefined, note) : createOperation("X", target, [], undefined, note));
}
function appendConditionalIncrement(operations: CircuitOperation[], coin: number, positionWires: number[]): void {
  // Coin=1 selects +1. Higher bits flip before lower bits so carry conditions use the old lower bits.
  for (let bit = positionWires.length - 1; bit >= 0; bit -= 1) appendControlledFlip(operations, positionWires[bit], [coin, ...positionWires.slice(0, bit)], "Conditional increment with carry");
}
function appendConditionalDecrement(operations: CircuitOperation[], coin: number, positionWires: number[]): void {
  // Coin=0 is converted to a positive control. Lower zero-controls are temporarily inverted.
  operations.push(createOperation("X", coin));
  for (let bit = positionWires.length - 1; bit >= 0; bit -= 1) {
    const lower = positionWires.slice(0, bit);
    lower.forEach((q) => operations.push(createOperation("X", q)));
    appendControlledFlip(operations, positionWires[bit], [coin, ...lower], "Conditional decrement with borrow");
    [...lower].reverse().forEach((q) => operations.push(createOperation("X", q)));
  }
  operations.push(createOperation("X", coin));
}
/** One-dimensional coined discrete-time quantum walk on a periodic position register. */
export function quantumWalkLineCircuit(positionQubits = 3, steps = 3, startingPosition = 0): CircuitDefinition {
  if (!Number.isInteger(positionQubits) || positionQubits < 1 || positionQubits > 6) throw new RangeError("Position register must contain 1..6 qubits.");
  if (!Number.isInteger(steps) || steps < 1 || steps > 20) throw new RangeError("Walk steps must be 1..20.");
  const positionCount = 2 ** positionQubits;
  if (!Number.isInteger(startingPosition) || startingPosition < 0 || startingPosition >= positionCount) throw new RangeError("Starting position is outside the position register.");
  const coin = 0; const positionWires = Array.from({ length: positionQubits }, (_, q) => q + 1); const operations: CircuitOperation[] = [];
  for (let bit = 0; bit < positionQubits; bit += 1) if ((startingPosition >> bit) & 1) operations.push(createOperation("X", positionWires[bit]));
  for (let step = 0; step < steps; step += 1) {
    operations.push(createOperation("H", coin, [], undefined, `Hadamard coin at step ${step + 1}`));
    appendConditionalIncrement(operations, coin, positionWires);
    appendConditionalDecrement(operations, coin, positionWires);
  }
  const circuit = createCircuit(`Quantum walk · ${steps} steps`, positionQubits + 1, positionQubits + 1, operations);
  circuit.description = "A coined walk on a periodic binary position register. Position wraps modulo 2^n.";
  return circuit;
}
export function summarizeQuantumWalk(circuit: CircuitDefinition): WalkSummary {
  if (circuit.qubitCount < 2) throw new Error("A coined walk needs one coin qubit and at least one position qubit.");
  const state = simulateCircuit(circuit).state; const raw = probabilityMap(state, circuit.qubitCount, false);
  const positionCount = 2 ** (circuit.qubitCount - 1); const positions = Array.from({ length: positionCount }, (_, position) => {
    let probability = 0;
    for (const [bitstring, value] of Object.entries(raw)) {
      // Q0 is the coin and therefore the right-most character in display-order bitstrings.
      const positionBits = bitstring.slice(0, -1);
      if (Number.parseInt(positionBits, 2) === position) probability += value;
    }
    return { position, bitstring: position.toString(2).padStart(circuit.qubitCount - 1, "0"), probability };
  });
  const meanPosition = positions.reduce((sum, item) => sum + item.position * item.probability, 0);
  const variance = positions.reduce((sum, item) => sum + (item.position - meanPosition) ** 2 * item.probability, 0);
  const mostLikelyPosition = [...positions].sort((a, b) => b.probability - a.probability)[0]?.position ?? 0;
  return { positions, meanPosition, variance, mostLikelyPosition };
}
export function quantumWalkExpectation(summary: WalkSummary): { mean: number; standardDeviation: number } {
  return { mean: summary.meanPosition, standardDeviation: Math.sqrt(summary.variance) };
}
