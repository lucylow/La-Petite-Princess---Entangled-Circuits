// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { createOperation } from "./circuit";
import { decomposeOperation } from "./synthesis";
import type { CircuitDefinition, CircuitOperation, GateName } from "./types";

export interface TranspileOptions { basis?: GateName[]; preserveBarriers?: boolean; maxExpansionDepth?: number; }
export interface TranspileReport {
  circuit: CircuitDefinition; originalGateCount: number; outputGateCount: number;
  warnings: string[]; globalPhaseRadians: number; exactUpToGlobalPhase: boolean;
}
const DEFAULT_BASIS: GateName[] = ["H", "X", "SX", "RZ", "CX", "MEASURE", "BARRIER"];
function createStepOperation(step: ReturnType<typeof decomposeOperation>["steps"][number], id: string): CircuitOperation {
  return { id, gate: step.gate, targets: [...step.targets], ...(step.controls ? { controls: [...step.controls] } : {}), ...(step.params ? { params: { ...step.params } } : {}), note: step.note };
}

/** Recursively reduce a circuit to the selected educational native basis. */
export function transpileCircuit(circuit: CircuitDefinition, options: TranspileOptions = {}): TranspileReport {
  const basis = new Set(options.basis ?? DEFAULT_BASIS); const warnings: string[] = [];
  const maxDepth = options.maxExpansionDepth ?? 8; const output: CircuitOperation[] = [];
  let globalPhaseRadians = 0; let exactUpToGlobalPhase = true;
  const expand = (operation: CircuitOperation, depth: number, ancestors: Set<string>) => {
    if (basis.has(operation.gate)) { output.push({ ...operation, id: `${operation.id}-native-${output.length}` }); return; }
    if (operation.gate === "BARRIER") { if (options.preserveBarriers !== false) output.push(operation); return; }
    if (depth >= maxDepth || ancestors.has(operation.gate)) {
      warnings.push(`Expansion stopped for ${operation.gate}; operation was retained.`); output.push(operation); return;
    }
    try {
      const decomposition = decomposeOperation(operation);
      if (decomposition.steps.length === 1 && decomposition.steps[0].gate === operation.gate) {
        warnings.push(`No lower-level decomposition available for ${operation.gate}; operation was retained.`); output.push(operation); return;
      }
      globalPhaseRadians += decomposition.globalPhase;
      exactUpToGlobalPhase = exactUpToGlobalPhase && decomposition.exactUpToGlobalPhase;
      const nextAncestors = new Set(ancestors); nextAncestors.add(operation.gate);
      decomposition.steps.forEach((step, index) => expand(createStepOperation(step, `${operation.id}-d${depth}-${index}`), depth + 1, nextAncestors));
    } catch (error) {
      warnings.push(error instanceof Error ? error.message : `Unable to decompose ${operation.gate}.`); output.push(operation);
    }
  };
  circuit.operations.forEach((operation) => expand(operation, 0, new Set()));
  const result: CircuitDefinition = { ...circuit, id: `${circuit.id}-transpiled`, name: `${circuit.name} (transpiled)`, operations: output };
  return { circuit: result, originalGateCount: circuit.operations.length, outputGateCount: output.length, warnings: [...new Set(warnings)], globalPhaseRadians, exactUpToGlobalPhase };
}
