// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import type { CircuitDefinition, CircuitRunOptions, CircuitRunReport, ShotResult } from "./types";
import { simulateCircuit, runCircuitShots } from "./simulator";
import { runNoisyShots } from "./noise";
import { circuitMetrics } from "./metrics";
import { probabilityMap } from "./statevector";

export type BackendStatus = "ready" | "busy" | "offline" | "unavailable";
export interface BackendCapabilities { maxQubits: number; supportsShots: boolean; supportsNoiseModel: boolean; supportsDynamicCircuits: boolean; supportsDensityMatrix: boolean; providerName: string; }
export interface BackendDescriptor { id: string; name: string; description: string; status: BackendStatus; capabilities: BackendCapabilities; educationalOnly?: boolean; }
export interface BackendRunRequest { circuit: CircuitDefinition; shots?: number; seed?: number; noise?: CircuitRunOptions["noise"]; }
export interface BackendRunResponse { backend: BackendDescriptor; report: CircuitRunReport; shots?: ShotResult; startedAt: string; completedAt: string; }
export interface QuantumBackend { descriptor: BackendDescriptor; run(request: BackendRunRequest): Promise<BackendRunResponse>; }
export const LOCAL_STATEVECTOR_BACKEND: BackendDescriptor = {
  id: "local-statevector", name: "Local state-vector simulator", description: "Runs ideal circuit simulation in the browser or local JavaScript runtime.", status: "ready",
  capabilities: { maxQubits: 10, supportsShots: true, supportsNoiseModel: true, supportsDynamicCircuits: false, supportsDensityMatrix: false, providerName: "La Petite Princess" }, educationalOnly: true,
};
export class LocalQuantumBackend implements QuantumBackend {
  descriptor = LOCAL_STATEVECTOR_BACKEND;
  async run(request: BackendRunRequest): Promise<BackendRunResponse> {
    const startedAt = new Date().toISOString();
    const state = simulateCircuit(request.circuit).state;
    const report: CircuitRunReport = { circuit: request.circuit, metrics: circuitMetrics(request.circuit), idealState: state, idealProbabilities: probabilityMap(state, request.circuit.qubitCount, false), warnings: [] };
    let shots: ShotResult | undefined;
    if (request.shots) shots = request.noise ? runNoisyShots(request.circuit, request.shots, request.noise, request.seed) : runCircuitShots(request.circuit, request.shots, request.seed);
    return { backend: this.descriptor, report, ...(shots ? { shots } : {}), startedAt, completedAt: new Date().toISOString() };
  }
}
/** Adapter contract for a future IBM Quantum / remote QPU integration. No credentials or network calls are performed here. */
export interface RemoteBackendAdapter {
  descriptor: BackendDescriptor;
  submit(circuit: CircuitDefinition, shots: number): Promise<{ jobId: string }>;
  status(jobId: string): Promise<"queued" | "running" | "completed" | "failed">;
  results(jobId: string): Promise<ShotResult>;
}
export class BackendRegistry {
  private backends = new Map<string, QuantumBackend>();
  register(backend: QuantumBackend): void { if (this.backends.has(backend.descriptor.id)) throw new Error(`Backend ${backend.descriptor.id} is already registered.`); this.backends.set(backend.descriptor.id, backend); }
  get(id: string): QuantumBackend { const backend = this.backends.get(id); if (!backend) throw new Error(`Backend ${id} is not registered.`); return backend; }
  list(): BackendDescriptor[] { return [...this.backends.values()].map((backend) => backend.descriptor); }
  remove(id: string): boolean { return this.backends.delete(id); }
}
export function backendCompatibility(backend: BackendDescriptor, circuit: CircuitDefinition): string[] {
  const errors: string[] = [];
  if (circuit.qubitCount > backend.capabilities.maxQubits) errors.push(`Circuit uses ${circuit.qubitCount} qubits; backend maximum is ${backend.capabilities.maxQubits}.`);
  if (!backend.capabilities.supportsShots && circuit.operations.some((operation) => operation.gate === "MEASURE")) errors.push("Backend does not support sampled measurements.");
  return errors;
}
