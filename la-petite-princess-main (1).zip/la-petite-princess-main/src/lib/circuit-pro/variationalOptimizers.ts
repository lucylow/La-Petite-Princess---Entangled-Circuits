// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
export type ObjectiveFunction = (parameters: number[]) => number;
export interface OptimizerPoint { iteration: number; value: number; parameters: number[]; gradientNorm: number; accepted: boolean; }
export interface OptimizerResult { parameters: number[]; value: number; history: OptimizerPoint[]; converged: boolean; evaluations: number; method: "adam" | "spsa" | "coordinate"; }
export interface AdamOptions { learningRate?: number; beta1?: number; beta2?: number; epsilon?: number; iterations?: number; tolerance?: number; }
export interface SpsaOptions { a?: number; c?: number; alpha?: number; gamma?: number; iterations?: number; seed?: number; tolerance?: number; }
function validateVector(parameters: number[]): void { if (!parameters.length || parameters.some((value) => !Number.isFinite(value))) throw new Error("Optimizer parameters must be a non-empty finite vector."); }
function norm(values: number[]): number { return Math.sqrt(values.reduce((sum, value) => sum + value * value, 0)); }
function evaluate(objective: ObjectiveFunction, parameters: number[]): number { const result = objective([...parameters]); if (!Number.isFinite(result)) throw new Error("Objective returned a non-finite value."); return result; }
export function centralFiniteDifference(objective: ObjectiveFunction, parameters: number[], step = 1e-5): number[] {
  validateVector(parameters); if (!Number.isFinite(step) || step <= 0) throw new RangeError("step must be positive.");
  return parameters.map((_, index) => {
    const plus = [...parameters]; const minus = [...parameters]; plus[index] += step; minus[index] -= step;
    return (evaluate(objective, plus) - evaluate(objective, minus)) / (2 * step);
  });
}
export function optimizeWithAdam(objective: ObjectiveFunction, initial: number[], options: AdamOptions = {}): OptimizerResult {
  validateVector(initial);
  const learningRate = options.learningRate ?? 0.05; const beta1 = options.beta1 ?? 0.9; const beta2 = options.beta2 ?? 0.999;
  const epsilon = options.epsilon ?? 1e-8; const iterations = options.iterations ?? 300; const tolerance = options.tolerance ?? 1e-8;
  if (!(learningRate > 0) || !(epsilon > 0) || ![beta1, beta2].every((v) => v >= 0 && v < 1) || !Number.isInteger(iterations) || iterations < 1) throw new Error("Invalid Adam options.");
  let parameters = [...initial]; let first = initial.map(() => 0); let second = initial.map(() => 0); let evaluations = 1;
  let value = evaluate(objective, parameters); let best = { parameters: [...parameters], value }; const history: OptimizerPoint[] = [];
  let converged = false;
  for (let iteration = 1; iteration <= iterations; iteration += 1) {
    const gradient = centralFiniteDifference(objective, parameters); evaluations += 2 * parameters.length;
    const gradientNorm = norm(gradient);
    if (gradientNorm < tolerance) { converged = true; history.push({ iteration, value, parameters: [...parameters], gradientNorm, accepted: true }); break; }
    first = first.map((m, i) => beta1 * m + (1 - beta1) * gradient[i]);
    second = second.map((v, i) => beta2 * v + (1 - beta2) * gradient[i] ** 2);
    const mHat = first.map((v) => v / (1 - beta1 ** iteration)); const vHat = second.map((v) => v / (1 - beta2 ** iteration));
    const candidate = parameters.map((value, i) => value - learningRate * mHat[i] / (Math.sqrt(vHat[i]) + epsilon));
    const candidateValue = evaluate(objective, candidate); evaluations += 1;
    const accepted = candidateValue <= value;
    if (accepted) { parameters = candidate; value = candidateValue; }
    if (value < best.value) best = { parameters: [...parameters], value };
    history.push({ iteration, value, parameters: [...parameters], gradientNorm, accepted });
  }
  return { parameters: best.parameters, value: best.value, history, converged, evaluations, method: "adam" };
}
export function optimizeWithSpsa(objective: ObjectiveFunction, initial: number[], options: SpsaOptions = {}): OptimizerResult {
  validateVector(initial);
  const a = options.a ?? 0.2; const c = options.c ?? 0.1; const alpha = options.alpha ?? 0.602; const gamma = options.gamma ?? 0.101;
  const iterations = options.iterations ?? 500; const tolerance = options.tolerance ?? 1e-8;
  if (!(a > 0) || !(c > 0) || !Number.isInteger(iterations) || iterations < 1) throw new Error("Invalid SPSA options.");
  let seed = (options.seed ?? 1) >>> 0; const random = () => { seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0; return seed / 4294967296; };
  let parameters = [...initial]; let value = evaluate(objective, parameters); let best = { parameters: [...parameters], value }; let evaluations = 1; let converged = false;
  const history: OptimizerPoint[] = [];
  for (let iteration = 0; iteration < iterations; iteration += 1) {
    const ak = a / ((iteration + 1 + 10) ** alpha); const ck = c / ((iteration + 1) ** gamma);
    const delta = parameters.map(() => random() < 0.5 ? -1 : 1);
    const plus = parameters.map((v, i) => v + ck * delta[i]); const minus = parameters.map((v, i) => v - ck * delta[i]);
    const yPlus = evaluate(objective, plus); const yMinus = evaluate(objective, minus); evaluations += 2;
    const gradient = delta.map((sign) => (yPlus - yMinus) / (2 * ck * sign)); const gradientNorm = norm(gradient);
    const candidate = parameters.map((v, i) => v - ak * gradient[i]); const candidateValue = evaluate(objective, candidate); evaluations += 1;
    parameters = candidate; value = candidateValue;
    if (value < best.value) best = { parameters: [...parameters], value };
    history.push({ iteration: iteration + 1, value, parameters: [...parameters], gradientNorm, accepted: true });
    if (gradientNorm < tolerance) { converged = true; break; }
  }
  return { parameters: best.parameters, value: best.value, history, converged, evaluations, method: "spsa" };
}
export function coordinateDescent(objective: ObjectiveFunction, initial: number[], options: { step?: number; iterations?: number; shrink?: number; tolerance?: number } = {}): OptimizerResult {
  validateVector(initial);
  let step = options.step ?? 0.2; const iterations = options.iterations ?? 300; const shrink = options.shrink ?? 0.5; const tolerance = options.tolerance ?? 1e-7;
  if (!(step > 0) || !(shrink > 0 && shrink < 1) || !Number.isInteger(iterations) || iterations < 1) throw new Error("Invalid coordinate descent options.");
  let parameters = [...initial]; let value = evaluate(objective, parameters); let evaluations = 1; const history: OptimizerPoint[] = [];
  let converged = false;
  for (let iteration = 1; iteration <= iterations; iteration += 1) {
    let improved = false;
    for (let index = 0; index < parameters.length; index += 1) {
      let bestCandidate = [...parameters]; let bestValue = value;
      for (const direction of [-1, 1]) {
        const candidate = [...parameters]; candidate[index] += direction * step;
        const candidateValue = evaluate(objective, candidate); evaluations += 1;
        if (candidateValue < bestValue) { bestCandidate = candidate; bestValue = candidateValue; improved = true; }
      }
      parameters = bestCandidate; value = bestValue;
    }
    history.push({ iteration, value, parameters: [...parameters], gradientNorm: step, accepted: improved });
    if (!improved) step *= shrink;
    if (step < tolerance) { converged = true; break; }
  }
  return { parameters, value, history, converged, evaluations, method: "coordinate" };
}
