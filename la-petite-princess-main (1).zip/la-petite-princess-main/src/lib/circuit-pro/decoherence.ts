// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import type { ComplexMatrix } from "./types";
import { applyChannelToDensity } from "./channels";
import { densityDiagnostics } from "./density";

export interface RelaxationParameters { elapsedTime: number; t1: number; t2: number; }
export interface DecoherenceReport { densityMatrix: ComplexMatrix; amplitudeDampingProbability: number; phaseDampingProbability: number; coherenceFactor: number; diagnostics: ReturnType<typeof densityDiagnostics>; }
export function validateRelaxationParameters(parameters: RelaxationParameters): string[] {
  const errors: string[] = [];
  if (!Number.isFinite(parameters.elapsedTime) || parameters.elapsedTime < 0) errors.push("Elapsed time must be finite and non-negative.");
  if (!Number.isFinite(parameters.t1) || parameters.t1 <= 0) errors.push("T1 must be positive and finite.");
  if (!Number.isFinite(parameters.t2) || parameters.t2 <= 0) errors.push("T2 must be positive and finite.");
  if (parameters.t1 > 0 && parameters.t2 > 0 && parameters.t2 > 2 * parameters.t1 + 1e-12) errors.push("For the simple Markovian model, T2 must not exceed 2·T1.");
  return errors;
}
/** Apply an illustrative Markovian T1/T2 decay model to one qubit of a density matrix. */
export function applyT1T2Decoherence(rho: ComplexMatrix, qubitCount: number, target: number, parameters: RelaxationParameters): DecoherenceReport {
  const errors = validateRelaxationParameters(parameters);
  if (errors.length) throw new Error(errors.join("\n"));
  const { elapsedTime, t1, t2 } = parameters;
  const amplitudeDampingProbability = 1 - Math.exp(-elapsedTime / t1);
  const totalCoherence = Math.exp(-elapsedTime / t2);
  const amplitudeCoherence = Math.exp(-elapsedTime / (2 * t1));
  const pureDephasingFactor = amplitudeCoherence === 0 ? 0 : Math.min(1, totalCoherence / amplitudeCoherence);
  const phaseDampingProbability = 1 - pureDephasingFactor ** 2;
  let output = applyChannelToDensity(rho, qubitCount, target, "amplitude-damping", amplitudeDampingProbability);
  output = applyChannelToDensity(output, qubitCount, target, "phase-damping", phaseDampingProbability);
  return { densityMatrix: output, amplitudeDampingProbability, phaseDampingProbability, coherenceFactor: totalCoherence, diagnostics: densityDiagnostics(output) };
}
export function t1Population(time: number, initialExcitedPopulation = 1, equilibriumPopulation = 0, t1 = 1): number {
  if (![time, initialExcitedPopulation, equilibriumPopulation, t1].every(Number.isFinite) || time < 0 || t1 <= 0) throw new RangeError("Invalid T1 curve parameters.");
  return equilibriumPopulation + (initialExcitedPopulation - equilibriumPopulation) * Math.exp(-time / t1);
}
export function t2Coherence(time: number, initialCoherence = 1, t2 = 1): number {
  if (![time, initialCoherence, t2].every(Number.isFinite) || time < 0 || t2 <= 0) throw new RangeError("Invalid T2 curve parameters.");
  return initialCoherence * Math.exp(-time / t2);
}
export function relaxationCurve(t1: number, t2: number, maximumTime: number, points = 50): Array<{ time: number; excitedPopulation: number; coherence: number }> {
  if (![t1, t2, maximumTime].every((value) => Number.isFinite(value) && value > 0) || !Number.isInteger(points) || points < 2) throw new RangeError("Provide positive T1/T2/maxTime and at least two points.");
  if (t2 > 2 * t1 + 1e-12) throw new Error("Physical T2 must be ≤ 2·T1 in this model.");
  return Array.from({ length: points }, (_, index) => {
    const time = maximumTime * index / (points - 1);
    return { time, excitedPopulation: Math.exp(-time / t1), coherence: Math.exp(-time / t2) };
  });
}
