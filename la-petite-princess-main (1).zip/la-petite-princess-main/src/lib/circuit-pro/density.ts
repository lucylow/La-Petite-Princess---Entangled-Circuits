// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { cAdd, cConjugate, cMagnitudeSquared, cMul, cScale, complex, type Complex } from "../advanced/complex";
import type { ComplexMatrix, DensityMatrixResult } from "./types";
import { adjoint, identity, isHermitian, multiplyMatrices, partialTrace, trace, zeros } from "./matrix";
import { probabilities } from "./statevector";
import type { Matrix2 } from "./gates";

export function densityFromState(state: Complex[]): ComplexMatrix {
  const matrix = zeros(state.length, state.length);
  for (let row = 0; row < state.length; row += 1) for (let col = 0; col < state.length; col += 1) matrix.data[row][col] = cMul(state[row], cConjugate(state[col]));
  return matrix;
}
export function applyLocalOperatorToDensity(rho: ComplexMatrix, qubitCount: number, target: number, operator: Matrix2): ComplexMatrix {
  const full = embedSingleQubitOperator(qubitCount, target, operator);
  return multiplyMatrices(multiplyMatrices(full, rho), adjoint(full));
}
export function applyKrausChannel(rho: ComplexMatrix, qubitCount: number, target: number, operators: Matrix2[]): ComplexMatrix {
  if (rho.rows !== 2 ** qubitCount || rho.cols !== rho.rows) throw new Error("Density matrix dimension does not match the register.");
  if (!operators.length) throw new Error("A Kraus channel needs at least one operator.");
  const result = zeros(rho.rows, rho.cols);
  for (const operator of operators) {
    const full = embedSingleQubitOperator(qubitCount, target, operator);
    const term = multiplyMatrices(multiplyMatrices(full, rho), adjoint(full));
    for (let r = 0; r < result.rows; r += 1) for (let c = 0; c < result.cols; c += 1) result.data[r][c] = cAdd(result.data[r][c], term.data[r][c]);
  }
  return result;
}
export function embedSingleQubitOperator(qubitCount: number, target: number, operator: Matrix2): ComplexMatrix {
  if (!Number.isInteger(qubitCount) || qubitCount < 1 || qubitCount > 6) throw new RangeError("Dense operator embedding supports 1–6 qubits.");
  if (!Number.isInteger(target) || target < 0 || target >= qubitCount) throw new RangeError("Target qubit is outside the register.");
  const dimension = 2 ** qubitCount; const full = zeros(dimension, dimension); const mask = 1 << target;
  for (let column = 0; column < dimension; column += 1) {
    if (column & mask) continue;
    const partner = column | mask;
    full.data[column][column] = operator[0][0]; full.data[column][partner] = operator[0][1];
    full.data[partner][column] = operator[1][0]; full.data[partner][partner] = operator[1][1];
  }
  return full;
}
export function reducedDensityMatrix(state: Complex[], qubitCount: number, retainedQubits: number[]): ComplexMatrix {
  return partialTrace(densityFromState(state), retainedQubits, qubitCount);
}
export function densityDiagnostics(matrix: ComplexMatrix): DensityMatrixResult {
  if (matrix.rows !== matrix.cols) throw new Error("A density matrix must be square.");
  const traceValue = trace(matrix);
  const square = multiplyMatrices(matrix, matrix);
  const purity = trace(square).re;
  const eigs = hermitianEigenvalues(matrix);
  const entropy = eigs.reduce((sum, value) => value <= 1e-14 ? sum : sum - value * Math.log2(value), 0);
  return { matrix, purity, trace: traceValue.re, vonNeumannEntropy: entropy };
}

/** Eigenvalues of a small Hermitian complex matrix via a real symmetric Jacobi solver. */
export function hermitianEigenvalues(matrix: ComplexMatrix, tolerance = 1e-12, maxIterations = 5000): number[] {
  if (matrix.rows !== matrix.cols || !isHermitian(matrix, 1e-8)) throw new Error("Eigenvalue input must be Hermitian and square.");
  const n = matrix.rows;
  // A Hermitian n×n matrix has a real symmetric 2n×2n representation with each eigenvalue twice.
  const size = 2 * n;
  const a = Array.from({ length: size }, () => Array.from({ length: size }, () => 0));
  for (let r = 0; r < n; r += 1) for (let c = 0; c < n; c += 1) {
    const value = matrix.data[r][c];
    a[r][c] = value.re; a[r][c + n] = -value.im;
    a[r + n][c] = value.im; a[r + n][c + n] = value.re;
  }
  for (let iteration = 0; iteration < maxIterations; iteration += 1) {
    let p = 0; let q = 1; let largest = 0;
    for (let r = 0; r < size; r += 1) for (let c = r + 1; c < size; c += 1) if (Math.abs(a[r][c]) > largest) { largest = Math.abs(a[r][c]); p = r; q = c; }
    if (largest < tolerance) break;
    const tau = (a[q][q] - a[p][p]) / (2 * a[p][q]);
    const t = Math.sign(tau || 1) / (Math.abs(tau) + Math.sqrt(1 + tau * tau));
    const cosine = 1 / Math.sqrt(1 + t * t); const sine = t * cosine;
    const app = a[p][p]; const aqq = a[q][q]; const apq = a[p][q];
    a[p][p] = app - t * apq; a[q][q] = aqq + t * apq; a[p][q] = 0; a[q][p] = 0;
    for (let k = 0; k < size; k += 1) {
      if (k === p || k === q) continue;
      const akp = a[k][p]; const akq = a[k][q];
      a[k][p] = cosine * akp - sine * akq; a[p][k] = a[k][p];
      a[k][q] = sine * akp + cosine * akq; a[q][k] = a[k][q];
    }
  }
  const values = a.map((row, index) => row[index]).sort((x, y) => y - x);
  // Keep negative eigenvalues: partial-transpose entanglement tests rely on them.
  return values.filter((_, index) => index % 2 === 0);
}
export function singleQubitPurityFromState(state: Complex[], qubitCount: number, target: number): number {
  const rho = reducedDensityMatrix(state, qubitCount, [target]);
  return multiplyMatrices(rho, rho).data[0][0].re + multiplyMatrices(rho, rho).data[1][1].re;
}
export function mixedStateBlochVector(rho: ComplexMatrix): { x: number; y: number; z: number; purity: number } {
  if (rho.rows !== 2 || rho.cols !== 2) throw new Error("A Bloch vector requires a 2×2 density matrix.");
  const x = 2 * rho.data[0][1].re; const y = -2 * rho.data[0][1].im; const z = rho.data[0][0].re - rho.data[1][1].re;
  return { x, y, z, purity: (1 + x * x + y * y + z * z) / 2 };
}
export function fidelityPureToDensity(state: Complex[], rho: ComplexMatrix): number {
  if (rho.rows !== state.length || rho.cols !== state.length) throw new Error("State and density matrix dimensions do not match.");
  let result = complex();
  for (let r = 0; r < state.length; r += 1) for (let c = 0; c < state.length; c += 1) result = cAdd(result, cMul(cMul({ re: state[r].re, im: -state[r].im }, rho.data[r][c]), state[c]));
  return Math.max(0, Math.min(1, result.re));
}
export function computationalMeasurementProbabilities(rho: ComplexMatrix): number[] {
  if (rho.rows !== rho.cols) throw new Error("Density matrix must be square.");
  return rho.data.map((row, index) => Math.max(0, row[index].re));
}
export function densityTraceDistanceEstimate(a: ComplexMatrix, b: ComplexMatrix): number {
  if (a.rows !== b.rows || a.cols !== b.cols) throw new Error("Density matrix dimensions must match.");
  const difference = zeros(a.rows, a.cols);
  for (let r = 0; r < a.rows; r += 1) for (let c = 0; c < a.cols; c += 1) difference.data[r][c] = complex(a.data[r][c].re - b.data[r][c].re, a.data[r][c].im - b.data[r][c].im);
  // Frobenius distance is a useful diagnostic, but is not the trace distance.
  return Math.sqrt(difference.data.flat().reduce((sum, value) => sum + cMagnitudeSquared(value), 0));
}
