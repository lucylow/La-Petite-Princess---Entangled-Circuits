// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { expectPauli } from "./observables";
import type { Complex } from "../advanced/complex";

export interface StabilizerGenerator { label: string; paulis: string; description: string; }
export interface StabilizerCheck { paulis: string; expectation: number; stabilized: boolean; }
export function pauliStringsCommute(first: string, second: string): boolean {
  if (first.length !== second.length || /[^IXYZ]/.test(first + second)) throw new Error("Pauli strings must have the same length and contain only I, X, Y or Z.");
  let antiCommutes = 0;
  for (let index = 0; index < first.length; index += 1) {
    if (first[index] === "I" || second[index] === "I" || first[index] === second[index]) continue;
    antiCommutes += 1;
  }
  return antiCommutes % 2 === 0;
}
export function validateStabilizerSet(generators: StabilizerGenerator[]): string[] {
  const errors: string[] = [];
  if (!generators.length) errors.push("At least one stabilizer generator is required.");
  const width = generators[0]?.paulis.length ?? 0;
  generators.forEach((generator, index) => {
    if (!generator.paulis || generator.paulis.length !== width || /[^IXYZ]/.test(generator.paulis)) errors.push(`Generator ${index + 1} has an invalid Pauli string.`);
  });
  for (let i = 0; i < generators.length; i += 1) for (let j = i + 1; j < generators.length; j += 1) {
    if (generators[i].paulis.length === generators[j].paulis.length && !pauliStringsCommute(generators[i].paulis, generators[j].paulis)) errors.push(`${generators[i].label} and ${generators[j].label} do not commute.`);
  }
  return errors;
}
export function ghzStabilizerGenerators(qubitCount = 3): StabilizerGenerator[] {
  if (!Number.isInteger(qubitCount) || qubitCount < 2 || qubitCount > 8) throw new RangeError("GHZ stabilizers support 2–8 qubits.");
  const generators: StabilizerGenerator[] = [
    { label: "Global X", paulis: "X".repeat(qubitCount), description: "A global bit flip leaves the GHZ superposition unchanged." },
  ];
  for (let qubit = 0; qubit < qubitCount - 1; qubit += 1) {
    const chars = Array.from({ length: qubitCount }, () => "I");
    chars[qubitCount - qubit - 1] = "Z"; chars[qubitCount - qubit - 2] = "Z";
    generators.push({ label: `Parity ${qubit + 1}`, paulis: chars.join(""), description: `Neighboring qubits ${qubit + 1} and ${qubit + 2} have matching computational-basis parity.` });
  }
  return generators;
}
export function checkStabilizers(state: Complex[], qubitCount: number, generators: StabilizerGenerator[], tolerance = 1e-8): StabilizerCheck[] {
  const errors = validateStabilizerSet(generators);
  if (errors.length) throw new Error(errors.join(" "));
  if (generators.some((item) => item.paulis.length !== qubitCount)) throw new Error("Stabilizer length must equal the circuit qubit count.");
  return generators.map((generator) => {
    const expectation = expectPauli(state, qubitCount, generator.paulis);
    return { paulis: generator.paulis, expectation, stabilized: Math.abs(expectation - 1) <= tolerance };
  });
}
export function stabilizerScore(state: Complex[], qubitCount: number, generators: StabilizerGenerator[]): number {
  const checks = checkStabilizers(state, qubitCount, generators);
  return checks.reduce((sum, check) => sum + (check.expectation + 1) / 2, 0) / checks.length;
}
