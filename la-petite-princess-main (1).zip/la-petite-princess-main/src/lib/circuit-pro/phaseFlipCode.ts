// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { complex, type Complex } from "../advanced/complex";
import { applyGateOperation } from "./gates";
import { createCircuit, createOperation } from "./circuit";
import type { CircuitDefinition, CircuitOperation } from "./types";
import { stateNormSquared } from "./statevector";

export interface PhaseFlipRecovery { state: Complex[]; corrected: boolean; errorQubit: number | null; norm: number; }
export function encodeThreeQubitPhaseRepetition(logicalState: Complex[]): Complex[] {
  if (logicalState.length !== 2) throw new Error("Logical qubit state must have two amplitudes.");
  const norm = stateNormSquared(logicalState);
  if (Math.abs(norm - 1) > 1e-8) throw new Error("Logical state must be normalized.");
  const encoded = Array.from({ length: 8 }, () => complex());
  encoded[0] = complex(logicalState[0].re, logicalState[0].im);
  encoded[7] = complex(logicalState[1].re, logicalState[1].im);
  let state = encoded;
  for (let q = 0; q < 3; q += 1) state = applyGateOperation(state, 3, createOperation("H", q));
  return state;
}
export function injectPhaseFlip(state: Complex[], qubit: number): Complex[] {
  if (state.length !== 8 || !Number.isInteger(qubit) || qubit < 0 || qubit > 2) throw new Error("Phase-flip injection needs a three-qubit codeword and qubit 0, 1 or 2.");
  return applyGateOperation(state, 3, createOperation("Z", qubit));
}
export function correctKnownPhaseFlip(state: Complex[], errorQubit: number | null): PhaseFlipRecovery {
  if (state.length !== 8) throw new Error("Phase-flip recovery requires an eight-amplitude state.");
  if (errorQubit !== null && (!Number.isInteger(errorQubit) || errorQubit < 0 || errorQubit > 2)) throw new RangeError("errorQubit must be 0, 1, 2 or null.");
  let recovered = state.map((value) => complex(value.re, value.im));
  for (let q = 0; q < 3; q += 1) recovered = applyGateOperation(recovered, 3, createOperation("H", q));
  if (errorQubit !== null) recovered = applyGateOperation(recovered, 3, createOperation("X", errorQubit));
  for (let q = 0; q < 3; q += 1) recovered = applyGateOperation(recovered, 3, createOperation("H", q));
  return { state: recovered, corrected: true, errorQubit, norm: stateNormSquared(recovered) };
}
export function phaseFlipEncodingCircuit(): CircuitDefinition {
  const operations: CircuitOperation[] = [createOperation("CX", 1, [0]), createOperation("CX", 2, [0]), createOperation("H", 0), createOperation("H", 1), createOperation("H", 2)];
  return createCircuit("Three-qubit phase-flip encoding", 3, 3, operations);
}
export function phaseFlipDecoderCircuit(): CircuitDefinition {
  const operations: CircuitOperation[] = [createOperation("H", 0), createOperation("H", 1), createOperation("H", 2), createOperation("CX", 2, [0]), createOperation("CX", 1, [0])];
  return createCircuit("Three-qubit phase-flip decoder", 3, 3, operations);
}
export function phaseFlipCodeLimitations(): string[] {
  return ["The code protects against one phase-flip error, not arbitrary unknown errors.", "The known-error recovery helper applies a specified correction; a complete fault-tolerant implementation measures syndromes with ancillas.", "Noise during encoding, syndrome extraction, and recovery is not corrected by this toy repetition code."];
}
