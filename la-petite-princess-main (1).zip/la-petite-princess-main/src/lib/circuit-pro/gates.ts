// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import {
  cAdd, cExpI, cMul, cScale, complex, type Complex,
} from "../advanced/complex";
import type { CircuitOperation, GateName } from "./types";

export type Matrix2 = [[Complex, Complex], [Complex, Complex]];
const S2 = 1 / Math.sqrt(2);
const C = (re: number, im = 0) => complex(re, im);
const M = (a: Complex, b: Complex, c: Complex, d: Complex): Matrix2 => [[a, b], [c, d]];

export function singleQubitMatrix(gate: GateName, params: CircuitOperation["params"] = {}): Matrix2 {
  const theta = params?.theta ?? 0;
  const phi = params?.phi ?? 0;
  const lambda = params?.lambda ?? 0;
  switch (gate) {
    case "I": return M(C(1), C(0), C(0), C(1));
    case "X": return M(C(0), C(1), C(1), C(0));
    case "Y": return M(C(0), C(0, -1), C(0, 1), C(0));
    case "Z": return M(C(1), C(0), C(0), C(-1));
    case "H": return M(C(S2), C(S2), C(S2), C(-S2));
    case "S": return M(C(1), C(0), C(0), C(0, 1));
    case "SDG": return M(C(1), C(0), C(0), C(0, -1));
    case "T": return M(C(1), C(0), C(0), cExpI(Math.PI / 4));
    case "TDG": return M(C(1), C(0), C(0), cExpI(-Math.PI / 4));
    case "SX": return M(C(0.5, 0.5), C(0.5, -0.5), C(0.5, -0.5), C(0.5, 0.5));
    case "SXDG": return M(C(0.5, -0.5), C(0.5, 0.5), C(0.5, 0.5), C(0.5, -0.5));
    case "RX": {
      const co = Math.cos(theta / 2); const si = Math.sin(theta / 2);
      return M(C(co), C(0, -si), C(0, -si), C(co));
    }
    case "RY": {
      const co = Math.cos(theta / 2); const si = Math.sin(theta / 2);
      return M(C(co), C(-si), C(si), C(co));
    }
    case "RZ": return M(cExpI(-theta / 2), C(0), C(0), cExpI(theta / 2));
    case "U3": {
      const co = Math.cos(theta / 2); const si = Math.sin(theta / 2);
      return M(C(co), cScale(cExpI(lambda), -si), cScale(cExpI(phi), si), cScale(cExpI(phi + lambda), co));
    }
    default: throw new Error(`${gate} is not a single-qubit gate.`);
  }
}

function validateIndex(index: number, qubitCount: number): void {
  if (!Number.isInteger(index) || index < 0 || index >= qubitCount) throw new RangeError(`Qubit ${index} is outside a ${qubitCount}-qubit register.`);
}

function applyMatrixToTarget(state: Complex[], qubitCount: number, target: number, matrix: Matrix2, controls: number[] = []): Complex[] {
  validateIndex(target, qubitCount);
  controls.forEach((control) => validateIndex(control, qubitCount));
  if (new Set([target, ...controls]).size !== controls.length + 1) throw new Error("Control and target qubits must be distinct.");
  const targetMask = 1 << target;
  const controlMask = controls.reduce((mask, q) => mask | (1 << q), 0);
  const result = state.map((v) => complex(v.re, v.im));
  for (let index = 0; index < state.length; index += 1) {
    if ((index & targetMask) !== 0 || (index & controlMask) !== controlMask) continue;
    const partner = index | targetMask;
    const a = state[index]; const b = state[partner];
    result[index] = cAdd(cMul(matrix[0][0], a), cMul(matrix[0][1], b));
    result[partner] = cAdd(cMul(matrix[1][0], a), cMul(matrix[1][1], b));
  }
  return result;
}

function applySwapLike(state: Complex[], qubitCount: number, first: number, second: number, useIPhase = false): Complex[] {
  validateIndex(first, qubitCount); validateIndex(second, qubitCount);
  if (first === second) throw new Error("A two-wire exchange needs two distinct qubits.");
  const firstMask = 1 << first; const secondMask = 1 << second;
  const result = state.map((v) => complex(v.re, v.im));
  for (let index = 0; index < state.length; index += 1) {
    const firstBit = (index & firstMask) !== 0; const secondBit = (index & secondMask) !== 0;
    if (!firstBit && secondBit) {
      const partner = index ^ firstMask ^ secondMask;
      result[index] = useIPhase ? cMul(C(0, 1), state[partner]) : state[partner];
      result[partner] = useIPhase ? cMul(C(0, 1), state[index]) : state[index];
    }
  }
  return result;
}

/** Apply one unitary instruction to a normalized or unnormalized state vector. */
export function applyGateOperation(state: Complex[], qubitCount: number, operation: CircuitOperation): Complex[] {
  if (state.length !== 2 ** qubitCount) throw new Error("State vector length does not match the circuit register.");
  const { gate, targets, controls = [] } = operation;
  if (gate === "BARRIER" || gate === "MEASURE") return state.map((v) => complex(v.re, v.im));
  if (gate === "SWAP" || gate === "ISWAP") {
    if (targets.length !== 2 || controls.length) throw new Error(`${gate} requires exactly two target wires and no controls.`);
    return applySwapLike(state, qubitCount, targets[0], targets[1], gate === "ISWAP");
  }
  if (gate === "CSWAP") {
    if (targets.length !== 2 || controls.length !== 1) throw new Error("CSWAP requires one control and two target wires.");
    validateIndex(controls[0], qubitCount);
    const result = state.map((v) => complex(v.re, v.im));
    const cMask = 1 << controls[0]; const aMask = 1 << targets[0]; const bMask = 1 << targets[1];
    if (targets[0] === targets[1] || controls[0] === targets[0] || controls[0] === targets[1]) throw new Error("CSWAP wires must be distinct.");
    for (let index = 0; index < state.length; index += 1) {
      if ((index & cMask) === 0) continue;
      const a = (index & aMask) !== 0; const b = (index & bMask) !== 0;
      if (!a && b) { const partner = index ^ aMask ^ bMask; result[index] = state[partner]; result[partner] = state[index]; }
    }
    return result;
  }
  if (gate === "CCX") {
    if (targets.length !== 1 || controls.length !== 2) throw new Error("CCX requires two controls and one target.");
    return applyMatrixToTarget(state, qubitCount, targets[0], singleQubitMatrix("X"), controls);
  }
  if (["CX", "CY", "CZ", "CH", "CP", "CRX", "CRY", "CRZ"].includes(gate)) {
    if (targets.length !== 1 || controls.length < 1) throw new Error(`${gate} requires one target and at least one control.`);
    const matrixGate = gate === "CX" ? "X" : gate === "CY" ? "Y" : gate === "CZ" ? "Z" : gate === "CH" ? "H" : gate === "CP" ? "RZ" : gate === "CRX" ? "RX" : gate === "CRY" ? "RY" : "RZ";
    if (gate === "CP") {
      const angle = operation.params?.theta ?? 0;
      const phaseMatrix: Matrix2 = [[C(1), C(0)], [C(0), cExpI(angle)]];
      return applyMatrixToTarget(state, qubitCount, targets[0], phaseMatrix, controls);
    }
    return applyMatrixToTarget(state, qubitCount, targets[0], singleQubitMatrix(matrixGate, operation.params), controls);
  }
  if (targets.length !== 1 || controls.length) throw new Error(`${gate} requires one target and no controls.`);
  return applyMatrixToTarget(state, qubitCount, targets[0], singleQubitMatrix(gate, operation.params));
}

export function applyGateSequence(state: Complex[], qubitCount: number, operations: CircuitOperation[]): Complex[] {
  return operations.reduce((current, operation) => applyGateOperation(current, qubitCount, operation), state);
}

export function gateArity(gate: GateName): number {
  if (gate === "BARRIER" || gate === "MEASURE") return 1;
  if (gate === "SWAP" || gate === "ISWAP" || gate === "CSWAP") return 2;
  return 1;
}
export function isEntanglingGate(gate: GateName): boolean {
  return ["CX", "CY", "CZ", "CH", "CP", "CRX", "CRY", "CRZ", "SWAP", "ISWAP", "CCX", "CSWAP"].includes(gate);
}
export function gateCategory(gate: GateName): "single" | "controlled" | "multi" | "directive" {
  if (gate === "BARRIER" || gate === "MEASURE") return "directive";
  if (["SWAP", "ISWAP", "CCX", "CSWAP"].includes(gate)) return "multi";
  if (["CX", "CY", "CZ", "CH", "CP", "CRX", "CRY", "CRZ"].includes(gate)) return "controlled";
  return "single";
}
