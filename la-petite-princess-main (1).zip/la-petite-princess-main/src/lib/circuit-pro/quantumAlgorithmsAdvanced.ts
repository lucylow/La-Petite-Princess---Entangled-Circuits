// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { createCircuit, createOperation } from "./circuit";
import type { CircuitDefinition, CircuitOperation } from "./types";

export interface SuperdenseCodingDemo { circuit: CircuitDefinition; message: [number, number]; senderQubit: number; receiverQubit: number; explanation: string[]; }
export interface BellMeasurementDemo { circuit: CircuitDefinition; label: string; stateDescription: string; }
function bit(value: number, label: string): void { if (value !== 0 && value !== 1) throw new RangeError(`${label} must be 0 or 1.`); }
function appendMeasure(operations: CircuitOperation[], qubit: number, bitIndex: number): void { const operation = createOperation("MEASURE", qubit); operation.classicalBit = bitIndex; operations.push(operation); }
/** Bell-pair based superdense coding. Alice sends two classical bits by transmitting one qubit. */
export function superdenseCodingCircuit(message: [number, number]): SuperdenseCodingDemo {
  bit(message[0], "Message bit a"); bit(message[1], "Message bit b");
  const [a, b] = message; const operations: CircuitOperation[] = [
    createOperation("H", 0, [], undefined, "Prepare Bell pair"),
    createOperation("CX", 1, [0], undefined, "Entangle sender and receiver"),
  ];
  if (b) operations.push(createOperation("Z", 0, [], undefined, "Encode phase bit"));
  if (a) operations.push(createOperation("X", 0, [], undefined, "Encode bit-flip bit"));
  operations.push(createOperation("CX", 1, [0], undefined, "Receiver decodes Bell correlations"));
  operations.push(createOperation("H", 0, [], undefined, "Undo sender Hadamard"));
  appendMeasure(operations, 0, 0); appendMeasure(operations, 1, 1);
  const circuit = createCircuit(`Superdense coding · ${a}${b}`, 2, 2, operations);
  circuit.description = "The sender encodes two classical bits on one half of a shared Bell pair; the receiver recovers the message using a CNOT and Hadamard.";
  return { circuit, message, senderQubit: 0, receiverQubit: 1, explanation: ["Create a shared Bell pair.", "Encode the two-bit message with X and Z on the sender qubit.", "Receiver applies CNOT and H.", "Measure both qubits to recover the classical message."] };
}
export function bellBasisMeasurementCircuit(qubitCount = 2): BellMeasurementDemo[] {
  if (qubitCount !== 2) throw new RangeError("Bell basis measurement acts on exactly two qubits.");
  const states: Array<{ label: string; preparation: CircuitOperation[]; stateDescription: string }> = [
    { label: "Φ+", preparation: [createOperation("H", 0), createOperation("CX", 1, [0])], stateDescription: "(|00⟩ + |11⟩) / √2" },
    { label: "Φ−", preparation: [createOperation("H", 0), createOperation("Z", 0), createOperation("CX", 1, [0])], stateDescription: "(|00⟩ − |11⟩) / √2" },
    { label: "Ψ+", preparation: [createOperation("H", 0), createOperation("CX", 1, [0]), createOperation("X", 1)], stateDescription: "(|01⟩ + |10⟩) / √2" },
    { label: "Ψ−", preparation: [createOperation("H", 0), createOperation("CX", 1, [0]), createOperation("X", 1), createOperation("Z", 0)], stateDescription: "(|01⟩ − |10⟩) / √2" },
  ];
  return states.map((state) => {
    const operations = [...state.preparation, createOperation("CX", 1, [0]), createOperation("H", 0)];
    appendMeasure(operations, 0, 0); appendMeasure(operations, 1, 1);
    return { circuit: createCircuit(`Bell analyser · ${state.label}`, 2, 2, operations), label: state.label, stateDescription: state.stateDescription };
  });
}
/** Shows phase kickback with an eigenstate target |1⟩ and a controlled phase rotation. */
export function phaseKickbackCircuit(angle: number): CircuitDefinition {
  if (!Number.isFinite(angle)) throw new Error("Phase angle must be finite.");
  return createCircuit("Phase kickback", 2, 2, [
    createOperation("H", 0, [], undefined, "Put the control into superposition"),
    createOperation("X", 1, [], undefined, "Prepare the target eigenstate |1⟩"),
    createOperation("CP", 1, [0], { theta: angle }, "Apply phase only when both qubits are |1⟩"),
    createOperation("H", 0, [], undefined, "Interference reveals the kicked-back phase"),
    ...[0, 1].map((qubit) => { const op = createOperation("MEASURE", qubit); op.classicalBit = qubit; return op; }),
  ]);
}
/** Entanglement swapping preparation and Bell measurement on the two middle qubits. */
export function entanglementSwappingCircuit(): CircuitDefinition {
  const operations = [
    createOperation("H", 0), createOperation("CX", 1, [0], undefined, "First Bell pair"),
    createOperation("H", 2), createOperation("CX", 3, [2], undefined, "Second Bell pair"),
    createOperation("CX", 2, [1], undefined, "Bell measurement coupling"), createOperation("H", 1),
  ];
  appendMeasure(operations, 1, 0); appendMeasure(operations, 2, 1);
  // Conditional Pauli corrections are represented as classical-branch placeholders in the note.
  operations.push(createOperation("BARRIER", [0, 3], [], undefined, "Apply X/Z corrections based on the two middle measurement bits in a dynamic-circuit backend."));
  const circuit = createCircuit("Entanglement swapping", 4, 2, operations);
  circuit.description = "Two Bell pairs are prepared, then the middle qubits are measured in the Bell basis. The end qubits become entangled conditioned on the two classical outcomes.";
  return circuit;
}
export interface SimonOracleSpec { inputBits: number; secret: string; }
/** A Simon promise oracle for a small secret, implemented as a reversible linear map over GF(2). */
export function simonOracleCircuit(spec: SimonOracleSpec): CircuitDefinition {
  if (!Number.isInteger(spec.inputBits) || spec.inputBits < 2 || spec.inputBits > 6) throw new RangeError("Simon demo supports 2..6 input bits.");
  if (spec.secret.length !== spec.inputBits || /[^01]/.test(spec.secret) || spec.secret === "0".repeat(spec.inputBits)) throw new Error("Simon secret must be a non-zero bitstring matching the input width.");
  const n = spec.inputBits; const operations: CircuitOperation[] = [];
  for (let q = 0; q < n; q += 1) operations.push(createOperation("H", q));
  // Choose a pivot where the secret has a 1; map outputs so x and x⊕s collide.
  const pivot = spec.secret.indexOf("1");
  for (let output = 0; output < n; output += 1) {
    if (output === pivot) continue;
    operations.push(createOperation("CX", n + output, [output], undefined, "Simon oracle output copy"));
  }
  for (let input = 0; input < n; input += 1) if (spec.secret[input] === "1" && input !== pivot) operations.push(createOperation("CX", n + pivot, [input], undefined, "Simon oracle secret parity"));
  const circuit = createCircuit(`Simon oracle · secret ${spec.secret}`, 2 * n, 2 * n, operations);
  circuit.description = "Toy Simon oracle for learning the promise structure; the output map is intentionally compact and should be interpreted with the associated secret/parity explanation.";
  return circuit;
}
export function controlledUnitaryPhaseCircuit(targetPhase: number, controlCount = 1): CircuitDefinition {
  if (!Number.isFinite(targetPhase) || !Number.isInteger(controlCount) || controlCount < 1 || controlCount > 5) throw new Error("Phase and control count are invalid.");
  const qubitCount = controlCount + 1; const target = controlCount; const operations: CircuitOperation[] = [];
  operations.push(createOperation("X", target, [], undefined, "Prepare phase-sensitive target"));
  operations.push(createOperation("CP", target, Array.from({ length: controlCount }, (_, index) => index), { theta: targetPhase }, "Controlled phase kickback"));
  return createCircuit("Controlled unitary phase", qubitCount, qubitCount, operations);
}
