// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { cMagnitudeSquared, complex } from "../advanced/complex";
import { assertValidCircuit } from "./circuit";
import { applyGateOperation } from "./gates";
import { measureQubit, sampleShots } from "./measurement";
import { resolveRandom } from "./random";
import { createZeroState, isNormalized, normalizeState, probabilityMap } from "./statevector";
import { DEFAULT_MAX_QUBITS, MAX_SHOTS, type CircuitDefinition, type CircuitOperation, type MeasurementRecord, type SimulationOptions, type SimulationResult, type ShotResult } from "./types";

export function simulateCircuit(circuit: CircuitDefinition, options: SimulationOptions = {}, rng: () => number = Math.random): SimulationResult {
  const started = performanceNow();
  const maxQubits = options.maxQubits ?? DEFAULT_MAX_QUBITS;
  assertValidCircuit(circuit, maxQubits);
  let state = createZeroState(circuit.qubitCount);
  const classicalBits = Array.from({ length: circuit.classicalBitCount }, () => 0);
  const measurements: MeasurementRecord[] = [];
  for (const operation of circuit.operations) {
    if (operation.gate === "BARRIER") continue;
    if (operation.gate === "MEASURE") {
      const qubit = operation.targets[0]; const classicalBit = operation.classicalBit!;
      const result = measureQubit(state, circuit.qubitCount, qubit, rng);
      state = result.collapsedState;
      classicalBits[classicalBit] = result.outcome;
      measurements.push({ qubit, classicalBit, outcome: result.outcome, probabilityZero: result.probabilityZero, probabilityOne: result.probabilityOne, operationId: operation.id });
      continue;
    }
    state = applyGateOperation(state, circuit.qubitCount, operation);
  }
  if (options.normalizeInput && !isNormalized(state)) state = normalizeState(state);
  return { state, qubitCount: circuit.qubitCount, classicalBits, measurements, operationCount: circuit.operations.length, elapsedMs: performanceNow() - started, normalized: isNormalized(state) };
}

export function runCircuitShots(circuit: CircuitDefinition, shots: number, seed?: number): ShotResult {
  if (!Number.isInteger(shots) || shots < 1 || shots > MAX_SHOTS) throw new RangeError(`Shots must be from 1 to ${MAX_SHOTS}.`);
  const rng = resolveRandom(seed);
  const hasExplicitMeasurements = circuit.operations.some((operation) => operation.gate === "MEASURE");
  if (!hasExplicitMeasurements) {
    const state = simulateCircuit(circuit).state;
    const result = sampleShots(state, circuit.qubitCount, shots, seed);
    return { ...result, idealProbabilities: result.probabilities, seed };
  }
  const counts: Record<string, number> = {};
  for (let shot = 0; shot < shots; shot += 1) {
    const result = simulateCircuit(circuit, {}, rng);
    const key = result.classicalBits.slice().reverse().join("");
    counts[key] = (counts[key] ?? 0) + 1;
  }
  const frequencies = Object.fromEntries(Object.entries(counts).map(([key, count]) => [key, count / shots]));
  return { shots, counts, frequencies, idealProbabilities: { ...frequencies }, seed };
}

export function simulateOperationList(qubitCount: number, operations: CircuitOperation[]) {
  const circuit: CircuitDefinition = { id: "ephemeral", name: "Circuit", qubitCount, classicalBitCount: qubitCount, operations, version: 1 };
  return simulateCircuit(circuit);
}
export function stateProbabilityMass(state: ReturnType<typeof createZeroState>): number {
  return state.reduce((sum, amplitude) => sum + cMagnitudeSquared(amplitude), 0);
}
export { probabilityMap };
function performanceNow(): number { return typeof performance !== "undefined" && performance.now ? performance.now() : Date.now(); }
