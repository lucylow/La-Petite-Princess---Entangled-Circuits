// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { cloneCircuit, cloneOperation } from "./circuit";
import type { CircuitDefinition, CircuitOperation } from "./types";

const SELF_INVERSE = new Set(["I", "X", "Y", "Z", "H", "CX", "CY", "CZ", "CH", "SWAP", "CCX", "CSWAP"]);
const INVERSES: Record<string, string> = { S: "SDG", SDG: "S", T: "TDG", TDG: "T", SX: "SXDG", SXDG: "SX" };
function sameWires(a: CircuitOperation, b: CircuitOperation): boolean {
  return JSON.stringify(a.targets) === JSON.stringify(b.targets) && JSON.stringify(a.controls ?? []) === JSON.stringify(b.controls ?? []);
}
function angle(operation: CircuitOperation): number { return operation.params?.theta ?? 0; }
function nearZero(value: number, epsilon: number): boolean { return Math.abs(value) <= epsilon; }
function isRotation(gate: string): boolean { return ["RX", "RY", "RZ", "CRX", "CRY", "CRZ", "CP"].includes(gate); }

export interface OptimizationReport {
  circuit: CircuitDefinition;
  originalOperationCount: number;
  optimizedOperationCount: number;
  removedOperations: number;
  passes: number;
  notes: string[];
}
export interface OptimizationOptions { epsilon?: number; maxPasses?: number; removeIdentity?: boolean; mergeRotations?: boolean; }

export function optimizeCircuit(circuit: CircuitDefinition, options: OptimizationOptions = {}): OptimizationReport {
  const epsilon = options.epsilon ?? 1e-10; const maxPasses = options.maxPasses ?? 8;
  let operations = circuit.operations.map(cloneOperation); const originalOperationCount = operations.length;
  const notes: string[] = []; let passes = 0; let changed = true;
  while (changed && passes < maxPasses) {
    changed = false; passes += 1; const next: CircuitOperation[] = [];
    for (const current of operations) {
      const previous = next[next.length - 1];
      if (options.removeIdentity !== false && current.gate === "I") { changed = true; continue; }
      if (previous && previous.gate === "BARRIER" || current.gate === "BARRIER" || previous?.gate === "MEASURE" || current.gate === "MEASURE") {
        next.push(current); continue;
      }
      if (previous && sameWires(previous, current) && isRotation(previous.gate) && previous.gate === current.gate && options.mergeRotations !== false) {
        const combined = angle(previous) + angle(current);
        if (nearZero(combined, epsilon)) { next.pop(); changed = true; notes.push(`Cancelled adjacent ${current.gate} rotations.`); }
        else { next[next.length - 1] = { ...previous, params: { ...previous.params, theta: combined } }; changed = true; }
        continue;
      }
      if (previous && sameWires(previous, current)) {
        const inverse = INVERSES[previous.gate] === current.gate;
        const selfInverse = previous.gate === current.gate && SELF_INVERSE.has(previous.gate);
        if (inverse || selfInverse) { next.pop(); changed = true; notes.push(`Cancelled ${previous.gate} followed by ${current.gate}.`); continue; }
      }
      next.push(current);
    }
    operations = next;
  }
  if (passes >= maxPasses && changed) notes.push(`Stopped after ${maxPasses} optimization passes.`);
  return { circuit: { ...cloneCircuit(circuit), operations }, originalOperationCount, optimizedOperationCount: operations.length, removedOperations: originalOperationCount - operations.length, passes, notes: [...new Set(notes)] };
}

export function cancelAdjacentInverses(operations: CircuitOperation[]): CircuitOperation[] {
  const fake: CircuitDefinition = { id: "temporary", name: "Temporary", qubitCount: 10, classicalBitCount: 10, operations, version: 1 };
  return optimizeCircuit(fake).circuit.operations;
}
