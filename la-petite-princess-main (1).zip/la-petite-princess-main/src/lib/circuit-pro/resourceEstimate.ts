// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import type { CircuitDefinition } from "./types";
import { circuitMetrics } from "./metrics";

export interface ResourceEstimate {
  qubitCount: number;
  stateVectorBytes: number;
  densityMatrixBytes: number;
  stateVectorMiB: number;
  densityMatrixMiB: number;
  operationCount: number;
  twoQubitOperationCount: number;
  estimatedGateTimeNs: number;
  estimatedCircuitTimeNs: number;
  practicalStateVectorLimitBytes: number;
  withinStateVectorBudget: boolean;
  caveats: string[];
}
export interface GateTimingProfile { singleQubitNs: number; twoQubitNs: number; measurementNs: number; resetNs?: number; }
export const ILLUSTRATIVE_GATE_TIMINGS: GateTimingProfile = { singleQubitNs: 35, twoQubitNs: 300, measurementNs: 800, resetNs: 500 };
export function estimateCircuitResources(circuit: CircuitDefinition, practicalStateVectorLimitBytes = 2 * 1024 ** 3, timing: GateTimingProfile = ILLUSTRATIVE_GATE_TIMINGS): ResourceEstimate {
  const metrics = circuitMetrics(circuit); const amplitudes = 2 ** circuit.qubitCount;
  const stateVectorBytes = amplitudes * 16; const densityMatrixBytes = amplitudes * amplitudes * 16;
  const estimatedGateTimeNs = circuit.operations.reduce((sum, operation) => {
    if (operation.gate === "MEASURE") return sum + timing.measurementNs;
    if (operation.gate === "BARRIER") return sum;
    return sum + (operation.targets.length + (operation.controls?.length ?? 0) > 1 ? timing.twoQubitNs : timing.singleQubitNs);
  }, 0);
  const estimatedCircuitTimeNs = estimatedGateTimeNs;
  return {
    qubitCount: circuit.qubitCount, stateVectorBytes, densityMatrixBytes,
    stateVectorMiB: stateVectorBytes / 1024 ** 2, densityMatrixMiB: densityMatrixBytes / 1024 ** 2,
    operationCount: metrics.operationCount, twoQubitOperationCount: metrics.twoQubitGateCount + metrics.multiQubitGateCount,
    estimatedGateTimeNs, estimatedCircuitTimeNs, practicalStateVectorLimitBytes,
    withinStateVectorBudget: stateVectorBytes <= practicalStateVectorLimitBytes,
    caveats: ["Memory estimates exclude JavaScript object overhead, temporary arrays, and UI copies.", "Timing values are illustrative only; they are not calibrated to a vendor or physical device.", "Density-matrix simulation stores 4^n complex entries and becomes expensive quickly."],
  };
}
export function formatBytes(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes < 0) throw new RangeError("bytes must be finite and non-negative.");
  if (bytes < 1024) return `${bytes.toFixed(0)} B`;
  const units = ["KiB", "MiB", "GiB", "TiB"]; let value = bytes / 1024; let unit = 0;
  while (value >= 1024 && unit < units.length - 1) { value /= 1024; unit += 1; }
  return `${value.toFixed(2)} ${units[unit]}`;
}
export function memoryGrowthTable(maxQubits = 12): Array<{ qubits: number; amplitudes: number; stateVector: string; densityMatrix: string }> {
  if (!Number.isInteger(maxQubits) || maxQubits < 1 || maxQubits > 30) throw new RangeError("maxQubits must be 1..30.");
  return Array.from({ length: maxQubits }, (_, index) => {
    const qubits = index + 1; const dimension = 2 ** qubits;
    return { qubits, amplitudes: dimension, stateVector: formatBytes(dimension * 16), densityMatrix: formatBytes(dimension * dimension * 16) };
  });
}
