// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import type { CircuitDefinition, CircuitOperation } from "./types";
import { cloneCircuit, createCircuit } from "./circuit";

function inverseOperation(operation: CircuitOperation): CircuitOperation {
  const parameters = operation.params ? { ...operation.params } : undefined;
  switch (operation.gate) {
    case "I": case "X": case "Y": case "Z": case "H": case "CCX": case "SWAP": case "CSWAP":
      return { ...operation, id: `${operation.id}-inv`, targets: [...operation.targets], ...(operation.controls ? { controls: [...operation.controls] } : {}) };
    case "T": return { ...operation, id: `${operation.id}-inv`, gate: "TDG" };
    case "TDG": return { ...operation, id: `${operation.id}-inv`, gate: "T" };
    case "SX": return { ...operation, id: `${operation.id}-inv`, gate: "SXDG" };
    case "SXDG": return { ...operation, id: `${operation.id}-inv`, gate: "SX" };
    case "S": return { ...operation, id: `${operation.id}-inv`, gate: "SDG" };
    case "SDG": return { ...operation, id: `${operation.id}-inv`, gate: "S" };
    case "RX": case "RY": case "RZ": case "CRX": case "CRY": case "CRZ": case "CP":
      return { ...operation, id: `${operation.id}-inv`, params: { ...parameters, theta: -(parameters?.theta ?? 0) } };
    case "U3":
      return { ...operation, id: `${operation.id}-inv`, params: { theta: -(parameters?.theta ?? 0), phi: -(parameters?.lambda ?? 0), lambda: -(parameters?.phi ?? 0) } };
    case "CX": case "CY": case "CZ": case "CH":
      return { ...operation, id: `${operation.id}-inv` };
    case "ISWAP":
      return {
        ...operation,
        id: `${operation.id}-inv`,
        gate: "SWAP",
        note: "Inverse iSWAP is SWAP followed by S† on both target wires; see appended operations.",
      };
    case "BARRIER": return { ...operation, id: `${operation.id}-inv` };
    case "MEASURE": throw new Error("A circuit containing measurement is not reversible.");
  }
}
/** Returns U† by reversing the order and inverting each operation. Measurements are rejected. */
export function inverseCircuit(circuit: CircuitDefinition): CircuitDefinition {
  if (circuit.operations.some((operation) => operation.gate === "MEASURE")) throw new Error("Cannot invert a circuit containing measurements.");
  const operations: CircuitOperation[] = [];
  for (const operation of [...circuit.operations].reverse()) {
    if (operation.gate === "ISWAP") {
      // iSWAP† = (S† ⊗ S†) · CZ · SWAP. The CZ cancels the unwanted -1 phase on |11>.
      const [a, b] = operation.targets;
      operations.push({ ...operation, id: `${operation.id}-inv-swap`, gate: "SWAP", note: "Inverse iSWAP: exchange" });
      operations.push({ ...operation, id: `${operation.id}-inv-cz`, gate: "CZ", targets: [b], controls: [a], note: "Cancel the |11> phase" });
      operations.push({ ...operation, id: `${operation.id}-inv-sdg-a`, gate: "SDG", targets: [a], controls: undefined, note: "Inverse iSWAP phase" });
      operations.push({ ...operation, id: `${operation.id}-inv-sdg-b`, gate: "SDG", targets: [b], controls: undefined, note: "Inverse iSWAP phase" });
    } else operations.push(inverseOperation(operation));
  }
  const result = cloneCircuit(circuit); result.id = `${circuit.id}-inverse`; result.name = `${circuit.name}†`; result.operations = operations;
  return result;
}
export function concatenateCircuits(name: string, circuits: CircuitDefinition[]): CircuitDefinition {
  if (!circuits.length) throw new Error("At least one circuit is required.");
  const qubitCount = circuits[0].qubitCount; const classicalBitCount = circuits[0].classicalBitCount;
  if (circuits.some((circuit) => circuit.qubitCount !== qubitCount || circuit.classicalBitCount !== classicalBitCount)) throw new Error("All circuits must have matching quantum and classical register sizes.");
  const operations: CircuitOperation[] = []; let ordinal = 0;
  for (const circuit of circuits) for (const operation of circuit.operations) operations.push({ ...operation, id: `concat-${ordinal++}-${operation.id}`, targets: [...operation.targets], controls: operation.controls ? [...operation.controls] : undefined, params: operation.params ? { ...operation.params } : undefined });
  return createCircuit(name, qubitCount, classicalBitCount, operations);
}
export function adjointCircuit(circuit: CircuitDefinition): CircuitDefinition { return inverseCircuit(circuit); }
export function circuitIsReversible(circuit: CircuitDefinition): boolean { return circuit.operations.every((operation) => operation.gate !== "MEASURE"); }
