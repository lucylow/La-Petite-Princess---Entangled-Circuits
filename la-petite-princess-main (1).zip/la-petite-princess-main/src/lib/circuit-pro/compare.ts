// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
export interface DistributionComparison {
  totalVariationDistance: number;
  hellingerDistance: number;
  kullbackLeiblerDivergence: number;
  intersection: number;
  labels: string[];
}
export function compareDistributions(reference: Record<string, number>, observed: Record<string, number>, epsilon = 1e-12): DistributionComparison {
  const labels = [...new Set([...Object.keys(reference), ...Object.keys(observed)])].sort();
  const pSum = labels.reduce((sum, label) => sum + Math.max(0, reference[label] ?? 0), 0);
  const qSum = labels.reduce((sum, label) => sum + Math.max(0, observed[label] ?? 0), 0);
  if (pSum <= 0 || qSum <= 0) throw new Error("Both distributions must have positive total probability.");
  let l1 = 0; let hellingerSquared = 0; let kl = 0; let intersection = 0;
  for (const label of labels) {
    const p = Math.max(0, reference[label] ?? 0) / pSum; const q = Math.max(0, observed[label] ?? 0) / qSum;
    l1 += Math.abs(p - q); hellingerSquared += (Math.sqrt(p) - Math.sqrt(q)) ** 2;
    if (p > 0) kl += p * Math.log(p / Math.max(q, epsilon));
    intersection += Math.min(p, q);
  }
  return { totalVariationDistance: l1 / 2, hellingerDistance: Math.sqrt(hellingerSquared / 2), kullbackLeiblerDivergence: kl, intersection, labels };
}
export function normalizeDistribution(values: Record<string, number>): Record<string, number> {
  const total = Object.values(values).reduce((sum, value) => sum + value, 0);
  if (!Number.isFinite(total) || total <= 0) throw new Error("Distribution must sum to a positive finite value.");
  return Object.fromEntries(Object.entries(values).map(([key, value]) => [key, value / total]));
}
export function chiSquaredStatistic(expected: Record<string, number>, observedCounts: Record<string, number>, shots: number): number {
  if (!Number.isInteger(shots) || shots < 1) throw new RangeError("Shot count must be positive.");
  const labels = [...new Set([...Object.keys(expected), ...Object.keys(observedCounts)])]; let statistic = 0;
  for (const label of labels) {
    const expectedCount = (expected[label] ?? 0) * shots; const observed = observedCounts[label] ?? 0;
    if (expectedCount <= 1e-12) { if (observed > 0) return Infinity; continue; }
    statistic += (observed - expectedCount) ** 2 / expectedCount;
  }
  return statistic;
}
export function jensenShannonDivergence(a: Record<string, number>, b: Record<string, number>): number {
  const p = normalizeDistribution(a); const q = normalizeDistribution(b); const labels = [...new Set([...Object.keys(p), ...Object.keys(q)])];
  const midpoint: Record<string, number> = Object.fromEntries(labels.map((label) => [label, ((p[label] ?? 0) + (q[label] ?? 0)) / 2]));
  const kl = (left: Record<string, number>, right: Record<string, number>) => Object.entries(left).reduce((sum, [label, value]) => value <= 0 ? sum : sum + value * Math.log2(value / Math.max(right[label] ?? 0, 1e-15)), 0);
  return (kl(p, midpoint) + kl(q, midpoint)) / 2;
}
