// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { describe, expect, it } from "vitest";
import { createCircuit, createOperation } from "../circuit";
import { simulateCircuit } from "../simulator";
import { routeCircuitToConnectivity, shortestCouplingPath, LINEAR_COUPLING, gridCoupling, couplingSummary } from "../connectivity";
import { probabilityMap } from "../statevector";

describe("hardware connectivity and routing", () => {
  it("finds shortest paths in a line topology", () => {
    expect(shortestCouplingPath(LINEAR_COUPLING(4), 0, 3)).toEqual([0, 1, 2, 3]);
  });
  it("reports a connected square grid", () => {
    expect(couplingSummary(gridCoupling(2, 2)).connected).toBe(true);
  });
  it("routes a remote CNOT by inserting swaps while preserving the logical result", () => {
    const source = createCircuit("remote cx", 4, 4, [createOperation("X", 0), createOperation("CX", 3, [0])]);
    const routed = routeCircuitToConnectivity(source, LINEAR_COUPLING(4));
    expect(routed.insertedSwaps).toBeGreaterThan(0);
    expect(routed.circuit.qubitCount).toBe(4);
    expect(probabilityMap(simulateCircuit(routed.circuit).state, 4, false)["1100"]).toBeCloseTo(1, 8);
  });
  it("decomposes reverse-directed CNOT with Hadamards", () => {
    const source = createCircuit("reverse cx", 2, 2, [createOperation("X", 0), createOperation("CX", 1, [0])]);
    const result = routeCircuitToConnectivity(source, { qubitCount: 2, directed: true, edges: [[1, 0]] });
    expect(result.circuit.operations.filter((operation) => operation.gate === "H")).toHaveLength(4);
  });
});
