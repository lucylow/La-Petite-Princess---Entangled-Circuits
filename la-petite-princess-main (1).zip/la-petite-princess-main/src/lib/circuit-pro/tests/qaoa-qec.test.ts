// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { describe, expect, it } from "vitest";
import { qaoaMaxCutCircuit, triangleGraph, evaluateQaoaState, bruteForceMaxCut } from "../qaoa";
import { simulateCircuit } from "../simulator";
import { encodeThreeQubitRepetition, injectBitFlip, recoverFromSingleBitFlip, measureParitySyndrome } from "../qec";
import { complex } from "../../advanced/complex";

describe("QAOA and repetition-code labs", () => {
  it("evaluates a triangle MaxCut circuit", () => {
    const graph = triangleGraph(); const circuit = qaoaMaxCutCircuit(graph, { gammas: [0.4], betas: [0.2] });
    const result = evaluateQaoaState(simulateCircuit(circuit).state, graph);
    expect(result.expectedCut).toBeGreaterThan(0);
    expect(bruteForceMaxCut(graph).bestValue).toBe(2);
  });
  it("recovers a known single-qubit bit flip", () => {
    const encoded = encodeThreeQubitRepetition([complex(Math.SQRT1_2), complex(Math.SQRT1_2)]);
    const corrupted = injectBitFlip(encoded, 1);
    const result = recoverFromSingleBitFlip(corrupted, 1);
    expect(result.corrected).toBe(true);
    expect(measureParitySyndrome([1, 0, 0]).errorQubit).toBe(0);
  });
});
