// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { describe, expect, it } from "vitest";
import { wilsonInterval, estimateBernoulli, histogramFromShots, chiSquaredGoodnessOfFit, normalizedEntropy } from "../statistics";

describe("shot statistics", () => {
  it("gives a finite Wilson interval for zero observed successes", () => {
    const interval = wilsonInterval(0, 100);
    expect(interval.lower).toBe(0); expect(interval.upper).toBeGreaterThan(0); expect(interval.upper).toBeLessThan(0.1);
  });
  it("estimates a balanced Bernoulli probability", () => {
    const estimate = estimateBernoulli(500, 1000);
    expect(estimate.estimate).toBe(0.5);
    expect(estimate.lower95).toBeLessThan(0.5);
    expect(estimate.upper95).toBeGreaterThan(0.5);
  });
  it("computes a flat histogram and entropy", () => {
    const result = { shots: 100, counts: { "0": 50, "1": 50 }, frequencies: { "0": 0.5, "1": 0.5 }, idealProbabilities: { "0": 0.5, "1": 0.5 } };
    expect(histogramFromShots(result)).toHaveLength(2);
    expect(normalizedEntropy(result.frequencies)).toBeCloseTo(1, 9);
    expect(chiSquaredGoodnessOfFit({ "0": 50, "1": 50 }, { "0": 50, "1": 50 }).chiSquared).toBe(0);
  });
});
