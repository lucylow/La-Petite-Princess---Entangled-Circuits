// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { describe, expect, it } from "vitest";
import { bernsteinVaziraniCircuit, preparePlusStateCircuit, randomCircuit } from "../advancedAlgorithms";
import { simulateCircuit } from "../simulator";
import { probabilityMap } from "../statevector";
import { graphStateTemplate, textbookCircuitTemplates, bellStateTemplate } from "../templates";

describe("algorithm and circuit templates", () => {
  it("recovers the Bernstein–Vazirani hidden string", () => {
    const circuit = bernsteinVaziraniCircuit("101");
    const distribution = probabilityMap(simulateCircuit(circuit).state, 4, false);
    expect(distribution["1101"]).toBeCloseTo(0.5, 8);
    expect(distribution["0101"]).toBeCloseTo(0.5, 8);
  });
  it("creates a uniform superposition on 4 qubits", () => {
    const values = Object.values(probabilityMap(simulateCircuit(preparePlusStateCircuit(4)).state, 4, false));
    expect(values).toHaveLength(16); values.forEach((value) => expect(value).toBeCloseTo(1 / 16, 8));
  });
  it("generates repeatable random circuits", () => {
    expect(randomCircuit(4, 6, 99).operations.map(({ gate, targets, controls, params }) => ({ gate, targets, controls, params }))).toEqual(randomCircuit(4, 6, 99).operations.map(({ gate, targets, controls, params }) => ({ gate, targets, controls, params })));
  });
  it("creates graph states with the correct edge count", () => {
    expect(graphStateTemplate(4, [[0, 1], [1, 2], [2, 3]]).operations.filter((item) => item.gate === "CZ")).toHaveLength(3);
    expect(textbookCircuitTemplates().length).toBeGreaterThanOrEqual(4);
    expect(bellStateTemplate("psi-minus").operations.length).toBe(4);
  });
});
