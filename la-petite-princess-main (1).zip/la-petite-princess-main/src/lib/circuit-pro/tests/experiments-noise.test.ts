// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { describe, expect, it } from "vitest";
import { createCircuit, createOperation } from "../circuit";
import { runExperimentBatch, sampleRotationSweep, linspace } from "../experiments";
import { sweepNoiseStrength, bootstrapMean, noiseSweepCsv } from "../noiseEnsemble";

describe("experiment automation", () => {
  const circuit = createCircuit("H", 1, 1, [createOperation("H", 0)]);
  it("runs a batch and preserves IDs", () => {
    const results = runExperimentBatch([{ id: "a", label: "A", circuit }, { id: "b", label: "B", circuit }], { shots: 50, seed: 3 });
    expect(results.map((item) => item.id)).toEqual(["a", "b"]);
    expect(results[0].shots?.shots).toBe(50);
  });
  it("sweeps a rotation parameter", () => {
    const result = sampleRotationSweep((theta) => createCircuit("RY", 1, 1, [createOperation("RY", 0, [], { theta })]), [0, Math.PI]);
    expect(result.points).toHaveLength(2);
    expect(result.points[0].probabilities["0"]).toBeCloseTo(1, 9);
  });
  it("builds inclusive linear parameter values", () => {
    expect(linspace(0, 1, 3)).toEqual([0, 0.5, 1]);
  });
  it("runs a noise strength study and exports CSV", () => {
    const result = sweepNoiseStrength(circuit, "depolarizing", [0, 0.2], 100, 12);
    expect(result.points).toHaveLength(2);
    expect(noiseSweepCsv(result)).toContain("total_variation");
  });
  it("bootstraps a mean reproducibly", () => {
    expect(bootstrapMean([1, 2, 3], 200, 8)).toEqual(bootstrapMean([1, 2, 3], 200, 8));
  });
});
