// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { describe, expect, it } from "vitest";
import { applyGateOperation, singleQubitMatrix } from "../gates";
import { isUnitary, fromRows } from "../matrix";
import { createZeroState, stateNormSquared } from "../statevector";
import { createOperation } from "../circuit";

describe("single-qubit gate library", () => {
  const gateCases = ["I", "X", "Y", "Z", "H", "S", "SDG", "T", "TDG", "SX", "SXDG", "RX", "RY", "RZ", "U3"] as const;
  it.each(gateCases)("%s is unitary", (gate) => {
    const matrix = fromRows(singleQubitMatrix(gate, { theta: 0.37, phi: -0.21, lambda: 0.42 }));
    expect(isUnitary(matrix, 1e-8)).toBe(true);
  });
  it("preserves vector norm for every gate", () => {
    for (const gate of gateCases) {
      const state = applyGateOperation(createZeroState(1), 1, createOperation(gate, 0, [], { theta: 0.7, phi: 0.2, lambda: -0.1 }));
      expect(stateNormSquared(state)).toBeCloseTo(1, 9);
    }
  });
  it("applies controlled gates only on the active control subspace", () => {
    const state = createZeroState(2);
    const h = applyGateOperation(state, 2, createOperation("H", 0));
    const output = applyGateOperation(h, 2, createOperation("CX", 1, [0]));
    expect(output[0].re).toBeCloseTo(Math.SQRT1_2, 9);
    expect(output[3].re).toBeCloseTo(Math.SQRT1_2, 9);
    expect(output[1].re).toBeCloseTo(0, 9);
    expect(output[2].re).toBeCloseTo(0, 9);
  });
  it("implements iSWAP with the expected i phase", () => {
    const input = [0, 0, 1, 0].map((value) => ({ re: value, im: 0 }));
    const output = applyGateOperation(input, 2, createOperation("ISWAP", [0, 1]));
    expect(output[1].re).toBeCloseTo(0, 9);
    expect(output[1].im).toBeCloseTo(1, 9);
  });
});
