// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { describe, expect, it } from "vitest";
import { createCircuit, createOperation } from "../circuit";
import { simulateCircuit } from "../simulator";
import { simulateSparseCircuit, sparseToDense, sparseProbabilityMap, sparseBasisState, sparseMeasure } from "../sparse";
import { stateNormSquared } from "../statevector";

describe("sparse state-vector engine", () => {
  it("matches dense simulation for a sparse GHZ circuit", () => {
    const circuit = createCircuit("GHZ", 5, 5, [createOperation("H", 0), ...Array.from({ length: 4 }, (_, q) => createOperation("CX", q + 1, [0]))]);
    const dense = simulateCircuit(circuit).state; const sparse = sparseToDense(simulateSparseCircuit(circuit).state);
    dense.forEach((value, index) => { expect(sparse[index].re).toBeCloseTo(value.re, 9); expect(sparse[index].im).toBeCloseTo(value.im, 9); });
  });
  it("supports sparse controlled rotations", () => {
    const circuit = createCircuit("controlled rotation", 2, 2, [createOperation("X", 0), createOperation("CRY", 1, [0], { theta: Math.PI / 2 })]);
    const dense = simulateCircuit(circuit).state; const sparse = sparseToDense(simulateSparseCircuit(circuit).state);
    dense.forEach((value, index) => { expect(sparse[index].re).toBeCloseTo(value.re, 9); expect(sparse[index].im).toBeCloseTo(value.im, 9); });
  });
  it("sparse measurement collapses and renormalizes", () => {
    const state = sparseBasisState(2, "10"); const result = sparseMeasure(state, 1, () => 0.2);
    expect(result.outcome).toBe(1); expect(stateNormSquared(sparseToDense(result.state))).toBeCloseTo(1, 9);
  });
  it("preserves the probability map", () => {
    const circuit = createCircuit("H", 1, 1, [createOperation("H", 0)]);
    expect(Object.values(sparseProbabilityMap(simulateSparseCircuit(circuit).state)).reduce((a, b) => a + b, 0)).toBeCloseTo(1, 9);
  });
});
