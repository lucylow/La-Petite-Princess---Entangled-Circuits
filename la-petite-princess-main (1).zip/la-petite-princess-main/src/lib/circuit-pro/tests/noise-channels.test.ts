// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { describe, expect, it } from "vitest";
import { channelKrausOperators, isTracePreserving, applyChannelToDensity } from "../channels";
import { createZeroState } from "../statevector";
import { densityFromState, densityDiagnostics } from "../density";
import { applyT1T2Decoherence, validateRelaxationParameters } from "../decoherence";

describe("quantum channels and decoherence", () => {
  it.each(["bit-flip", "phase-flip", "bit-phase-flip", "depolarizing", "amplitude-damping", "phase-damping", "reset"] as const)("%s is trace preserving", (channel) => {
    expect(isTracePreserving(channelKrausOperators(channel, 0.23))).toBe(true);
  });
  it("amplitude damping preserves the ground state", () => {
    const rho = densityFromState(createZeroState(1));
    const out = applyChannelToDensity(rho, 1, 0, "amplitude-damping", 0.8);
    expect(out.data[0][0].re).toBeCloseTo(1, 9);
  });
  it("amplitude damping relaxes the excited state", () => {
    const rho = densityFromState([{ re: 0, im: 0 }, { re: 1, im: 0 }]);
    const out = applyChannelToDensity(rho, 1, 0, "amplitude-damping", 0.25);
    expect(out.data[0][0].re).toBeCloseTo(0.25, 9);
    expect(out.data[1][1].re).toBeCloseTo(0.75, 9);
  });
  it("rejects non-physical T1/T2 inputs", () => {
    expect(validateRelaxationParameters({ elapsedTime: 1, t1: 1, t2: 3 }).length).toBeGreaterThan(0);
  });
  it("returns a normalized density matrix after T1/T2 decay", () => {
    const rho = densityFromState([{ re: Math.SQRT1_2, im: 0 }, { re: Math.SQRT1_2, im: 0 }]);
    const result = applyT1T2Decoherence(rho, 1, 0, { elapsedTime: 0.5, t1: 2, t2: 2 });
    expect(result.diagnostics.trace).toBeCloseTo(1, 8);
  });
});
