// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { describe, expect, it } from "vitest";
import { marginalFromCounts, pairCorrelation, parityStatistics, parityFromBitstring, shotResultToCsv } from "../measurementStatistics";

describe("measurement result analytics", () => {
  const counts = { "00": 45, "11": 55 };
  it("computes parity from a bitstring", () => {
    expect(parityFromBitstring("1011")).toBe(1);
    expect(parityFromBitstring("1100")).toBe(0);
  });
  it("computes even and odd shot counts", () => {
    const result = parityStatistics(counts);
    expect(result.evenCount).toBe(100); expect(result.oddCount).toBe(0);
  });
  it("computes single-qubit marginals using little-endian qubit indices", () => {
    const result = marginalFromCounts(counts, 2);
    expect(result[0].probabilityOne).toBeCloseTo(0.55, 8);
    expect(result[1].probabilityOne).toBeCloseTo(0.55, 8);
  });
  it("computes pairwise correlation", () => {
    const result = pairCorrelation(counts, 0, 1);
    expect(result.correlation).toBeCloseTo(1, 9);
  });
  it("exports shot counts as CSV", () => {
    const csv = shotResultToCsv({ shots: 100, counts, frequencies: { "00": 0.45, "11": 0.55 }, idealProbabilities: { "00": 0.5, "11": 0.5 } });
    expect(csv).toContain("bitstring,count,frequency,ideal_probability");
    expect(csv).toContain("11,55,0.55000000,0.5");
  });
});
