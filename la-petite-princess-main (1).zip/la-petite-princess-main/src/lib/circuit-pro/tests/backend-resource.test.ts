// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { describe, expect, it } from "vitest";
import { LocalQuantumBackend, BackendRegistry, LOCAL_STATEVECTOR_BACKEND, backendCompatibility } from "../backend";
import { createCircuit, createOperation } from "../circuit";
import { estimateCircuitResources, formatBytes } from "../resourceEstimate";

describe("backend and resource interfaces", () => {
  it("runs a local backend request", async () => {
    const circuit = createCircuit("H", 1, 1, [createOperation("H", 0)]);
    const response = await new LocalQuantumBackend().run({ circuit, shots: 100, seed: 7 });
    expect(response.shots?.shots).toBe(100);
    expect(response.backend.id).toBe("local-statevector");
  });
  it("registers unique backend IDs", () => {
    const registry = new BackendRegistry(); registry.register(new LocalQuantumBackend());
    expect(registry.list()).toHaveLength(1);
    expect(() => registry.register(new LocalQuantumBackend())).toThrow();
  });
  it("checks backend circuit limits", () => {
    const tooLarge = createCircuit("large", 11, 11);
    expect(backendCompatibility(LOCAL_STATEVECTOR_BACKEND, tooLarge).length).toBeGreaterThan(0);
  });
  it("formats memory sizes", () => {
    expect(formatBytes(1024)).toBe("1.00 KiB");
    expect(estimateCircuitResources(createCircuit("one", 1, 1)).stateVectorBytes).toBe(32);
  });
});
