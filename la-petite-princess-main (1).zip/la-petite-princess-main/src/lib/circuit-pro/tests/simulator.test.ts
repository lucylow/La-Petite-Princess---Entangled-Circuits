// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { describe, expect, it } from "vitest";
import { createCircuit, createOperation } from "../circuit";
import { simulateCircuit, runCircuitShots } from "../simulator";
import { bellPairCircuit, ghzCircuit, qftCircuit, groverSearchCircuit } from "../algorithms";
import { probabilityMap } from "../statevector";

describe("ideal circuit simulation", () => {
  it("creates a Bell state", () => {
    const result = simulateCircuit(bellPairCircuit());
    expect(probabilityMap(result.state, 2, false)["00"]).toBeCloseTo(0.5, 9);
    expect(probabilityMap(result.state, 2, false)["11"]).toBeCloseTo(0.5, 9);
  });
  it("creates a three-qubit GHZ state", () => {
    const result = simulateCircuit(ghzCircuit(3));
    expect(probabilityMap(result.state, 3, false)["000"]).toBeCloseTo(0.5, 9);
    expect(probabilityMap(result.state, 3, false)["111"]).toBeCloseTo(0.5, 9);
  });
  it("undoes a Fourier transform", () => {
    const qft = qftCircuit(3);
    const inverse = qftCircuit(3, true);
    const circuit = createCircuit("QFT inverse test", 3, 3, [...qft.operations, ...inverse.operations]);
    const probabilities = probabilityMap(simulateCircuit(circuit).state, 3, false);
    expect(probabilities["000"]).toBeCloseTo(1, 8);
  });
  it("finds a marked two-qubit item with Grover search", () => {
    for (const marked of ["00", "01", "10", "11"]) {
      const result = simulateCircuit(groverSearchCircuit(2, marked));
      expect(probabilityMap(result.state, 2, false)[marked]).toBeCloseTo(1, 8);
    }
  });
  it("repeats sampled results with a fixed seed", () => {
    const circuit = createCircuit("sample", 2, 2, [createOperation("H", 0), createOperation("CX", 1, [0])]);
    expect(runCircuitShots(circuit, 400, 123).counts).toEqual(runCircuitShots(circuit, 400, 123).counts);
  });
});
