// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { describe, expect, it } from "vitest";
import { calibrateRotationGate, applyCalibration, validateCalibrationProfile, calibrationToMarkdown } from "../gateCalibration";
import { createOperation } from "../circuit";

describe("gate calibration tools", () => {
  it("reports zero angle error for a perfect rotation", () => {
    const result = calibrateRotationGate("RX", Math.PI / 3, Math.PI / 3);
    expect(result.angleError).toBeCloseTo(0, 9);
    expect(result.processFidelity).toBeCloseTo(1, 9);
  });
  it("detects a rotation over-rotation", () => {
    const result = calibrateRotationGate("RY", 0.2, 0.3);
    expect(result.angleError).toBeCloseTo(0.1, 9);
    expect(result.processFidelity).toBeLessThan(1);
  });
  it("applies a configured rotation offset", () => {
    const operation = applyCalibration(createOperation("RZ", 0, [], { theta: 0.5 }), { label: "lab", singleQubitAngleOffset: 0.1, depolarizingProbability: 0, readoutFlipProbability: 0 });
    expect(operation.params?.theta).toBeCloseTo(0.6, 9);
  });
  it("validates a profile and clearly labels its illustrative nature", () => {
    const profile = { label: "teaching profile", singleQubitAngleOffset: 0.01, depolarizingProbability: 0.02, readoutFlipProbability: 0.03 };
    expect(validateCalibrationProfile(profile)).toHaveLength(0);
    expect(calibrationToMarkdown(profile)).toContain("not a hardware calibration certificate");
  });
});
