// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { describe, expect, it } from "vitest";
import { createCircuit, createOperation } from "../circuit";
import { trotterizeHamiltonian } from "../hamiltonianEvolution";
import { simulateCircuit } from "../simulator";
import { probabilities } from "../statevector";
import { circuitUnitary } from "../unitary";
import { isUnitary } from "../matrix";

describe("Pauli Hamiltonian product-formula circuits", () => {
  it("produces a unitary Z evolution", () => {
    const circuit = trotterizeHamiltonian([{ paulis: "Z", coefficient: 0.7 }], 1, { time: 0.4, steps: 2 });
    expect(isUnitary(circuitUnitary(circuit))).toBe(true);
  });
  it("preserves computational basis probabilities for Z evolution", () => {
    const prepared = createCircuit("one", 1, 1, [createOperation("X", 0)]);
    const evolution = trotterizeHamiltonian([{ paulis: "Z", coefficient: 1 }], 1, { time: 1.2, steps: 4, order: 2 });
    const combined = createCircuit("combined", 1, 1, [...prepared.operations, ...evolution.operations]);
    expect(probabilities(simulateCircuit(combined).state)[1]).toBeCloseTo(1, 8);
  });
  it("rejects invalid Pauli terms", () => {
    expect(() => trotterizeHamiltonian([{ paulis: "A", coefficient: 1 }], 1, { time: 1 })).toThrow();
  });
});
