// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { describe, expect, it } from "vitest";
import { createCircuit, createOperation } from "../circuit";
import { optimizeCircuit } from "../optimizer";
import { lintCircuit } from "../circuitLint";
import { simulateCircuit } from "../simulator";
import { probabilities } from "../statevector";

describe("circuit optimization and lint", () => {
  it("removes adjacent cancelling Hadamards", () => {
    const input = createCircuit("cancel", 1, 1, [createOperation("H", 0), createOperation("H", 0)]);
    const result = optimizeCircuit(input);
    expect(result.circuit.operations).toHaveLength(0);
  });
  it("preserves ideal output probabilities after optimization", () => {
    const input = createCircuit("optimize", 2, 2, [createOperation("H", 0), createOperation("CX", 1, [0]), createOperation("H", 0), createOperation("H", 0)]);
    const optimized = optimizeCircuit(input).circuit;
    expect(probabilities(simulateCircuit(optimized).state)).toEqual(probabilities(simulateCircuit(input).state));
  });
  it("identifies unused wires and reports a score", () => {
    const report = lintCircuit(createCircuit("unused", 2, 2, [createOperation("H", 0)]));
    expect(report.issues.some((item) => item.code === "UNUSED_QUBIT")).toBe(true);
    expect(report.score).toBeGreaterThanOrEqual(0);
  });
});
