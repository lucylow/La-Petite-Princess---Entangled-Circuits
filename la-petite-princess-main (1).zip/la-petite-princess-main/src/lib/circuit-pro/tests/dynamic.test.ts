// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { describe, expect, it } from "vitest";
import { executeDynamicShot, runDynamicShots, validateDynamicCircuit } from "../dynamic";
import { quantumTeleportationDemo } from "../advancedAlgorithms";
import { reducedDensityMatrix } from "../density";
import { singleQubitMatrix } from "../gates";
import { complex, cConjugate, cMul, cMagnitudeSquared } from "../../advanced/complex";

describe("dynamic circuits", () => {
  it("teleports a prepared state to the destination qubit", () => {
    const demo = quantumTeleportationDemo({ theta: 0.83, phi: 0.2, lambda: -0.3 });
    const result = executeDynamicShot(demo.circuit, () => 0.37);
    const actual = reducedDensityMatrix(result.state, 3, [2]);
    const u = singleQubitMatrix("U3", { theta: 0.83, phi: 0.2, lambda: -0.3 });
    const alpha = u[0][0]; const beta = u[1][0];
    expect(actual.data[0][0].re).toBeCloseTo(cMagnitudeSquared(alpha), 8);
    expect(actual.data[1][1].re).toBeCloseTo(cMagnitudeSquared(beta), 8);
    const coherence = cMul(alpha, cConjugate(beta));
    expect(actual.data[0][1].re).toBeCloseTo(coherence.re, 8);
    expect(actual.data[0][1].im).toBeCloseTo(coherence.im, 8);
    expect(result.measurements).toHaveLength(2);
    expect(result.branchTrace).toHaveLength(2);
  });
  it("executes reset after a deterministic bit flip", () => {
    const circuit = { id: "reset", name: "reset", qubitCount: 1, classicalBitCount: 1, instructions: [
      { kind: "gate" as const, operation: { id: "x", gate: "X" as const, targets: [0] } },
      { kind: "reset" as const, qubit: 0 },
      { kind: "measure" as const, qubit: 0, classicalBit: 0 },
    ] };
    const result = executeDynamicShot(circuit, () => 0.9);
    expect(result.classicalBits[0]).toBe(0);
  });
  it("records deterministic measurement-conditioned branches", () => {
    const result = runDynamicShots(quantumTeleportationDemo({ theta: Math.PI / 2 }).circuit, 300, 7);
    expect(Object.values(result.counts).reduce((a, b) => a + b, 0)).toBe(300);
  });
  it("validates an out-of-range measurement", () => {
    const circuit = { id: "bad", name: "bad", qubitCount: 1, classicalBitCount: 1, instructions: [{ kind: "measure" as const, qubit: 2, classicalBit: 0 }] };
    expect(validateDynamicCircuit(circuit).length).toBeGreaterThan(0);
  });
});
