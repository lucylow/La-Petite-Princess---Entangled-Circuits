// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { describe, expect, it } from "vitest";
import { bellPairCircuit } from "../algorithms";
import { simulateCircuit } from "../simulator";
import { densityFromState, reducedDensityMatrix, densityDiagnostics } from "../density";
import { matrixClose, identity, isHermitian } from "../matrix";
import { complex } from "../../advanced/complex";

describe("density matrices", () => {
  it("reduces a Bell pair to a maximally mixed qubit", () => {
    const state = simulateCircuit(bellPairCircuit()).state;
    const reduced = reducedDensityMatrix(state, 2, [0]);
    expect(reduced.data[0][0].re).toBeCloseTo(0.5, 9);
    expect(reduced.data[1][1].re).toBeCloseTo(0.5, 9);
    expect(reduced.data[0][1].re).toBeCloseTo(0, 9);
    expect(densityDiagnostics(reduced).purity).toBeCloseTo(0.5, 9);
  });
  it("constructs a rank-one density matrix from a pure state", () => {
    const rho = densityFromState([complex(Math.SQRT1_2), complex(0, Math.SQRT1_2)]);
    expect(isHermitian(rho)).toBe(true);
    expect(densityDiagnostics(rho).purity).toBeCloseTo(1, 9);
  });
  it("partial trace keeps requested subsystems", () => {
    const state = simulateCircuit(bellPairCircuit()).state;
    expect(reducedDensityMatrix(state, 2, [1])).toEqual(reducedDensityMatrix(state, 2, [0]));
  });
  it("identity matrix is Hermitian and unitary", () => {
    expect(matrixClose(identity(4), identity(4))).toBe(true);
  });
});
