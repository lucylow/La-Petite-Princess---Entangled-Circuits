// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { describe, expect, it } from "vitest";
import { quantumWalkLineCircuit, summarizeQuantumWalk } from "../quantumWalk";
import { gridSearchQaoa, qaoaHistoryCsv } from "../qaoaOptimizer";
import { triangleGraph } from "../qaoa";

describe("advanced circuit experiments", () => {
  it("keeps quantum-walk probability normalized", () => {
    const circuit = quantumWalkLineCircuit(3, 3, 0);
    const summary = summarizeQuantumWalk(circuit);
    const total = summary.positions.reduce((sum, item) => sum + item.probability, 0);
    expect(total).toBeCloseTo(1, 8);
    expect(summary.positions).toHaveLength(8);
  });
  it("moves the walk away from its initial position", () => {
    const summary = summarizeQuantumWalk(quantumWalkLineCircuit(3, 2, 0));
    expect(summary.positions.some((item) => item.position !== 0 && item.probability > 0.01)).toBe(true);
  });
  it("runs a bounded coarse QAOA parameter search", () => {
    const result = gridSearchQaoa(triangleGraph(), { layers: 1, gridPoints: 4 });
    expect(result.evaluations).toBe(16);
    expect(result.best.expectedCut).toBeGreaterThan(0);
    expect(qaoaHistoryCsv(result)).toContain("approximation_ratio");
  });
});
