// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { describe, expect, it } from "vitest";
import { createCircuit, createOperation } from "../circuit";
import { inverseCircuit, concatenateCircuits } from "../reversible";
import { simulateCircuit } from "../simulator";
import { probabilityMap } from "../statevector";
import { twoQubitEntanglementReport } from "../entanglementMeasures";
import { bellPairCircuit } from "../algorithms";
import { unitaryEquivalenceUpToGlobalPhase, circuitUnitary } from "../unitary";

describe("reversible circuit operations and entanglement measures", () => {
  it("inverts phase and rotation gates", () => {
    const circuit = createCircuit("phase", 1, 1, [createOperation("H", 0), createOperation("T", 0), createOperation("RX", 0, [], { theta: 0.31 })]);
    const combined = concatenateCircuits("U dagger U", [circuit, inverseCircuit(circuit)]);
    expect(probabilityMap(simulateCircuit(combined).state, 1, false)["0"]).toBeCloseTo(1, 8);
  });
  it("inverts iSWAP using local phase corrections", () => {
    const circuit = createCircuit("iswap", 2, 2, [createOperation("H", 0), createOperation("CX", 1, [0]), createOperation("ISWAP", [0, 1])]);
    const inverse = inverseCircuit(circuit);
    expect(unitaryEquivalenceUpToGlobalPhase(circuitUnitary(concatenateCircuits("U†U", [circuit, inverse])), circuitUnitary(createCircuit("I", 2, 2))).equivalent).toBe(true);
  });
  it("recognizes Bell-state entanglement through negativity", () => {
    const report = twoQubitEntanglementReport(simulateCircuit(bellPairCircuit()).state);
    expect(report.concurrence).toBeCloseTo(1, 8);
    expect(report.negativity).toBeCloseTo(0.5, 8);
    expect(report.logarithmicNegativity).toBeCloseTo(1, 8);
    expect(report.pptEntangled).toBe(true);
  });
  it("concatenates compatible circuits", () => {
    const one = createCircuit("H", 1, 1, [createOperation("H", 0)]);
    const two = createCircuit("X", 1, 1, [createOperation("X", 0)]);
    expect(concatenateCircuits("combined", [one, two]).operations).toHaveLength(2);
  });
});
