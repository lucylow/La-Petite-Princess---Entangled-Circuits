// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { describe, expect, it } from "vitest";
import { createCircuit, createOperation } from "../circuit";
import { simulateCircuit } from "../simulator";
import { blochVectorFromState, cartesianToSpherical, sphericalToCartesian, densityFromBlochVector } from "../bloch";
import { singleQubitProcessTomography, averageGateFidelityFromTransfer } from "../processTomography";
import { stateNormSquared } from "../statevector";

describe("Bloch sphere and process characterization", () => {
  it("maps |+⟩ to the positive X pole", () => {
    const state = simulateCircuit(createCircuit("plus", 1, 1, [createOperation("H", 0)])).state;
    const point = blochVectorFromState(state, 1, 0);
    expect(point.x).toBeCloseTo(1, 8); expect(point.y).toBeCloseTo(0, 8); expect(point.z).toBeCloseTo(0, 8);
  });
  it("round-trips spherical and Cartesian coordinates", () => {
    const point = sphericalToCartesian({ theta: 0.7, phi: -1.2, radius: 0.8 });
    const spherical = cartesianToSpherical(point);
    expect(spherical.theta).toBeCloseTo(0.7, 8); expect(spherical.phi).toBeCloseTo(-1.2, 8);
    expect(stateNormSquared([densityFromBlochVector(point).data[0][0], densityFromBlochVector(point).data[1][1]])).toBeGreaterThan(0);
  });
  it("recovers the Hadamard Bloch transfer matrix", () => {
    const report = singleQubitProcessTomography(createCircuit("H", 1, 1, [createOperation("H", 0)]));
    expect(report.transferMatrix[0][2]).toBeCloseTo(1, 8);
    expect(averageGateFidelityFromTransfer(report)).toBeGreaterThan(0);
  });
});
