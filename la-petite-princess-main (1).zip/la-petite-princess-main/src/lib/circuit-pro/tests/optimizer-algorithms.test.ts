// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { describe, expect, it } from "vitest";
import { optimizeWithAdam, optimizeWithSpsa, coordinateDescent } from "../variationalOptimizers";

describe("classical optimizers for variational circuits", () => {
  const bowl = (values: number[]) => values.reduce((sum, value) => sum + (value - 0.75) ** 2, 0);
  it("Adam minimizes a smooth quadratic objective", () => {
    const result = optimizeWithAdam(bowl, [2, -1], { learningRate: 0.08, iterations: 400 });
    expect(result.value).toBeLessThan(1e-5);
    expect(result.parameters[0]).toBeCloseTo(0.75, 2);
  });
  it("SPSA is deterministic for a fixed seed", () => {
    const a = optimizeWithSpsa(bowl, [1, 1], { seed: 23, iterations: 100 });
    const b = optimizeWithSpsa(bowl, [1, 1], { seed: 23, iterations: 100 });
    expect(a.parameters).toEqual(b.parameters);
    expect(a.value).toBe(b.value);
  });
  it("coordinate descent reduces objective value", () => {
    const result = coordinateDescent(bowl, [-1, 2], { iterations: 200 });
    expect(result.value).toBeLessThan(bowl([-1, 2]));
  });
});
