// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { describe, expect, it } from "vitest";
import { createCircuit, createOperation } from "../circuit";
import { createParameterizedCircuit, bindCircuitParameters, gridParameterBindings, wrapAngle } from "../parameterized";

describe("parameterized circuits", () => {
  const template = createParameterizedCircuit(createCircuit("Rz template", 1, 1, [createOperation("RZ", 0, [], { theta: "$angle" as unknown as number })]), [{ name: "angle", label: "Rotation angle", defaultValue: 0.5, min: -Math.PI, max: Math.PI }]);
  it("binds defaults and supplied numeric parameters", () => {
    const result = bindCircuitParameters(template, { angle: 1.2 });
    expect(result.circuit.operations[0].params?.theta).toBeCloseTo(1.2, 9);
  });
  it("rejects unknown and out-of-range bindings", () => {
    expect(() => bindCircuitParameters(template, { other: 1 })).toThrow();
    expect(() => bindCircuitParameters(template, { angle: 9 })).toThrow();
  });
  it("generates bounded cartesian parameter grids", () => {
    expect(gridParameterBindings(template.parameters, 4)).toHaveLength(4);
    expect(() => gridParameterBindings(template.parameters, 20, 10)).toThrow();
  });
  it("wraps periodic angles into a canonical interval", () => {
    expect(wrapAngle(3 * Math.PI)).toBeCloseTo(-Math.PI, 8);
  });
});
