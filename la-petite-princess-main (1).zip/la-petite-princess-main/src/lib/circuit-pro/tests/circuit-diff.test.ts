// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { describe, expect, it } from "vitest";
import { createCircuit, createOperation, appendOperation, removeOperation } from "../circuit";
import { diffCircuits, diffToMarkdown, circuitVersionHash } from "../circuitDiff";

describe("circuit revisions", () => {
  it("recognizes an identical circuit", () => {
    const circuit = createCircuit("same", 1, 1, [createOperation("H", 0)]);
    expect(diffCircuits(circuit, circuit).identical).toBe(true);
  });
  it("detects added and removed operations", () => {
    const first = createCircuit("revision", 1, 1, [createOperation("H", 0)]);
    const second = appendOperation(first, createOperation("X", 0));
    expect(diffCircuits(first, second).changes.some((change) => change.kind === "added")).toBe(true);
    expect(diffCircuits(second, removeOperation(second, first.operations[0].id)).changes.some((change) => change.kind === "removed")).toBe(true);
  });
  it("renders a revision summary", () => {
    const a = createCircuit("a", 1, 1); const b = { ...a, name: "b" };
    expect(diffToMarkdown(diffCircuits(a, b))).toContain("name changed");
    expect(circuitVersionHash(a)).not.toBe("");
  });
});
