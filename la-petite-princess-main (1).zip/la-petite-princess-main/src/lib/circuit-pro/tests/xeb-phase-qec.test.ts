// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { describe, expect, it } from "vitest";
import { createCircuit, createOperation } from "../circuit";
import { runXebExperiment } from "../crossEntropyBenchmark";
import { runCircuitShots } from "../simulator";
import { summarizePhaseEstimation } from "../phaseEstimationAnalysis";
import { encodeThreeQubitPhaseRepetition, injectPhaseFlip, correctKnownPhaseFlip } from "../phaseFlipCode";
import { fidelityOfPureStates } from "../entanglementMeasures";
import { complex } from "../../advanced/complex";

describe("benchmarking, phase estimation and phase-flip code", () => {
  it("reports positive ideal XEB for a Bell distribution", () => {
    const circuit = createCircuit("Bell", 2, 2, [createOperation("H", 0), createOperation("CX", 1, [0])]);
    expect(runXebExperiment(circuit, 1000, 9).idealLinearXeb).toBeCloseTo(1, 8);
  });
  it("summarizes a concentrated phase estimate", () => {
    const result = { shots: 100, counts: { "0100": 100 }, frequencies: { "0100": 1 }, idealProbabilities: { "0100": 1 } };
    const estimate = summarizePhaseEstimation(result, 4);
    expect(estimate.phase).toBeCloseTo(0.25, 8);
    expect(estimate.mostLikelyBitstring).toBe("0100");
  });
  it("recovers a known phase flip", () => {
    const logical = [complex(0.8), complex(0, 0.6)];
    const encoded = encodeThreeQubitPhaseRepetition(logical);
    const recovered = correctKnownPhaseFlip(injectPhaseFlip(encoded, 1), 1);
    expect(fidelityOfPureStates(encoded, recovered.state)).toBeCloseTo(1, 8);
  });
  it("retains unitary behavior for the zero-error phase code", () => {
    const encoded = encodeThreeQubitPhaseRepetition([complex(1), complex(0)]);
    const recovered = correctKnownPhaseFlip(encoded, null);
    expect(fidelityOfPureStates(encoded, recovered.state)).toBeCloseTo(1, 8);
  });
});
