// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { describe, expect, it } from "vitest";
import { bellPairCircuit } from "../algorithms";
import { simulateCircuit } from "../simulator";
import { reconstructPureStateTomography, reconstructSampledTomography, enumeratePauliStrings } from "../multiQubitTomography";
import { densityDiagnostics } from "../density";

describe("multi-qubit Pauli tomography", () => {
  it("enumerates the full Pauli basis", () => {
    expect(enumeratePauliStrings(2)).toHaveLength(16);
    expect(enumeratePauliStrings(2)).toContain("XX");
    expect(enumeratePauliStrings(2)).toContain("ZZ");
  });
  it("reconstructs a Bell-state density matrix from ideal Pauli expectations", () => {
    const state = simulateCircuit(bellPairCircuit()).state;
    const report = reconstructPureStateTomography(state, 2);
    expect(report.trace).toBeCloseTo(1, 8);
    expect(report.purity).toBeCloseTo(1, 8);
    expect(report.minimumEigenvalue).toBeGreaterThan(-1e-8);
  });
  it("produces a physical, trace-one sampled estimate within finite-shot tolerance", () => {
    const state = simulateCircuit(bellPairCircuit()).state;
    const report = reconstructSampledTomography(state, 2, 1000, 123);
    expect(report.trace).toBeCloseTo(1, 8);
    expect(report.hermitian).toBe(true);
    expect(report.estimates.length).toBe(16);
  });
});
