// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { describe, expect, it } from "vitest";
import { createCircuit, createOperation } from "../circuit";
import { estimateCircuitResources, memoryGrowthTable } from "../resourceEstimate";
import { diffCircuits, circuitVersionHash } from "../circuitDiff";
import { circuitMetrics } from "../metrics";
import { lintCircuit } from "../circuitLint";

describe("engineering tools", () => {
  it("estimates exponential state-vector and density matrix costs", () => {
    const report = estimateCircuitResources(createCircuit("small", 4, 4));
    expect(report.stateVectorBytes).toBe(256);
    expect(report.densityMatrixBytes).toBe(4096);
    expect(memoryGrowthTable(4)).toHaveLength(4);
  });
  it("diffs circuits by stable operation IDs", () => {
    const first = createCircuit("one", 1, 1, [createOperation("H", 0)]);
    const second = { ...first, operations: [createOperation("X", 0)] };
    expect(diffCircuits(first, second).changes[0].kind).toBe("removed");
    expect(circuitVersionHash(first)).toMatch(/^[0-9a-f]{8}$/);
  });
  it("reports gate depth and lint score", () => {
    const circuit = createCircuit("two", 2, 2, [createOperation("H", 0), createOperation("CX", 1, [0])]);
    expect(circuitMetrics(circuit).depth).toBeGreaterThanOrEqual(2);
    expect(lintCircuit(circuit).passed).toBe(true);
  });
});
