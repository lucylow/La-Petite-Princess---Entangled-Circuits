// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { describe, expect, it } from "vitest";
import { createCircuit, createOperation } from "../circuit";
import { serializeCircuit, parseCircuit, circuitToOpenQasm } from "../serialization";
import { circuitToOpenQasm3 } from "../qasm3";

describe("circuit interchange formats", () => {
  const circuit = createCircuit("Bell with phase", 2, 2, [createOperation("H", 0), createOperation("CX", 1, [0]), createOperation("RZ", 1, [], { theta: Math.PI / 2 })]);
  it("round-trips through JSON", () => {
    expect(parseCircuit(serializeCircuit(circuit))).toEqual(circuit);
  });
  it("exports QASM 2", () => {
    const qasm = circuitToOpenQasm(circuit);
    expect(qasm).toContain("OPENQASM 2.0;"); expect(qasm).toContain("cx q[0],q[1];");
  });
  it("exports OpenQASM 3 declarations and operations", () => {
    const qasm = circuitToOpenQasm3(circuit);
    expect(qasm).toContain("OPENQASM 3.0;"); expect(qasm).toContain("qubit[2] q;"); expect(qasm).toContain("rz(pi / 2) q[1];");
  });
  it("exports an educational Qiskit starter", () => {
    expect(circuitToOpenQasm3(circuit)).toContain("include \"stdgates.inc\";");
  });
});
