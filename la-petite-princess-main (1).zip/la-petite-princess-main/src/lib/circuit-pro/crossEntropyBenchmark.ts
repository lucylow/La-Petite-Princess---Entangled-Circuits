// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import type { CircuitDefinition, ShotResult } from "./types";
import { simulateCircuit, runCircuitShots } from "./simulator";
import { probabilities } from "./statevector";
import { basisLabel } from "./statevector";

export interface XebReport { qubits: number; shots: number; linearXeb: number; idealLinearXeb: number; collisionProbability: number; uniformBaseline: number; histogram: Record<string, number>; }
export function linearCrossEntropyBenchmark(circuit: CircuitDefinition, result: ShotResult): XebReport {
  if (result.shots < 1) throw new Error("XEB requires at least one shot.");
  const ideal = probabilities(simulateCircuit(circuit).state);
  let measuredIdealProbability = 0;
  for (const [bitstring, count] of Object.entries(result.counts)) {
    const index = Number.parseInt(bitstring, 2);
    if (!Number.isInteger(index) || index < 0 || index >= ideal.length) throw new Error(`Invalid measured bitstring ${bitstring}.`);
    measuredIdealProbability += (count / result.shots) * ideal[index];
  }
  const dimension = 2 ** circuit.qubitCount;
  const linearXeb = dimension * measuredIdealProbability - 1;
  const collisionProbability = ideal.reduce((sum, probability) => sum + probability ** 2, 0);
  const idealLinearXeb = dimension * collisionProbability - 1;
  return { qubits: circuit.qubitCount, shots: result.shots, linearXeb, idealLinearXeb, collisionProbability, uniformBaseline: 0, histogram: { ...result.counts } };
}
export function runXebExperiment(circuit: CircuitDefinition, shots = 2000, seed = 1): XebReport {
  return linearCrossEntropyBenchmark(circuit, runCircuitShots(circuit, shots, seed));
}
export function xebToMarkdown(report: XebReport): string {
  return ["# Linear cross-entropy benchmarking", "", `- Qubits: ${report.qubits}`, `- Shots: ${report.shots}`, `- Sampled linear XEB: ${report.linearXeb.toFixed(6)}`, `- Ideal collision-based XEB: ${report.idealLinearXeb.toFixed(6)}`, `- Collision probability: ${report.collisionProbability.toFixed(6)}`, `- Uniform baseline: ${report.uniformBaseline.toFixed(1)}`, "", "XEB is a circuit-distribution benchmark. Interpretation depends on the ensemble of circuits and sampling model; this educational simulator is not a hardware fidelity measurement."].join("\n");
}
export function sampleDistributionFromHistogram(histogram: Record<string, number>, qubitCount: number): number[] {
  const total = Object.values(histogram).reduce((sum, value) => sum + value, 0);
  if (!total) throw new Error("Histogram is empty.");
  const result = Array(2 ** qubitCount).fill(0);
  for (const [label, count] of Object.entries(histogram)) {
    if (label.length !== qubitCount || !/^[01]+$/.test(label) || count < 0) throw new Error("Histogram contains an invalid key or count.");
    result[Number.parseInt(label, 2)] += count / total;
  }
  return result;
}
export function idealDistributionMap(circuit: CircuitDefinition): Record<string, number> {
  return Object.fromEntries(probabilities(simulateCircuit(circuit).state).map((value, index) => [basisLabel(index, circuit.qubitCount), value]));
}
