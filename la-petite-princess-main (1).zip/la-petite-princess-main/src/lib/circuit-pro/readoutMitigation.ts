// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
export interface ReadoutErrorRates { zeroToOne: number; oneToZero: number; }
export interface MitigationResult { raw: Record<string, number>; mitigated: Record<string, number>; corrected: Record<string, number>; conditionEstimate: number; warnings: string[]; }
export function validateReadoutRates(rates: ReadoutErrorRates): string[] {
  return [rates.zeroToOne, rates.oneToZero].flatMap((value, index) => !Number.isFinite(value) || value < 0 || value >= 0.5 ? [`Readout error rate ${index + 1} must be in [0, 0.5).`] : []);
}
export function singleQubitConfusionMatrix(rates: ReadoutErrorRates): number[][] {
  const errors = validateReadoutRates(rates); if (errors.length) throw new Error(errors.join(" "));
  return [[1 - rates.zeroToOne, rates.oneToZero], [rates.zeroToOne, 1 - rates.oneToZero]];
}
export function tensorConfusionMatrix(qubitRates: ReadoutErrorRates[]): number[][] {
  if (!qubitRates.length || qubitRates.length > 8) throw new RangeError("Readout tensor model supports 1–8 qubits.");
  let matrix = [[1]];
  for (const rates of qubitRates) {
    const local = singleQubitConfusionMatrix(rates); const next = Array.from({ length: matrix.length * 2 }, () => Array.from({ length: matrix.length * 2 }, () => 0));
    for (let r = 0; r < matrix.length; r += 1) for (let c = 0; c < matrix.length; c += 1)
      for (let lr = 0; lr < 2; lr += 1) for (let lc = 0; lc < 2; lc += 1) next[r * 2 + lr][c * 2 + lc] = matrix[r][c] * local[lr][lc];
    matrix = next;
  }
  return matrix;
}
function solveLinearSystem(matrix: number[][], vector: number[]): number[] {
  const n = vector.length; const a = matrix.map((row, index) => [...row, vector[index]]);
  for (let column = 0; column < n; column += 1) {
    let pivot = column;
    for (let row = column + 1; row < n; row += 1) if (Math.abs(a[row][column]) > Math.abs(a[pivot][column])) pivot = row;
    if (Math.abs(a[pivot][column]) < 1e-12) throw new Error("Readout calibration matrix is singular or ill-conditioned.");
    [a[column], a[pivot]] = [a[pivot], a[column]];
    const scale = a[column][column]; for (let c = column; c <= n; c += 1) a[column][c] /= scale;
    for (let row = 0; row < n; row += 1) {
      if (row === column) continue; const factor = a[row][column];
      for (let c = column; c <= n; c += 1) a[row][c] -= factor * a[column][c];
    }
  }
  return a.map((row) => row[n]);
}
export function mitigateReadoutCounts(counts: Record<string, number>, qubitRates: ReadoutErrorRates[]): MitigationResult {
  const n = qubitRates.length; const dimension = 2 ** n; const labels = Array.from({ length: dimension }, (_, index) => index.toString(2).padStart(n, "0"));
  const total = Object.values(counts).reduce((sum, value) => sum + value, 0);
  if (total <= 0 || !Number.isFinite(total)) throw new Error("Counts must have positive total shots.");
  const rawVector = labels.map((label) => (counts[label] ?? 0) / total);
  const matrix = tensorConfusionMatrix(qubitRates); const mitigatedVector = solveLinearSystem(matrix, rawVector);
  const mitigated = Object.fromEntries(labels.map((label, index) => [label, mitigatedVector[index]]));
  const clipped = mitigatedVector.map((value) => Math.max(0, value)); const clippedTotal = clipped.reduce((sum, value) => sum + value, 0);
  const corrected = Object.fromEntries(labels.map((label, index) => [label, clippedTotal > 0 ? clipped[index] / clippedTotal : 0]));
  const warnings = mitigatedVector.some((value) => value < 0) ? ["Linear inversion produced negative quasi-probabilities; the corrected view clips and renormalizes them."] : [];
  const maximumRate = Math.max(...qubitRates.flatMap((rate) => [rate.zeroToOne, rate.oneToZero]));
  const conditionEstimate = (1 + 2 * maximumRate) / Math.max(1e-12, 1 - 2 * maximumRate);
  return { raw: Object.fromEntries(labels.map((label, index) => [label, rawVector[index]])), mitigated, corrected, conditionEstimate, warnings };
}
