// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { cAdd, cConjugate, cMagnitudeSquared, cMul, complex } from "../advanced/complex";
import type { Complex } from "../advanced/complex";
import type { CircuitDefinition } from "./types";
import { createBasisState, validateQubitCount } from "./statevector";
import { applyGateOperation } from "./gates";
import { zeros, adjoint, multiplyMatrices, trace } from "./matrix";

export function circuitUnitary(circuit: CircuitDefinition, maxQubits = 5) {
  validateQubitCount(circuit.qubitCount, maxQubits);
  if (circuit.operations.some((operation) => operation.gate === "MEASURE")) throw new Error("A circuit containing measurement does not define a unitary operator.");
  const dimension = 2 ** circuit.qubitCount; const unitary = zeros(dimension, dimension);
  for (let column = 0; column < dimension; column += 1) {
    const initial = createBasisState(circuit.qubitCount, column.toString(2).padStart(circuit.qubitCount, "0"));
    // Run every operation from this basis vector to recover one column of U.
    const custom = circuit.operations.reduce((state, operation) => applyGateOperation(state, circuit.qubitCount, operation), initial);
    custom.forEach((amplitude, row) => { unitary.data[row][column] = complex(amplitude.re, amplitude.im); });
  }
  return unitary;
}
export function operatorOverlap(a: ReturnType<typeof circuitUnitary>, b: ReturnType<typeof circuitUnitary>): Complex {
  if (a.rows !== b.rows || a.cols !== b.cols) throw new Error("Unitary dimensions must match.");
  const product = multiplyMatrices(adjoint(a), b);
  return trace(product);
}
export function processFidelity(a: ReturnType<typeof circuitUnitary>, b: ReturnType<typeof circuitUnitary>): number {
  const dimension = a.rows; const overlap = operatorOverlap(a, b);
  return Math.min(1, cMagnitudeSquared(overlap) / (dimension * dimension));
}
export function unitaryEquivalenceUpToGlobalPhase(a: ReturnType<typeof circuitUnitary>, b: ReturnType<typeof circuitUnitary>, tolerance = 1e-8): { equivalent: boolean; globalPhase: number; maximumEntryError: number } {
  if (a.rows !== b.rows || a.cols !== b.cols) return { equivalent: false, globalPhase: 0, maximumEntryError: Infinity };
  const overlap = operatorOverlap(b, a); const phase = Math.atan2(overlap.im, overlap.re);
  const factor = complex(Math.cos(phase), Math.sin(phase)); let maximumEntryError = 0;
  for (let row = 0; row < a.rows; row += 1) for (let col = 0; col < a.cols; col += 1) {
    const expected = cMul(factor, b.data[row][col]);
    maximumEntryError = Math.max(maximumEntryError, Math.hypot(a.data[row][col].re - expected.re, a.data[row][col].im - expected.im));
  }
  return { equivalent: maximumEntryError <= tolerance, globalPhase: phase, maximumEntryError };
}
