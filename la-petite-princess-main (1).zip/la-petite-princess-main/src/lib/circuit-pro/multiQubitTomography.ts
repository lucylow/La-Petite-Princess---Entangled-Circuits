// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { cAdd, cConjugate, cMagnitudeSquared, cMul, complex, type Complex } from "../advanced/complex";
import type { ComplexMatrix } from "./types";
import { zeros, trace, isHermitian } from "./matrix";
import { expectPauli } from "./observables";
import { measureInBasis } from "./measurement";
import { createSeededRandom } from "./random";
import { hermitianEigenvalues } from "./density";

export interface PauliEstimate { setting: string; expectation: number; shots: number; standardError: number; }
export interface TomographyReconstruction { qubitCount: number; densityMatrix: ComplexMatrix; estimates: PauliEstimate[]; trace: number; purity: number; minimumEigenvalue: number; hermitian: boolean; }
const PAULI = ["I", "X", "Y", "Z"] as const;
export function enumeratePauliStrings(qubitCount: number): string[] {
  if (!Number.isInteger(qubitCount) || qubitCount < 1 || qubitCount > 3) throw new RangeError("Full Pauli tomography is limited to 1..3 qubits in the browser implementation.");
  const count = 4 ** qubitCount;
  return Array.from({ length: count }, (_, index) => {
    let cursor = index; let value = "";
    for (let q = qubitCount - 1; q >= 0; q -= 1) { value = PAULI[cursor % 4] + value; cursor = Math.floor(cursor / 4); }
    return value;
  });
}
function applyPauliToBasis(index: number, paulis: string, qubitCount: number): { row: number; phase: Complex } {
  let row = index; let phase = complex(1);
  for (let q = 0; q < qubitCount; q += 1) {
    const axis = paulis[qubitCount - q - 1]; const bit = (index >> q) & 1;
    if (axis === "X") row ^= 1 << q;
    if (axis === "Y") { row ^= 1 << q; phase = cMul(phase, complex(0, bit === 0 ? 1 : -1)); }
    if (axis === "Z" && bit) phase = cMul(phase, complex(-1));
  }
  return { row, phase };
}
export function pauliStringMatrix(paulis: string): ComplexMatrix {
  if (!paulis.length || /[^IXYZ]/.test(paulis)) throw new Error("Pauli string must contain I, X, Y or Z.");
  const dimension = 2 ** paulis.length; const result = zeros(dimension, dimension);
  for (let col = 0; col < dimension; col += 1) { const mapped = applyPauliToBasis(col, paulis, paulis.length); result.data[mapped.row][col] = mapped.phase; }
  return result;
}
export function reconstructDensityFromPauliEstimates(qubitCount: number, estimates: Record<string, number>): ComplexMatrix {
  const dimension = 2 ** qubitCount; const result = zeros(dimension, dimension);
  for (const setting of enumeratePauliStrings(qubitCount)) {
    const expectation = estimates[setting];
    if (!Number.isFinite(expectation)) throw new Error(`Missing or invalid Pauli expectation for ${setting}.`);
    const operator = pauliStringMatrix(setting);
    for (let row = 0; row < dimension; row += 1) for (let col = 0; col < dimension; col += 1) result.data[row][col] = cAdd(result.data[row][col], cMul(complex(expectation / dimension), operator.data[row][col]));
  }
  return result;
}
export function reconstructPureStateTomography(state: Complex[], qubitCount: number): TomographyReconstruction {
  const expectedLength = 2 ** qubitCount;
  if (state.length !== expectedLength) throw new Error("State vector length does not match qubit count.");
  const estimates = enumeratePauliStrings(qubitCount).map((setting) => ({ setting, expectation: expectPauli(state, qubitCount, setting), shots: 0, standardError: 0 }));
  return makeReport(qubitCount, Object.fromEntries(estimates.map((item) => [item.setting, item.expectation])), estimates);
}
export function reconstructSampledTomography(
  state: Complex[], qubitCount: number, shotsPerSetting: number, seed = 1,
): TomographyReconstruction {
  if (!Number.isInteger(shotsPerSetting) || shotsPerSetting < 1 || shotsPerSetting > 100_000) throw new RangeError("shotsPerSetting must be 1..100000.");
  if (state.length !== 2 ** qubitCount) throw new Error("State vector length does not match qubit count.");
  if (qubitCount > 3) throw new RangeError("Sampled full tomography is limited to three qubits.");
  const settings = enumeratePauliStrings(qubitCount).filter((setting) => setting !== "I".repeat(qubitCount));
  const estimates: PauliEstimate[] = [{ setting: "I".repeat(qubitCount), expectation: 1, shots: shotsPerSetting, standardError: 0 }];
  const random = createSeededRandom(seed);
  for (const setting of settings) {
    let sum = 0; let sumSquares = 0;
    for (let shot = 0; shot < shotsPerSetting; shot += 1) {
      let collapsed = state.map((value) => complex(value.re, value.im)); let parity = 1;
      for (let q = 0; q < qubitCount; q += 1) {
        const axis = setting[qubitCount - q - 1];
        if (axis === "I") continue;
        const measured = measureInBasis(collapsed, qubitCount, q, axis as "X" | "Y" | "Z", random);
        collapsed = measured.collapsedState; parity *= measured.outcome === 0 ? 1 : -1;
      }
      sum += parity; sumSquares += parity * parity;
    }
    const mean = sum / shotsPerSetting;
    const variance = Math.max(0, (sumSquares - shotsPerSetting * mean * mean) / Math.max(1, shotsPerSetting - 1));
    estimates.push({ setting, expectation: mean, shots: shotsPerSetting, standardError: Math.sqrt(variance / shotsPerSetting) });
  }
  const map = Object.fromEntries(estimates.map((item) => [item.setting, item.expectation]));
  return makeReport(qubitCount, map, estimates);
}
function makeReport(qubitCount: number, map: Record<string, number>, estimates: PauliEstimate[]): TomographyReconstruction {
  const densityMatrix = reconstructDensityFromPauliEstimates(qubitCount, map);
  let purity = 0;
  for (let r = 0; r < densityMatrix.rows; r += 1) for (let c = 0; c < densityMatrix.cols; c += 1) purity += cMagnitudeSquared(densityMatrix.data[r][c]);
  const eigenvalues = hermitianEigenvalues(densityMatrix);
  return { qubitCount, densityMatrix, estimates, trace: trace(densityMatrix).re, purity, minimumEigenvalue: Math.min(...eigenvalues), hermitian: isHermitian(densityMatrix, 1e-7) };
}
export function projectToPhysicalDensityEstimate(matrix: ComplexMatrix): ComplexMatrix {
  if (matrix.rows !== matrix.cols || matrix.rows === 0) throw new Error("A density matrix must be non-empty and square.");
  const dimension = matrix.rows; const result = zeros(dimension, dimension);
  // Basic Hermitian symmetrization and trace normalization. This is not a PSD projection.
  for (let r = 0; r < dimension; r += 1) for (let c = 0; c < dimension; c += 1) {
    const a = matrix.data[r][c]; const b = cConjugate(matrix.data[c][r]);
    result.data[r][c] = complex((a.re + b.re) / 2, (a.im + b.im) / 2);
  }
  const total = trace(result).re;
  if (Math.abs(total) < 1e-14) throw new Error("Cannot normalize a matrix with zero trace.");
  result.data.forEach((row) => row.forEach((value, col) => { /* preserve object identity; normalize below */ result.data[result.data.indexOf(row)][col] = complex(value.re / total, value.im / total); }));
  return result;
}
