// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import type { CircuitDefinition, CircuitOperation } from "./types";
import { serializeCircuit } from "./serialization";

export interface CircuitChange { kind: "added" | "removed" | "modified" | "moved"; operationId: string; before?: CircuitOperation; after?: CircuitOperation; fromIndex?: number; toIndex?: number; }
export interface CircuitDiff { nameChanged: boolean; qubitCountChanged: boolean; classicalBitCountChanged: boolean; changes: CircuitChange[]; identical: boolean; }
function stableOperation(operation: CircuitOperation): string { return JSON.stringify({ gate: operation.gate, targets: operation.targets, controls: operation.controls ?? [], params: operation.params ?? {}, classicalBit: operation.classicalBit ?? null, note: operation.note ?? "" }); }
export function diffCircuits(before: CircuitDefinition, after: CircuitDefinition): CircuitDiff {
  const oldIndex = new Map(before.operations.map((operation, index) => [operation.id, index]));
  const newIndex = new Map(after.operations.map((operation, index) => [operation.id, index]));
  const oldOps = new Map(before.operations.map((operation) => [operation.id, operation]));
  const newOps = new Map(after.operations.map((operation) => [operation.id, operation]));
  const changes: CircuitChange[] = [];
  for (const operation of before.operations) {
    const next = newOps.get(operation.id);
    if (!next) changes.push({ kind: "removed", operationId: operation.id, before: operation, fromIndex: oldIndex.get(operation.id) });
    else {
      if (stableOperation(operation) !== stableOperation(next)) changes.push({ kind: "modified", operationId: operation.id, before: operation, after: next, fromIndex: oldIndex.get(operation.id), toIndex: newIndex.get(operation.id) });
      else if (oldIndex.get(operation.id) !== newIndex.get(operation.id)) changes.push({ kind: "moved", operationId: operation.id, before: operation, after: next, fromIndex: oldIndex.get(operation.id), toIndex: newIndex.get(operation.id) });
    }
  }
  for (const operation of after.operations) if (!oldOps.has(operation.id)) changes.push({ kind: "added", operationId: operation.id, after: operation, toIndex: newIndex.get(operation.id) });
  const nameChanged = before.name !== after.name; const qubitCountChanged = before.qubitCount !== after.qubitCount; const classicalBitCountChanged = before.classicalBitCount !== after.classicalBitCount;
  return { nameChanged, qubitCountChanged, classicalBitCountChanged, changes, identical: !nameChanged && !qubitCountChanged && !classicalBitCountChanged && changes.length === 0 };
}
export function circuitVersionHash(circuit: CircuitDefinition): string {
  const text = serializeCircuit(circuit); let hash = 2166136261;
  for (let index = 0; index < text.length; index += 1) { hash ^= text.charCodeAt(index); hash = Math.imul(hash, 16777619); }
  return (hash >>> 0).toString(16).padStart(8, "0");
}
export function diffToMarkdown(diff: CircuitDiff): string {
  const lines = ["# Circuit comparison", "", `Identical: ${diff.identical ? "yes" : "no"}`];
  if (diff.nameChanged) lines.push("- Circuit name changed.");
  if (diff.qubitCountChanged) lines.push("- Qubit register size changed.");
  if (diff.classicalBitCountChanged) lines.push("- Classical register size changed.");
  for (const change of diff.changes) lines.push(`- ${change.kind}: ${change.operationId}${change.fromIndex !== undefined ? ` (index ${change.fromIndex + 1}` : ""}${change.toIndex !== undefined ? `${change.fromIndex !== undefined ? " → " : " (index "}${change.toIndex + 1}` : ""}${change.fromIndex !== undefined || change.toIndex !== undefined ? ")" : ""}`);
  return lines.join("\n");
}
