// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import type { CircuitDefinition, CircuitOperation } from "./types";
import { assertValidCircuit } from "./circuit";

function angle(value: number): string {
  if (!Number.isFinite(value)) throw new Error("QASM angle parameters must be finite.");
  if (Math.abs(value) < 1e-12) return "0";
  const piMultiple = value / Math.PI;
  for (const denominator of [1, 2, 4, 8, 16]) {
    const numerator = Math.round(piMultiple * denominator);
    if (Math.abs(piMultiple - numerator / denominator) < 1e-10) {
      if (denominator === 1) return `${numerator} * pi`;
      if (numerator === 1) return `pi / ${denominator}`;
      if (numerator === -1) return `-pi / ${denominator}`;
      return `${numerator} * pi / ${denominator}`;
    }
  }
  return value.toPrecision(12);
}
function qubitList(operation: CircuitOperation): string { return operation.targets.map((q) => `q[${q}]`).join(", "); }
function controls(operation: CircuitOperation): string { return (operation.controls ?? []).map((q) => `q[${q}]`).join(", "); }
function operationToQasm3(operation: CircuitOperation): string {
  const target = qubitList(operation);
  switch (operation.gate) {
    case "I": case "X": case "Y": case "Z": case "H": case "S": case "SDG": case "T": case "TDG": case "SX": case "SXDG":
      return `${operation.gate.toLowerCase()} ${target};`;
    case "RX": case "RY": case "RZ":
      return `${operation.gate.toLowerCase()}(${angle(operation.params?.theta ?? 0)}) ${target};`;
    case "U3":
      return `U(${angle(operation.params?.theta ?? 0)}, ${angle(operation.params?.phi ?? 0)}, ${angle(operation.params?.lambda ?? 0)}) ${target};`;
    case "CX": case "CY": case "CZ": case "CH": case "CP": case "CRX": case "CRY": case "CRZ": {
      const controlText = controls(operation);
      const gate = operation.gate === "CX" ? "cx" : operation.gate === "CY" ? "cy" : operation.gate === "CZ" ? "cz" : operation.gate === "CH" ? "ch" : operation.gate === "CP" ? `cp(${angle(operation.params?.theta ?? 0)})` : `${operation.gate.toLowerCase()}(${angle(operation.params?.theta ?? 0)})`;
      if (operation.controls?.length !== 1) throw new Error(`QASM 3 exporter currently writes one-control ${operation.gate} operations only.`);
      return `${gate} ${controlText}, ${target};`;
    }
    case "SWAP": case "ISWAP":
      if (operation.targets.length !== 2) throw new Error(`${operation.gate} needs two targets.`);
      return `${operation.gate.toLowerCase()} ${target};`;
    case "CCX":
      if (operation.controls?.length !== 2) throw new Error("CCX needs two controls.");
      return `ccx ${controls(operation)}, ${target};`;
    case "CSWAP":
      if (operation.controls?.length !== 1 || operation.targets.length !== 2) throw new Error("CSWAP needs one control and two targets.");
      return `cswap ${controls(operation)}, ${target};`;
    case "MEASURE":
      if (operation.classicalBit === undefined) throw new Error("Measurement has no classical destination.");
      return `c[${operation.classicalBit}] = measure ${target};`;
    case "BARRIER": return operation.targets.length ? `barrier ${target};` : "barrier q;";
  }
}
export function circuitToOpenQasm3(circuit: CircuitDefinition, includeComments = true): string {
  assertValidCircuit(circuit);
  const lines = ["OPENQASM 3.0;", 'include "stdgates.inc";', `qubit[${circuit.qubitCount}] q;`];
  if (circuit.classicalBitCount) lines.push(`bit[${circuit.classicalBitCount}] c;`);
  lines.push("");
  circuit.operations.forEach((operation, index) => {
    if (includeComments && operation.note) lines.push(`// ${index + 1}. ${operation.note.replace(/[\r\n]/g, " ")}`);
    lines.push(operationToQasm3(operation));
  });
  return `${lines.join("\n")}\n`;
}
export function qasm3SupportedGates(): string[] {
  return ["i", "x", "y", "z", "h", "s", "sdg", "t", "tdg", "sx", "sxdg", "rx", "ry", "rz", "u", "cx", "cy", "cz", "ch", "cp", "crx", "cry", "crz", "swap", "iswap", "ccx", "cswap", "measure", "barrier"];
}
