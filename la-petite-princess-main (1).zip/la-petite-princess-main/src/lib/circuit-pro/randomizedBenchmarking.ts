// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { createCircuit, createOperation } from "./circuit";
import { simulateCircuit } from "./simulator";
import { sampleShots } from "./measurement";
import { createSeededRandom } from "./random";
import type { CircuitDefinition, CircuitOperation, ShotResult } from "./types";

const CLIFFORD_GATES = ["H", "S", "SDG", "X", "Y", "Z"] as const;
type CliffordGate = typeof CLIFFORD_GATES[number];
const INVERSE: Record<CliffordGate, CliffordGate> = { H: "H", S: "SDG", SDG: "S", X: "X", Y: "Y", Z: "Z" };
export interface RandomizedBenchmarkingResult { circuit: CircuitDefinition; sequence: CliffordGate[]; inverse: CliffordGate[]; survivalProbability: number; shots: ShotResult; }
export function makeCliffordSequence(length: number, seed = 1): CliffordGate[] {
  if (!Number.isInteger(length) || length < 0 || length > 1000) throw new RangeError("Clifford sequence length must be from 0 to 1,000.");
  const rng = createSeededRandom(seed);
  return Array.from({ length }, () => CLIFFORD_GATES[Math.floor(rng() * CLIFFORD_GATES.length)]);
}
export function inverseCliffordSequence(sequence: CliffordGate[]): CliffordGate[] {
  return [...sequence].reverse().map((gate) => INVERSE[gate]);
}
export function randomizedBenchmarkingCircuit(length: number, seed = 1, qubit = 0): { circuit: CircuitDefinition; sequence: CliffordGate[]; inverse: CliffordGate[] } {
  const sequence = makeCliffordSequence(length, seed); const inverse = inverseCliffordSequence(sequence);
  const operations: CircuitOperation[] = [...sequence.map((gate) => createOperation(gate, qubit)), ...inverse.map((gate) => createOperation(gate, qubit))];
  return { circuit: { ...createCircuit(`Single-qubit randomized benchmarking · m=${length}`, Math.max(1, qubit + 1)), operations }, sequence, inverse };
}
export function runRandomizedBenchmarking(length: number, shots = 1000, seed = 1, qubit = 0): RandomizedBenchmarkingResult {
  const generated = randomizedBenchmarkingCircuit(length, seed, qubit);
  const state = simulateCircuit(generated.circuit).state;
  const result = sampleShots(state, generated.circuit.qubitCount, shots, seed);
  return { ...generated, survivalProbability: result.frequencies["0".repeat(generated.circuit.qubitCount)] ?? 0, shots: { ...result, counts: result.counts, frequencies: result.frequencies, idealProbabilities: result.probabilities } };
}
export function validateCliffordInverse(sequence: CliffordGate[]): boolean {
  const generated = randomizedBenchmarkingCircuit(sequence.length, 1, 0);
  const operations = [...sequence.map((gate) => createOperation(gate, 0)), ...inverseCliffordSequence(sequence).map((gate) => createOperation(gate, 0))];
  const circuit = { ...generated.circuit, operations };
  return Math.abs((simulateCircuit(circuit).state[0].re ** 2 + simulateCircuit(circuit).state[0].im ** 2) - 1) < 1e-8;
}
