// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import type { CircuitDefinition, CircuitOperation } from "./types";
import { cloneCircuit, createOperation } from "./circuit";

export interface CouplingMap { qubitCount: number; edges: Array<[number, number]>; directed?: boolean; }
export interface RoutingOptions { initialLayout?: number[]; allowReverseCnot?: boolean; optimizeSwaps?: boolean; }
export interface RoutingResult { circuit: CircuitDefinition; initialLayout: number[]; finalLayout: number[]; insertedSwaps: number; warnings: string[]; }

export function validateCouplingMap(map: CouplingMap): string[] {
  const errors: string[] = [];
  if (!Number.isInteger(map.qubitCount) || map.qubitCount < 1) errors.push("Coupling-map qubitCount must be a positive integer.");
  const seen = new Set<string>();
  for (const [a, b] of map.edges) {
    if (!Number.isInteger(a) || !Number.isInteger(b) || a < 0 || b < 0 || a >= map.qubitCount || b >= map.qubitCount) errors.push(`Invalid coupling edge (${a}, ${b}).`);
    if (a === b) errors.push(`Self-coupling (${a}, ${b}) is not allowed.`);
    const key = map.directed ? `${a}>${b}` : [a, b].sort((x, y) => x - y).join(":");
    if (seen.has(key)) errors.push(`Duplicate coupling edge ${key}.`);
    seen.add(key);
  }
  return errors;
}
export function adjacencyList(map: CouplingMap): number[][] {
  const errors = validateCouplingMap(map);
  if (errors.length) throw new Error(errors.join("\n"));
  const graph = Array.from({ length: map.qubitCount }, () => [] as number[]);
  for (const [a, b] of map.edges) { graph[a].push(b); if (!map.directed) graph[b].push(a); }
  return graph.map((row) => row.sort((a, b) => a - b));
}
export function shortestCouplingPath(map: CouplingMap, start: number, end: number): number[] | null {
  const graph = adjacencyList(map);
  if (![start, end].every((v) => Number.isInteger(v) && v >= 0 && v < map.qubitCount)) throw new RangeError("Path endpoints must be valid physical qubits.");
  if (start === end) return [start];
  const queue = [start]; const parent = Array(map.qubitCount).fill(-1); parent[start] = start;
  while (queue.length) {
    const current = queue.shift()!;
    for (const next of graph[current]) {
      if (parent[next] !== -1) continue;
      parent[next] = current;
      if (next === end) {
        const path = [end]; let cursor = end;
        while (cursor !== start) { cursor = parent[cursor]; path.push(cursor); }
        return path.reverse();
      }
      queue.push(next);
    }
  }
  return null;
}
function isTwoWire(operation: CircuitOperation): boolean {
  return operation.gate === "SWAP" || operation.gate === "ISWAP" || operation.gate === "CX" || operation.gate === "CY" || operation.gate === "CZ" || operation.gate === "CH" || operation.gate === "CP" || operation.gate === "CRX" || operation.gate === "CRY" || operation.gate === "CRZ";
}
function edgeExists(map: CouplingMap, a: number, b: number): boolean {
  return map.edges.some(([x, y]) => map.directed ? x === a && y === b : (x === a && y === b) || (x === b && y === a));
}
/**
 * Greedy logical-to-physical router. SWAPs move logical state along a shortest path;
 * `finalLayout[logicalQubit]` records where each logical qubit ended up.
 */
export function routeCircuitToConnectivity(circuit: CircuitDefinition, map: CouplingMap, options: RoutingOptions = {}): RoutingResult {
  const mapErrors = validateCouplingMap(map);
  if (mapErrors.length) throw new Error(mapErrors.join("\n"));
  if (circuit.qubitCount > map.qubitCount) throw new Error("The coupling map has fewer physical qubits than the circuit requires.");
  const layout = options.initialLayout ? [...options.initialLayout] : Array.from({ length: circuit.qubitCount }, (_, i) => i);
  if (layout.length !== circuit.qubitCount || new Set(layout).size !== layout.length || layout.some((p) => p < 0 || p >= map.qubitCount)) throw new Error("Initial layout must map every logical qubit to a distinct valid physical qubit.");
  const initialLayout = [...layout]; const operations: CircuitOperation[] = []; let insertedSwaps = 0; const warnings: string[] = [];
  const physicalToLogical = new Map(layout.map((physical, logical) => [physical, logical]));
  const swapPhysical = (a: number, b: number) => {
    operations.push(createOperation("SWAP", [a, b], [], undefined, "Inserted by connectivity router"));
    const logicalA = physicalToLogical.get(a); const logicalB = physicalToLogical.get(b);
    if (logicalA !== undefined) layout[logicalA] = b;
    if (logicalB !== undefined) layout[logicalB] = a;
    if (logicalA === undefined) physicalToLogical.delete(b); else physicalToLogical.set(b, logicalA);
    if (logicalB === undefined) physicalToLogical.delete(a); else physicalToLogical.set(a, logicalB);
    insertedSwaps += 1;
  };
  for (const operation of circuit.operations) {
    const logicalWires = [...operation.targets, ...(operation.controls ?? [])];
    if (logicalWires.some((q) => q >= circuit.qubitCount || q < 0)) throw new Error(`Operation ${operation.id} references a logical qubit outside the circuit.`);
    if (!isTwoWire(operation)) {
      operations.push({ ...operation, targets: operation.targets.map((q) => layout[q]), controls: operation.controls?.map((q) => layout[q]) });
      continue;
    }
    if (logicalWires.length !== 2) {
      warnings.push(`${operation.gate} has more than two wires; left unchanged after logical-to-physical remapping.`);
      operations.push({ ...operation, targets: operation.targets.map((q) => layout[q]), controls: operation.controls?.map((q) => layout[q]) });
      continue;
    }
    const [logicalA, logicalB] = operation.gate === "SWAP" || operation.gate === "ISWAP" ? operation.targets : [operation.controls![0], operation.targets[0]];
    let a = layout[logicalA]; let b = layout[logicalB];
    if (map.directed && operation.gate === "CX" && !edgeExists(map, a, b) && edgeExists(map, b, a) && options.allowReverseCnot !== false) {
      // H⊗H conjugation reverses CNOT control and target for the opposite native direction.
      operations.push(createOperation("H", a)); operations.push(createOperation("H", b));
      operations.push(createOperation("CX", a, [b], undefined, "Direction-reversed native CNOT"));
      operations.push(createOperation("H", a)); operations.push(createOperation("H", b));
      continue;
    }
    if (!edgeExists(map, a, b)) {
      const path = shortestCouplingPath(map, a, b);
      if (!path) throw new Error(`No coupling path connects logical qubits ${logicalA} and ${logicalB}.`);
      // Move the first logical wire until it is adjacent to the second.
      for (let i = 0; i < path.length - 2; i += 1) swapPhysical(path[i], path[i + 1]);
      a = layout[logicalA]; b = layout[logicalB];
    }
    operations.push({ ...operation, targets: operation.targets.map((q) => layout[q]), controls: operation.controls?.map((q) => layout[q]) });
  }
  const routed = cloneCircuit(circuit);
  routed.qubitCount = map.qubitCount;
  routed.operations = operations;
  routed.name = `${circuit.name} · routed`;
  return { circuit: routed, initialLayout, finalLayout: [...layout], insertedSwaps, warnings };
}
export const LINEAR_COUPLING = (qubitCount: number): CouplingMap => ({ qubitCount, edges: Array.from({ length: Math.max(0, qubitCount - 1) }, (_, i) => [i, i + 1] as [number, number]) });
export const RING_COUPLING = (qubitCount: number): CouplingMap => ({ qubitCount, edges: [...LINEAR_COUPLING(qubitCount).edges, ...(qubitCount > 2 ? [[qubitCount - 1, 0] as [number, number]] : [])] });
export function gridCoupling(rows: number, columns: number): CouplingMap {
  if (![rows, columns].every((n) => Number.isInteger(n) && n > 0)) throw new RangeError("Grid dimensions must be positive integers.");
  const edges: Array<[number, number]> = [];
  for (let r = 0; r < rows; r += 1) for (let c = 0; c < columns; c += 1) {
    const index = r * columns + c;
    if (c + 1 < columns) edges.push([index, index + 1]);
    if (r + 1 < rows) edges.push([index, index + columns]);
  }
  return { qubitCount: rows * columns, edges };
}
export function couplingDegree(map: CouplingMap, qubit: number): number { return adjacencyList(map)[qubit]?.length ?? 0; }
export function couplingSummary(map: CouplingMap): { qubits: number; connections: number; averageDegree: number; maximumDegree: number; connected: boolean } {
  const graph = adjacencyList(map); const degrees = graph.map((row) => row.length);
  const visited = new Set<number>(); const queue = [0];
  while (queue.length) { const q = queue.shift()!; if (visited.has(q)) continue; visited.add(q); graph[q].forEach((next) => { if (!visited.has(next)) queue.push(next); }); }
  return { qubits: map.qubitCount, connections: map.edges.length, averageDegree: degrees.reduce((a, b) => a + b, 0) / map.qubitCount, maximumDegree: Math.max(...degrees), connected: visited.size === map.qubitCount };
}
