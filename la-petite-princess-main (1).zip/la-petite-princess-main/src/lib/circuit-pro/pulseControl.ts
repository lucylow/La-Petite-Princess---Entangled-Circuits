// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { complex, type Complex } from "../advanced/complex";
import { applyGateOperation } from "./gates";
import { probabilities, normalizeState } from "./statevector";
import type { CircuitOperation } from "./types";

/** Pulse-envelope primitives used by the educational control-stack simulator.
 * Amplitudes are angular-frequency units (radians / ns); times are ns.
 * This is an ideal rotating-frame model, not a calibrated hardware backend.
 */
export type PulseShape = "square" | "gaussian" | "gaussian-square" | "drag" | "cosine";
export interface PulseSpec {
  id: string;
  channel: string;
  shape: PulseShape;
  durationNs: number;
  sampleCount: number;
  amplitude: number;
  phaseRad?: number;
  sigmaNs?: number;
  beta?: number;
  flatTopNs?: number;
  detuningRadPerNs?: number;
  metadata?: Record<string, string | number | boolean>;
}
export interface PulseSample { timeNs: number; i: number; q: number; amplitude: number; phaseRad: number; }
export interface SampledPulse { spec: PulseSpec; samples: PulseSample[]; dtNs: number; areaI: number; areaQ: number; peakAmplitude: number; rmsAmplitude: number; }
export interface PulseSchedule { id: string; durationNs: number; pulses: Array<{ spec: PulseSpec; startNs: number; samples: SampledPulse }>; }
export interface BlochPulseResult { state: Complex[]; probabilities: number[]; bloch: { x: number; y: number; z: number }; fidelityToTarget?: number; samplesApplied: number; }

function finite(value: number, label: string): void { if (!Number.isFinite(value)) throw new Error(`${label} must be finite.`); }
function validateSpec(spec: PulseSpec): void {
  if (!spec.id.trim() || !spec.channel.trim()) throw new Error("Pulse ID and channel are required.");
  if (!(spec.durationNs > 0) || !Number.isFinite(spec.durationNs)) throw new RangeError("Pulse duration must be positive and finite.");
  if (!Number.isInteger(spec.sampleCount) || spec.sampleCount < 2 || spec.sampleCount > 100_000) throw new RangeError("Pulse sampleCount must be 2..100000.");
  finite(spec.amplitude, "Pulse amplitude"); finite(spec.phaseRad ?? 0, "Pulse phase");
  finite(spec.detuningRadPerNs ?? 0, "Pulse detuning");
  if (spec.sigmaNs !== undefined && (!(spec.sigmaNs > 0) || !Number.isFinite(spec.sigmaNs))) throw new RangeError("Gaussian sigma must be positive.");
  if (spec.flatTopNs !== undefined && (spec.flatTopNs < 0 || spec.flatTopNs > spec.durationNs)) throw new RangeError("Pulse flat top must lie within its duration.");
  if (spec.beta !== undefined) finite(spec.beta, "DRAG beta");
}
function gaussian(t: number, center: number, sigma: number): number { const z = (t - center) / sigma; return Math.exp(-0.5 * z * z); }
function envelope(spec: PulseSpec, time: number): { i: number; q: number } {
  const duration = spec.durationNs; const sigma = spec.sigmaNs ?? duration / 6; const center = duration / 2;
  let value = 0; let derivative = 0;
  if (spec.shape === "square") value = 1;
  else if (spec.shape === "gaussian") value = gaussian(time, center, sigma);
  else if (spec.shape === "cosine") value = 0.5 - 0.5 * Math.cos(2 * Math.PI * time / duration);
  else if (spec.shape === "gaussian-square") {
    const flat = spec.flatTopNs ?? duration * 0.4; const edge = (duration - flat) / 2;
    if (time >= edge && time <= duration - edge) value = 1;
    else if (time < edge) value = gaussian(time, edge, Math.max(sigma, edge / 2));
    else value = gaussian(time, duration - edge, Math.max(sigma, edge / 2));
  } else {
    value = gaussian(time, center, sigma);
    derivative = -(time - center) / (sigma * sigma) * value;
  }
  const phase = spec.phaseRad ?? 0; const detuningPhase = (spec.detuningRadPerNs ?? 0) * (time - center);
  const rotated = value * spec.amplitude; const quadrature = spec.shape === "drag" ? (spec.beta ?? 0) * derivative * spec.amplitude : 0;
  const angle = phase + detuningPhase; const i = rotated * Math.cos(angle) - quadrature * Math.sin(angle); const q = rotated * Math.sin(angle) + quadrature * Math.cos(angle);
  return { i, q };
}
export function samplePulse(spec: PulseSpec): SampledPulse {
  validateSpec(spec); const dtNs = spec.durationNs / spec.sampleCount;
  const samples = Array.from({ length: spec.sampleCount }, (_, index) => {
    const timeNs = (index + 0.5) * dtNs; const value = envelope(spec, timeNs); const amplitude = Math.hypot(value.i, value.q);
    return { timeNs, ...value, amplitude, phaseRad: Math.atan2(value.q, value.i) };
  });
  const areaI = samples.reduce((sum, sample) => sum + sample.i * dtNs, 0);
  const areaQ = samples.reduce((sum, sample) => sum + sample.q * dtNs, 0);
  const peakAmplitude = Math.max(...samples.map((sample) => sample.amplitude));
  const rmsAmplitude = Math.sqrt(samples.reduce((sum, sample) => sum + sample.amplitude ** 2, 0) / samples.length);
  return { spec: { ...spec }, samples, dtNs, areaI, areaQ, peakAmplitude, rmsAmplitude };
}
export function pulseArea(pulse: SampledPulse): number { return Math.hypot(pulse.areaI, pulse.areaQ); }
export function pulseAreaPhase(pulse: SampledPulse): number { return Math.atan2(pulse.areaQ, pulse.areaI); }
export function scalePulse(pulse: SampledPulse, factor: number): SampledPulse {
  finite(factor, "Pulse scale");
  const samples = pulse.samples.map((sample) => ({ ...sample, i: sample.i * factor, q: sample.q * factor, amplitude: sample.amplitude * Math.abs(factor) }));
  return { ...pulse, samples, areaI: pulse.areaI * factor, areaQ: pulse.areaQ * factor, peakAmplitude: pulse.peakAmplitude * Math.abs(factor), rmsAmplitude: pulse.rmsAmplitude * Math.abs(factor) };
}
export function phaseShiftPulse(pulse: SampledPulse, phaseRad: number): SampledPulse {
  finite(phaseRad, "Phase shift"); const cosine = Math.cos(phaseRad); const sine = Math.sin(phaseRad);
  const samples = pulse.samples.map((sample) => ({ ...sample, i: sample.i * cosine - sample.q * sine, q: sample.i * sine + sample.q * cosine, phaseRad: sample.phaseRad + phaseRad }));
  const areaI = pulse.areaI * cosine - pulse.areaQ * sine; const areaQ = pulse.areaI * sine + pulse.areaQ * cosine;
  return { ...pulse, samples, areaI, areaQ };
}
export function composePulses(id: string, entries: Array<{ spec: PulseSpec; startNs: number }>): PulseSchedule {
  if (!id.trim() || !entries.length) throw new Error("A pulse schedule needs an ID and at least one pulse.");
  const channels = new Map<string, Array<[number, number]>>();
  const pulses = entries.map((entry) => {
    if (!Number.isFinite(entry.startNs) || entry.startNs < 0) throw new RangeError("Pulse start time must be non-negative.");
    const samples = samplePulse(entry.spec); const end = entry.startNs + entry.spec.durationNs;
    const occupied = channels.get(entry.spec.channel) ?? [];
    if (occupied.some(([start, stop]) => entry.startNs < stop - 1e-12 && end > start + 1e-12)) throw new Error(`Overlapping pulses on channel ${entry.spec.channel}.`);
    occupied.push([entry.startNs, end]); channels.set(entry.spec.channel, occupied);
    return { spec: { ...entry.spec }, startNs: entry.startNs, samples };
  });
  return { id, durationNs: Math.max(...pulses.map((pulse) => pulse.startNs + pulse.spec.durationNs)), pulses: pulses.sort((a, b) => a.startNs - b.startNs) };
}
export function sampleScheduleAt(schedule: PulseSchedule, timeNs: number, channel?: string): { i: number; q: number } {
  finite(timeNs, "Schedule time"); let i = 0; let q = 0;
  for (const pulse of schedule.pulses) {
    if (channel && pulse.spec.channel !== channel) continue;
    const local = timeNs - pulse.startNs;
    if (local < 0 || local >= pulse.spec.durationNs) continue;
    const index = Math.min(pulse.samples.samples.length - 1, Math.floor(local / pulse.samples.dtNs));
    i += pulse.samples.samples[index].i; q += pulse.samples.samples[index].q;
  }
  return { i, q };
}
function blochFromState(state: Complex[]): { x: number; y: number; z: number } {
  if (state.length !== 2) throw new Error("Bloch visualization requires one qubit.");
  const a = state[0]; const b = state[1];
  return { x: 2 * (a.re * b.re + a.im * b.im), y: 2 * (a.im * b.re - a.re * b.im), z: a.re * a.re + a.im * a.im - b.re * b.re - b.im * b.im };
}
/** Simulates a single-qubit pulse in the rotating frame using piecewise-constant Hamiltonian steps. */
export function evolveQubitWithPulse(initialState: Complex[], pulse: SampledPulse, options: { detuningRadPerNs?: number; targetState?: Complex[] } = {}): BlochPulseResult {
  if (initialState.length !== 2) throw new Error("Pulse evolution currently supports exactly one qubit.");
  let state = normalizeState(initialState); const detuning = options.detuningRadPerNs ?? pulse.spec.detuningRadPerNs ?? 0; finite(detuning, "Detuning");
  for (const sample of pulse.samples) {
    const ox = sample.i; const oy = sample.q; const oz = detuning; const magnitude = Math.hypot(ox, oy, oz); if (magnitude < 1e-15) continue;
    const angle = magnitude * pulse.dtNs; const azimuth = Math.atan2(oy, ox); const polar = Math.atan2(Math.hypot(ox, oy), oz);
    const ops: CircuitOperation[] = [
      { id: "pulse-z-pre", gate: "RZ", targets: [0], params: { theta: -azimuth } },
      { id: "pulse-y", gate: "RY", targets: [0], params: { theta: -polar } },
      { id: "pulse-z-rotation", gate: "RZ", targets: [0], params: { theta: angle } },
      { id: "pulse-y-post", gate: "RY", targets: [0], params: { theta: polar } },
      { id: "pulse-z-post", gate: "RZ", targets: [0], params: { theta: azimuth } },
    ];
    // R_n(angle) = Rz(azimuth) Ry(polar) Rz(angle) Ry(-polar) Rz(-azimuth).
    for (const operation of ops) state = applyGateOperation(state, 1, operation);
  }
  const target = options.targetState;
  let fidelityToTarget: number | undefined;
  if (target) {
    if (target.length !== 2) throw new Error("Target state must contain two amplitudes.");
    const overlap = { re: state[0].re * target[0].re + state[0].im * target[0].im + state[1].re * target[1].re + state[1].im * target[1].im, im: 0 };
    // A full complex overlap is used below; this local expression is replaced by its phase-safe expansion.
    const oi = state[0].re * target[0].im - state[0].im * target[0].re + state[1].re * target[1].im - state[1].im * target[1].re;
    fidelityToTarget = Math.min(1, overlap.re ** 2 + oi ** 2);
  }
  return { state, probabilities: probabilities(state), bloch: blochFromState(state), ...(fidelityToTarget === undefined ? {} : { fidelityToTarget }), samplesApplied: pulse.samples.length };
}
export function gaussianPiPulse(id = "x90", durationNs = 40, sampleCount = 256): PulseSpec {
  return { id, channel: "drive0", shape: "gaussian", durationNs, sampleCount, amplitude: Math.PI / (durationNs * Math.sqrt(2 * Math.PI) / 6), sigmaNs: durationNs / 6, phaseRad: 0 };
}
export function calibratedRotationError(actual: Complex[], target: Complex[]): number {
  if (actual.length !== target.length) throw new Error("State vectors must have equal dimensions.");
  let overlapRe = 0; let overlapIm = 0;
  actual.forEach((value, index) => { const other = target[index]; overlapRe += value.re * other.re + value.im * other.im; overlapIm += value.re * other.im - value.im * other.re; });
  return Math.max(0, 1 - Math.min(1, overlapRe ** 2 + overlapIm ** 2));
}
