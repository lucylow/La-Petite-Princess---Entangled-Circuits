// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import type { CircuitDefinition, ShotResult } from "./types";
import { runCircuitShots } from "./simulator";
import { wilsonInterval, binomialStandardError } from "./errorMitigationPro";
import type { RandomizedBenchmarkingResult } from "./randomizedBenchmarking";

export interface ObservableEstimate { label: string; expectation: number; standardError: number; shots: number; confidenceInterval: [number, number]; }
export interface CircuitSweepPoint { parameter: number; value: number; standardError: number; shots: number; counts: Record<string, number>; }
export interface CircuitSweepReport { name: string; points: CircuitSweepPoint[]; bestParameter: number; bestValue: number; minimized: boolean; }
export interface OutputDistributionSummary { shots: number; outcomes: number; entropyBits: number; minFrequency: number; maxFrequency: number; mostLikely: Array<{ bitstring: string; count: number; frequency: number }>; }
export function estimateBitstringProbability(shotResult: ShotResult, bitstring: string): ObservableEstimate {
  const successes = shotResult.counts[bitstring] ?? 0; const shots = shotResult.shots; const probability = successes / shots;
  return { label: `P(${bitstring})`, expectation: probability, standardError: binomialStandardError(probability, shots), shots, confidenceInterval: wilsonInterval(successes, shots) };
}
export function estimateParity(shotResult: ShotResult, qubitCount: number): ObservableEstimate {
  if (!Number.isInteger(qubitCount) || qubitCount < 1) throw new Error("qubitCount must be positive.");
  let even = 0; for (const [bitstring, count] of Object.entries(shotResult.counts)) if (bitstring.split("").reduce((sum, char) => sum ^ Number(char), 0) === 0) even += count;
  const probabilityEven = even / shotResult.shots; const expectation = 2 * probabilityEven - 1;
  const error = 2 * binomialStandardError(probabilityEven, shotResult.shots);
  return { label: "Z⊗…⊗Z parity", expectation, standardError: error, shots: shotResult.shots, confidenceInterval: [Math.max(-1, expectation - 1.96 * error), Math.min(1, expectation + 1.96 * error)] };
}
export function summarizeOutputDistribution(result: ShotResult, top = 8): OutputDistributionSummary {
  if (!Number.isInteger(top) || top < 1) throw new RangeError("top must be a positive integer.");
  const frequencies = Object.values(result.frequencies); const entropyBits = frequencies.reduce((sum, probability) => probability <= 0 ? sum : sum - probability * Math.log2(probability), 0);
  const mostLikely = Object.entries(result.counts).sort((a, b) => b[1] - a[1]).slice(0, top).map(([bitstring, count]) => ({ bitstring, count, frequency: count / result.shots }));
  return { shots: result.shots, outcomes: Object.keys(result.counts).length, entropyBits, minFrequency: Math.min(...frequencies), maxFrequency: Math.max(...frequencies), mostLikely };
}
export function runParameterizedCircuitSweep(
  name: string,
  parameters: number[],
  buildCircuit: (parameter: number) => CircuitDefinition,
  measure: (counts: Record<string, number>) => number,
  options: { shots?: number; seed?: number; minimize?: boolean } = {},
): CircuitSweepReport {
  if (!name.trim() || !parameters.length || parameters.some((value) => !Number.isFinite(value))) throw new Error("Sweep needs a name and finite parameter values.");
  const shots = options.shots ?? 2048; const points = parameters.map((parameter, index) => {
    const result = runCircuitShots(buildCircuit(parameter), shots, (options.seed ?? 11) + index);
    const value = measure(result.counts); if (!Number.isFinite(value)) throw new Error(`Observable returned a non-finite value at parameter ${parameter}.`);
    const varianceBound = 1 / Math.sqrt(shots);
    return { parameter, value, standardError: varianceBound, shots, counts: result.counts };
  });
  const minimized = options.minimize ?? false; const best = [...points].sort((a, b) => minimized ? a.value - b.value : b.value - a.value)[0];
  return { name, points, bestParameter: best.parameter, bestValue: best.value, minimized };
}
export function compareDistributions(first: Record<string, number>, second: Record<string, number>): { totalVariation: number; hellinger: number; l1: number; labels: string[] } {
  const labels = [...new Set([...Object.keys(first), ...Object.keys(second)])].sort();
  const sumA = Object.values(first).reduce((sum, value) => sum + value, 0); const sumB = Object.values(second).reduce((sum, value) => sum + value, 0);
  if (sumA <= 0 || sumB <= 0) throw new Error("Both distributions must have positive total mass.");
  let l1 = 0; let affinity = 0;
  labels.forEach((label) => { const a = (first[label] ?? 0) / sumA; const b = (second[label] ?? 0) / sumB; l1 += Math.abs(a - b); affinity += Math.sqrt(a * b); });
  return { totalVariation: l1 / 2, hellinger: Math.sqrt(Math.max(0, 1 - affinity)), l1, labels };
}
export function bootstrapMean(values: number[], iterations = 1000, seed = 19): { mean: number; lower: number; upper: number; samples: number[] } {
  if (!values.length || values.some((value) => !Number.isFinite(value)) || !Number.isInteger(iterations) || iterations < 100) throw new Error("Bootstrap requires finite samples and at least 100 iterations.");
  let state = seed >>> 0; const random = () => { state = (Math.imul(state, 1664525) + 1013904223) >>> 0; return state / 4294967296; };
  const samples = Array.from({ length: iterations }, () => values.reduce((sum) => sum + values[Math.floor(random() * values.length)], 0) / values.length).sort((a, b) => a - b);
  const mean = values.reduce((sum, value) => sum + value, 0) / values.length;
  return { mean, lower: samples[Math.floor(iterations * 0.025)], upper: samples[Math.min(iterations - 1, Math.floor(iterations * 0.975))], samples };
}
export function randomizedBenchmarkSummary(results: RandomizedBenchmarkingResult[]): { medianSurvival: number; sequenceCount: number; lengths: number[] } {
  if (!results.length) throw new Error("At least one randomized-benchmarking result is required.");
  const lengths = [...new Set(results.map((result) => result.sequence.length))].sort((a, b) => a - b);
  const medianSurvival = results.map((result) => result.survivalProbability).sort((a, b) => a - b)[Math.floor(results.length / 2)];
  return { medianSurvival, sequenceCount: results.length, lengths };
}
