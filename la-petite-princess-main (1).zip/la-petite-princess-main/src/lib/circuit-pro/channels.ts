// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { cAdd, cConjugate, cMagnitudeSquared, cMul, cScale, complex, type Complex } from "../advanced/complex";
import type { ComplexMatrix } from "./types";
import { zeros, trace, adjoint, multiplyMatrices, identity, matrixClose } from "./matrix";
import { amplitudeDampingKraus, phaseDampingKraus } from "./noise";
import type { Matrix2 } from "./gates";
import { densityFromState, applyKrausChannel } from "./density";
import { clampProbability } from "./random";

export type QuantumChannelName = "bit-flip" | "phase-flip" | "bit-phase-flip" | "depolarizing" | "amplitude-damping" | "phase-damping" | "reset";
export interface ChannelParameters { probability: number; }
export interface ChannelDescription { name: QuantumChannelName; title: string; description: string; parameter: string; }
export const CHANNEL_CATALOG: ChannelDescription[] = [
  { name: "bit-flip", title: "Bit flip", description: "Applies Pauli X with probability p.", parameter: "p" },
  { name: "phase-flip", title: "Phase flip", description: "Applies Pauli Z with probability p.", parameter: "p" },
  { name: "bit-phase-flip", title: "Bit-phase flip", description: "Applies Pauli Y with probability p.", parameter: "p" },
  { name: "depolarizing", title: "Depolarizing", description: "Replaces the state with a uniform Pauli error mixture.", parameter: "p" },
  { name: "amplitude-damping", title: "Amplitude damping", description: "Models energy relaxation toward |0⟩.", parameter: "γ" },
  { name: "phase-damping", title: "Phase damping", description: "Suppresses coherence without changing populations.", parameter: "λ" },
  { name: "reset", title: "Reset", description: "Erases the qubit to |0⟩ irrespective of input.", parameter: "none" },
];
const X: Matrix2 = [[complex(0), complex(1)], [complex(1), complex(0)]];
const Y: Matrix2 = [[complex(0), complex(0, -1)], [complex(0, 1), complex(0)]];
const Z: Matrix2 = [[complex(1), complex(0)], [complex(0), complex(-1)]];
const I: Matrix2 = [[complex(1), complex(0)], [complex(0), complex(1)]];
function validate(p: number): void { clampProbability(p, "channel probability"); }
function scaled(matrix: Matrix2, amount: number): Matrix2 { return matrix.map((row) => row.map((item) => cScale(item, Math.sqrt(amount)))) as Matrix2; }
export function channelKrausOperators(channel: QuantumChannelName, probability = 0.05): Matrix2[] {
  validate(probability);
  switch (channel) {
    case "bit-flip": return [scaled(I, 1 - probability), scaled(X, probability)];
    case "phase-flip": return [scaled(I, 1 - probability), scaled(Z, probability)];
    case "bit-phase-flip": return [scaled(I, 1 - probability), scaled(Y, probability)];
    case "depolarizing": return [scaled(I, 1 - probability), scaled(X, probability / 3), scaled(Y, probability / 3), scaled(Z, probability / 3)];
    case "amplitude-damping": return amplitudeDampingKraus(probability);
    case "phase-damping": return phaseDampingKraus(probability);
    case "reset": return [ [[complex(1), complex(0)], [complex(0), complex(0)]], [[complex(0), complex(1)], [complex(0), complex(0)]] ];
  }
}
export function isTracePreserving(kraus: Matrix2[], tolerance = 1e-9): boolean {
  const sum = zeros(2, 2);
  for (const operator of kraus) {
    const matrix = { rows: 2, cols: 2, data: operator.map((row) => row.map((value) => complex(value.re, value.im))) };
    const product = multiplyMatrices(adjoint(matrix), matrix);
    for (let r = 0; r < 2; r += 1) for (let c = 0; c < 2; c += 1) sum.data[r][c] = cAdd(sum.data[r][c], product.data[r][c]);
  }
  return matrixClose(sum, identity(2), tolerance);
}
export function applyChannelToDensity(rho: ComplexMatrix, qubitCount: number, target: number, channel: QuantumChannelName, probability = 0.05): ComplexMatrix {
  return applyKrausChannel(rho, qubitCount, target, channelKrausOperators(channel, probability));
}
export function applyChannelToStateAsDensity(state: Complex[], qubitCount: number, target: number, channel: QuantumChannelName, probability = 0.05): ComplexMatrix {
  return applyChannelToDensity(densityFromState(state), qubitCount, target, channel, probability);
}
export function channelTraceDistance(before: ComplexMatrix, after: ComplexMatrix): number {
  if (before.rows !== after.rows || before.cols !== after.cols) throw new Error("Density matrices must have identical dimensions.");
  let squared = 0;
  for (let r = 0; r < before.rows; r += 1) for (let c = 0; c < before.cols; c += 1) {
    const a = before.data[r][c]; const b = after.data[r][c]; squared += cMagnitudeSquared(complex(a.re - b.re, a.im - b.im));
  }
  return Math.sqrt(squared) / 2;
}
export function channelFidelityForPureState(state: Complex[], channelOutput: ComplexMatrix): number {
  const vector = state.map((value) => complex(value.re, value.im));
  let result = complex();
  for (let row = 0; row < vector.length; row += 1) for (let col = 0; col < vector.length; col += 1) {
    result = cAdd(result, cMul(cConjugate(vector[row]), cMul(channelOutput.data[row][col], vector[col])));
  }
  return Math.max(0, Math.min(1, result.re));
}
export function channelOutputTrace(rho: ComplexMatrix): number { return trace(rho).re; }
export function depolarizingBlochShrink(probability: number): number { validate(probability); return 1 - 4 * probability / 3; }
