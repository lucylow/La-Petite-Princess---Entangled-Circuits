// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { complex } from "../advanced/complex";
import type { CircuitOperation } from "./types";
import { applyGateOperation } from "./gates";
import { measureInBasis } from "./measurement"
import { resolveRandom } from "./random";

export type DynamicInstruction =
  | { kind: "gate"; operation: CircuitOperation }
  | { kind: "measure"; qubit: number; classicalBit: number; basis?: "X" | "Y" | "Z"; id?: string }
  | { kind: "reset"; qubit: number; id?: string }
  | { kind: "if"; classicalBit: number; equals: 0 | 1; then: DynamicInstruction[]; otherwise?: DynamicInstruction[]; id?: string }
  | { kind: "barrier"; qubits: number[]; id?: string };
export interface DynamicCircuit { id: string; name: string; qubitCount: number; classicalBitCount: number; instructions: DynamicInstruction[]; }
export interface DynamicShotResult { state: ReturnType<typeof complex>[]; classicalBits: number[]; measurements: Array<{ qubit: number; classicalBit: number; outcome: 0 | 1 }>; branchTrace: string[]; }
export interface DynamicBatchResult { shots: number; counts: Record<string, number>; classicalCounts: Record<string, number>; seed?: number; }

export function validateDynamicCircuit(circuit: DynamicCircuit): string[] {
  const errors: string[] = [];
  if (!Number.isInteger(circuit.qubitCount) || circuit.qubitCount < 1 || circuit.qubitCount > 10) errors.push("Dynamic circuit qubitCount must be 1..10.");
  if (!Number.isInteger(circuit.classicalBitCount) || circuit.classicalBitCount < 1 || circuit.classicalBitCount > 64) errors.push("Dynamic circuit classicalBitCount must be 1..64.");
  const visit = (instructions: DynamicInstruction[], path: string) => instructions.forEach((instruction, index) => {
    const label = `${path}${index}`;
    if (instruction.kind === "gate") {
      const wires = [...instruction.operation.targets, ...(instruction.operation.controls ?? [])];
      if (wires.some((q) => !Number.isInteger(q) || q < 0 || q >= circuit.qubitCount)) errors.push(`${label}: gate references an invalid qubit.`);
      if (instruction.operation.gate === "MEASURE" || instruction.operation.gate === "BARRIER") errors.push(`${label}: use dynamic measure/barrier instructions, not directive gates.`);
    }
    if (instruction.kind === "measure" && (!validQubit(instruction.qubit, circuit.qubitCount) || !validClassical(instruction.classicalBit, circuit.classicalBitCount))) errors.push(`${label}: measurement indices are out of range.`);
    if (instruction.kind === "reset" && !validQubit(instruction.qubit, circuit.qubitCount)) errors.push(`${label}: reset qubit is out of range.`);
    if (instruction.kind === "if") {
      if (!validClassical(instruction.classicalBit, circuit.classicalBitCount)) errors.push(`${label}: condition references an invalid classical bit.`);
      visit(instruction.then, `${label}.then.`); if (instruction.otherwise) visit(instruction.otherwise, `${label}.else.`);
    }
    if (instruction.kind === "barrier" && instruction.qubits.some((q) => !validQubit(q, circuit.qubitCount))) errors.push(`${label}: barrier references an invalid qubit.`);
  });
  visit(circuit.instructions, "instruction-");
  return errors;
}
function validQubit(q: number, count: number): boolean { return Number.isInteger(q) && q >= 0 && q < count; }
function validClassical(q: number, count: number): boolean { return Number.isInteger(q) && q >= 0 && q < count; }
export function executeDynamicShot(circuit: DynamicCircuit, rng: () => number = Math.random): DynamicShotResult {
  const errors = validateDynamicCircuit(circuit);
  if (errors.length) throw new Error(errors.join("\n"));
  let state = Array.from({ length: 2 ** circuit.qubitCount }, (_, index) => index === 0 ? complex(1) : complex());
  const classicalBits = Array(circuit.classicalBitCount).fill(0);
  const measurements: DynamicShotResult["measurements"] = []; const branchTrace: string[] = [];
  const execute = (instructions: DynamicInstruction[]) => {
    for (const instruction of instructions) {
      if (instruction.kind === "gate") state = applyGateOperation(state, circuit.qubitCount, instruction.operation);
      else if (instruction.kind === "measure") {
        const result = measureInBasis(state, circuit.qubitCount, instruction.qubit, instruction.basis ?? "Z", rng);
        state = result.collapsedState; classicalBits[instruction.classicalBit] = result.outcome;
        measurements.push({ qubit: instruction.qubit, classicalBit: instruction.classicalBit, outcome: result.outcome });
      } else if (instruction.kind === "reset") {
        const result = measureInBasis(state, circuit.qubitCount, instruction.qubit, "Z", rng);
        state = result.outcome === 1 ? applyGateOperation(result.collapsedState, circuit.qubitCount, { id: `reset-${instruction.qubit}`, gate: "X", targets: [instruction.qubit] }) : result.collapsedState;
      } else if (instruction.kind === "if") {
        const passed = classicalBits[instruction.classicalBit] === instruction.equals;
        branchTrace.push(`${instruction.id ?? "if"}: c[${instruction.classicalBit}]=${classicalBits[instruction.classicalBit]} → ${passed ? "then" : "else"}`);
        execute(passed ? instruction.then : instruction.otherwise ?? []);
      } else {
        // A barrier only establishes an ordering boundary; the sequential emulator needs no state change.
      }
    }
  };
  execute(circuit.instructions);
  return { state, classicalBits, measurements, branchTrace };
}
export function runDynamicShots(circuit: DynamicCircuit, shots: number, seed?: number): DynamicBatchResult {
  if (!Number.isInteger(shots) || shots < 1 || shots > 100_000) throw new RangeError("shots must be 1..100000.");
  const rng = resolveRandom(seed); const counts: Record<string, number> = {}; const classicalCounts: Record<string, number> = {};
  for (let shot = 0; shot < shots; shot += 1) {
    const result = executeDynamicShot(circuit, rng);
    const quantumKey = result.classicalBits.map((bit) => bit.toString()).reverse().join("");
    const classicalKey = [...result.classicalBits].reverse().join("");
    counts[quantumKey] = (counts[quantumKey] ?? 0) + 1;
    classicalCounts[classicalKey] = (classicalCounts[classicalKey] ?? 0) + 1;
  }
  return { shots, counts, classicalCounts, ...(seed === undefined ? {} : { seed }) };
}
export function dynamicCircuitDepth(circuit: DynamicCircuit): number {
  let depth = 0;
  const visit = (items: DynamicInstruction[]) => { for (const item of items) { depth += item.kind === "if" ? Math.max(dynamicCircuitDepth({ ...circuit, instructions: item.then }), dynamicCircuitDepth({ ...circuit, instructions: item.otherwise ?? [] })) : 1; } };
  visit(circuit.instructions); return depth;
}
export function describeDynamicInstruction(instruction: DynamicInstruction): string {
  switch (instruction.kind) {
    case "gate": return `${instruction.operation.gate} on ${instruction.operation.targets.map((q) => `q[${q}]`).join(", ")}`;
    case "measure": return `measure q[${instruction.qubit}] → c[${instruction.classicalBit}] in ${instruction.basis ?? "Z"} basis`;
    case "reset": return `reset q[${instruction.qubit}] to |0⟩`;
    case "if": return `if c[${instruction.classicalBit}] == ${instruction.equals} (${instruction.then.length} then-instructions)`;
    case "barrier": return `barrier ${instruction.qubits.map((q) => `q[${q}]`).join(", ")}`;
  }
}
