// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import type { CircuitDefinition, CircuitRunReport, NoiseParameters, ShotResult } from "./types";
import { simulateCircuit, runCircuitShots } from "./simulator";
import { runNoisyShots } from "./noise";
import { circuitMetrics } from "./metrics";
import { probabilityMap } from "./statevector";
import { resolveRandom } from "./random";

export interface ExperimentCase { id: string; label: string; circuit: CircuitDefinition; metadata?: Record<string, string | number | boolean>; }
export interface ExperimentResult { id: string; label: string; qubitCount: number; operationCount: number; depth: number; probabilities: Record<string, number>; shots?: ShotResult; metadata?: Record<string, string | number | boolean>; }
export interface SweepPoint { parameter: number; probabilities: Record<string, number>; expectation?: number; }
export interface SweepResult { name: string; points: SweepPoint[]; parameterLabel: string; resultLabels: string[]; }
export interface BatchOptions { shots?: number; seed?: number; noise?: NoiseParameters; }

export function runExperimentCase(testCase: ExperimentCase, options: BatchOptions = {}): ExperimentResult {
  const simulation = simulateCircuit(testCase.circuit);
  const shots = options.shots ? (options.noise ? runNoisyShots(testCase.circuit, options.shots, options.noise, options.seed) : runCircuitShots(testCase.circuit, options.shots, options.seed)) : undefined;
  const metrics = circuitMetrics(testCase.circuit);
  return {
    id: testCase.id,
    label: testCase.label,
    qubitCount: testCase.circuit.qubitCount,
    operationCount: metrics.operationCount,
    depth: metrics.depth,
    probabilities: probabilityMap(simulation.state, testCase.circuit.qubitCount, false),
    ...(shots ? { shots } : {}),
    ...(testCase.metadata ? { metadata: { ...testCase.metadata } } : {}),
  };
}
export function runExperimentBatch(cases: ExperimentCase[], options: BatchOptions = {}): ExperimentResult[] {
  if (!cases.length) return [];
  const ids = new Set<string>();
  for (const testCase of cases) {
    if (!testCase.id.trim() || ids.has(testCase.id)) throw new Error(`Experiment IDs must be unique and non-empty: ${testCase.id}`);
    ids.add(testCase.id);
  }
  return cases.map((testCase, index) => runExperimentCase(testCase, { ...options, seed: options.seed === undefined ? undefined : options.seed + index }));
}
export function sampleRotationSweep(
  build: (angle: number) => CircuitDefinition,
  angles: number[],
  parameterLabel = "θ (radians)",
): SweepResult {
  if (!angles.length || angles.some((value) => !Number.isFinite(value))) throw new Error("Sweep requires at least one finite parameter value.");
  const points = angles.map((parameter) => {
    const circuit = build(parameter);
    const state = simulateCircuit(circuit).state;
    return { parameter, probabilities: probabilityMap(state, circuit.qubitCount, false) };
  });
  const resultLabels = [...new Set(points.flatMap((point) => Object.keys(point.probabilities)))].sort();
  return { name: "Parameter sweep", points, parameterLabel, resultLabels };
}
export function linspace(start: number, stop: number, count: number): number[] {
  if (![start, stop].every(Number.isFinite) || !Number.isInteger(count) || count < 2) throw new RangeError("linspace needs finite bounds and at least two points.");
  return Array.from({ length: count }, (_, index) => start + (stop - start) * index / (count - 1));
}
export function repeatableRandomizedBenchmark<T>(
  build: (rng: () => number, trial: number) => T,
  trials: number,
  seed: number,
): T[] {
  if (!Number.isInteger(trials) || trials < 1 || trials > 10_000) throw new RangeError("trials must be 1..10000.");
  const rng = resolveRandom(seed);
  return Array.from({ length: trials }, (_, index) => build(rng, index));
}
export function circuitRunReport(circuit: CircuitDefinition): CircuitRunReport {
  const state = simulateCircuit(circuit).state;
  return {
    circuit,
    metrics: circuitMetrics(circuit),
    idealState: state,
    idealProbabilities: probabilityMap(state, circuit.qubitCount, false),
    warnings: [],
  };
}
