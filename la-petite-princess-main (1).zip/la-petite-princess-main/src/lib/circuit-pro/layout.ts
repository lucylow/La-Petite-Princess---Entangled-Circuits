// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import type { CircuitDefinition, CircuitOperation, GateName } from "./types";
import { touchedQubits } from "./metrics";
import { operationDepths } from "./metrics";

export interface GateLayoutNode { operationId: string; gate: GateName; column: number; x: number; y: number; targets: number[]; controls: number[]; label: string; }
export interface WireLayout { qubit: number; y: number; label: string; }
export interface CircuitLayout { width: number; height: number; wires: WireLayout[]; nodes: GateLayoutNode[]; connectors: { operationId: string; x: number; y1: number; y2: number }[]; }
export interface LayoutOptions { left?: number; top?: number; columnWidth?: number; rowHeight?: number; gateWidth?: number; paddingRight?: number; }
export function createCircuitLayout(circuit: CircuitDefinition, options: LayoutOptions = {}): CircuitLayout {
  const left = options.left ?? 90; const top = options.top ?? 44; const columnWidth = options.columnWidth ?? 76; const rowHeight = options.rowHeight ?? 64; const gateWidth = options.gateWidth ?? 38; const paddingRight = options.paddingRight ?? 72;
  const depth = operationDepths(circuit); const wires = Array.from({ length: circuit.qubitCount }, (_, qubit) => ({ qubit, y: top + qubit * rowHeight, label: `Q${qubit + 1}` }));
  const nodes: GateLayoutNode[] = []; const connectors: CircuitLayout["connectors"] = [];
  const occupiedAtDepth: number[] = [];
  circuit.operations.forEach((operation, index) => {
    let column = depth[index];
    const wiresUsed = touchedQubits(operation);
    while (wiresUsed.some((wire) => occupiedAtDepth[column * circuit.qubitCount + wire] === 1)) column += 1;
    wiresUsed.forEach((wire) => { occupiedAtDepth[column * circuit.qubitCount + wire] = 1; });
    const x = left + column * columnWidth;
    const controls = operation.controls ?? [];
    const ys = [...operation.targets, ...controls].map((qubit) => top + qubit * rowHeight);
    nodes.push({ operationId: operation.id, gate: operation.gate, column, x, y: operation.targets.length ? top + operation.targets[0] * rowHeight : top, targets: [...operation.targets], controls: [...controls], label: gateLabel(operation) });
    if (ys.length > 1 && (controls.length > 0 || operation.gate === "SWAP" || operation.gate === "ISWAP")) connectors.push({ operationId: operation.id, x: x + gateWidth / 2, y1: Math.min(...ys), y2: Math.max(...ys) });
  });
  const columns = nodes.reduce((max, node) => Math.max(max, node.column + 1), 0);
  return { width: left + columns * columnWidth + paddingRight, height: top * 2 + Math.max(0, circuit.qubitCount - 1) * rowHeight, wires, nodes, connectors };
}
export function gateLabel(operation: CircuitOperation): string {
  const theta = operation.params?.theta;
  if (["RX", "RY", "RZ", "CP", "CRX", "CRY", "CRZ"].includes(operation.gate)) return `${operation.gate}\n${(theta ?? 0).toFixed(2)}`;
  if (operation.gate === "U3") return "U3";
  if (operation.gate === "BARRIER") return "║";
  if (operation.gate === "MEASURE") return "M";
  if (operation.gate === "SWAP" || operation.gate === "ISWAP") return "×";
  if (operation.gate === "CCX") return "CCX";
  if (operation.gate === "CSWAP") return "×";
  return operation.gate;
}
export function circuitToSvg(circuit: CircuitDefinition, options: LayoutOptions = {}): string {
  const layout = createCircuitLayout(circuit, options); const nodeById = new Map(layout.nodes.map((node) => [node.operationId, node]));
  const parts = [`<svg xmlns="http://www.w3.org/2000/svg" width="${layout.width}" height="${layout.height}" viewBox="0 0 ${layout.width} ${layout.height}" role="img" aria-label="Quantum circuit with ${circuit.qubitCount} qubits">`];
  parts.push(`<rect width="100%" height="100%" fill="#171326" rx="18"/>`);
  layout.wires.forEach((wire) => { parts.push(`<text x="24" y="${wire.y + 5}" fill="#f4e9d4" font-size="13">${wire.label}</text>`); parts.push(`<line x1="${options.left ?? 90}" y1="${wire.y}" x2="${layout.width - 30}" y2="${wire.y}" stroke="#ad9acb" stroke-width="1.5"/>`); });
  layout.connectors.forEach((connector) => parts.push(`<line x1="${connector.x}" y1="${connector.y1}" x2="${connector.x}" y2="${connector.y2}" stroke="#f2c58b" stroke-width="2"/>`));
  layout.nodes.forEach((node) => {
    if (node.gate === "BARRIER") return;
    if (node.controls.length) node.controls.forEach((control) => { const y = layout.wires[control].y; parts.push(`<circle cx="${node.x + 19}" cy="${y}" r="5" fill="#f2c58b"/>`); });
    const y = layout.wires[node.targets[0]]?.y ?? node.y;
    parts.push(`<rect x="${node.x}" y="${y - 17}" width="38" height="34" rx="7" fill="#37294c" stroke="#e9b6d8" stroke-width="1.3"/>`);
    parts.push(`<text x="${node.x + 19}" y="${y + 4}" fill="#fff7ec" text-anchor="middle" font-size="12">${escapeXml(node.gate)}</text>`);
  });
  parts.push("</svg>"); return parts.join("");
}
function escapeXml(value: string): string { return value.replace(/[&<>"']/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&apos;" }[character] ?? character)); }
