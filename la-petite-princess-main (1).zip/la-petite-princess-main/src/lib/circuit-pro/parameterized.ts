// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import type { CircuitDefinition, CircuitOperation } from "./types";
import { cloneCircuit } from "./circuit";

export interface ParameterSpec { name: string; label: string; defaultValue: number; min?: number; max?: number; periodic?: boolean; description?: string; }
export interface ParameterBinding { name: string; value: number; }
export interface ParameterizedCircuit { circuit: CircuitDefinition; parameters: ParameterSpec[]; }
export interface BoundCircuit { circuit: CircuitDefinition; bindings: Record<string, number>; }

const PARAMETER_TOKEN = /^\$([A-Za-z][A-Za-z0-9_]*)$/;
export function createParameterizedCircuit(circuit: CircuitDefinition, parameters: ParameterSpec[]): ParameterizedCircuit {
  const names = new Set<string>();
  for (const parameter of parameters) {
    if (!/^[A-Za-z][A-Za-z0-9_]*$/.test(parameter.name)) throw new Error(`Invalid parameter name: ${parameter.name}`);
    if (names.has(parameter.name)) throw new Error(`Duplicate parameter: ${parameter.name}`);
    names.add(parameter.name);
    if (!Number.isFinite(parameter.defaultValue)) throw new Error(`Parameter ${parameter.name} requires a finite default value.`);
    if (parameter.min !== undefined && parameter.max !== undefined && parameter.min > parameter.max) throw new Error(`Parameter ${parameter.name} has min greater than max.`);
    if (parameter.min !== undefined && parameter.defaultValue < parameter.min) throw new Error(`Parameter ${parameter.name} default is below minimum.`);
    if (parameter.max !== undefined && parameter.defaultValue > parameter.max) throw new Error(`Parameter ${parameter.name} default is above maximum.`);
  }
  const referenced = new Set<string>();
  circuit.operations.forEach((operation) => Object.values(operation.params ?? {}).forEach((value) => {
    if (typeof value === "string") { const token = value.match(PARAMETER_TOKEN); if (token) referenced.add(token[1]); }
  }));
  for (const name of referenced) if (!names.has(name)) throw new Error(`No specification exists for parameter ${name}.`);
  return { circuit: cloneCircuit(circuit), parameters: parameters.map((parameter) => ({ ...parameter })) };
}
export function bindCircuitParameters(template: ParameterizedCircuit, bindings: Record<string, number> = {}): BoundCircuit {
  const allowed = new Set(template.parameters.map((parameter) => parameter.name));
  const resolved: Record<string, number> = {};
  for (const parameter of template.parameters) {
    const value = bindings[parameter.name] ?? parameter.defaultValue;
    if (!Number.isFinite(value)) throw new Error(`Parameter ${parameter.name} must be finite.`);
    if (parameter.min !== undefined && value < parameter.min) throw new RangeError(`${parameter.name} is below its minimum ${parameter.min}.`);
    if (parameter.max !== undefined && value > parameter.max) throw new RangeError(`${parameter.name} is above its maximum ${parameter.max}.`);
    resolved[parameter.name] = parameter.periodic ? wrapAngle(value) : value;
  }
  const unknown = Object.keys(bindings).filter((name) => !allowed.has(name));
  if (unknown.length) throw new Error(`Unknown parameter binding(s): ${unknown.join(", ")}.`);
  const circuit = cloneCircuit(template.circuit);
  for (const operation of circuit.operations) {
    if (!operation.params) continue;
    const mutable = operation.params as Record<string, number | string | undefined>;
    for (const [key, value] of Object.entries(mutable)) {
      if (typeof value !== "string") continue;
      const match = value.match(PARAMETER_TOKEN);
      if (match) mutable[key] = resolved[match[1]];
    }
  }
  return { circuit, bindings: resolved };
}
export function interpolateParameter(spec: ParameterSpec, amount: number): number {
  if (!Number.isFinite(amount) || amount < 0 || amount > 1) throw new RangeError("Interpolation amount must be between 0 and 1.");
  const min = spec.min ?? 0; const max = spec.max ?? 2 * Math.PI;
  return min + (max - min) * amount;
}
export function gridParameterBindings(parameters: ParameterSpec[], pointsPerParameter = 5, maximumCases = 500): Record<string, number>[] {
  if (!Number.isInteger(pointsPerParameter) || pointsPerParameter < 2) throw new RangeError("At least two points per parameter are required.");
  const total = pointsPerParameter ** parameters.length;
  if (total > maximumCases) throw new RangeError(`Parameter grid would create ${total} circuits; maximum is ${maximumCases}.`);
  let combinations: Record<string, number>[] = [{}];
  for (const spec of parameters) {
    const values = Array.from({ length: pointsPerParameter }, (_, i) => interpolateParameter(spec, i / (pointsPerParameter - 1)));
    combinations = combinations.flatMap((entry) => values.map((value) => ({ ...entry, [spec.name]: value })));
  }
  return combinations;
}
export function wrapAngle(angle: number): number {
  if (!Number.isFinite(angle)) throw new Error("Angle must be finite.");
  const wrapped = ((angle + Math.PI) % (2 * Math.PI) + 2 * Math.PI) % (2 * Math.PI) - Math.PI;
  return Object.is(wrapped, -0) ? 0 : wrapped;
}
export function parameterSummary(template: ParameterizedCircuit): string[] {
  return template.parameters.map((parameter) => {
    const bounds = parameter.min === undefined && parameter.max === undefined ? "unbounded" : `${parameter.min ?? "−∞"} to ${parameter.max ?? "+∞"}`;
    return `${parameter.label || parameter.name}: default ${parameter.defaultValue}, range ${bounds}${parameter.description ? ` — ${parameter.description}` : ""}`;
  });
}
export function findParameterizedOperations(circuit: CircuitDefinition): CircuitOperation[] {
  return circuit.operations.filter((operation) => Object.values(operation.params ?? {}).some((value) => typeof value === "string" && PARAMETER_TOKEN.test(value)));
}
