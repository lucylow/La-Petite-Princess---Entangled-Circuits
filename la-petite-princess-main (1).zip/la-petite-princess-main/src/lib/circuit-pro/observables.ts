// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { cAdd, cConjugate, cMagnitudeSquared, cMul, cSub, complex } from "../advanced/complex";
import type { Complex } from "../advanced/complex";
import type { PauliExpectation, PauliTerm } from "./types";
import { applyGateOperation } from "./gates";
import { hermitianEigenvalues, reducedDensityMatrix } from "./density";

/** Pauli strings use display order: the leftmost symbol acts on the highest-index qubit. */
export function applyPauliString(state: Complex[], qubitCount: number, paulis: string): Complex[] {
  if (paulis.length !== qubitCount || /[^IXYZ]/.test(paulis)) throw new Error(`Expected a ${qubitCount}-character Pauli string containing only I, X, Y or Z.`);
  let result = state.map((amplitude) => complex(amplitude.re, amplitude.im));
  for (let qubit = 0; qubit < qubitCount; qubit += 1) {
    const pauli = paulis[qubitCount - 1 - qubit];
    if (pauli === "I") continue;
    result = applyGateOperation(result, qubitCount, { id: `pauli-${qubit}`, gate: pauli as "X" | "Y" | "Z", targets: [qubit] });
  }
  return result;
}
export function expectPauli(state: Complex[], qubitCount: number, paulis: string): number {
  const transformed = applyPauliString(state, qubitCount, paulis);
  let overlap = complex();
  for (let index = 0; index < state.length; index += 1) overlap = cAdd(overlap, cMul(cConjugate(state[index]), transformed[index]));
  if (Math.abs(overlap.im) > 1e-7) throw new Error("Pauli expectation developed a non-negligible imaginary component; check normalization.");
  return overlap.re;
}
export function expectHamiltonian(state: Complex[], qubitCount: number, terms: PauliTerm[]): { total: number; breakdown: PauliExpectation[] } {
  const breakdown = terms.map((term) => {
    if (!Number.isFinite(term.coefficient)) throw new Error("Hamiltonian coefficients must be finite.");
    const expectation = expectPauli(state, qubitCount, term.paulis);
    return { paulis: term.paulis, expectation, coefficient: term.coefficient, contribution: term.coefficient * expectation };
  });
  return { total: breakdown.reduce((sum, item) => sum + item.contribution, 0), breakdown };
}
export function reducedQubitPurity(state: Complex[], qubitCount: number, qubit: number): number {
  const rho = reducedDensityMatrix(state, qubitCount, [qubit]);
  const squared = cMagnitudeSquared(rho.data[0][0]) + cMagnitudeSquared(rho.data[0][1]) + cMagnitudeSquared(rho.data[1][0]) + cMagnitudeSquared(rho.data[1][1]);
  return squared;
}
export function qubitVonNeumannEntropy(state: Complex[], qubitCount: number, qubit: number): number {
  const rho = reducedDensityMatrix(state, qubitCount, [qubit]);
  return entropyFromHermitian(rho);
}
export function entanglementEntropy(state: Complex[], qubitCount: number, subsystem: number[]): number {
  if (subsystem.length === 0 || subsystem.length >= qubitCount) throw new Error("Choose a non-empty proper subsystem for a pure-state bipartition.");
  const rho = reducedDensityMatrix(state, qubitCount, subsystem);
  return entropyFromHermitian(rho);
}
export function entropyFromHermitian(matrix: ReturnType<typeof reducedDensityMatrix>): number {
  return hermitianEigenvalues(matrix).reduce((sum, value) => value < 1e-14 ? sum : sum - value * Math.log2(value), 0);
}
export function pureTwoQubitConcurrence(state: Complex[]): number {
  if (state.length !== 4) throw new Error("Concurrence is defined here only for a pure two-qubit state.");
  const determinant = cSub(cMul(state[0], state[3]), cMul(state[1], state[2]));
  return Math.min(1, 2 * Math.sqrt(cMagnitudeSquared(determinant)));
}
export function isSeparablePureTwoQubit(state: Complex[], tolerance = 1e-9): boolean { return pureTwoQubitConcurrence(state) < tolerance; }
export function expectationSummary(state: Complex[], qubitCount: number): { qubit: number; x: number; y: number; z: number; purity: number; entropy: number }[] {
  return Array.from({ length: qubitCount }, (_, qubit) => {
    const paulis = (axis: string) => `${"I".repeat(qubitCount - qubit - 1)}${axis}${"I".repeat(qubit)}`;
    const x = expectPauli(state, qubitCount, paulis("X"));
    const y = expectPauli(state, qubitCount, paulis("Y"));
    const z = expectPauli(state, qubitCount, paulis("Z"));
    return { qubit, x, y, z, purity: (1 + x * x + y * y + z * z) / 2, entropy: qubitVonNeumannEntropy(state, qubitCount, qubit) };
  });
}
export function allComputationalProbabilities(state: Complex[]): number[] { return state.map(cMagnitudeSquared); }
