// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import type { Complex } from "../advanced/complex";
import { cMagnitudeSquared, complex } from "../advanced/complex";
import type { CircuitDefinition, ComplexMatrix, GateName } from "./types";
import { circuitUnitary, unitaryEquivalenceUpToGlobalPhase } from "./unitary";
import { identity, multiplyMatrices, adjoint, zeros } from "./matrix";
import { applyGateOperation, singleQubitMatrix } from "./gates";
import { simulateCircuit } from "./simulator";
import { expectPauli } from "./observables";

export interface VerificationResult { passed: boolean; metric: number; tolerance: number; summary: string; details: string[]; }
export interface CircuitComparison { equivalent: boolean; maxEntryError: number; globalPhase: number; operationDelta: number; firstDifferentOperation?: number; }
function maxMatrixError(a: ComplexMatrix, b: ComplexMatrix): number {
  if (a.rows !== b.rows || a.cols !== b.cols) return Number.POSITIVE_INFINITY; let maximum = 0;
  for (let row = 0; row < a.rows; row += 1) for (let col = 0; col < a.cols; col += 1) maximum = Math.max(maximum, Math.hypot(a.data[row][col].re - b.data[row][col].re, a.data[row][col].im - b.data[row][col].im));
  return maximum;
}
export function verifyUnitaryMatrix(unitary: ComplexMatrix, tolerance = 1e-9): VerificationResult {
  if (unitary.rows !== unitary.cols) return { passed: false, metric: Infinity, tolerance, summary: "Operator is not square.", details: [] };
  const product = multiplyMatrices(adjoint(unitary), unitary); const error = maxMatrixError(product, identity(unitary.rows));
  return { passed: error <= tolerance, metric: error, tolerance, summary: error <= tolerance ? "U†U is numerically equal to identity." : "Unitary residual exceeds tolerance.", details: [`Dimension: ${unitary.rows}`, `Maximum entry residual: ${error.toExponential(3)}`] };
}
export function compareCircuitDefinitions(first: CircuitDefinition, second: CircuitDefinition, tolerance = 1e-9): CircuitComparison {
  if (first.qubitCount !== second.qubitCount) return { equivalent: false, maxEntryError: Infinity, globalPhase: 0, operationDelta: second.operations.length - first.operations.length };
  const a = circuitUnitary(first); const b = circuitUnitary(second); const comparison = unitaryEquivalenceUpToGlobalPhase(a, b, tolerance);
  let firstDifferentOperation: number | undefined;
  const count = Math.min(first.operations.length, second.operations.length);
  for (let index = 0; index < count; index += 1) {
    const x = first.operations[index]; const y = second.operations[index];
    if (x.gate !== y.gate || x.targets.join(",") !== y.targets.join(",") || (x.controls ?? []).join(",") !== (y.controls ?? []).join(",") || JSON.stringify(x.params ?? {}) !== JSON.stringify(y.params ?? {})) { firstDifferentOperation = index; break; }
  }
  if (firstDifferentOperation === undefined && first.operations.length !== second.operations.length) firstDifferentOperation = count;
  return { equivalent: comparison.equivalent, maxEntryError: comparison.maximumEntryError, globalPhase: comparison.globalPhase, operationDelta: second.operations.length - first.operations.length, ...(firstDifferentOperation === undefined ? {} : { firstDifferentOperation }) };
}
export function verifyCircuitInverse(circuit: CircuitDefinition, inverse: CircuitDefinition, tolerance = 1e-9): VerificationResult {
  const comparison = compareCircuitDefinitions({ ...circuit, operations: [...circuit.operations, ...inverse.operations] }, { ...circuit, operations: [] }, tolerance);
  return { passed: comparison.equivalent, metric: comparison.maxEntryError, tolerance, summary: comparison.equivalent ? "The circuit followed by its proposed inverse is identity up to global phase." : "The proposed inverse does not undo the circuit.", details: [`First structurally different operation: ${comparison.firstDifferentOperation ?? "none"}`, `Operation delta: ${comparison.operationDelta}`] };
}
export function commutator(a: ComplexMatrix, b: ComplexMatrix): ComplexMatrix {
  if (a.rows !== b.rows || a.cols !== b.cols || a.rows !== a.cols) throw new Error("Commutator operands must be equal-size square matrices.");
  const ab = multiplyMatrices(a, b); const ba = multiplyMatrices(b, a); const result = zeros(a.rows, a.cols);
  for (let row = 0; row < result.rows; row += 1) for (let col = 0; col < result.cols; col += 1) result.data[row][col] = complex(ab.data[row][col].re - ba.data[row][col].re, ab.data[row][col].im - ba.data[row][col].im);
  return result;
}
export function frobeniusNorm(matrix: ComplexMatrix): number { return Math.sqrt(matrix.data.flat().reduce((sum, value) => sum + cMagnitudeSquared(value), 0)); }
export function verifyCommutation(a: ComplexMatrix, b: ComplexMatrix, tolerance = 1e-9): VerificationResult {
  const norm = frobeniusNorm(commutator(a, b)); return { passed: norm <= tolerance, metric: norm, tolerance, summary: norm <= tolerance ? "The operators commute within tolerance." : "The operators do not commute within tolerance.", details: [`‖[A,B]‖F = ${norm.toExponential(4)}`] };
}
export function pauliMatrix(label: "I" | "X" | "Y" | "Z"): ComplexMatrix {
  const entries: Record<string, [[Complex, Complex], [Complex, Complex]]> = {
    I: [[complex(1), complex(0)], [complex(0), complex(1)]], X: [[complex(0), complex(1)], [complex(1), complex(0)]],
    Y: [[complex(0), complex(0, -1)], [complex(0, 1), complex(0)]], Z: [[complex(1), complex(0)], [complex(0), complex(-1)]],
  };
  const values = entries[label]; return { rows: 2, cols: 2, data: values.map((row) => row.map((value) => complex(value.re, value.im))) };
}
export function verifySingleQubitGateIsUnitary(gate: GateName, params?: { theta?: number; phi?: number; lambda?: number }, tolerance = 1e-9): VerificationResult {
  const matrix = singleQubitMatrix(gate, params); const complexMatrix: ComplexMatrix = { rows: 2, cols: 2, data: matrix.map((row) => row.map((value) => complex(value.re, value.im))) };
  return verifyUnitaryMatrix(complexMatrix, tolerance);
}
export function verifyCircuitPreservesPauli(circuit: CircuitDefinition, pauliString: string, tolerance = 1e-8): VerificationResult {
  if (pauliString.length !== circuit.qubitCount || /[^IXYZ]/.test(pauliString)) throw new Error("Pauli string length must match the circuit and contain only I/X/Y/Z.");
  // Computational-basis inputs span the state space; the check remains a diagnostic
  // because expectation preservation alone does not prove an operator identity.
  let maximumDrift = 0;
  for (let basis = 0; basis < 2 ** circuit.qubitCount; basis += 1) {
    const input = Array.from({ length: 2 ** circuit.qubitCount }, (_, index) => complex(Number(index === basis)));
    let output = input;
    for (const operation of circuit.operations) output = applyGateOperation(output, circuit.qubitCount, operation);
    const before = expectPauli(input, circuit.qubitCount, pauliString);
    const after = expectPauli(output, circuit.qubitCount, pauliString);
    maximumDrift = Math.max(maximumDrift, Math.abs(after - before));
  }
  return { passed: maximumDrift <= tolerance, metric: maximumDrift, tolerance, summary: maximumDrift <= tolerance ? `Observable ${pauliString} appears conserved on the tested input ensemble.` : `Observable ${pauliString} is not conserved on the tested input ensemble.`, details: ["This sampled computational-basis check is diagnostic, not a formal proof for all states."] };
}
export function verifyStateNorm(state: Complex[], tolerance = 1e-9): VerificationResult {
  const normSquared = state.reduce((sum, amplitude) => sum + cMagnitudeSquared(amplitude), 0); const error = Math.abs(normSquared - 1);
  return { passed: error <= tolerance, metric: error, tolerance, summary: error <= tolerance ? "State vector is normalized." : "State-vector norm differs from one.", details: [`‖ψ‖² = ${normSquared.toPrecision(12)}`] };
}
