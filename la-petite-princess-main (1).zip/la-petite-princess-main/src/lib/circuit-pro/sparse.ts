// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { cAdd, cMagnitudeSquared, cMul, cScale, complex, type Complex } from "../advanced/complex";
import { singleQubitMatrix } from "./gates";
import { cExpI } from "../advanced/complex";
import type { CircuitDefinition, CircuitOperation, GateName } from "./types";
import { basisLabel } from "./statevector";
import { resolveRandom } from "./random";

export interface SparseState { qubitCount: number; amplitudes: Map<number, Complex>; }
export interface SparseSimulationResult { state: SparseState; prunedAmplitudes: number; peakTerms: number; }
export interface SparseShots { shots: number; counts: Record<string, number>; }
export function sparseZeroState(qubitCount: number): SparseState {
  if (!Number.isInteger(qubitCount) || qubitCount < 1 || qubitCount > 30) throw new RangeError("Sparse state supports 1..30 qubits.");
  return { qubitCount, amplitudes: new Map([[0, complex(1)]]) };
}
export function sparseBasisState(qubitCount: number, bitstring: string): SparseState {
  if (!new RegExp(`^[01]{${qubitCount}}$`).test(bitstring)) throw new Error(`Expected ${qubitCount} bits.`);
  return { qubitCount, amplitudes: new Map([[Number.parseInt(bitstring, 2), complex(1)]]) };
}
export function sparseNormSquared(state: SparseState): number { let total = 0; state.amplitudes.forEach((value) => { total += cMagnitudeSquared(value); }); return total; }
export function normalizeSparseState(state: SparseState): SparseState {
  const norm = Math.sqrt(sparseNormSquared(state)); if (norm < 1e-14) throw new Error("Sparse state has zero norm.");
  return { qubitCount: state.qubitCount, amplitudes: new Map([...state.amplitudes].map(([index, value]) => [index, cScale(value, 1 / norm)])) };
}
function controlsActive(index: number, controls: number[]): boolean { return controls.every((q) => (index & (1 << q)) !== 0); }
function singleGateSparse(state: SparseState, operation: CircuitOperation): SparseState {
  const target = operation.targets[0]; const mask = 1 << target;
  const sourceGate = operation.gate;
  const mappedGate = sourceGate === "CX" ? "X" : sourceGate === "CY" ? "Y" : sourceGate === "CZ" ? "Z" : sourceGate === "CH" ? "H" : sourceGate === "CRX" ? "RX" : sourceGate === "CRY" ? "RY" : sourceGate === "CRZ" ? "RZ" : sourceGate;
  const matrix = sourceGate === "CP" ? [[complex(1), complex(0)], [complex(0), cExpI(operation.params?.theta ?? 0)]] as const : singleQubitMatrix(mappedGate as GateName, operation.params);
  const pairs = new Set<number>();
  for (const index of state.amplitudes.keys()) pairs.add(index & ~mask);
  const output = new Map<number, Complex>(); const controls = operation.controls ?? [];
  const add = (index: number, value: Complex) => {
    const previous = output.get(index) ?? complex(); const next = cAdd(previous, value);
    if (cMagnitudeSquared(next) > 1e-28) output.set(index, next);
  };
  for (const base of pairs) {
    const zero = state.amplitudes.get(base) ?? complex(); const one = state.amplitudes.get(base | mask) ?? complex();
    if (!controlsActive(base, controls)) { add(base, zero); add(base | mask, one); continue; }
    add(base, cAdd(cMul(matrix[0][0], zero), cMul(matrix[0][1], one)));
    add(base | mask, cAdd(cMul(matrix[1][0], zero), cMul(matrix[1][1], one)));
  }
  return { qubitCount: state.qubitCount, amplitudes: output };
}
function transformIndex(index: number, qubitCount: number, operation: CircuitOperation): { index: number; phase: Complex } {
  const bits = (q: number) => (index >> q) & 1;
  switch (operation.gate) {
    case "SWAP": case "ISWAP": {
      const [a, b] = operation.targets; const av = bits(a); const bv = bits(b);
      if (av === bv) return { index, phase: complex(1) };
      const next = index ^ (1 << a) ^ (1 << b);
      return { index: next, phase: operation.gate === "ISWAP" ? complex(0, 1) : complex(1) };
    }
    case "CCX": {
      if ((operation.controls ?? []).every((q) => bits(q) === 1)) return { index: index ^ (1 << operation.targets[0]), phase: complex(1) };
      return { index, phase: complex(1) };
    }
    case "CSWAP": {
      const [a, b] = operation.targets; if (!controlsActive(index, operation.controls ?? [])) return { index, phase: complex(1) };
      return bits(a) === bits(b) ? { index, phase: complex(1) } : { index: index ^ (1 << a) ^ (1 << b), phase: complex(1) };
    }
    case "BARRIER": return { index, phase: complex(1) };
    default: return { index, phase: complex(1) };
  }
}
export function applySparseOperation(state: SparseState, operation: CircuitOperation): SparseState {
  if (operation.gate === "MEASURE") throw new Error("Use sparseMeasure for measurement operations.");
  if (["BARRIER"].includes(operation.gate)) return { qubitCount: state.qubitCount, amplitudes: new Map(state.amplitudes) };
  if (["SWAP", "ISWAP", "CCX", "CSWAP"].includes(operation.gate)) {
    const result = new Map<number, Complex>();
    state.amplitudes.forEach((amplitude, index) => { const mapped = transformIndex(index, state.qubitCount, operation); const previous = result.get(mapped.index) ?? complex(); result.set(mapped.index, cAdd(previous, cMul(mapped.phase, amplitude))); });
    return { qubitCount: state.qubitCount, amplitudes: result };
  }
  if (operation.targets.length !== 1 || operation.targets[0] >= state.qubitCount) throw new Error(`Unsupported sparse operation: ${operation.gate}`);
  const supported: GateName[] = ["I", "X", "Y", "Z", "H", "S", "SDG", "T", "TDG", "SX", "SXDG", "RX", "RY", "RZ", "U3", "CX", "CY", "CZ", "CH", "CP", "CRX", "CRY", "CRZ"];
  if (!supported.includes(operation.gate)) throw new Error(`Gate ${operation.gate} is not supported by sparse simulator.`);
  return singleGateSparse(state, operation);
}
export function sparseMeasure(state: SparseState, qubit: number, rng: () => number = Math.random): { outcome: 0 | 1; state: SparseState; probabilityZero: number; probabilityOne: number } {
  if (!Number.isInteger(qubit) || qubit < 0 || qubit >= state.qubitCount) throw new RangeError("Invalid sparse measurement qubit.");
  let p1 = 0; state.amplitudes.forEach((value, index) => { if (index & (1 << qubit)) p1 += cMagnitudeSquared(value); });
  const p0 = Math.max(0, 1 - p1); const outcome: 0 | 1 = rng() < p0 ? 0 : 1; const probability = outcome ? p1 : p0;
  if (probability < 1e-14) throw new Error("Impossible sparse measurement outcome selected.");
  const amplitudes = new Map<number, Complex>();
  state.amplitudes.forEach((value, index) => { if (((index >> qubit) & 1) === outcome) amplitudes.set(index, cScale(value, 1 / Math.sqrt(probability))); });
  return { outcome, state: { qubitCount: state.qubitCount, amplitudes }, probabilityZero: p0, probabilityOne: p1 };
}
export function simulateSparseCircuit(circuit: CircuitDefinition, options: { pruneBelow?: number; maxTerms?: number } = {}): SparseSimulationResult {
  const pruneBelow = options.pruneBelow ?? 1e-14; const maxTerms = options.maxTerms ?? 1_000_000;
  let state = sparseZeroState(circuit.qubitCount); let prunedAmplitudes = 0; let peakTerms = 1;
  for (const operation of circuit.operations) {
    if (operation.gate === "MEASURE") throw new Error("Sparse deterministic simulation does not support measurement; use shot simulation.");
    state = applySparseOperation(state, operation);
    for (const [index, amplitude] of [...state.amplitudes]) if (cMagnitudeSquared(amplitude) < pruneBelow ** 2) { state.amplitudes.delete(index); prunedAmplitudes += 1; }
    peakTerms = Math.max(peakTerms, state.amplitudes.size);
    if (state.amplitudes.size > maxTerms) throw new RangeError(`Sparse state exceeded maxTerms=${maxTerms}.`);
  }
  return { state: normalizeSparseState(state), prunedAmplitudes, peakTerms };
}
export function sparseProbabilityMap(state: SparseState): Record<string, number> {
  const norm = sparseNormSquared(state);
  return Object.fromEntries([...state.amplitudes].sort(([a], [b]) => a - b).map(([index, value]) => [basisLabel(index, state.qubitCount), cMagnitudeSquared(value) / norm]));
}
export function sparseRunShots(circuit: CircuitDefinition, shots: number, seed?: number): SparseShots {
  if (!Number.isInteger(shots) || shots < 1 || shots > 100_000) throw new RangeError("shots must be 1..100000.");
  const rng = resolveRandom(seed); const base = simulateSparseCircuit(circuit).state; const counts: Record<string, number> = {};
  for (let shot = 0; shot < shots; shot += 1) {
    let roll = rng(); let selected = 0;
    for (const [index, value] of base.amplitudes) { roll -= cMagnitudeSquared(value); if (roll <= 0) { selected = index; break; } }
    const key = basisLabel(selected, base.qubitCount); counts[key] = (counts[key] ?? 0) + 1;
  }
  return { shots, counts };
}
export function sparseToDense(state: SparseState): Complex[] {
  const dense = Array.from({ length: 2 ** state.qubitCount }, () => complex());
  state.amplitudes.forEach((amplitude, index) => { dense[index] = complex(amplitude.re, amplitude.im); });
  return dense;
}
export function denseToSparse(state: Complex[], qubitCount: number, threshold = 1e-14): SparseState {
  if (state.length !== 2 ** qubitCount) throw new Error("Dense vector length and qubit count disagree.");
  const amplitudes = new Map<number, Complex>();
  state.forEach((amplitude, index) => { if (cMagnitudeSquared(amplitude) > threshold ** 2) amplitudes.set(index, complex(amplitude.re, amplitude.im)); });
  return { qubitCount, amplitudes };
}
