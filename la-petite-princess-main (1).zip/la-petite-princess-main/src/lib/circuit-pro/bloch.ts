// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { cMagnitudeSquared, complex, type Complex } from "../advanced/complex";
import { densityFromState, reducedDensityMatrix, mixedStateBlochVector } from "./density";
import type { ComplexMatrix } from "./types";

export interface BlochPoint { x: number; y: number; z: number; radius: number; purity: number; }
export interface SphericalCoordinates { theta: number; phi: number; radius: number; }

/** Bloch vector convention: x=2 Re(rho01), y=-2 Im(rho01), z=rho00-rho11. */
export function blochVectorFromDensity(rho: ComplexMatrix): BlochPoint {
  if (rho.rows !== 2 || rho.cols !== 2) throw new Error("A single-qubit density matrix must be 2×2.");
  const summary = mixedStateBlochVector(rho);
  const radius = Math.sqrt(summary.x ** 2 + summary.y ** 2 + summary.z ** 2);
  return { ...summary, radius };
}
export function blochVectorFromState(state: Complex[], qubitCount: number, qubit: number): BlochPoint {
  const reduced = reducedDensityMatrix(state, qubitCount, [qubit]);
  return blochVectorFromDensity(reduced);
}
export function pureStateBlochVector(alpha: Complex, beta: Complex): BlochPoint {
  const norm = cMagnitudeSquared(alpha) + cMagnitudeSquared(beta);
  if (norm < 1e-14) throw new Error("State amplitudes cannot both be zero.");
  const x = 2 * (alpha.re * beta.re + alpha.im * beta.im) / norm;
  const y = 2 * (alpha.re * beta.im - alpha.im * beta.re) / norm;
  const z = (cMagnitudeSquared(alpha) - cMagnitudeSquared(beta)) / norm;
  return { x, y, z, radius: Math.sqrt(x * x + y * y + z * z), purity: 1 };
}
export function cartesianToSpherical(point: Pick<BlochPoint, "x" | "y" | "z">): SphericalCoordinates {
  const radius = Math.sqrt(point.x ** 2 + point.y ** 2 + point.z ** 2);
  if (radius < 1e-14) return { theta: 0, phi: 0, radius: 0 };
  return {
    theta: Math.acos(Math.max(-1, Math.min(1, point.z / radius))),
    phi: Math.atan2(point.y, point.x),
    radius,
  };
}
export function sphericalToCartesian(coords: SphericalCoordinates): BlochPoint {
  const { theta, phi, radius } = coords;
  if (![theta, phi, radius].every(Number.isFinite) || radius < 0) throw new RangeError("Spherical coordinates must be finite and radius non-negative.");
  const x = radius * Math.sin(theta) * Math.cos(phi);
  const y = radius * Math.sin(theta) * Math.sin(phi);
  const z = radius * Math.cos(theta);
  return { x, y, z, radius, purity: (1 + radius * radius) / 2 };
}
export function densityFromBlochVector(vector: Pick<BlochPoint, "x" | "y" | "z">): ComplexMatrix {
  const radius = Math.sqrt(vector.x ** 2 + vector.y ** 2 + vector.z ** 2);
  if (radius > 1 + 1e-9) throw new RangeError("A physical qubit Bloch vector must lie inside the unit sphere.");
  return {
    rows: 2, cols: 2,
    data: [
      [complex((1 + vector.z) / 2), complex(vector.x / 2, -vector.y / 2)],
      [complex(vector.x / 2, vector.y / 2), complex((1 - vector.z) / 2)],
    ],
  };
}
export function blochSphereGrid(latitudeCount = 9, longitudeCount = 18): { latitude: number; longitude: number; points: { x: number; y: number; z: number }[] }[] {
  if (latitudeCount < 2 || longitudeCount < 3) throw new RangeError("Bloch grid needs at least 2 latitudes and 3 longitudes.");
  return Array.from({ length: latitudeCount + 1 }, (_, i) => {
    const theta = Math.PI * i / latitudeCount;
    return {
      latitude: Math.PI / 2 - theta,
      longitude: 0,
      points: Array.from({ length: longitudeCount + 1 }, (_, j) => {
        const phi = 2 * Math.PI * j / longitudeCount;
        return { x: Math.sin(theta) * Math.cos(phi), y: Math.sin(theta) * Math.sin(phi), z: Math.cos(theta) };
      }),
    };
  });
}
export function blochPurity(vector: Pick<BlochPoint, "x" | "y" | "z">): number {
  return (1 + vector.x ** 2 + vector.y ** 2 + vector.z ** 2) / 2;
}
export function stateBlochReport(state: Complex[], qubitCount: number): BlochPoint[] {
  return Array.from({ length: qubitCount }, (_, qubit) => blochVectorFromState(state, qubitCount, qubit));
}
