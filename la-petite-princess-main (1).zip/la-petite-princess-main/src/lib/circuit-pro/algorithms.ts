// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { createCircuit, createOperation } from "./circuit";
import type { CircuitDefinition, CircuitPreset, CircuitOperation } from "./types";

const add = (list: CircuitOperation[], gate: CircuitOperation) => { list.push(gate); };
export function bellPairCircuit(): CircuitDefinition {
  const circuit = createCircuit("Bell pair", 2, 2);
  circuit.description = "Create |Φ+> = (|00> + |11>)/√2 using H then CX.";
  circuit.operations = [createOperation("H", 0), createOperation("CX", 1, [0])];
  return circuit;
}
export function ghzCircuit(qubitCount = 3): CircuitDefinition {
  if (!Number.isInteger(qubitCount) || qubitCount < 3 || qubitCount > 8) throw new RangeError("GHZ preset supports 3–8 qubits.");
  const operations = [createOperation("H", 0)];
  for (let target = 1; target < qubitCount; target += 1) operations.push(createOperation("CX", target, [target - 1]));
  return { ...createCircuit(`${qubitCount}-qubit GHZ state`, qubitCount), operations, description: "Prepare a Greenberger–Horne–Zeilinger state with a Hadamard gate and a chain of CNOT gates." };
}
export function qftCircuit(qubitCount = 3, inverse = false): CircuitDefinition {
  if (!Number.isInteger(qubitCount) || qubitCount < 1 || qubitCount > 8) throw new RangeError("QFT preset supports 1–8 qubits.");
  const operations: CircuitOperation[] = [];
  if (!inverse) {
    for (let target = qubitCount - 1; target >= 0; target -= 1) {
      add(operations, createOperation("H", target));
      for (let control = target - 1; control >= 0; control -= 1) {
        const theta = Math.PI / 2 ** (target - control);
        add(operations, createOperation("CP", target, [control], { theta }));
      }
    }
    for (let i = 0; i < Math.floor(qubitCount / 2); i += 1) add(operations, createOperation("SWAP", [i, qubitCount - i - 1]));
  } else {
    for (let i = 0; i < Math.floor(qubitCount / 2); i += 1) add(operations, createOperation("SWAP", [i, qubitCount - i - 1]));
    for (let target = 0; target < qubitCount; target += 1) {
      for (let control = 0; control < target; control += 1) {
        const theta = -Math.PI / 2 ** (target - control);
        add(operations, createOperation("CP", target, [control], { theta }));
      }
      add(operations, createOperation("H", target));
    }
  }
  return { ...createCircuit(inverse ? "Inverse quantum Fourier transform" : "Quantum Fourier transform", qubitCount), operations, description: inverse ? "Undo the QFT using reversed controlled phases and Hadamards." : "Transform computational basis amplitudes into a phase-sensitive Fourier basis." };
}
export function groverSearchCircuit(qubitCount = 2, markedBitstring = "11"): CircuitDefinition {
  if (!Number.isInteger(qubitCount) || qubitCount < 2 || qubitCount > 6) throw new RangeError("Grover preset supports 2–6 search qubits.");
  if (!new RegExp(`^[01]{${qubitCount}}$`).test(markedBitstring)) throw new Error(`Marked item must be a ${qubitCount}-bit string.`);
  const operations: CircuitOperation[] = [];
  for (let q = 0; q < qubitCount; q += 1) add(operations, createOperation("H", q));
  // Phase oracle: conjugate an all-ones multi-controlled Z with X gates for zero bits.
  for (let q = 0; q < qubitCount; q += 1) if (markedBitstring[qubitCount - q - 1] === "0") add(operations, createOperation("X", q));
  add(operations, createOperation("CZ", qubitCount - 1, Array.from({ length: qubitCount - 1 }, (_, index) => index)));
  for (let q = 0; q < qubitCount; q += 1) if (markedBitstring[qubitCount - q - 1] === "0") add(operations, createOperation("X", q));
  // Diffusion operator: H^n X^n H(last) MCZ H(last) X^n H^n.
  for (let q = 0; q < qubitCount; q += 1) add(operations, createOperation("H", q));
  for (let q = 0; q < qubitCount; q += 1) add(operations, createOperation("X", q));
  add(operations, createOperation("H", qubitCount - 1));
  // The multi-controlled X is conjugated by H to create a phase flip on |11…1>.
  add(operations, createOperation("CX", qubitCount - 1, Array.from({ length: qubitCount - 1 }, (_, index) => index)));
  add(operations, createOperation("H", qubitCount - 1));
  for (let q = 0; q < qubitCount; q += 1) add(operations, createOperation("X", q));
  for (let q = 0; q < qubitCount; q += 1) add(operations, createOperation("H", q));
  return { ...createCircuit(`Grover search for ${markedBitstring}`, qubitCount), operations, description: "One ideal Grover iteration for a single marked item. The multi-control phase operation is represented directly by the simulator." };
}
export function phaseKickbackCircuit(): CircuitDefinition {
  const operations = [createOperation("X", 1), createOperation("H", 0), createOperation("H", 1), createOperation("CX", 1, [0]), createOperation("H", 0), createOperation("H", 1)];
  return { ...createCircuit("Phase kickback demonstration", 2), operations, description: "A controlled operation can transfer a relative phase onto the control register when the target is an eigenstate." };
}
export function superdenseCodingCircuit(message: "00" | "01" | "10" | "11" = "00"): CircuitDefinition {
  const operations = [createOperation("H", 0), createOperation("CX", 1, [0])];
  if (message[0] === "1") operations.push(createOperation("X", 0));
  if (message[1] === "1") operations.push(createOperation("Z", 0));
  operations.push(createOperation("CX", 1, [0]), createOperation("H", 0));
  return { ...createCircuit(`Superdense coding · ${message}`, 2, 2, operations), description: `Ideal superdense-coding circuit for classical message ${message}; the final two-qubit measurement recovers the message.` };
}
export function deutschJozsaBalancedTwoQubit(): CircuitDefinition {
  const operations = [createOperation("X", 1), createOperation("H", 0), createOperation("H", 1), createOperation("CX", 1, [0]), createOperation("H", 0), createOperation("H", 1)];
  return { ...createCircuit("Deutsch–Jozsa · balanced oracle", 2), operations, description: "A two-qubit balanced-oracle teaching example. The first qubit is the one-bit input and the second is the phase-kickback ancilla." };
}
export function createCircuitPresets(): CircuitPreset[] {
  const circuits = [bellPairCircuit(), ghzCircuit(3), qftCircuit(3), groverSearchCircuit(2, "11"), phaseKickbackCircuit(), superdenseCodingCircuit("10"), deutschJozsaBalancedTwoQubit()];
  return circuits.map((circuit, index) => ({
    id: `preset-${index + 1}`, title: circuit.name, subtitle: circuit.description ?? "Quantum circuit experiment",
    level: index < 2 ? "introductory" : index < 5 ? "intermediate" : "advanced",
    qubitCount: circuit.qubitCount, circuit,
    learningObjectives: objectivesForPreset(index),
  }));
}
function objectivesForPreset(index: number): string[] {
  const values = [
    ["Prepare a Bell state", "Recognize two-qubit correlations"],
    ["Extend entanglement to multiple qubits", "Inspect global versus local properties"],
    ["Understand controlled phase rotations", "Explore the Fourier basis"],
    ["See amplitude amplification", "Compare ideal and sampled outcomes"],
    ["Understand relative phase", "Explore eigenstates and controlled operations"],
    ["Encode two classical bits using a shared Bell pair", "Connect circuit steps to communication"],
    ["Use an ancilla for phase kickback", "Distinguish balanced and constant functions"],
  ];
  return values[index] ?? [];
}

/**
 * Estimate an eigenphase using n counting qubits and one target eigenstate.
 * The target is prepared as |1>, an eigenstate of RZ(phaseAngle).
 * Phase fraction = phaseAngle / (4π), modulo one.
 */
export function phaseEstimationCircuit(countingQubits = 3, phaseAngle = Math.PI / 2, includeMeasurements = true): CircuitDefinition {
  if (!Number.isInteger(countingQubits) || countingQubits < 1 || countingQubits > 7) throw new RangeError("Phase estimation supports 1–7 counting qubits.");
  if (!Number.isFinite(phaseAngle)) throw new RangeError("Phase angle must be finite.");
  const target = countingQubits; const operations: CircuitOperation[] = [createOperation("X", target)];
  for (let q = 0; q < countingQubits; q += 1) operations.push(createOperation("H", q));
  for (let q = 0; q < countingQubits; q += 1) operations.push(createOperation("CRZ", target, [q], { theta: phaseAngle * 2 ** q }));
  const inverse = qftCircuit(countingQubits, true);
  operations.push(...inverse.operations.map((operation) => ({ ...operation, id: `qpe-${operation.id}` })));
  if (includeMeasurements) for (let q = 0; q < countingQubits; q += 1) operations.push({ ...createOperation("MEASURE", q), classicalBit: q });
  return { ...createCircuit(`Quantum phase estimation · ${countingQubits} counting qubits`, countingQubits + 1, countingQubits + 1, operations), description: `Estimate the eigenphase of RZ(${phaseAngle.toFixed(3)}) using controlled powers and an inverse QFT.` };
}
