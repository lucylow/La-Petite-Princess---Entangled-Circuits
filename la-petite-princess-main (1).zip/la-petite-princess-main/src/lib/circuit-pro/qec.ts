// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { complex, type Complex } from "../advanced/complex";
import { createOperation } from "./circuit";
import { applyGateSequence } from "./gates";
import type { CircuitOperation } from "./types";

export interface BitFlipSyndrome { parity01: 0 | 1; parity12: 0 | 1; errorQubit: 0 | 1 | 2 | null; label: string; }
export interface RecoveryReport { syndrome: BitFlipSyndrome; correctedQubit: number | null; state: Complex[]; corrected: boolean; }
export function encodeThreeQubitRepetition(logicalState: Complex[]): Complex[] {
  if (logicalState.length !== 2) throw new Error("A logical qubit state must have two amplitudes.");
  const norm = logicalState.reduce((sum, amplitude) => sum + amplitude.re ** 2 + amplitude.im ** 2, 0);
  if (Math.abs(norm - 1) > 1e-8) throw new Error("Logical input state must be normalized.");
  const encoded = Array.from({ length: 8 }, () => complex());
  encoded[0] = complex(logicalState[0].re, logicalState[0].im);
  encoded[7] = complex(logicalState[1].re, logicalState[1].im);
  return encoded;
}
export function logicalZeroCodeword(): Complex[] { return [complex(1), ...Array.from({ length: 7 }, () => complex())]; }
export function logicalOneCodeword(): Complex[] { return [...Array.from({ length: 7 }, () => complex()), complex(1)]; }
export function logicalPlusCodeword(): Complex[] {
  const half = 1 / Math.sqrt(2);
  return [complex(half), complex(), complex(), complex(), complex(), complex(), complex(), complex(half)];
}
export function injectBitFlip(state: Complex[], qubit: number): Complex[] {
  if (!Number.isInteger(qubit) || qubit < 0 || qubit > 2) throw new RangeError("Three-qubit repetition code index must be 0, 1 or 2.");
  return applyGateSequence(state, 3, [createOperation("X", qubit)]);
}
export function syndromeForBasisOutcome(bitstring: string): BitFlipSyndrome {
  if (!/^[01]{3}$/.test(bitstring)) throw new Error("Syndrome extraction expects a three-bit data outcome.");
  const [q2, q1, q0] = bitstring.split("").map(Number);
  const parity01 = (q0 ^ q1) as 0 | 1;
  const parity12 = (q1 ^ q2) as 0 | 1;
  const map: Record<string, 0 | 1 | 2 | null> = { "00": null, "10": 0, "11": 1, "01": 2 };
  const errorQubit = map[`${parity01}${parity12}`];
  return { parity01, parity12, errorQubit, label: errorQubit === null ? "No bit-flip detected" : `Bit flip on Q${errorQubit + 1}` };
}
export function correctKnownBitFlip(state: Complex[], qubit: number): Complex[] {
  if (state.length !== 8) throw new Error("Recovery expects a three-qubit state vector.");
  if (!Number.isInteger(qubit) || qubit < 0 || qubit > 2) throw new RangeError("Error location must be Q1, Q2 or Q3.");
  return applyGateSequence(state, 3, [createOperation("X", qubit)]);
}
export function recoverFromSingleBitFlip(state: Complex[], errorQubit: number | null): RecoveryReport {
  if (state.length !== 8) throw new Error("Recovery expects a three-qubit state vector.");
  if (errorQubit === null) return { syndrome: { parity01: 0, parity12: 0, errorQubit: null, label: "No bit-flip detected" }, correctedQubit: null, state, corrected: false };
  const correctedState = correctKnownBitFlip(state, errorQubit);
  const synthetic = errorQubit === 0 ? "001" : errorQubit === 1 ? "010" : "100";
  return { syndrome: syndromeForBasisOutcome(synthetic), correctedQubit: errorQubit, state: correctedState, corrected: true };
}
export function repetitionCodeOperations(): CircuitOperation[] {
  // Encode q0 into q0,q1,q2. The state on q0 can be an arbitrary unknown qubit.
  return [createOperation("CX", 1, [0]), createOperation("CX", 2, [0])];
}
export function measureParitySyndrome(dataBits: [0 | 1, 0 | 1, 0 | 1]): BitFlipSyndrome {
  const [q0, q1, q2] = dataBits;
  const parity01 = (q0 ^ q1) as 0 | 1; const parity12 = (q1 ^ q2) as 0 | 1;
  const map: Record<string, 0 | 1 | 2 | null> = { "00": null, "10": 0, "11": 1, "01": 2 };
  const errorQubit = map[`${parity01}${parity12}`];
  return { parity01, parity12, errorQubit, label: errorQubit === null ? "No bit-flip detected" : `Bit flip on Q${errorQubit + 1}` };
}
export function repetitionCodeLimitations(): string[] {
  return [
    "The three-qubit repetition code protects against one bit-flip error, not an arbitrary unknown single-qubit error.",
    "It does not by itself protect against phase-flip errors; a phase-flip repetition code uses a different basis.",
    "Syndrome extraction must avoid learning the encoded logical information.",
    "Real fault-tolerant quantum computing needs repeated syndrome rounds, fault-tolerant gates and more complete codes.",
  ];
}
