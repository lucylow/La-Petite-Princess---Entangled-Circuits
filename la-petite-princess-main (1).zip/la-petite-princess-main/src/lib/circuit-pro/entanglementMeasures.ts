// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import type { ComplexMatrix } from "./types";
import { cAdd, cConjugate, cMagnitudeSquared, cMul, complex } from "../advanced/complex";
import { hermitianEigenvalues, reducedDensityMatrix, densityFromState } from "./density";
import { trace } from "./matrix";
import { entanglementEntropy, pureTwoQubitConcurrence } from "./observables";
import type { Complex } from "../advanced/complex";

export interface EntanglementReport { subsystemEntropy: number; purityA: number; purityB: number; concurrence?: number; negativity: number; logarithmicNegativity: number; pptEntangled: boolean; }
export function partialTranspose(rho: ComplexMatrix, qubitCount: number, transposedQubit: number): ComplexMatrix {
  if (rho.rows !== rho.cols || rho.rows !== 2 ** qubitCount) throw new Error("Density matrix dimension does not match qubit count.");
  if (!Number.isInteger(transposedQubit) || transposedQubit < 0 || transposedQubit >= qubitCount) throw new RangeError("Invalid partial-transpose qubit.");
  const mask = 1 << transposedQubit;
  const result: ComplexMatrix = { rows: rho.rows, cols: rho.cols, data: Array.from({ length: rho.rows }, () => Array.from({ length: rho.cols }, () => complex())) };
  for (let row = 0; row < rho.rows; row += 1) for (let col = 0; col < rho.cols; col += 1) {
    const transposedRow = (row & ~mask) | (col & mask);
    const transposedCol = (col & ~mask) | (row & mask);
    result.data[row][col] = complex(rho.data[transposedRow][transposedCol].re, rho.data[transposedRow][transposedCol].im);
  }
  return result;
}
export function negativityFromDensity(rho: ComplexMatrix, qubitCount: number, transposedQubit = qubitCount - 1): number {
  const eigenvalues = hermitianEigenvalues(partialTranspose(rho, qubitCount, transposedQubit));
  return eigenvalues.reduce((sum, value) => sum + Math.max(0, -value), 0);
}
export function logarithmicNegativity(rho: ComplexMatrix, qubitCount: number, transposedQubit = qubitCount - 1): number {
  return Math.log2(1 + 2 * negativityFromDensity(rho, qubitCount, transposedQubit));
}
export function twoQubitEntanglementReport(state: Complex[]): EntanglementReport {
  if (state.length !== 4) throw new Error("Two-qubit report requires a four-amplitude pure state.");
  const rho = densityFromState(state);
  const purity = (qubit: number) => {
    const reduced = reducedDensityMatrix(state, 2, [qubit]); let value = 0;
    reduced.data.forEach((row) => row.forEach((entry) => { value += cMagnitudeSquared(entry); })); return value;
  };
  const negativity = negativityFromDensity(rho, 2, 1);
  return { subsystemEntropy: entanglementEntropy(state, 2, [0]), purityA: purity(0), purityB: purity(1), concurrence: pureTwoQubitConcurrence(state), negativity, logarithmicNegativity: Math.log2(1 + 2 * negativity), pptEntangled: negativity > 1e-9 };
}
export function fidelityOfPureStates(a: Complex[], b: Complex[]): number {
  if (a.length !== b.length) throw new Error("State vectors must have equal length.");
  let overlap = complex();
  for (let index = 0; index < a.length; index += 1) overlap = cAdd(overlap, cMul(cConjugate(a[index]), b[index]));
  return Math.min(1, cMagnitudeSquared(overlap));
}
export function traceDistancePureStates(a: Complex[], b: Complex[]): number { return Math.sqrt(Math.max(0, 1 - fidelityOfPureStates(a, b))); }
export function stateOverlap(a: Complex[], b: Complex[]): Complex {
  if (a.length !== b.length) throw new Error("State vectors must have equal lengths.");
  return a.reduce((sum, value, index) => cAdd(sum, cMul(cConjugate(value), b[index])), complex());
}
export function mixedStatePurity(rho: ComplexMatrix): number {
  if (rho.rows !== rho.cols) throw new Error("Density matrix must be square.");
  let result = 0;
  for (let r = 0; r < rho.rows; r += 1) for (let c = 0; c < rho.cols; c += 1) result += cMagnitudeSquared(rho.data[r][c]);
  return result;
}
export function densityTrace(rho: ComplexMatrix): number { return trace(rho).re; }
