// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { cMagnitudeSquared } from "../advanced/complex";
import type { CircuitDefinition, CircuitOperation } from "./types";
import { applyGateOperation } from "./gates";
import { createZeroState, formatState, probabilities } from "./statevector";
import { measureQubit } from "./measurement";
import { resolveRandom } from "./random";

export interface SimulationSnapshot {
  step: number; operation: CircuitOperation | null; label: string; stateText: string;
  probabilityMass: number; probabilities: number[]; measuredOutcome?: 0 | 1;
}
export function traceCircuit(circuit: CircuitDefinition, seed?: number): SimulationSnapshot[] {
  const rng = resolveRandom(seed); let state = createZeroState(circuit.qubitCount);
  const snapshots: SimulationSnapshot[] = [{ step: 0, operation: null, label: "Initial state", stateText: formatState(state, circuit.qubitCount), probabilityMass: 1, probabilities: probabilities(state) }];
  circuit.operations.forEach((operation, index) => {
    let measuredOutcome: 0 | 1 | undefined;
    if (operation.gate === "MEASURE") {
      const measurement = measureQubit(state, circuit.qubitCount, operation.targets[0], rng);
      state = measurement.collapsedState; measuredOutcome = measurement.outcome;
    } else if (operation.gate !== "BARRIER") state = applyGateOperation(state, circuit.qubitCount, operation);
    snapshots.push({ step: index + 1, operation, label: `${operation.gate}${measuredOutcome === undefined ? "" : ` → ${measuredOutcome}`}`, stateText: formatState(state, circuit.qubitCount), probabilityMass: state.reduce((sum, amplitude) => sum + cMagnitudeSquared(amplitude), 0), probabilities: probabilities(state), ...(measuredOutcome === undefined ? {} : { measuredOutcome }) });
  });
  return snapshots;
}
export function traceAsMarkdown(circuit: CircuitDefinition, snapshots: SimulationSnapshot[]): string {
  const lines = [`# ${circuit.name}`, "", `- Qubits: ${circuit.qubitCount}`, `- Operations: ${circuit.operations.length}`, "", "| Step | Operation | State vector | Norm² |", "|---:|---|---|---:|"];
  snapshots.forEach((snapshot) => lines.push(`| ${snapshot.step} | ${snapshot.label} | \\(${snapshot.stateText.replaceAll("|", "\\vert ").replaceAll("⟩", "\\rangle") }\\) | ${snapshot.probabilityMass.toFixed(8)} |`));
  return `${lines.join("\n")}\n`;
}
