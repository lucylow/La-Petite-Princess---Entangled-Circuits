import { describe, expect, it } from 'vitest';
import {
  applyGate,
  bellStateSelfCheck,
  collapseToOutcome,
  formatState,
  initialState,
  isNormalized,
  probabilities,
} from './quantum';

describe('two-qubit state-vector simulator', () => {
  it('starts in |00⟩', () => {
    expect(probabilities(initialState())).toEqual([1, 0, 0, 0]);
  });

  it('creates a 50/50 superposition with H on Q1', () => {
    const state = applyGate(initialState(), 'H_Q1');
    const p = probabilities(state);
    expect(p[0]).toBeCloseTo(0.5);
    expect(p[1]).toBeCloseTo(0.5);
    expect(p[2]).toBeCloseTo(0);
    expect(p[3]).toBeCloseTo(0);
    expect(isNormalized(state)).toBe(true);
  });

  it('creates a Bell state with H(Q1), then CNOT(Q1→Q2)', () => {
    expect(bellStateSelfCheck()).toBe(true);
    const state = applyGate(applyGate(initialState(), 'H_Q1'), 'CNOT_Q1_TO_Q2');
    const p = probabilities(state);
    expect(p[0]).toBeCloseTo(0.5);
    expect(p[1]).toBeCloseTo(0);
    expect(p[2]).toBeCloseTo(0);
    expect(p[3]).toBeCloseTo(0.5);
    expect(formatState(state)).toContain('|00⟩');
    expect(formatState(state)).toContain('|11⟩');
  });

  it('collapses to the measured basis state', () => {
    const collapsed = collapseToOutcome(initialState(), '11');
    expect(probabilities(collapsed)).toEqual([0, 0, 0, 1]);
  });

  it('rejects invalid measurement outcomes', () => {
    expect(() => collapseToOutcome(initialState(), '2')).toThrow();
  });
});
