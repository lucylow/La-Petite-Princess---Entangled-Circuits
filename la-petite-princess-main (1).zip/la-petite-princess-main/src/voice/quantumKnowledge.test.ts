import { describe, expect, it } from "vitest";
import { answerQuantumQuestion, QUANTUM_MENTOR_SYSTEM_PROMPT } from "./quantumKnowledge";

describe("Mademoiselle Q local quantum guide", () => {
  it("explains qubits with a normalized state", () => {
    const answer = answerQuantumQuestion("What is a qubit?");
    expect(answer.topic).toBe("qubit");
    expect(answer.formula).toContain("|α|² + |β|² = 1");
  });

  it("distinguishes entanglement from faster-than-light messaging", () => {
    const answer = answerQuantumQuestion("Explain entanglement and Bell pairs");
    expect(answer.topic).toBe("entanglement");
    expect(answer.paragraphs.join(" ")).toMatch(/faster-than-light/i);
  });

  it("returns an experiment for a gate question", () => {
    const answer = answerQuantumQuestion("How does the Hadamard gate work?");
    expect(answer.topic).toBe("superposition");
    expect(answer.experiment).toMatch(/H twice/i);
  });

  it("separates topological braiding from ordinary entanglement", () => {
    const answer = answerQuantumQuestion("What is anyon braiding in topological quantum computing?");
    expect(answer.topic).toBe("braiding");
    expect(answer.misconception).toMatch(/not a quantum computer/i);
  });

  it("gently redirects unrelated or unrecognized questions", () => {
    const answer = answerQuantumQuestion("Can you recommend a movie?");
    expect(answer.topic).toBe("unknown");
    expect(answer.title).toMatch(/quantum/i);
  });

  it("provides a quantum-only, non-patronizing system instruction", () => {
    expect(QUANTUM_MENTOR_SYSTEM_PROMPT).toMatch(/faster-than-light/i);
    expect(QUANTUM_MENTOR_SYSTEM_PROMPT).toMatch(/never patronize girls/i);
  });
});
