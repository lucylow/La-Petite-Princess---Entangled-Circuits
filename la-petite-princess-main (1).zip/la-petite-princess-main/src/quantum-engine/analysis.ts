// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { C, cAdd, cMul, cScale, type Complex } from "./complex";
import { densityFromState, partialTrace, purity, type DensityMatrix } from "./density";
import { matrixForGate } from "./gates";
import { applySingleQubitMatrix, type StateVector } from "./statevector";

export function expectationPauli(state: StateVector, pauli: "I" | "X" | "Y" | "Z", qubit: number): number {
  if (pauli === "I") return 1;
  const transformed = applySingleQubitMatrix(state, qubit, matrixForGate(pauli));
  let overlap = C(0);
  for (let index = 0; index < state.amplitudes.length; index += 1) overlap = cAdd(overlap, cMul({ re: state.amplitudes[index].re, im: -state.amplitudes[index].im }, transformed.amplitudes[index]));
  return overlap.re;
}
export function pauliExpectationString(state: StateVector): Array<{ qubit: number; x: number; y: number; z: number }> {
  return Array.from({ length: state.qubits }, (_, qubit) => ({ qubit, x: expectationPauli(state, "X", qubit), y: expectationPauli(state, "Y", qubit), z: expectationPauli(state, "Z", qubit) }));
}
export function fidelityPureStates(a: StateVector, b: StateVector): number {
  if (a.qubits !== b.qubits) throw new Error("Cannot compare states with different register sizes.");
  let re = 0; let im = 0;
  for (let i = 0; i < a.amplitudes.length; i += 1) { const x = a.amplitudes[i]; const y = b.amplitudes[i]; re += x.re * y.re + x.im * y.im; im += x.re * y.im - x.im * y.re; }
  return Math.max(0, Math.min(1, re * re + im * im));
}
export function frobeniusDistance(a: DensityMatrix, b: DensityMatrix): number {
  if (a.qubits !== b.qubits) throw new Error("Density matrices have different dimensions.");
  let sum = 0;
  for (let r = 0; r < a.values.length; r += 1) for (let c = 0; c < a.values.length; c += 1) {
    const re = a.values[r][c].re - b.values[r][c].re; const im = a.values[r][c].im - b.values[r][c].im; sum += re * re + im * im;
  }
  return Math.sqrt(sum);
}
export function linearEntropyOfSubsystem(state: StateVector, qubits: number[]): number { return 1 - purity(partialTrace(densityFromState(state), qubits)); }
export function zParityExpectation(state: StateVector, qubits: number[]): number {
  if (!qubits.length || new Set(qubits).size !== qubits.length || qubits.some((q) => q < 0 || q >= state.qubits)) throw new Error("Parity requires unique qubits in the register.");
  let result = 0;
  state.amplitudes.forEach((amplitude, index) => {
    const parity = qubits.reduce((value, q) => value ^ ((index >> q) & 1), 0);
    result += (parity ? -1 : 1) * (amplitude.re * amplitude.re + amplitude.im * amplitude.im);
  });
  return result;
}
export function estimatePhaseFromBloch(x: number, y: number): number { return Math.atan2(y, x); }
export function statePopulation(state: StateVector): number[] { return state.amplitudes.map((amplitude) => amplitude.re * amplitude.re + amplitude.im * amplitude.im); }
export function purityOfPureState(state: StateVector): number { return 1; }
export function expectationOfDiagonal(state: StateVector, diagonal: number[]): number {
  if (diagonal.length !== state.amplitudes.length) throw new Error("Diagonal observable size does not match the state dimension.");
  return state.amplitudes.reduce((sum, amplitude, index) => sum + diagonal[index] * (amplitude.re * amplitude.re + amplitude.im * amplitude.im), 0);
}
export function standardErrorBernoulli(probability: number, shots: number): number {
  if (shots <= 0) throw new Error("Shot count must be positive.");
  return Math.sqrt(probability * (1 - probability) / shots);
}
export function confidenceInterval95(successes: number, shots: number): [number, number] {
  if (!Number.isInteger(successes) || !Number.isInteger(shots) || shots <= 0 || successes < 0 || successes > shots) throw new Error("Invalid binomial sample counts.");
  const p = successes / shots; const z = 1.96; const denominator = 1 + z * z / shots;
  const center = (p + z * z / (2 * shots)) / denominator;
  const margin = z * Math.sqrt((p * (1 - p) / shots) + z * z / (4 * shots * shots)) / denominator;
  return [Math.max(0, center - margin), Math.min(1, center + margin)];
}
export function addExpectationNoise(value: number, standardDeviation: number, random = Math.random): number {
  if (standardDeviation < 0) throw new Error("Standard deviation cannot be negative.");
  // Box–Muller transform.
  const u1 = Math.max(1e-12, random()); const u2 = random();
  return value + standardDeviation * Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
}
