// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { C, EPSILON, ONE, ZERO, cAbs2, cAdd, cScale, type Complex } from "./complex";
import { matrixForGate, type GateId, type GateOperation } from "./gates";
import type { Matrix } from "./matrix";

export interface StateVector {
  qubits: number;
  amplitudes: Complex[];
}
export interface MeasurementResult {
  qubit: number;
  outcome: 0 | 1;
  probability: number;
  state: StateVector;
}

export function dimensionFor(qubits: number): number {
  if (!Number.isInteger(qubits) || qubits < 1 || qubits > 16) throw new Error("A state-vector simulation supports 1–16 qubits in this engine. Large registers may require substantial memory.");
  return 2 ** qubits;
}
export function zeroState(qubits: number): StateVector {
  const amplitudes = Array.from({ length: dimensionFor(qubits) }, () => ZERO);
  amplitudes[0] = ONE;
  return { qubits, amplitudes };
}
export function basisState(qubits: number, basisIndex: number): StateVector {
  const dimension = dimensionFor(qubits);
  if (!Number.isInteger(basisIndex) || basisIndex < 0 || basisIndex >= dimension) throw new Error("Basis index is outside the register range.");
  const state = zeroState(qubits);
  state.amplitudes.fill(ZERO);
  state.amplitudes[basisIndex] = ONE;
  return state;
}
export function cloneState(state: StateVector): StateVector {
  return { qubits: state.qubits, amplitudes: state.amplitudes.map((a) => C(a.re, a.im)) };
}
export function stateNormSquared(state: StateVector): number { return state.amplitudes.reduce((sum, a) => sum + cAbs2(a), 0); }
export function normalizeState(state: StateVector): StateVector {
  const norm = Math.sqrt(stateNormSquared(state));
  if (norm < EPSILON) throw new Error("Cannot normalize a zero quantum state.");
  return { qubits: state.qubits, amplitudes: state.amplitudes.map((a) => cScale(a, 1 / norm)) };
}
export function assertNormalized(state: StateVector, tolerance = 1e-8): void {
  const norm = stateNormSquared(state);
  if (Math.abs(norm - 1) > tolerance) throw new Error(`State is not normalized (norm² = ${norm}).`);
}
function assertQubit(state: StateVector, qubit: number): void {
  if (!Number.isInteger(qubit) || qubit < 0 || qubit >= state.qubits) throw new Error(`Qubit ${qubit} is outside a ${state.qubits}-qubit register.`);
}
function bit(index: number, qubit: number): 0 | 1 { return ((index >> qubit) & 1) as 0 | 1; }

/** Apply a 2×2 unitary to one qubit; qubit 0 is the least-significant bit. */
export function applySingleQubitMatrix(state: StateVector, qubit: number, matrix: Matrix): StateVector {
  assertQubit(state, qubit);
  if (matrix.length !== 2 || matrix.some((row) => row.length !== 2)) throw new Error("A single-qubit operation must be a 2×2 matrix.");
  const mask = 1 << qubit; const output = state.amplitudes.map(() => ZERO);
  for (let base = 0; base < state.amplitudes.length; base += 1) {
    if ((base & mask) !== 0) continue;
    const partner = base | mask; const a = state.amplitudes[base]; const b = state.amplitudes[partner];
    output[base] = cAdd(
      { re: matrix[0][0].re * a.re - matrix[0][0].im * a.im, im: matrix[0][0].re * a.im + matrix[0][0].im * a.re },
      { re: matrix[0][1].re * b.re - matrix[0][1].im * b.im, im: matrix[0][1].re * b.im + matrix[0][1].im * b.re },
    );
    output[partner] = cAdd(
      { re: matrix[1][0].re * a.re - matrix[1][0].im * a.im, im: matrix[1][0].re * a.im + matrix[1][0].im * a.re },
      { re: matrix[1][1].re * b.re - matrix[1][1].im * b.im, im: matrix[1][1].re * b.im + matrix[1][1].im * b.re },
    );
  }
  return { qubits: state.qubits, amplitudes: output };
}

/** Apply a unitary to a target only in basis branches where every control bit is 1. */
export function applyControlledMatrix(state: StateVector, controls: number[], target: number, matrix: Matrix): StateVector {
  assertQubit(state, target); controls.forEach((control) => assertQubit(state, control));
  if (controls.includes(target)) throw new Error("A control qubit cannot also be the target.");
  if (new Set(controls).size !== controls.length) throw new Error("Control qubits must be unique.");
  if (matrix.length !== 2 || matrix.some((row) => row.length !== 2)) throw new Error("Controlled single-qubit operation requires a 2×2 matrix.");
  const targetMask = 1 << target; const controlMask = controls.reduce((mask, q) => mask | (1 << q), 0);
  const output = state.amplitudes.slice();
  for (let base = 0; base < state.amplitudes.length; base += 1) {
    if ((base & targetMask) !== 0 || (base & controlMask) !== controlMask) continue;
    const partner = base | targetMask; const a = state.amplitudes[base]; const b = state.amplitudes[partner];
    output[base] = cAdd(mul(matrix[0][0], a), mul(matrix[0][1], b));
    output[partner] = cAdd(mul(matrix[1][0], a), mul(matrix[1][1], b));
  }
  return { qubits: state.qubits, amplitudes: output };
}
function mul(a: Complex, b: Complex): Complex { return C(a.re * b.re - a.im * b.im, a.re * b.im + a.im * b.re); }

export function applySwap(state: StateVector, qubitA: number, qubitB: number): StateVector {
  assertQubit(state, qubitA); assertQubit(state, qubitB);
  if (qubitA === qubitB) return cloneState(state);
  const maskA = 1 << qubitA; const maskB = 1 << qubitB; const output = state.amplitudes.slice();
  for (let index = 0; index < state.amplitudes.length; index += 1) {
    const a = (index & maskA) !== 0; const b = (index & maskB) !== 0;
    if (a === b) continue;
    const partner = index ^ maskA ^ maskB;
    if (index < partner) { output[index] = state.amplitudes[partner]; output[partner] = state.amplitudes[index]; }
  }
  return { qubits: state.qubits, amplitudes: output };
}
export function applyControlledSwap(state: StateVector, control: number, targetA: number, targetB: number): StateVector {
  [control, targetA, targetB].forEach((q) => assertQubit(state, q));
  if (new Set([control, targetA, targetB]).size !== 3) throw new Error("CSWAP requires three distinct qubits.");
  const cm = 1 << control; const am = 1 << targetA; const bm = 1 << targetB; const output = state.amplitudes.slice();
  for (let index = 0; index < state.amplitudes.length; index += 1) {
    if ((index & cm) === 0) continue;
    const a = (index & am) !== 0; const b = (index & bm) !== 0;
    if (a === b) continue;
    const partner = index ^ am ^ bm;
    if (index < partner) { output[index] = state.amplitudes[partner]; output[partner] = state.amplitudes[index]; }
  }
  return { qubits: state.qubits, amplitudes: output };
}
export function applyGate(state: StateVector, operation: GateOperation): StateVector {
  const { gate, targets, controls = [], params = {} } = operation;
  if (operation.disabled) return cloneState(state);
  if (gate === "SWAP") {
    if (targets.length !== 2) throw new Error("SWAP requires exactly two target qubits.");
    return applySwap(state, targets[0], targets[1]);
  }
  if (gate === "CSWAP") {
    if (targets.length !== 2 || controls.length !== 1) throw new Error("CSWAP requires one control and two targets.");
    return applyControlledSwap(state, controls[0], targets[0], targets[1]);
  }
  if (gate === "CCX") {
    if (targets.length !== 1 || controls.length !== 2) throw new Error("CCX requires two controls and one target.");
    return applyControlledMatrix(state, controls, targets[0], matrixForGate("X"));
  }
  if (["CX", "CY", "CZ", "CH", "CP", "CRX", "CRY", "CRZ"].includes(gate)) {
    if (targets.length !== 1 || controls.length < 1) throw new Error(`${gate} requires one target and at least one control.`);
    const baseGate = gate === "CX" ? "X" : gate === "CY" ? "Y" : gate === "CZ" ? "Z" : gate === "CH" ? "H" : gate;
    const matrix = baseGate === "CP" ? matrixForGate("P", params) : matrixForGate(baseGate as GateId, params);
    return applyControlledMatrix(state, controls, targets[0], matrix);
  }
  if (targets.length !== 1 || controls.length) throw new Error(`${gate} is a single-qubit gate and needs one target with no controls.`);
  return applySingleQubitMatrix(state, targets[0], matrixForGate(gate, params));
}
export function applyGateSequence(state: StateVector, operations: readonly GateOperation[]): StateVector {
  return operations.reduce((current, operation) => applyGate(current, operation), cloneState(state));
}
export function basisProbabilities(state: StateVector): number[] { return state.amplitudes.map((a) => a.re * a.re + a.im * a.im); }
export function probabilityOfQubit(state: StateVector, qubit: number, outcome: 0 | 1): number {
  assertQubit(state, qubit); return state.amplitudes.reduce((sum, a, index) => bit(index, qubit) === outcome ? sum + a.re * a.re + a.im * a.im : sum, 0);
}
export function measureQubit(state: StateVector, qubit: number, random = Math.random()): MeasurementResult {
  assertQubit(state, qubit);
  if (random < 0 || random >= 1) throw new Error("Measurement random value must be in [0, 1).");
  const p0 = probabilityOfQubit(state, qubit, 0); const outcome: 0 | 1 = random < p0 ? 0 : 1; const probability = outcome === 0 ? p0 : 1 - p0;
  if (probability < EPSILON) throw new Error("Selected measurement outcome has zero probability.");
  const scale = 1 / Math.sqrt(probability); const amplitudes = state.amplitudes.map((a, index) => bit(index, qubit) === outcome ? cScale(a, scale) : ZERO);
  return { qubit, outcome, probability, state: { qubits: state.qubits, amplitudes } };
}
export function measureAll(state: StateVector, random = Math.random()): { bitString: string; basisIndex: number; probability: number; state: StateVector } {
  if (random < 0 || random >= 1) throw new Error("Measurement random value must be in [0, 1).");
  const probabilities = basisProbabilities(state); let cumulative = 0; let index = probabilities.length - 1;
  for (let i = 0; i < probabilities.length; i += 1) { cumulative += probabilities[i]; if (random < cumulative) { index = i; break; } }
  const probability = probabilities[index]; const amplitudes = state.amplitudes.map((a, i) => i === index ? cScale(a, 1 / Math.sqrt(probability)) : ZERO);
  return { bitString: index.toString(2).padStart(state.qubits, "0"), basisIndex: index, probability, state: { qubits: state.qubits, amplitudes } };
}
export function formatBasisLabel(index: number, qubits: number): string { return `|${index.toString(2).padStart(qubits, "0")}⟩`; }
export function stateAsTerms(state: StateVector, threshold = 1e-7): Array<{ basis: string; re: number; im: number; probability: number }> {
  return state.amplitudes.map((a, index) => ({ basis: formatBasisLabel(index, state.qubits), re: a.re, im: a.im, probability: a.re * a.re + a.im * a.im })).filter((item) => item.probability > threshold);
}
export function expectationPauliZ(state: StateVector, qubit: number): number {
  assertQubit(state, qubit); return state.amplitudes.reduce((sum, a, index) => sum + (bit(index, qubit) === 0 ? 1 : -1) * cAbs2(a), 0);
}
export function blochVector(state: StateVector, qubit: number): { x: number; y: number; z: number } {
  assertQubit(state, qubit);
  const p1 = probabilityOfQubit(state, qubit, 1); const z = 1 - 2 * p1;
  // Reduced off-diagonal element rho_01 = sum(rest) a_(q=0) * conj(a_(q=1)).
  let re = 0; let im = 0; const mask = 1 << qubit;
  for (let index = 0; index < state.amplitudes.length; index += 1) {
    if ((index & mask) !== 0) continue;
    const a = state.amplitudes[index]; const b = state.amplitudes[index | mask];
    re += a.re * b.re + a.im * b.im; im += a.im * b.re - a.re * b.im;
  }
  return { x: 2 * re, y: -2 * im, z };
}
