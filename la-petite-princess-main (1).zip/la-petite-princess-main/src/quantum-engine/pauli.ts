// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { C, cAdd, cMul, type Complex } from "./complex";
import type { StateVector } from "./statevector";

export type Pauli = "I" | "X" | "Y" | "Z";
export type PauliWord = Pauli[];
export interface PauliProduct { phase: Complex; word: PauliWord; }
const MULTIPLICATION: Record<Pauli, Record<Pauli, PauliProduct>> = {
  I: { I: { phase: C(1), word: ["I"] }, X: { phase: C(1), word: ["X"] }, Y: { phase: C(1), word: ["Y"] }, Z: { phase: C(1), word: ["Z"] } },
  X: { I: { phase: C(1), word: ["X"] }, X: { phase: C(1), word: ["I"] }, Y: { phase: C(0, 1), word: ["Z"] }, Z: { phase: C(0, -1), word: ["Y"] } },
  Y: { I: { phase: C(1), word: ["Y"] }, X: { phase: C(0, -1), word: ["Z"] }, Y: { phase: C(1), word: ["I"] }, Z: { phase: C(0, 1), word: ["X"] } },
  Z: { I: { phase: C(1), word: ["Z"] }, X: { phase: C(0, 1), word: ["Y"] }, Y: { phase: C(0, -1), word: ["X"] }, Z: { phase: C(1), word: ["I"] } },
};
export function multiplyPaulis(a: Pauli, b: Pauli): PauliProduct { return MULTIPLICATION[a][b]; }
export function multiplyPauliWords(a: PauliWord, b: PauliWord): PauliProduct {
  if (a.length !== b.length) throw new Error("Pauli words must have the same length.");
  let phase = C(1); const word: Pauli[] = [];
  for (let index = 0; index < a.length; index += 1) { const product = multiplyPaulis(a[index], b[index]); phase = cMul(phase, product.phase); word.push(product.word[0]); }
  return { phase, word };
}
export function pauliWordsCommute(a: PauliWord, b: PauliWord): boolean {
  if (a.length !== b.length) throw new Error("Pauli words must have the same length.");
  let antiCommutations = 0;
  for (let i = 0; i < a.length; i += 1) if (a[i] !== "I" && b[i] !== "I" && a[i] !== b[i]) antiCommutations += 1;
  return antiCommutations % 2 === 0;
}
export function pauliWordLabel(word: PauliWord): string { return word.join(""); }
export function pauliWeight(word: PauliWord): number { return word.filter((item) => item !== "I").length; }
export function pauliExpectation(state: StateVector, word: PauliWord): number {
  if (word.length !== state.qubits) throw new Error("Pauli word length must equal the register size.");
  let totalRe = 0; let totalIm = 0;
  for (let index = 0; index < state.amplitudes.length; index += 1) {
    let destination = index; let phase = C(1);
    for (let q = 0; q < word.length; q += 1) {
      const value = word[q]; const one = ((index >> q) & 1) === 1;
      if (value === "X") destination ^= 1 << q;
      if (value === "Y") { destination ^= 1 << q; phase = cMul(phase, C(0, one ? -1 : 1)); }
      if (value === "Z" && one) phase = cMul(phase, C(-1));
    }
    const lhs = state.amplitudes[destination]; const rhs = state.amplitudes[index];
    const overlap = cMul(cMul(C(lhs.re, -lhs.im), phase), rhs);
    totalRe += overlap.re; totalIm += overlap.im;
  }
  if (Math.abs(totalIm) > 1e-7) throw new Error("Pauli expectation should be real for a Hermitian observable; check the state or word.");
  return totalRe;
}
export function groupCommutingPaulis(words: PauliWord[]): PauliWord[][] {
  const groups: PauliWord[][] = [];
  for (const word of words) {
    let target = groups.find((group) => group.every((existing) => pauliWordsCommute(existing, word)));
    if (!target) { target = []; groups.push(target); }
    target.push(word);
  }
  return groups;
}
export function pauliWordFromLabel(label: string): PauliWord {
  if (!/^[IXYZ]+$/i.test(label)) throw new Error("Pauli label may contain only I, X, Y and Z.");
  return [...label.toUpperCase()] as PauliWord;
}
export function pauliWordToMask(word: PauliWord): { xMask: number; zMask: number } {
  if (word.length > 30) throw new Error("Bit-mask Pauli encoding supports at most 30 qubits.");
  let xMask = 0; let zMask = 0;
  word.forEach((value, q) => { if (value === "X" || value === "Y") xMask |= 1 << q; if (value === "Z" || value === "Y") zMask |= 1 << q; });
  return { xMask, zMask };
}
export function pauliCommutationMatrix(words: PauliWord[]): boolean[][] {
  return words.map((a) => words.map((b) => pauliWordsCommute(a, b)));
}
