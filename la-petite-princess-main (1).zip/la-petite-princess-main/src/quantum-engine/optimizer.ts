// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { circuitDepth, gateCount, type QuantumCircuit, type CircuitInstruction } from "./circuit";
import { gateDefinition, type GateOperation } from "./gates";

export interface OptimizationPassResult { name: string; removed: number; changed: number; notes: string[]; }
export interface OptimizationResult { circuit: QuantumCircuit; before: { gates: number; depth: number }; after: { gates: number; depth: number }; passes: OptimizationPassResult[]; }
function sameWires(a: GateOperation, b: GateOperation): boolean {
  return JSON.stringify([...a.controls ?? []].sort()) === JSON.stringify([...b.controls ?? []].sort()) && JSON.stringify([...a.targets].sort()) === JSON.stringify([...b.targets].sort());
}
function inversePair(a: GateOperation, b: GateOperation): boolean {
  if (!sameWires(a, b) || a.gate !== b.gate) return false;
  if (["I", "X", "Y", "Z", "H", "CX", "CY", "CZ", "CH", "SWAP", "CCX", "CSWAP"].includes(a.gate)) return true;
  if (a.gate === "RX" || a.gate === "RY" || a.gate === "RZ" || a.gate === "P" || a.gate === "CP" || a.gate === "CRX" || a.gate === "CRY" || a.gate === "CRZ") return Math.abs((a.params?.theta ?? 0) + (b.params?.theta ?? 0)) < 1e-10;
  if (a.gate === "S" && b.gate === "SDG") return true;
  if (a.gate === "SDG" && b.gate === "S") return true;
  if (a.gate === "T" && b.gate === "TDG") return true;
  if (a.gate === "TDG" && b.gate === "T") return true;
  if (a.gate === "SX" && b.gate === "SXDG") return true;
  if (a.gate === "SXDG" && b.gate === "SX") return true;
  return false;
}
function radians(angle: number): number { const tau = 2 * Math.PI; return ((angle % tau) + tau) % tau; }
export function removeIdentityGates(circuit: QuantumCircuit): { circuit: QuantumCircuit; removed: number } {
  const instructions = circuit.instructions.filter((item) => !(item.type === "gate" && item.gate === "I"));
  return { circuit: { ...circuit, instructions }, removed: circuit.instructions.length - instructions.length };
}
export function cancelAdjacentInverses(circuit: QuantumCircuit): { circuit: QuantumCircuit; removed: number } {
  const output: CircuitInstruction[] = []; let removed = 0;
  for (const instruction of circuit.instructions) {
    const previous = output[output.length - 1];
    if (instruction.type === "gate" && previous?.type === "gate" && inversePair(previous, instruction)) { output.pop(); removed += 2; continue; }
    output.push(instruction);
  }
  return { circuit: { ...circuit, instructions: output }, removed };
}
export function mergeAdjacentRotations(circuit: QuantumCircuit): { circuit: QuantumCircuit; changed: number; removed: number } {
  const output: CircuitInstruction[] = []; let changed = 0; let removed = 0;
  for (const instruction of circuit.instructions) {
    const previous = output[output.length - 1];
    if (instruction.type === "gate" && previous?.type === "gate" && instruction.gate === previous.gate && ["RX", "RY", "RZ", "P", "CRX", "CRY", "CRZ", "CP"].includes(instruction.gate) && sameWires(previous, instruction)) {
      const theta = radians((previous.params?.theta ?? 0) + (instruction.params?.theta ?? 0));
      if (Math.min(theta, 2 * Math.PI - theta) < 1e-10) { output.pop(); removed += 2; }
      else output[output.length - 1] = { ...previous, params: { ...previous.params, theta } };
      changed += 1; continue;
    }
    output.push(instruction);
  }
  return { circuit: { ...circuit, instructions: output }, changed, removed };
}
export function optimizeCircuit(input: QuantumCircuit): OptimizationResult {
  const before = { gates: gateCount(input), depth: circuitDepth(input) }; let circuit = input; const passes: OptimizationPassResult[] = [];
  const identityPass = removeIdentityGates(circuit); circuit = identityPass.circuit;
  passes.push({ name: "Remove identity gates", removed: identityPass.removed, changed: identityPass.removed, notes: ["An identity operation does not change the quantum state."] });
  const inversePass = cancelAdjacentInverses(circuit); circuit = inversePass.circuit;
  passes.push({ name: "Cancel adjacent inverse pairs", removed: inversePass.removed, changed: inversePass.removed, notes: ["Cancellation is applied only to adjacent, matching operations on the same wires."] });
  const rotationPass = mergeAdjacentRotations(circuit); circuit = rotationPass.circuit;
  passes.push({ name: "Merge adjacent rotations", removed: rotationPass.removed, changed: rotationPass.changed, notes: ["Rotations about the same axis are combined by adding angles modulo 2π."] });
  const after = { gates: gateCount(circuit), depth: circuitDepth(circuit) };
  return { circuit, before, after, passes };
}
export function estimateCircuitCost(circuit: QuantumCircuit): { total: number; oneQubit: number; twoQubit: number; measurement: number; depth: number } {
  let oneQubit = 0; let twoQubit = 0; let measurement = 0;
  for (const instruction of circuit.instructions) {
    if (instruction.type === "measure") measurement += instruction.qubits.length;
    if (instruction.type === "gate") {
      const touched = instruction.targets.length + (instruction.controls?.length ?? 0);
      if (touched <= 1) oneQubit += 1; else twoQubit += 1;
    }
  }
  const depth = circuitDepth(circuit); return { total: oneQubit + 5 * twoQubit + 0.25 * measurement, oneQubit, twoQubit, measurement, depth };
}
export function suggestOptimizations(circuit: QuantumCircuit): string[] {
  const suggestions: string[] = [];
  for (let i = 1; i < circuit.instructions.length; i += 1) {
    const a = circuit.instructions[i - 1]; const b = circuit.instructions[i];
    if (a.type === "gate" && b.type === "gate" && inversePair(a, b)) suggestions.push(`Instructions ${a.id} and ${b.id} cancel and can be removed.`);
    if (a.type === "gate" && b.type === "gate" && a.gate === b.gate && ["RX", "RY", "RZ", "P"].includes(a.gate) && sameWires(a, b)) suggestions.push(`Adjacent ${a.gate} rotations can be merged.`);
  }
  if (circuit.instructions.filter((i) => i.type === "gate" && i.targets.length + (i.controls?.length ?? 0) > 1).length > 6) suggestions.push("This circuit has many multi-qubit operations; hardware topology may require additional routing SWAPs.");
  if (circuit.instructions.length > 30) suggestions.push("Consider splitting the circuit into named subroutines to make it easier to inspect.");
  return [...new Set(suggestions)];
}
export function gateHasParameters(gate: GateOperation["gate"]): boolean { return gateDefinition(gate).parameterCount > 0; }
