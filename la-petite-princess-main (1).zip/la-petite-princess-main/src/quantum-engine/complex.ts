// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
/** Complex arithmetic for the ideal state-vector and density-matrix engines.
 * No external numerical package is required. Qubit 0 is the least-significant bit.
 */
export type Complex = Readonly<{ re: number; im: number }>;
export type ComplexLike = Complex | number;

export const C = (re = 0, im = 0): Complex => ({ re, im });
export const ZERO = C(0, 0);
export const ONE = C(1, 0);
export const I = C(0, 1);
export const INV_SQRT2 = 1 / Math.sqrt(2);
export const EPSILON = 1e-10;

export function asComplex(value: ComplexLike): Complex {
  return typeof value === "number" ? C(value, 0) : value;
}
export function cAdd(a: ComplexLike, b: ComplexLike): Complex {
  const x = asComplex(a); const y = asComplex(b);
  return C(x.re + y.re, x.im + y.im);
}
export function cSub(a: ComplexLike, b: ComplexLike): Complex {
  const x = asComplex(a); const y = asComplex(b);
  return C(x.re - y.re, x.im - y.im);
}
export function cMul(a: ComplexLike, b: ComplexLike): Complex {
  const x = asComplex(a); const y = asComplex(b);
  return C(x.re * y.re - x.im * y.im, x.re * y.im + x.im * y.re);
}
export function cScale(a: ComplexLike, factor: number): Complex {
  const x = asComplex(a); return C(x.re * factor, x.im * factor);
}
export function cDiv(a: ComplexLike, b: ComplexLike): Complex {
  const x = asComplex(a); const y = asComplex(b);
  const d = y.re * y.re + y.im * y.im;
  if (d < EPSILON) throw new Error("Cannot divide by a zero complex number.");
  return C((x.re * y.re + x.im * y.im) / d, (x.im * y.re - x.re * y.im) / d);
}
export function cConj(a: ComplexLike): Complex { const x = asComplex(a); return C(x.re, -x.im); }
export function cAbs2(a: ComplexLike): number { const x = asComplex(a); return x.re * x.re + x.im * x.im; }
export function cAbs(a: ComplexLike): number { return Math.sqrt(cAbs2(a)); }
export function cArg(a: ComplexLike): number { const x = asComplex(a); return Math.atan2(x.im, x.re); }
export function cExpI(theta: number): Complex { return C(Math.cos(theta), Math.sin(theta)); }
export function cSqrt(a: ComplexLike): Complex {
  const x = asComplex(a); const r = cAbs(x); const sign = x.im < 0 ? -1 : 1;
  return C(Math.sqrt(Math.max(0, (r + x.re) / 2)), sign * Math.sqrt(Math.max(0, (r - x.re) / 2)));
}
export function cNearlyEqual(a: ComplexLike, b: ComplexLike, epsilon = EPSILON): boolean {
  return cAbs(cSub(a, b)) <= epsilon;
}
export function cIsZero(a: ComplexLike, epsilon = EPSILON): boolean { return cAbs(a) <= epsilon; }
export function cFormat(a: ComplexLike, digits = 4): string {
  const x = asComplex(a); const r = Math.abs(x.re) < EPSILON ? 0 : x.re; const im = Math.abs(x.im) < EPSILON ? 0 : x.im;
  if (im === 0) return r.toFixed(digits).replace(/\.0+$/, "").replace(/(\.\d*?)0+$/, "$1");
  if (r === 0) return `${im.toFixed(digits).replace(/\.0+$/, "")}i`;
  const sign = im < 0 ? " − " : " + ";
  return `${r.toFixed(digits)}${sign}${Math.abs(im).toFixed(digits)}i`;
}
export function cFromPolar(radius: number, phase: number): Complex {
  return C(radius * Math.cos(phase), radius * Math.sin(phase));
}
export function cSum(values: readonly ComplexLike[]): Complex {
  return values.reduce<Complex>((sum, value) => cAdd(sum, value), ZERO);
}
export function cProduct(values: readonly ComplexLike[]): Complex {
  return values.reduce<Complex>((product, value) => cMul(product, value), ONE);
}
export function cMean(values: readonly ComplexLike[]): Complex {
  if (!values.length) return ZERO;
  return cScale(cSum(values), 1 / values.length);
}
export function cClampTiny(value: ComplexLike, epsilon = EPSILON): Complex {
  const x = asComplex(value);
  return C(Math.abs(x.re) < epsilon ? 0 : x.re, Math.abs(x.im) < epsilon ? 0 : x.im);
}
export function cAssertFinite(value: ComplexLike, label = "complex value"): void {
  const x = asComplex(value);
  if (!Number.isFinite(x.re) || !Number.isFinite(x.im)) throw new Error(`${label} must contain finite real and imaginary parts.`);
}
