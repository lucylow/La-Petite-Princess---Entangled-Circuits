// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import type { CircuitInstruction, QuantumCircuit } from "./circuit";
import { gateDefinition } from "./gates";

export interface CircuitMoment {
  index: number;
  instructionIds: string[];
  qubits: number[];
  label: string;
}

export interface CircuitMetrics {
  qubits: number;
  classicalBits: number;
  totalInstructions: number;
  unitaryGates: number;
  measurements: number;
  resets: number;
  barriers: number;
  oneQubitGates: number;
  controlledGates: number;
  multiQubitGates: number;
  parameterizedGates: number;
  estimatedDepth: number;
  twoQubitDepth: number;
  measurementCount: number;
  qubitUtilization: number;
  activeQubits: number[];
  idleQubits: number[];
}

function touchedQubits(instruction: CircuitInstruction): number[] {
  if (instruction.type === "gate") return [...instruction.targets, ...(instruction.controls ?? [])];
  if (instruction.type === "measure" || instruction.type === "reset") return [...instruction.qubits];
  return instruction.qubits ? [...instruction.qubits] : [];
}

export function instructionLabel(instruction: CircuitInstruction): string {
  if (instruction.type === "measure") return `Measure ${instruction.qubits.map((q) => `q${q}`).join(", ")}`;
  if (instruction.type === "reset") return `Reset ${instruction.qubits.map((q) => `q${q}`).join(", ")}`;
  if (instruction.type === "barrier") return "Barrier";
  const controls = instruction.controls?.length ? `ctrl ${instruction.controls.join(",")}` : "";
  const targets = instruction.targets.map((q) => `q${q}`).join(",");
  const params = Object.entries(instruction.params ?? {}).filter(([, value]) => typeof value === "number").map(([key, value]) => `${key}=${Number(value).toFixed(3)}`).join(", ");
  return `${instruction.gate} ${controls} → ${targets}${params ? ` (${params})` : ""}`.trim();
}

/** Greedy ASAP scheduling: instructions that share a qubit are never placed in the same moment. */
export function scheduleCircuitMoments(circuit: QuantumCircuit): CircuitMoment[] {
  const moments: CircuitMoment[] = [];
  const lastUsed = Array.from({ length: circuit.qubits }, () => -1);
  circuit.instructions.forEach((instruction) => {
    if (instruction.type === "barrier") {
      const index = Math.max(-1, ...touchedQubits(instruction).map((q) => lastUsed[q] ?? -1)) + 1;
      const moment = moments[index] ?? { index, instructionIds: [], qubits: [], label: "Barrier" };
      moment.instructionIds.push(instruction.id);
      moments[index] = moment;
      const affected = instruction.qubits ?? Array.from({ length: circuit.qubits }, (_, q) => q);
      affected.forEach((q) => { if (q >= 0 && q < lastUsed.length) lastUsed[q] = index; });
      return;
    }
    const qubits = touchedQubits(instruction);
    const index = Math.max(-1, ...qubits.map((q) => lastUsed[q] ?? -1)) + 1;
    const moment = moments[index] ?? { index, instructionIds: [], qubits: [], label: "" };
    moment.instructionIds.push(instruction.id);
    moment.qubits.push(...qubits);
    moment.label = moment.label ? `${moment.label} · ${instructionLabel(instruction)}` : instructionLabel(instruction);
    moments[index] = moment;
    qubits.forEach((q) => { if (q >= 0 && q < lastUsed.length) lastUsed[q] = index; });
  });
  return moments.map((moment, index) => ({ ...moment, index, qubits: [...new Set(moment.qubits)] }));
}

export function calculateCircuitMetrics(circuit: QuantumCircuit): CircuitMetrics {
  const gates = circuit.instructions.filter((instruction) => instruction.type === "gate");
  const measurements = circuit.instructions.filter((instruction) => instruction.type === "measure");
  const resets = circuit.instructions.filter((instruction) => instruction.type === "reset");
  const barriers = circuit.instructions.filter((instruction) => instruction.type === "barrier");
  const active = new Set<number>();
  circuit.instructions.forEach((instruction) => touchedQubits(instruction).forEach((q) => active.add(q)));
  const moments = scheduleCircuitMoments(circuit);
  const twoQubitMoments = new Set<number>();
  moments.forEach((moment) => {
    const hasEntangler = moment.instructionIds.some((id) => {
      const instruction = circuit.instructions.find((item) => item.id === id);
      return instruction?.type === "gate" && (instruction.targets.length + (instruction.controls?.length ?? 0)) >= 2;
    });
    if (hasEntangler) twoQubitMoments.add(moment.index);
  });
  const oneQubitGates = gates.filter((instruction) => instruction.targets.length === 1 && !(instruction.controls?.length)).length;
  const controlledGates = gates.filter((instruction) => (instruction.controls?.length ?? 0) === 1 && instruction.targets.length === 1).length;
  const multiQubitGates = gates.filter((instruction) => instruction.targets.length + (instruction.controls?.length ?? 0) > 2).length;
  const parameterizedGates = gates.filter((instruction) => gateDefinition(instruction.gate).parameterCount > 0).length;
  const activeQubits = [...active].sort((a, b) => a - b);
  const idleQubits = Array.from({ length: circuit.qubits }, (_, q) => q).filter((q) => !active.has(q));
  return {
    qubits: circuit.qubits,
    classicalBits: circuit.classicalBits,
    totalInstructions: circuit.instructions.length,
    unitaryGates: gates.length,
    measurements: measurements.length,
    resets: resets.length,
    barriers: barriers.length,
    oneQubitGates,
    controlledGates,
    multiQubitGates,
    parameterizedGates,
    estimatedDepth: moments.length,
    twoQubitDepth: twoQubitMoments.size,
    measurementCount: measurements.reduce((sum, instruction) => sum + instruction.qubits.length, 0),
    qubitUtilization: circuit.qubits ? active.size / circuit.qubits : 0,
    activeQubits,
    idleQubits,
  };
}

export function countGateFamilies(circuit: QuantumCircuit): Record<string, number> {
  const counts: Record<string, number> = {};
  circuit.instructions.forEach((instruction) => {
    if (instruction.type !== "gate") return;
    const family = gateDefinition(instruction.gate).category;
    counts[family] = (counts[family] ?? 0) + 1;
  });
  return counts;
}

export function gateFrequency(circuit: QuantumCircuit): Record<string, number> {
  const counts: Record<string, number> = {};
  circuit.instructions.forEach((instruction) => {
    if (instruction.type === "gate") counts[instruction.gate] = (counts[instruction.gate] ?? 0) + 1;
  });
  return counts;
}

export function qubitParticipation(circuit: QuantumCircuit): number[] {
  const counts = Array.from({ length: circuit.qubits }, () => 0);
  circuit.instructions.forEach((instruction) => touchedQubits(instruction).forEach((q) => {
    if (q >= 0 && q < counts.length) counts[q] += 1;
  }));
  return counts;
}

export function gateInteractionGraph(circuit: QuantumCircuit): Array<{ source: number; target: number; weight: number }> {
  const pairs = new Map<string, number>();
  circuit.instructions.forEach((instruction) => {
    if (instruction.type !== "gate") return;
    const wires = [...instruction.controls ?? [], ...instruction.targets];
    for (let i = 0; i < wires.length; i += 1) {
      for (let j = i + 1; j < wires.length; j += 1) {
        const a = Math.min(wires[i], wires[j]);
        const b = Math.max(wires[i], wires[j]);
        const key = `${a}:${b}`;
        pairs.set(key, (pairs.get(key) ?? 0) + 1);
      }
    }
  });
  return [...pairs.entries()].map(([key, weight]) => {
    const [source, target] = key.split(":").map(Number);
    return { source, target, weight };
  }).sort((a, b) => b.weight - a.weight || a.source - b.source || a.target - b.target);
}

export function findUnusedQubits(circuit: QuantumCircuit): number[] {
  return calculateCircuitMetrics(circuit).idleQubits;
}

export function estimateTwoQubitGateCount(circuit: QuantumCircuit): number {
  return circuit.instructions.filter((instruction) => instruction.type === "gate" && instruction.targets.length + (instruction.controls?.length ?? 0) >= 2).length;
}

export function parameterizedInstructionIds(circuit: QuantumCircuit): string[] {
  return circuit.instructions.filter((instruction) => instruction.type === "gate" && gateDefinition(instruction.gate).parameterCount > 0).map((instruction) => instruction.id);
}

export function analyzeCircuitSummary(circuit: QuantumCircuit): string {
  const metrics = calculateCircuitMetrics(circuit);
  return `${circuit.name}: ${metrics.qubits} qubits, ${metrics.unitaryGates} gates, depth ${metrics.estimatedDepth}, ${metrics.measurementCount} measured wire(s).`;
}
