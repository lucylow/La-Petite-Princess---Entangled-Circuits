// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import type { QuantumCircuit } from "./circuit";
import type { GateOperation } from "./gates";

function angle(value: number | undefined): string { return (value ?? 0).toPrecision(10).replace(/\.0+$/, ""); }
function qasmGate(operation: GateOperation): string {
  const q = operation.targets.map((target) => `q[${target}]`);
  const c = (operation.controls ?? []).map((control) => `q[${control}]`);
  const args = operation.gate === "SWAP" ? q : [...c, ...q];
  const theta = operation.params?.theta; const phi = operation.params?.phi; const lambda = operation.params?.lambda;
  if (operation.gate === "RX" || operation.gate === "RY" || operation.gate === "RZ" || operation.gate === "P") return `${operation.gate.toLowerCase()}(${angle(theta)}) ${q.join(",")};`;
  if (operation.gate === "U3") return `u(${angle(theta)},${angle(phi)},${angle(lambda)}) ${q[0]};`;
  if (operation.gate === "CX") return `cx ${args.join(",")};`;
  if (operation.gate === "CY" || operation.gate === "CZ" || operation.gate === "CH") return `${operation.gate.toLowerCase()} ${args.join(",")};`;
  if (operation.gate === "CP" || operation.gate === "CRX" || operation.gate === "CRY" || operation.gate === "CRZ") return `${operation.gate.toLowerCase()}(${angle(theta)}) ${args.join(",")};`;
  const names: Record<string, string> = { SDG: "sdg", TDG: "tdg", SXDG: "sxdg", CCX: "ccx", CSWAP: "cswap" };
  return `${names[operation.gate] ?? operation.gate.toLowerCase()} ${args.join(",")};`;
}
export function exportOpenQASM3(circuit: QuantumCircuit): string {
  const lines = ["OPENQASM 3.0;", 'include "stdgates.inc";', `qubit[${circuit.qubits}] q;`, `bit[${circuit.classicalBits}] c;`, ""];
  for (const instruction of circuit.instructions) {
    if (instruction.type === "gate") {
      const statement = qasmGate(instruction);
      if (instruction.condition) lines.push(`if (c[${instruction.condition.bit}] == ${instruction.condition.equals}) { ${statement} }`);
      else lines.push(statement);
    } else if (instruction.type === "measure") instruction.qubits.forEach((qubit, index) => lines.push(`c[${instruction.classicalBits[index]}] = measure q[${qubit}];`));
    else if (instruction.type === "reset") instruction.qubits.forEach((qubit) => lines.push(`reset q[${qubit}];`));
    else if (instruction.type === "barrier") lines.push(instruction.qubits?.length ? `barrier ${instruction.qubits.map((q) => `q[${q}]`).join(",")};` : "barrier q;");
  }
  return lines.join("\n");
}
export function exportOpenQASM2(circuit: QuantumCircuit): string {
  if (circuit.instructions.some((i) => i.type === "gate" && i.condition)) throw new Error("OpenQASM 2 exporter does not support classical conditions in this starter.");
  const lines = ["OPENQASM 2.0;", 'include "qelib1.inc";', `qreg q[${circuit.qubits}];`, `creg c[${circuit.classicalBits}];`, ""];
  for (const instruction of circuit.instructions) {
    if (instruction.type === "gate") lines.push(qasmGate(instruction));
    else if (instruction.type === "measure") instruction.qubits.forEach((qubit, index) => lines.push(`measure q[${qubit}] -> c[${instruction.classicalBits[index]}];`));
    else if (instruction.type === "reset") instruction.qubits.forEach((qubit) => lines.push(`reset q[${qubit}];`));
    else if (instruction.type === "barrier") lines.push(`barrier ${(instruction.qubits ?? Array.from({ length: circuit.qubits }, (_, q) => q)).map((q) => `q[${q}]`).join(",")};`);
  }
  return lines.join("\n");
}
export function exportCircuitAsPython(circuit: QuantumCircuit): string {
  const lines = ["from qiskit import QuantumCircuit, transpile", "from qiskit_aer import AerSimulator", "", `qc = QuantumCircuit(${circuit.qubits}, ${circuit.classicalBits})`];
  for (const instruction of circuit.instructions) {
    if (instruction.type === "gate") {
      const t = instruction.targets; const c = instruction.controls ?? []; const p = instruction.params ?? {};
      const call: Record<string, string> = { I: `qc.id(${t[0]})`, X: `qc.x(${t[0]})`, Y: `qc.y(${t[0]})`, Z: `qc.z(${t[0]})`, H: `qc.h(${t[0]})`, S: `qc.s(${t[0]})`, SDG: `qc.sdg(${t[0]})`, T: `qc.t(${t[0]})`, TDG: `qc.tdg(${t[0]})`, SX: `qc.sx(${t[0]})`, SXDG: `qc.sxdg(${t[0]})`, RX: `qc.rx(${p.theta ?? 0}, ${t[0]})`, RY: `qc.ry(${p.theta ?? 0}, ${t[0]})`, RZ: `qc.rz(${p.theta ?? 0}, ${t[0]})`, P: `qc.p(${p.theta ?? 0}, ${t[0]})`, U3: `qc.u(${p.theta ?? 0}, ${p.phi ?? 0}, ${p.lambda ?? 0}, ${t[0]})`, CX: `qc.cx(${c[0]}, ${t[0]})`, CY: `qc.cy(${c[0]}, ${t[0]})`, CZ: `qc.cz(${c[0]}, ${t[0]})`, CH: `qc.ch(${c[0]}, ${t[0]})`, CP: `qc.cp(${p.theta ?? 0}, ${c[0]}, ${t[0]})`, CRX: `qc.crx(${p.theta ?? 0}, ${c[0]}, ${t[0]})`, CRY: `qc.cry(${p.theta ?? 0}, ${c[0]}, ${t[0]})`, CRZ: `qc.crz(${p.theta ?? 0}, ${c[0]}, ${t[0]})`, SWAP: `qc.swap(${t[0]}, ${t[1]})`, CCX: `qc.ccx(${c[0]}, ${c[1]}, ${t[0]})`, CSWAP: `qc.cswap(${c[0]}, ${t[0]}, ${t[1]})` };
      if (instruction.condition) lines.push(`with qc.if_test((qc.clbits[${instruction.condition.bit}], ${instruction.condition.equals})):\n    ${call[instruction.gate]}`);
      else lines.push(call[instruction.gate]);
    } else if (instruction.type === "measure") instruction.qubits.forEach((q, i) => lines.push(`qc.measure(${q}, ${instruction.classicalBits[i]})`));
    else if (instruction.type === "reset") instruction.qubits.forEach((q) => lines.push(`qc.reset(${q})`));
    else if (instruction.type === "barrier") lines.push(`qc.barrier(${(instruction.qubits ?? []).join(", ")})`);
  }
  lines.push("", "backend = AerSimulator()", "compiled = transpile(qc, backend)", "result = backend.run(compiled, shots=1024).result()", "print(result.get_counts())");
  return lines.join("\n");
}
