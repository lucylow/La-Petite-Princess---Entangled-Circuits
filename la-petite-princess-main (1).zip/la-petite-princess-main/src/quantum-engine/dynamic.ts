// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { appendBarrier, appendGate, appendMeasurement, appendReset, createCircuit, type QuantumCircuit } from "./circuit";
import type { GateId } from "./gates";

export function measureInto(circuit: QuantumCircuit, qubit: number, classicalBit: number): QuantumCircuit {
  return appendMeasurement(circuit, [qubit], [classicalBit]);
}
export function conditionalGate(circuit: QuantumCircuit, gate: GateId, target: number, classicalBit: number, equals: 0 | 1, control?: number): QuantumCircuit {
  if (classicalBit < 0 || classicalBit >= circuit.classicalBits) throw new Error("Classical condition bit is outside the circuit register.");
  const withGate = appendGate(circuit, gate, [target], control === undefined ? [] : [control]);
  const last = withGate.instructions[withGate.instructions.length - 1];
  if (last.type !== "gate") throw new Error("Expected a gate instruction.");
  return { ...withGate, instructions: withGate.instructions.map((item) => item.id === last.id && item.type === "gate" ? { ...item, condition: { bit: classicalBit, equals } } : item) };
}
export function measurementResetCircuit(qubits = 1): QuantumCircuit {
  if (!Number.isInteger(qubits) || qubits < 1 || qubits > 8) throw new Error("Dynamic reset demo supports 1–8 qubits.");
  let circuit = createCircuit(qubits, "Measure and reset demonstration");
  for (let q = 0; q < qubits; q += 1) circuit = appendGate(circuit, "H", [q]);
  circuit = appendMeasurement(circuit, Array.from({ length: qubits }, (_, q) => q));
  return appendReset(circuit, Array.from({ length: qubits }, (_, q) => q));
}
export function teleportationWithClassicalFeedForward(): QuantumCircuit {
  let circuit = createCircuit(3, "Teleportation with classical feed-forward");
  circuit = appendGate(circuit, "RY", [0], [], { theta: Math.PI / 3 });
  circuit = appendGate(circuit, "RZ", [0], [], { theta: Math.PI / 7 });
  circuit = appendGate(circuit, "H", [1]); circuit = appendGate(circuit, "CX", [2], [1]);
  circuit = appendGate(circuit, "CX", [1], [0]); circuit = appendGate(circuit, "H", [0]);
  circuit = appendMeasurement(circuit, [0, 1], [0, 1]);
  circuit = conditionalGate(circuit, "X", 2, 1, 1);
  circuit = conditionalGate(circuit, "Z", 2, 0, 1);
  return appendBarrier(circuit, [2]);
}
export function midCircuitParityCheck(): QuantumCircuit {
  let circuit = createCircuit(3, "Mid-circuit parity check");
  circuit = appendGate(circuit, "H", [0]); circuit = appendGate(circuit, "H", [1]);
  circuit = appendGate(circuit, "CX", [2], [0]); circuit = appendGate(circuit, "CX", [2], [1]);
  circuit = appendMeasurement(circuit, [2], [0]);
  circuit = conditionalGate(circuit, "Z", 1, 0, 1);
  return circuit;
}
export function dynamicCircuitGuide(): Array<{ title: string; explanation: string }> {
  return [
    { title: "Mid-circuit measurement", explanation: "A qubit may be measured before the end of a program. Later gates can depend on the classical result." },
    { title: "Classical feed-forward", explanation: "A conditional gate executes only when the referenced classical bit matches the requested value." },
    { title: "Reset", explanation: "Reset prepares a qubit in |0⟩. In a shot simulator this can be modeled by measurement followed by a conditional X." },
    { title: "Why it matters", explanation: "Dynamic circuits are used for teleportation, error correction, syndrome extraction and adaptive protocols." },
  ];
}
