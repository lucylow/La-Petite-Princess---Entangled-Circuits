// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { appendGate, appendMeasurement, appendReset, createCircuit, createId, type QuantumCircuit } from "../circuit";
import type { GateOperation } from "../gates";

function add(circuit: QuantumCircuit, gate: GateOperation["gate"], targets: number[], controls: number[] = [], theta?: number): QuantumCircuit {
  return { ...circuit, instructions: [...circuit.instructions, { type: "gate", id: createId(`algo-${gate.toLowerCase()}`), gate, targets, controls, params: theta === undefined ? {} : { theta } }] };
}
function addMany(circuit: QuantumCircuit, gate: GateOperation["gate"], qubits: number[]): QuantumCircuit {
  return qubits.reduce((current, q) => add(current, gate, [q]), circuit);
}
export function bellCircuit(variant: "phi-plus" | "phi-minus" | "psi-plus" | "psi-minus" = "phi-plus"): QuantumCircuit {
  let c = createCircuit(2, `Bell state · ${variant}`);
  if (variant === "psi-plus" || variant === "psi-minus") c = add(c, "X", [1]);
  c = add(c, "H", [0]); c = add(c, "CX", [1], [0]);
  if (variant === "phi-minus" || variant === "psi-minus") c = add(c, "Z", [0]);
  return c;
}
export function ghzCircuit(qubits = 3): QuantumCircuit {
  if (!Number.isInteger(qubits) || qubits < 2 || qubits > 12) throw new Error("GHZ builder supports 2–12 qubits.");
  let c = createCircuit(qubits, `${qubits}-qubit GHZ state`); c = add(c, "H", [0]);
  for (let q = 1; q < qubits; q += 1) c = add(c, "CX", [q], [q - 1]);
  return c;
}
export function wStateCircuit(qubits = 3): QuantumCircuit {
  if (!Number.isInteger(qubits) || qubits < 2 || qubits > 8) throw new Error("W-state builder supports 2–8 qubits.");
  // Sequentially split the remaining excitation amplitude. The control q0 is reset
  // to |0> whenever an excitation is transferred to the next wire.
  let c = createCircuit(qubits, `${qubits}-qubit W state`);
  c = add(c, "X", [0]);
  for (let target = 1; target < qubits; target += 1) {
    const remaining = qubits - target + 1;
    const theta = 2 * Math.asin(1 / Math.sqrt(remaining));
    c = add(c, "CRY", [target], [0], theta);
    c = add(c, "CX", [0], [target]);
  }
  return c;
}
export function qftCircuit(qubits = 3, inverse = false): QuantumCircuit {
  if (!Number.isInteger(qubits) || qubits < 1 || qubits > 8) throw new Error("QFT builder supports 1–8 qubits.");
  let c = createCircuit(qubits, inverse ? `Inverse QFT · ${qubits} qubits` : `Quantum Fourier transform · ${qubits} qubits`);
  if (!inverse) {
    for (let target = qubits - 1; target >= 0; target -= 1) {
      c = add(c, "H", [target]);
      for (let control = target - 1; control >= 0; control -= 1) c = add(c, "CP", [target], [control], Math.PI / 2 ** (target - control));
    }
    for (let left = 0; left < Math.floor(qubits / 2); left += 1) c = add(c, "SWAP", [left, qubits - 1 - left]);
  } else {
    // Exact inverse: reverse the final bit-reversal swaps first, then undo gates.
    for (let left = 0; left < Math.floor(qubits / 2); left += 1) c = add(c, "SWAP", [left, qubits - 1 - left]);
    for (let target = 0; target < qubits; target += 1) {
      if (target > 0) for (let control = 0; control < target; control += 1) c = add(c, "CP", [target], [control], -Math.PI / 2 ** (target - control));
      c = add(c, "H", [target]);
    }
  }
  return c;
}
function applyBitPatternX(circuit: QuantumCircuit, pattern: number, qubits: number): QuantumCircuit {
  let c = circuit;
  for (let q = 0; q < qubits; q += 1) if (((pattern >> q) & 1) === 0) c = add(c, "X", [q]);
  return c;
}
function phaseFlipAllOnes(circuit: QuantumCircuit, qubits: number): QuantumCircuit {
  if (qubits === 1) return add(circuit, "Z", [0]);
  const target = qubits - 1; let c = add(circuit, "H", [target]);
  c = add(c, "CX", [target], Array.from({ length: target }, (_, q) => q));
  return add(c, "H", [target]);
}
function groverOracle(circuit: QuantumCircuit, qubits: number, marked: number): QuantumCircuit {
  let c = applyBitPatternX(circuit, marked, qubits); c = phaseFlipAllOnes(c, qubits); return applyBitPatternX(c, marked, qubits);
}
function groverDiffusion(circuit: QuantumCircuit, qubits: number): QuantumCircuit {
  let c = addMany(circuit, "H", Array.from({ length: qubits }, (_, q) => q));
  c = addMany(c, "X", Array.from({ length: qubits }, (_, q) => q));
  c = phaseFlipAllOnes(c, qubits);
  c = addMany(c, "X", Array.from({ length: qubits }, (_, q) => q));
  return addMany(c, "H", Array.from({ length: qubits }, (_, q) => q));
}
export function groverCircuit(qubits = 3, marked = 5, iterations?: number): QuantumCircuit {
  if (!Number.isInteger(qubits) || qubits < 2 || qubits > 8) throw new Error("Grover builder supports 2–8 qubits.");
  if (!Number.isInteger(marked) || marked < 0 || marked >= 2 ** qubits) throw new Error("Marked item must be a valid basis index.");
  const optimal = Math.max(1, Math.floor(Math.PI / 4 * Math.sqrt(2 ** qubits)));
  const rounds = iterations ?? optimal;
  if (!Number.isInteger(rounds) || rounds < 0 || rounds > 20) throw new Error("Grover iteration count must be between 0 and 20.");
  let c = createCircuit(qubits, `Grover search · marked ${marked.toString(2).padStart(qubits, "0")}`);
  c = addMany(c, "H", Array.from({ length: qubits }, (_, q) => q));
  for (let i = 0; i < rounds; i += 1) { c = groverOracle(c, qubits, marked); c = groverDiffusion(c, qubits); }
  return c;
}
export function deutschJozsaCircuit(qubits = 3, balancedMask = 5): QuantumCircuit {
  if (!Number.isInteger(qubits) || qubits < 1 || qubits > 8) throw new Error("Deutsch–Jozsa builder supports 1–8 input qubits.");
  let c = createCircuit(qubits + 1, "Deutsch–Jozsa algorithm"); c = add(c, "X", [qubits]);
  c = addMany(c, "H", Array.from({ length: qubits + 1 }, (_, q) => q));
  for (let q = 0; q < qubits; q += 1) if ((balancedMask >> q) & 1) c = add(c, "CX", [qubits], [q]);
  c = addMany(c, "H", Array.from({ length: qubits }, (_, q) => q));
  c = appendMeasurement(c, Array.from({ length: qubits }, (_, q) => q));
  return { ...c, classicalBits: qubits };
}
export function bernsteinVaziraniCircuit(secret: string): QuantumCircuit {
  if (!/^[01]{1,8}$/.test(secret)) throw new Error("Secret string must contain 1–8 binary digits.");
  const n = secret.length; let c = createCircuit(n + 1, `Bernstein–Vazirani · secret length ${n}`);
  c = add(c, "X", [n]); c = addMany(c, "H", Array.from({ length: n + 1 }, (_, q) => q));
  for (let q = 0; q < n; q += 1) if (secret[n - 1 - q] === "1") c = add(c, "CX", [n], [q]);
  c = addMany(c, "H", Array.from({ length: n }, (_, q) => q));
  return { ...appendMeasurement(c, Array.from({ length: n }, (_, q) => q)), classicalBits: n };
}
export function teleportationCircuit(theta = Math.PI / 3, phi = Math.PI / 5): QuantumCircuit {
  let c = createCircuit(3, "Quantum teleportation"); c = add(c, "RY", [0], [], theta); c = add(c, "RZ", [0], [], phi);
  c = add(c, "H", [1]); c = add(c, "CX", [2], [1]); c = add(c, "CX", [1], [0]); c = add(c, "H", [0]);
  c = appendMeasurement(c, [0, 1], [0, 1]);
  c = { ...c, instructions: [...c.instructions,
    { type: "gate", id: "teleport-correction-x", gate: "X", targets: [2], controls: [], condition: { bit: 1, equals: 1 } },
    { type: "gate", id: "teleport-correction-z", gate: "Z", targets: [2], controls: [], condition: { bit: 0, equals: 1 } },
  ] };
  return { ...c, classicalBits: 2 };
}
export function phaseEstimationCircuit(precisionQubits = 3, eigenphase = 0.25): QuantumCircuit {
  if (!Number.isInteger(precisionQubits) || precisionQubits < 1 || precisionQubits > 6) throw new Error("Phase estimation supports 1–6 precision qubits.");
  if (eigenphase < 0 || eigenphase >= 1) throw new Error("Eigenphase must be in [0, 1).");
  const target = precisionQubits; let c = createCircuit(precisionQubits + 1, `Quantum phase estimation · φ=${eigenphase}`);
  c = add(c, "X", [target]); c = addMany(c, "H", Array.from({ length: precisionQubits }, (_, q) => q));
  for (let q = 0; q < precisionQubits; q += 1) c = add(c, "CP", [target], [q], 2 * Math.PI * eigenphase * 2 ** q);
  // Inverse QFT on the control register.
  c = { ...c, instructions: [...c.instructions, ...qftCircuit(precisionQubits, true).instructions.map((instruction, i) => ({ ...instruction, id: `qpe-iqft-${i}` }))] };
  return { ...appendMeasurement(c, Array.from({ length: precisionQubits }, (_, q) => q)), classicalBits: precisionQubits };
}
export function qaoaMaxCutCircuit(qubits = 3, layers = 1, gamma: number[] = [0.7], beta: number[] = [0.3]): QuantumCircuit {
  if (!Number.isInteger(qubits) || qubits < 2 || qubits > 8) throw new Error("QAOA Max-Cut supports 2–8 qubits.");
  if (!Number.isInteger(layers) || layers < 1 || layers > 6 || gamma.length < layers || beta.length < layers) throw new Error("Provide gamma and beta parameters for each QAOA layer.");
  let c = createCircuit(qubits, `QAOA Max-Cut · p=${layers}`); c = addMany(c, "H", Array.from({ length: qubits }, (_, q) => q));
  for (let layer = 0; layer < layers; layer += 1) {
    for (let q = 0; q < qubits; q += 1) {
      const next = (q + 1) % qubits; c = add(c, "CX", [next], [q]); c = add(c, "RZ", [next], [], -2 * gamma[layer]); c = add(c, "CX", [next], [q]);
    }
    for (let q = 0; q < qubits; q += 1) c = add(c, "RX", [q], [], 2 * beta[layer]);
  }
  return c;
}
export function makeTeachingCircuit(kind: "bell" | "ghz" | "qft" | "grover" | "teleportation" | "deutsch-jozsa" | "bv" | "qpe" | "qaoa"): QuantumCircuit {
  switch (kind) {
    case "bell": return bellCircuit(); case "ghz": return ghzCircuit(3); case "qft": return qftCircuit(3); case "grover": return groverCircuit(3, 5);
    case "teleportation": return teleportationCircuit(); case "deutsch-jozsa": return deutschJozsaCircuit(3, 5); case "bv": return bernsteinVaziraniCircuit("1011");
    case "qpe": return phaseEstimationCircuit(3, 0.25); case "qaoa": return qaoaMaxCutCircuit(4, 1);
  }
}
