// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { createCircuit, type QuantumCircuit } from "./circuit";
import type { GateOperation } from "./gates";
import { createId } from "./circuit";

export interface CouplingMap { qubits: number; edges: Array<[number, number]>; }
export interface RoutedCircuit { circuit: QuantumCircuit; logicalToPhysical: number[]; insertedSwaps: number; notes: string[]; }
export function lineCouplingMap(qubits: number): CouplingMap {
  return { qubits, edges: Array.from({ length: Math.max(0, qubits - 1) }, (_, index) => [index, index + 1] as [number, number]) };
}
export function ringCouplingMap(qubits: number): CouplingMap {
  return { qubits, edges: [...lineCouplingMap(qubits).edges, ...(qubits > 2 ? [[0, qubits - 1] as [number, number]] : [])] };
}
export function validateCouplingMap(map: CouplingMap): void {
  if (!Number.isInteger(map.qubits) || map.qubits < 1 || map.qubits > 64) throw new Error("Coupling map must contain 1–64 physical qubits.");
  const pairs = new Set<string>();
  for (const [a, b] of map.edges) {
    if (a < 0 || b < 0 || a >= map.qubits || b >= map.qubits || a === b) throw new Error(`Invalid coupling edge ${a}–${b}.`);
    pairs.add([Math.min(a, b), Math.max(a, b)].join(":"));
  }
  if (pairs.size !== map.edges.length) throw new Error("Coupling map contains duplicate edges.");
}
export function adjacencyList(map: CouplingMap): number[][] {
  validateCouplingMap(map); const adjacency = Array.from({ length: map.qubits }, () => [] as number[]);
  map.edges.forEach(([a, b]) => { adjacency[a].push(b); adjacency[b].push(a); });
  return adjacency.map((neighbors) => neighbors.sort((a, b) => a - b));
}
export function shortestPath(map: CouplingMap, start: number, end: number): number[] {
  const adjacency = adjacencyList(map);
  if (start < 0 || end < 0 || start >= map.qubits || end >= map.qubits) throw new Error("Path endpoint is outside the coupling map.");
  const queue = [start]; const previous = Array.from({ length: map.qubits }, () => -1); previous[start] = start;
  while (queue.length) {
    const current = queue.shift()!;
    if (current === end) break;
    for (const neighbor of adjacency[current]) if (previous[neighbor] === -1) { previous[neighbor] = current; queue.push(neighbor); }
  }
  if (previous[end] === -1) throw new Error(`No route exists between physical qubits ${start} and ${end}.`);
  const path = [end]; let cursor = end;
  while (cursor !== start) { cursor = previous[cursor]; path.push(cursor); }
  return path.reverse();
}
function physicalSwap(a: number, b: number): GateOperation { return { id: createId("routing-swap"), gate: "SWAP", targets: [a, b], controls: [], label: "routing SWAP" }; }
export function routeCircuitToCouplingMap(circuit: QuantumCircuit, map: CouplingMap): RoutedCircuit {
  validateCouplingMap(map);
  if (map.qubits < circuit.qubits) throw new Error("Coupling map has fewer physical qubits than the circuit has logical qubits.");
  const adjacency = adjacencyList(map); const logicalToPhysical = Array.from({ length: circuit.qubits }, (_, index) => index);
  const physicalToLogical = Array.from({ length: map.qubits }, (_, index) => index < circuit.qubits ? index : -1);
  const output: QuantumCircuit["instructions"] = []; let insertedSwaps = 0; const notes: string[] = [];
  for (const instruction of circuit.instructions) {
    if (instruction.type === "measure") { output.push({ ...instruction, qubits: instruction.qubits.map((q) => logicalToPhysical[q]) }); continue; }
    if (instruction.type === "reset") { output.push({ ...instruction, qubits: instruction.qubits.map((q) => logicalToPhysical[q]) }); continue; }
    if (instruction.type === "barrier") { output.push({ ...instruction, qubits: instruction.qubits?.map((q) => logicalToPhysical[q]) }); continue; }
    const controls = instruction.controls ?? [];
    if (controls.length === 1 && instruction.targets.length === 1 && instruction.gate !== "SWAP") {
      const logicalControl = controls[0]; const logicalTarget = instruction.targets[0];
      let pc = logicalToPhysical[logicalControl]; const pt = logicalToPhysical[logicalTarget];
      if (!adjacency[pc].includes(pt)) {
        const path = shortestPath(map, pc, pt);
        // Move the control toward the target until the two physical sites are adjacent.
        for (let step = 0; step < path.length - 2; step += 1) {
          const a = path[step]; const b = path[step + 1]; output.push({ type: "gate", ...physicalSwap(a, b) }); insertedSwaps += 1;
          const logicalA = physicalToLogical[a]; const logicalB = physicalToLogical[b];
          physicalToLogical[a] = logicalB; physicalToLogical[b] = logicalA;
          if (logicalA >= 0) logicalToPhysical[logicalA] = b;
          if (logicalB >= 0) logicalToPhysical[logicalB] = a;
        }
        pc = logicalToPhysical[logicalControl];
        notes.push(`Routed logical control ${logicalControl} next to target ${logicalTarget} using ${path.length - 2} SWAP(s).`);
      }
      output.push({ ...instruction, controls: [pc], targets: [logicalToPhysical[logicalTarget]] });
    } else if (instruction.gate === "SWAP" && instruction.targets.length === 2) {
      const a = logicalToPhysical[instruction.targets[0]]; const b = logicalToPhysical[instruction.targets[1]];
      output.push({ ...instruction, targets: [a, b] });
      const la = physicalToLogical[a]; const lb = physicalToLogical[b]; physicalToLogical[a] = lb; physicalToLogical[b] = la;
      if (la >= 0) logicalToPhysical[la] = b; if (lb >= 0) logicalToPhysical[lb] = a;
    } else {
      output.push({ ...instruction, targets: instruction.targets.map((q) => logicalToPhysical[q]), controls: controls.map((q) => logicalToPhysical[q]) });
      if (instruction.targets.length + controls.length > 2) notes.push(`Multi-qubit gate ${instruction.gate} was mapped directly; verify that the target hardware supports its decomposition.`);
    }
  }
  return { circuit: { ...circuit, qubits: map.qubits, instructions: output }, logicalToPhysical, insertedSwaps, notes };
}
export function createHardwareLayout(name: "line" | "ring", qubits: number): CouplingMap {
  return name === "line" ? lineCouplingMap(qubits) : ringCouplingMap(qubits);
}
export function routingOverhead(original: QuantumCircuit, routed: RoutedCircuit): { swaps: number; originalGates: number; routedGates: number; overheadRatio: number } {
  const originalGates = original.instructions.filter((i) => i.type === "gate").length; const routedGates = routed.circuit.instructions.filter((i) => i.type === "gate").length;
  return { swaps: routed.insertedSwaps, originalGates, routedGates, overheadRatio: originalGates ? (routedGates - originalGates) / originalGates : 0 };
}
