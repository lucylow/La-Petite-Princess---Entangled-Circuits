// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { blochVector, type StateVector } from "./statevector";
import { partialTrace, densityFromState, oneQubitEigenvalues, type DensityMatrix } from "./density";

export interface BlochCoordinates { x: number; y: number; z: number; radius: number; theta: number; phi: number; }
export function vectorToBlochCoordinates(vector: { x: number; y: number; z: number }): BlochCoordinates {
  const radius = Math.sqrt(vector.x ** 2 + vector.y ** 2 + vector.z ** 2);
  return { ...vector, radius, theta: radius < 1e-12 ? 0 : Math.acos(Math.max(-1, Math.min(1, vector.z / radius))), phi: Math.atan2(vector.y, vector.x) };
}
export function stateQubitBlochCoordinates(state: StateVector, qubit: number): BlochCoordinates { return vectorToBlochCoordinates(blochVector(state, qubit)); }
export function densityQubitBlochCoordinates(rho: DensityMatrix, qubit: number): BlochCoordinates {
  const reduced = partialTrace(rho, [qubit]); const off = reduced.values[0][1];
  return vectorToBlochCoordinates({ x: 2 * off.re, y: -2 * off.im, z: reduced.values[0][0].re - reduced.values[1][1].re });
}
export function blochSpherePoint(theta: number, phi: number, radius = 1): { x: number; y: number; z: number } {
  return { x: radius * Math.sin(theta) * Math.cos(phi), y: radius * Math.sin(theta) * Math.sin(phi), z: radius * Math.cos(theta) };
}
export function sampleGreatCircle(normal: { x: number; y: number; z: number }, points = 64): Array<{ x: number; y: number; z: number }> {
  if (points < 4) throw new Error("A great circle needs at least four sample points.");
  const norm = Math.hypot(normal.x, normal.y, normal.z); if (norm < 1e-12) throw new Error("Great-circle normal must be nonzero.");
  const n = { x: normal.x / norm, y: normal.y / norm, z: normal.z / norm };
  const seed = Math.abs(n.x) < 0.8 ? { x: 1, y: 0, z: 0 } : { x: 0, y: 1, z: 0 };
  const dot = n.x * seed.x + n.y * seed.y + n.z * seed.z;
  const u0 = { x: seed.x - dot * n.x, y: seed.y - dot * n.y, z: seed.z - dot * n.z };
  const uNorm = Math.hypot(u0.x, u0.y, u0.z); const u = { x: u0.x / uNorm, y: u0.y / uNorm, z: u0.z / uNorm };
  const v = { x: n.y * u.z - n.z * u.y, y: n.z * u.x - n.x * u.z, z: n.x * u.y - n.y * u.x };
  return Array.from({ length: points }, (_, index) => { const angle = 2 * Math.PI * index / points; return { x: Math.cos(angle) * u.x + Math.sin(angle) * v.x, y: Math.cos(angle) * u.y + Math.sin(angle) * v.y, z: Math.cos(angle) * u.z + Math.sin(angle) * v.z }; });
}
export function statePurityLabel(state: StateVector, qubit: number): string {
  const reduced = partialTrace(densityFromState(state), [qubit]); const eigenvalues = oneQubitEigenvalues(reduced);
  const purity = eigenvalues[0] ** 2 + eigenvalues[1] ** 2;
  return purity > 0.999 ? "Pure reduced state" : purity > 0.75 ? "Partially mixed reduced state" : "Strongly mixed reduced state";
}
export function projectToSphere(vector: { x: number; y: number; z: number }): { x: number; y: number; z: number } {
  const length = Math.hypot(vector.x, vector.y, vector.z); if (length <= 1) return vector;
  return { x: vector.x / length, y: vector.y / length, z: vector.z / length };
}
