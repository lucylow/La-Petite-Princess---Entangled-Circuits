// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { gateDefinition, type GateId, type GateOperation, type GateParameters } from "./gates";

export interface MeasurementOperation { id: string; qubits: number[]; classicalBits: number[]; label?: string; }
export interface ResetOperation { id: string; qubits: number[]; }
export interface BarrierOperation { id: string; qubits?: number[]; }
export type CircuitInstruction =
  | ({ type: "gate" } & GateOperation)
  | ({ type: "measure" } & MeasurementOperation)
  | ({ type: "reset" } & ResetOperation)
  | ({ type: "barrier" } & BarrierOperation);
export interface QuantumCircuit {
  id: string;
  name: string;
  qubits: number;
  classicalBits: number;
  instructions: CircuitInstruction[];
  metadata: { description?: string; tags?: string[]; createdAt?: string; author?: string };
}
export interface CircuitValidationIssue { severity: "error" | "warning" | "info"; code: string; message: string; instructionId?: string; }

let nextId = 1;
export function createId(prefix = "op"): string { nextId += 1; return `${prefix}-${Date.now().toString(36)}-${nextId.toString(36)}`; }
export function createCircuit(qubits = 2, name = "Untitled quantum circuit"): QuantumCircuit {
  if (!Number.isInteger(qubits) || qubits < 1 || qubits > 16) throw new Error("Circuit size must be an integer from 1 to 16 qubits.");
  return { id: createId("circuit"), name, qubits, classicalBits: qubits, instructions: [], metadata: { createdAt: new Date().toISOString(), tags: [] } };
}
export function cloneCircuit(circuit: QuantumCircuit): QuantumCircuit {
  return { ...circuit, metadata: { ...circuit.metadata, tags: circuit.metadata.tags ? [...circuit.metadata.tags] : [] }, instructions: circuit.instructions.map((instruction) => JSON.parse(JSON.stringify(instruction)) as CircuitInstruction) };
}
export function appendGate(circuit: QuantumCircuit, gate: GateId, targets: number[], controls: number[] = [], params: GateParameters = {}): QuantumCircuit {
  const operation: CircuitInstruction = { type: "gate", id: createId(), gate, targets: [...targets], controls: [...controls], params: { ...params } };
  return { ...circuit, instructions: [...circuit.instructions, operation] };
}
export function appendMeasurement(circuit: QuantumCircuit, qubits: number[], classicalBits = qubits): QuantumCircuit {
  if (qubits.length !== classicalBits.length) throw new Error("Each measured qubit must map to one classical bit.");
  return { ...circuit, classicalBits: Math.max(circuit.classicalBits, ...classicalBits.map((bit) => bit + 1)), instructions: [...circuit.instructions, { type: "measure", id: createId("measure"), qubits: [...qubits], classicalBits: [...classicalBits] }] };
}
export function appendReset(circuit: QuantumCircuit, qubits: number[]): QuantumCircuit {
  return { ...circuit, instructions: [...circuit.instructions, { type: "reset", id: createId("reset"), qubits: [...qubits] }] };
}
export function appendBarrier(circuit: QuantumCircuit, qubits?: number[]): QuantumCircuit {
  return { ...circuit, instructions: [...circuit.instructions, { type: "barrier", id: createId("barrier"), qubits: qubits ? [...qubits] : undefined }] };
}
export function insertInstruction(circuit: QuantumCircuit, index: number, instruction: CircuitInstruction): QuantumCircuit {
  if (index < 0 || index > circuit.instructions.length) throw new Error("Instruction insertion index is outside the circuit.");
  const instructions = circuit.instructions.slice(); instructions.splice(index, 0, instruction);
  return { ...circuit, instructions };
}
export function replaceInstruction(circuit: QuantumCircuit, id: string, replacement: CircuitInstruction): QuantumCircuit {
  if (!circuit.instructions.some((item) => item.id === id)) throw new Error(`Instruction ${id} was not found.`);
  return { ...circuit, instructions: circuit.instructions.map((item) => item.id === id ? replacement : item) };
}
export function removeInstruction(circuit: QuantumCircuit, id: string): QuantumCircuit {
  return { ...circuit, instructions: circuit.instructions.filter((item) => item.id !== id) };
}
export function moveInstruction(circuit: QuantumCircuit, id: string, destination: number): QuantumCircuit {
  const index = circuit.instructions.findIndex((item) => item.id === id);
  if (index < 0) throw new Error(`Instruction ${id} was not found.`);
  if (!Number.isInteger(destination) || destination < 0 || destination >= circuit.instructions.length) throw new Error("Destination index is invalid.");
  const instructions = circuit.instructions.slice(); const [item] = instructions.splice(index, 1); instructions.splice(destination, 0, item);
  return { ...circuit, instructions };
}
function checkQubit(q: number, circuit: QuantumCircuit, issues: CircuitValidationIssue[], id: string, role: string): void {
  if (!Number.isInteger(q) || q < 0 || q >= circuit.qubits) issues.push({ severity: "error", code: "QUBIT_OUT_OF_RANGE", message: `${role} qubit ${q} is outside the register (0–${circuit.qubits - 1}).`, instructionId: id });
}
export function validateCircuit(circuit: QuantumCircuit): CircuitValidationIssue[] {
  const issues: CircuitValidationIssue[] = [];
  if (!Number.isInteger(circuit.qubits) || circuit.qubits < 1 || circuit.qubits > 16) issues.push({ severity: "error", code: "INVALID_QUBIT_COUNT", message: "Circuit qubit count must be between 1 and 16." });
  if (!Number.isInteger(circuit.classicalBits) || circuit.classicalBits < 0 || circuit.classicalBits > 64) issues.push({ severity: "error", code: "INVALID_CLASSICAL_COUNT", message: "Classical bit count must be between 0 and 64." });
  const ids = new Set<string>();
  for (const instruction of circuit.instructions) {
    if (ids.has(instruction.id)) issues.push({ severity: "error", code: "DUPLICATE_INSTRUCTION_ID", message: `Instruction id ${instruction.id} is duplicated.`, instructionId: instruction.id });
    ids.add(instruction.id);
    if (instruction.type === "gate") {
      let definition;
      try { definition = gateDefinition(instruction.gate); } catch { issues.push({ severity: "error", code: "UNKNOWN_GATE", message: `Gate ${instruction.gate} is not recognized.`, instructionId: instruction.id }); continue; }
      instruction.targets.forEach((q) => checkQubit(q, circuit, issues, instruction.id, "Target"));
      (instruction.controls ?? []).forEach((q) => checkQubit(q, circuit, issues, instruction.id, "Control"));
      const all = [...instruction.targets, ...(instruction.controls ?? [])];
      if (new Set(all).size !== all.length) issues.push({ severity: "error", code: "DUPLICATE_QUBIT", message: "A qubit cannot appear more than once in one gate operation.", instructionId: instruction.id });
      if (instruction.targets.length !== definition.targetCount) issues.push({ severity: "error", code: "TARGET_ARITY", message: `${instruction.gate} expects ${definition.targetCount} target(s).`, instructionId: instruction.id });
      if ((instruction.controls ?? []).length < definition.controlCount) issues.push({ severity: "error", code: "CONTROL_ARITY", message: `${instruction.gate} expects at least ${definition.controlCount} control(s).`, instructionId: instruction.id });
      if (definition.parameterCount > 0 && !Number.isFinite(instruction.params?.theta)) issues.push({ severity: "error", code: "MISSING_PARAMETER", message: `${instruction.gate} needs a finite theta parameter.`, instructionId: instruction.id });
      if (instruction.condition) {
        if (instruction.condition.bit < 0 || instruction.condition.bit >= circuit.classicalBits) issues.push({ severity: "error", code: "CONDITION_BIT_RANGE", message: "Classical condition references a bit outside the classical register.", instructionId: instruction.id });
        if (instruction.condition.equals !== 0 && instruction.condition.equals !== 1) issues.push({ severity: "error", code: "CONDITION_VALUE", message: "Classical condition must compare to 0 or 1.", instructionId: instruction.id });
      }
    } else if (instruction.type === "measure") {
      if (instruction.qubits.length !== instruction.classicalBits.length || !instruction.qubits.length) issues.push({ severity: "error", code: "MEASURE_ARITY", message: "Measurement needs matching, non-empty qubit and classical-bit lists.", instructionId: instruction.id });
      instruction.qubits.forEach((q) => checkQubit(q, circuit, issues, instruction.id, "Measured"));
      instruction.classicalBits.forEach((bit) => { if (!Number.isInteger(bit) || bit < 0 || bit >= circuit.classicalBits) issues.push({ severity: "error", code: "CLASSICAL_BIT_RANGE", message: `Classical bit ${bit} is outside the register.`, instructionId: instruction.id }); });
      if (new Set(instruction.qubits).size !== instruction.qubits.length) issues.push({ severity: "error", code: "DUPLICATE_MEASURE_QUBIT", message: "A measurement instruction cannot measure the same qubit twice.", instructionId: instruction.id });
    } else if (instruction.type === "reset") {
      if (!instruction.qubits.length) issues.push({ severity: "error", code: "EMPTY_RESET", message: "Reset must reference at least one qubit.", instructionId: instruction.id });
      instruction.qubits.forEach((q) => checkQubit(q, circuit, issues, instruction.id, "Reset"));
    } else if (instruction.type === "barrier") {
      (instruction.qubits ?? []).forEach((q) => checkQubit(q, circuit, issues, instruction.id, "Barrier"));
    }
  }
  const measured = new Set<number>();
  circuit.instructions.forEach((instruction) => { if (instruction.type === "measure") instruction.qubits.forEach((q) => measured.add(q)); });
  if (!measured.size) issues.push({ severity: "info", code: "NO_MEASUREMENT", message: "No measurement is present. A shot run will measure the final state in the computational basis." });
  if (circuit.qubits > 12) issues.push({ severity: "warning", code: "LARGE_STATE", message: "State-vector simulation above 12 qubits can require significant memory and compute time." });
  return issues;
}
export function circuitDepth(circuit: QuantumCircuit): number {
  const lastLayer = Array.from({ length: circuit.qubits }, () => -1); let maxLayer = -1;
  for (const instruction of circuit.instructions) {
    if (instruction.type === "barrier") { const layer = Math.max(maxLayer, ...lastLayer) + 1; instruction.qubits?.forEach((q) => { if (q >= 0 && q < circuit.qubits) lastLayer[q] = layer; }); maxLayer = Math.max(maxLayer, layer); continue; }
    const touched = instruction.type === "gate" ? [...instruction.targets, ...(instruction.controls ?? [])] : instruction.qubits;
    const layer = Math.max(-1, ...touched.map((q) => lastLayer[q] ?? -1)) + 1;
    touched.forEach((q) => { if (q >= 0 && q < circuit.qubits) lastLayer[q] = layer; }); maxLayer = Math.max(maxLayer, layer);
  }
  return maxLayer + 1;
}
export function gateCount(circuit: QuantumCircuit): number { return circuit.instructions.filter((item) => item.type === "gate").length; }
export function twoQubitGateCount(circuit: QuantumCircuit): number { return circuit.instructions.filter((item) => item.type === "gate" && (item.targets.length + (item.controls?.length ?? 0)) >= 2).length; }
export function parameterizedGateCount(circuit: QuantumCircuit): number { return circuit.instructions.filter((item) => item.type === "gate" && gateDefinition(item.gate).parameterCount > 0).length; }
export function renameCircuit(circuit: QuantumCircuit, name: string): QuantumCircuit { return { ...circuit, name: name.trim() || "Untitled quantum circuit" }; }
export function updateGateParameter(circuit: QuantumCircuit, id: string, key: keyof GateParameters, value: number): QuantumCircuit {
  if (!Number.isFinite(value)) throw new Error("Gate parameter must be finite.");
  return { ...circuit, instructions: circuit.instructions.map((item) => item.id === id && item.type === "gate" ? { ...item, params: { ...item.params, [key]: value } } : item) };
}
