// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { C, cAbs2 } from "./complex";
import { applyGate, basisState, type StateVector } from "./statevector";
import type { QuantumCircuit } from "./circuit";
import type { Matrix } from "./matrix";
import { dagger, identity, matrixMultiply } from "./matrix";

export interface UnitaryCheck {
  isUnitary: boolean;
  maxDeviation: number;
  dimension: number;
  columnsChecked: number;
}

export function circuitToUnitary(circuit: QuantumCircuit, maxQubits = 8): Matrix {
  if (circuit.qubits > maxQubits) throw new Error(`Dense unitary construction is limited to ${maxQubits} qubits.`);
  if (circuit.instructions.some((instruction) => instruction.type !== "gate")) throw new Error("A circuit unitary can only be built from gate-only circuits.");
  if (circuit.instructions.some((instruction) => instruction.type === "gate" && instruction.condition)) throw new Error("Classically conditioned circuits do not define one unitary matrix.");
  const dimension = 2 ** circuit.qubits;
  const matrix: Matrix = Array.from({ length: dimension }, () => Array.from({ length: dimension }, () => C(0)));
  for (let column = 0; column < dimension; column += 1) {
    const basis = basisState(circuit.qubits, column);
    const final = circuit.instructions.reduce((state, instruction) => instruction.type === "gate" ? applyGate(state, instruction) : state, basis);
    final.amplitudes.forEach((amplitude, row) => { matrix[row][column] = amplitude; });
  }
  return matrix;
}

export function verifyUnitary(matrix: Matrix, tolerance = 1e-8): UnitaryCheck {
  if (!matrix.length || matrix.some((row) => row.length !== matrix.length)) throw new Error("Unitary verification needs a non-empty square matrix.");
  const product = matrixMultiply(dagger(matrix), matrix);
  const target = identity(matrix.length);
  let maxDeviation = 0;
  product.forEach((row, r) => row.forEach((value, c) => {
    maxDeviation = Math.max(maxDeviation, Math.hypot(value.re - target[r][c].re, value.im - target[r][c].im));
  }));
  return { isUnitary: maxDeviation <= tolerance, maxDeviation, dimension: matrix.length, columnsChecked: matrix.length };
}

export function stateFidelity(a: StateVector, b: StateVector): number {
  if (a.qubits !== b.qubits) throw new Error("State registers must have equal size.");
  let real = 0;
  let imaginary = 0;
  for (let index = 0; index < a.amplitudes.length; index += 1) {
    const left = a.amplitudes[index];
    const right = b.amplitudes[index];
    real += left.re * right.re + left.im * right.im;
    imaginary += left.re * right.im - left.im * right.re;
  }
  return Math.max(0, Math.min(1, real * real + imaginary * imaginary));
}

export function equivalentUpToGlobalPhase(a: QuantumCircuit, b: QuantumCircuit, tolerance = 1e-8): boolean {
  if (a.qubits !== b.qubits) return false;
  const ua = circuitToUnitary(a);
  const ub = circuitToUnitary(b);
  let phaseReal = 0;
  let phaseImag = 0;
  let found = false;
  for (let row = 0; row < ua.length && !found; row += 1) {
    for (let column = 0; column < ua.length; column += 1) {
      const left = ua[row][column];
      const right = ub[row][column];
      const denominator = right.re * right.re + right.im * right.im;
      if (denominator > tolerance * tolerance) {
        phaseReal = (left.re * right.re + left.im * right.im) / denominator;
        phaseImag = (left.im * right.re - left.re * right.im) / denominator;
        found = true;
        break;
      }
    }
  }
  if (!found) return false;
  const magnitude = Math.hypot(phaseReal, phaseImag);
  if (Math.abs(magnitude - 1) > tolerance) return false;
  const normalizedPhase = { re: phaseReal / magnitude, im: phaseImag / magnitude };
  for (let row = 0; row < ua.length; row += 1) for (let column = 0; column < ua.length; column += 1) {
    const right = ub[row][column];
    const transformed = { re: right.re * normalizedPhase.re - right.im * normalizedPhase.im, im: right.re * normalizedPhase.im + right.im * normalizedPhase.re };
    if (Math.hypot(ua[row][column].re - transformed.re, ua[row][column].im - transformed.im) > tolerance) return false;
  }
  return true;
}

export function unitaryStateNormSquared(state: StateVector): number {
  return state.amplitudes.reduce((sum, amplitude) => sum + cAbs2(amplitude), 0);
}
