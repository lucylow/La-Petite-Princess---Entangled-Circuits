// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
export interface CalibrationRun { timestamp: string; qubit: number; t1Microseconds?: number; t2Microseconds?: number; readout0?: number; readout1?: number; gateError?: number; notes?: string; }
export interface CalibrationSummary {
  qubit: number;
  samples: number;
  meanT1?: number;
  meanT2?: number;
  meanReadoutFidelity?: number;
  meanGateError?: number;
  t2PhysicalityWarnings: string[];
}
function mean(values: number[]): number | undefined { return values.length ? values.reduce((sum, value) => sum + value, 0) / values.length : undefined; }
function validMetric(value: number | undefined, name: string): void { if (value !== undefined && (!Number.isFinite(value) || value < 0)) throw new Error(`${name} must be a finite non-negative number.`); }
export function summarizeCalibration(runs: CalibrationRun[]): CalibrationSummary[] {
  const byQubit = new Map<number, CalibrationRun[]>();
  for (const run of runs) {
    if (!Number.isInteger(run.qubit) || run.qubit < 0) throw new Error("Calibration qubit index must be a non-negative integer.");
    validMetric(run.t1Microseconds, "T1"); validMetric(run.t2Microseconds, "T2"); validMetric(run.gateError, "Gate error");
    if (run.readout0 !== undefined && (run.readout0 < 0 || run.readout0 > 1)) throw new Error("Readout probability must be between 0 and 1.");
    if (run.readout1 !== undefined && (run.readout1 < 0 || run.readout1 > 1)) throw new Error("Readout probability must be between 0 and 1.");
    (byQubit.get(run.qubit) ?? (byQubit.set(run.qubit, []), byQubit.get(run.qubit)!)).push(run);
  }
  return [...byQubit.entries()].sort((a, b) => a[0] - b[0]).map(([qubit, values]) => {
    const t1 = values.map((r) => r.t1Microseconds).filter((v): v is number => v !== undefined);
    const t2 = values.map((r) => r.t2Microseconds).filter((v): v is number => v !== undefined);
    const readout = values.filter((r) => r.readout0 !== undefined && r.readout1 !== undefined).map((r) => ((r.readout0! + r.readout1!) / 2));
    const errors = values.map((r) => r.gateError).filter((v): v is number => v !== undefined); const warnings: string[] = [];
    values.forEach((r) => { if (r.t1Microseconds !== undefined && r.t2Microseconds !== undefined && r.t2Microseconds > 2 * r.t1Microseconds + 1e-8) warnings.push(`T2 (${r.t2Microseconds} μs) exceeds 2·T1 (${2 * r.t1Microseconds} μs); check the reported convention or data.`); });
    return { qubit, samples: values.length, meanT1: mean(t1), meanT2: mean(t2), meanReadoutFidelity: mean(readout), meanGateError: mean(errors), t2PhysicalityWarnings: [...new Set(warnings)] };
  });
}
export function exponentialDecay(times: number[], t: number, amplitude = 1, offset = 0): number[] {
  if (!Number.isFinite(t) || t <= 0 || !Number.isFinite(amplitude) || !Number.isFinite(offset)) throw new Error("Decay fit parameters must be finite, with positive T.");
  return times.map((time) => offset + amplitude * Math.exp(-time / t));
}
export function estimateDecayConstant(times: number[], observations: number[], offset = 0): number {
  if (times.length !== observations.length || times.length < 2) throw new Error("Decay fitting needs matching arrays with at least two samples.");
  const xs: number[] = []; const ys: number[] = [];
  times.forEach((time, index) => { const value = observations[index] - offset; if (time >= 0 && value > 0 && Number.isFinite(value)) { xs.push(time); ys.push(Math.log(value)); } });
  if (xs.length < 2) throw new Error("Not enough positive observations remain for exponential fitting.");
  const xMean = mean(xs)!; const yMean = mean(ys)!;
  const slope = xs.reduce((sum, x, index) => sum + (x - xMean) * (ys[index] - yMean), 0) / xs.reduce((sum, x) => sum + (x - xMean) ** 2, 0);
  if (slope >= 0) throw new Error("Observed data does not show a decaying exponential.");
  return -1 / slope;
}
export function compareCalibration(current: CalibrationSummary, previous: CalibrationSummary): Array<{ metric: string; current?: number; previous?: number; change?: number; direction: "improved" | "worsened" | "unchanged" | "unavailable" }> {
  const pairs = [{ metric: "T1", current: current.meanT1, previous: previous.meanT1, higherIsBetter: true }, { metric: "T2", current: current.meanT2, previous: previous.meanT2, higherIsBetter: true }, { metric: "Readout fidelity", current: current.meanReadoutFidelity, previous: previous.meanReadoutFidelity, higherIsBetter: true }, { metric: "Gate error", current: current.meanGateError, previous: previous.meanGateError, higherIsBetter: false }];
  return pairs.map((item) => {
    if (item.current === undefined || item.previous === undefined) return { metric: item.metric, current: item.current, previous: item.previous, direction: "unavailable" as const };
    const change = item.current - item.previous; const direction = Math.abs(change) < 1e-9 ? "unchanged" : ((change > 0) === item.higherIsBetter ? "improved" : "worsened");
    return { metric: item.metric, current: item.current, previous: item.previous, change, direction };
  });
}
