// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { C, cAdd, cMul, type Complex } from "./complex";
import { appendGate, createCircuit, type QuantumCircuit } from "./circuit";
import type { StateVector } from "./statevector";

export interface PauliTerm { coefficient: number; paulis: Record<number, "X" | "Y" | "Z">; label?: string; }
export interface Hamiltonian { qubits: number; terms: PauliTerm[]; name: string; }
export function validateHamiltonian(hamiltonian: Hamiltonian): void {
  if (!Number.isInteger(hamiltonian.qubits) || hamiltonian.qubits < 1 || hamiltonian.qubits > 16) throw new Error("Hamiltonian qubit count must be between 1 and 16.");
  hamiltonian.terms.forEach((term, index) => {
    if (!Number.isFinite(term.coefficient)) throw new Error(`Term ${index} has a non-finite coefficient.`);
    for (const [qText, pauli] of Object.entries(term.paulis)) {
      const q = Number(qText); if (!Number.isInteger(q) || q < 0 || q >= hamiltonian.qubits) throw new Error(`Term ${index} references invalid qubit ${qText}.`);
      if (!["X", "Y", "Z"].includes(pauli)) throw new Error(`Term ${index} contains an invalid Pauli operator.`);
    }
  });
}
function pauliAction(index: number, term: PauliTerm): { destination: number; phase: Complex } {
  let destination = index; let phase = C(1);
  for (const [qText, pauli] of Object.entries(term.paulis)) {
    const q = Number(qText); const isOne = ((index >> q) & 1) === 1;
    if (pauli === "X") destination ^= 1 << q;
    if (pauli === "Y") { destination ^= 1 << q; phase = cMul(phase, isOne ? C(0, -1) : C(0, 1)); }
    if (pauli === "Z" && isOne) phase = cMul(phase, C(-1));
  }
  return { destination, phase };
}
export function expectationPauliTerm(state: StateVector, term: PauliTerm): number {
  let total = C(0);
  for (let index = 0; index < state.amplitudes.length; index += 1) {
    const { destination, phase } = pauliAction(index, term); const a = state.amplitudes[destination]; const b = state.amplitudes[index];
    total = cAdd(total, cMul(cMul({ re: a.re, im: -a.im }, phase), b));
  }
  return total.re;
}
export function expectationHamiltonian(state: StateVector, hamiltonian: Hamiltonian): number {
  validateHamiltonian(hamiltonian); if (state.qubits !== hamiltonian.qubits) throw new Error("Hamiltonian and state register sizes differ.");
  return hamiltonian.terms.reduce((energy, term) => energy + term.coefficient * expectationPauliTerm(state, term), 0);
}
export function hamiltonianFromIsing(weights: number[][], fields: number[] = []): Hamiltonian {
  const qubits = weights.length;
  if (!qubits || weights.some((row) => row.length !== qubits)) throw new Error("Ising interaction matrix must be non-empty and square.");
  const terms: PauliTerm[] = [];
  for (let i = 0; i < qubits; i += 1) {
    if (fields[i]) terms.push({ coefficient: fields[i], paulis: { [i]: "Z" }, label: `h${i} Z${i}` });
    for (let j = i + 1; j < qubits; j += 1) if (weights[i][j]) terms.push({ coefficient: weights[i][j], paulis: { [i]: "Z", [j]: "Z" }, label: `J${i}${j} Z${i}Z${j}` });
  }
  const result = { qubits, terms, name: "Ising Hamiltonian" }; validateHamiltonian(result); return result;
}
export function trotterizedEvolution(hamiltonian: Hamiltonian, time: number, steps = 1): QuantumCircuit {
  validateHamiltonian(hamiltonian);
  if (!Number.isFinite(time) || !Number.isInteger(steps) || steps < 1 || steps > 100) throw new Error("Evolution time must be finite and Trotter steps must be 1–100.");
  const dt = time / steps; let circuit = createCircuit(hamiltonian.qubits, `Trotter evolution · ${hamiltonian.name}`);
  for (let step = 0; step < steps; step += 1) for (const term of hamiltonian.terms) {
    const qubits = Object.keys(term.paulis).map(Number).sort((a, b) => a - b);
    if (!qubits.length) continue;
    for (const q of qubits) {
      const pauli = term.paulis[q]; if (pauli === "X") circuit = appendGate(circuit, "H", [q]);
      if (pauli === "Y") { circuit = appendGate(circuit, "SDG", [q]); circuit = appendGate(circuit, "H", [q]); }
    }
    const pivot = qubits[qubits.length - 1];
    for (let i = 0; i < qubits.length - 1; i += 1) circuit = appendGate(circuit, "CX", [pivot], [qubits[i]]);
    circuit = appendGate(circuit, "RZ", [pivot], [], { theta: 2 * term.coefficient * dt });
    for (let i = qubits.length - 2; i >= 0; i -= 1) circuit = appendGate(circuit, "CX", [pivot], [qubits[i]]);
    for (const q of qubits) {
      const pauli = term.paulis[q]; if (pauli === "X") circuit = appendGate(circuit, "H", [q]);
      if (pauli === "Y") { circuit = appendGate(circuit, "H", [q]); circuit = appendGate(circuit, "S", [q]); }
    }
  }
  return circuit;
}
export function transverseFieldIsing(qubits: number, coupling = 1, field = 1): Hamiltonian {
  if (!Number.isInteger(qubits) || qubits < 2 || qubits > 16) throw new Error("Transverse-field Ising model supports 2–16 qubits.");
  const terms: PauliTerm[] = [];
  for (let q = 0; q < qubits - 1; q += 1) terms.push({ coefficient: -coupling, paulis: { [q]: "Z", [q + 1]: "Z" } });
  for (let q = 0; q < qubits; q += 1) terms.push({ coefficient: -field, paulis: { [q]: "X" } });
  return { qubits, terms, name: "Transverse-field Ising model" };
}
