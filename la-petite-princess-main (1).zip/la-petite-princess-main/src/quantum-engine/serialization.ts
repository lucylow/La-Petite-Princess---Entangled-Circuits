// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { validateCircuit, type QuantumCircuit } from "./circuit";

export interface CircuitPackage { format: "la-petite-princesse-circuit"; version: 1; checksum: string; circuit: QuantumCircuit; }
function canonical(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(canonical).join(",")}]`;
  if (value && typeof value === "object") return `{${Object.entries(value as Record<string, unknown>).sort(([a], [b]) => a.localeCompare(b)).map(([key, item]) => `${JSON.stringify(key)}:${canonical(item)}`).join(",")}}`;
  return JSON.stringify(value);
}
export function fnv1a(text: string): string {
  let hash = 0x811c9dc5;
  for (let index = 0; index < text.length; index += 1) { hash ^= text.charCodeAt(index); hash = Math.imul(hash, 0x01000193); }
  return (hash >>> 0).toString(16).padStart(8, "0");
}
export function packageCircuit(circuit: QuantumCircuit): CircuitPackage {
  const errors = validateCircuit(circuit).filter((issue) => issue.severity === "error"); if (errors.length) throw new Error(`Cannot package invalid circuit: ${errors.map((i) => i.message).join(" ")}`);
  const copy = JSON.parse(JSON.stringify(circuit)) as QuantumCircuit;
  return { format: "la-petite-princesse-circuit", version: 1, checksum: fnv1a(canonical(copy)), circuit: copy };
}
export function serializeCircuit(circuit: QuantumCircuit, pretty = true): string { return JSON.stringify(packageCircuit(circuit), null, pretty ? 2 : 0); }
export function parseCircuitPackage(text: string): CircuitPackage {
  let parsed: unknown;
  try { parsed = JSON.parse(text); } catch { throw new Error("Circuit file is not valid JSON."); }
  if (!parsed || typeof parsed !== "object") throw new Error("Circuit file must contain an object.");
  const item = parsed as Partial<CircuitPackage>;
  if (item.format !== "la-petite-princesse-circuit" || item.version !== 1 || !item.circuit || typeof item.checksum !== "string") throw new Error("Unrecognized circuit package format or version.");
  const expected = fnv1a(canonical(item.circuit)); if (expected !== item.checksum) throw new Error("Circuit checksum mismatch. The file may have been edited or damaged.");
  const errors = validateCircuit(item.circuit).filter((issue) => issue.severity === "error"); if (errors.length) throw new Error(`Circuit validation failed: ${errors.map((i) => i.message).join(" ")}`);
  return item as CircuitPackage;
}
export function cloneCircuitPackage(circuit: QuantumCircuit): QuantumCircuit { return parseCircuitPackage(serializeCircuit(circuit)).circuit; }
export function circuitSummary(circuit: QuantumCircuit): Record<string, unknown> {
  const gates: Record<string, number> = {}; let measurements = 0; let resets = 0; let barriers = 0;
  for (const instruction of circuit.instructions) {
    if (instruction.type === "gate") gates[instruction.gate] = (gates[instruction.gate] ?? 0) + 1;
    else if (instruction.type === "measure") measurements += instruction.qubits.length;
    else if (instruction.type === "reset") resets += instruction.qubits.length;
    else barriers += 1;
  }
  return { id: circuit.id, name: circuit.name, qubits: circuit.qubits, classicalBits: circuit.classicalBits, instructions: circuit.instructions.length, gates, measurements, resets, barriers };
}
