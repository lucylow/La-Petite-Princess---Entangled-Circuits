// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { createId, type QuantumCircuit, type CircuitInstruction } from "./circuit";
import type { GateOperation } from "./gates";
import { validateCircuit } from "./circuit";

export interface CompilationReport { circuit: QuantumCircuit; originalGateCount: number; compiledGateCount: number; decompositionCount: number; warnings: string[]; }
const gate = (kind: GateOperation["gate"], targets: number[], controls: number[] = [], params: GateOperation["params"] = {}): CircuitInstruction => ({ type: "gate", id: createId("compiled"), gate: kind, targets, controls, params });
export function decomposeSwap(a: number, b: number): CircuitInstruction[] {
  return [gate("CX", [b], [a]), gate("CX", [a], [b]), gate("CX", [b], [a])];
}
export function decomposeControlledZ(control: number, target: number): CircuitInstruction[] {
  return [gate("H", [target]), gate("CX", [target], [control]), gate("H", [target])];
}
export function decomposeToffoli(controlA: number, controlB: number, target: number): CircuitInstruction[] {
  // Standard exact decomposition over H, S, T, T† and CX.
  return [
    gate("H", [target]), gate("CX", [target], [controlB]), gate("TDG", [target]), gate("CX", [target], [controlA]),
    gate("T", [target]), gate("CX", [target], [controlB]), gate("TDG", [target]), gate("CX", [target], [controlA]),
    gate("T", [controlB]), gate("T", [target]), gate("H", [target]), gate("CX", [controlB], [controlA]), gate("T", [controlA]),
    gate("TDG", [controlB]), gate("CX", [controlB], [controlA]),
  ];
}
export function decomposeFredkin(control: number, targetA: number, targetB: number): CircuitInstruction[] {
  return [gate("CX", [targetA], [targetB]), gate("CCX", [targetB], [control, targetA]), gate("CX", [targetA], [targetB])];
}
export function compileToCliffordT(circuit: QuantumCircuit): CompilationReport {
  const errors = validateCircuit(circuit).filter((issue) => issue.severity === "error"); if (errors.length) throw new Error(errors.map((issue) => issue.message).join(" "));
  const output: CircuitInstruction[] = []; let decompositionCount = 0; const warnings: string[] = [];
  for (const instruction of circuit.instructions) {
    if (instruction.type !== "gate") { output.push(instruction); continue; }
    if (instruction.gate === "SWAP") { output.push(...decomposeSwap(instruction.targets[0], instruction.targets[1])); decompositionCount += 1; }
    else if (instruction.gate === "CZ") { output.push(...decomposeControlledZ(instruction.controls?.[0] ?? instruction.targets[0], instruction.targets[instruction.targets.length - 1])); decompositionCount += 1; }
    else if (instruction.gate === "CSWAP") {
      const fredkin = decomposeFredkin(instruction.controls?.[0] ?? 0, instruction.targets[0], instruction.targets[1]);
      for (const operation of fredkin) {
        if (operation.type === "gate" && operation.gate === "CCX") {
          output.push(...decomposeToffoli(operation.controls?.[0] ?? 0, operation.controls?.[1] ?? 1, operation.targets[0]));
        } else output.push(operation);
      }
      decompositionCount += 1;
    }
    else if (instruction.gate === "CCX") { output.push(...decomposeToffoli(instruction.controls?.[0] ?? 0, instruction.controls?.[1] ?? 1, instruction.targets[0])); decompositionCount += 1; }
    else if (["RX", "RY", "RZ", "P", "U3"].includes(instruction.gate)) warnings.push(`${instruction.gate} remains parameterized; a hardware backend may need angle synthesis.`);
    else output.push(instruction);
  }
  const compiled = { ...circuit, instructions: output, name: `${circuit.name} · Clifford+T transpilation` };
  return { circuit: compiled, originalGateCount: circuit.instructions.filter((i) => i.type === "gate").length, compiledGateCount: output.filter((i) => i.type === "gate").length, decompositionCount, warnings };
}
export function invertCircuit(circuit: QuantumCircuit): QuantumCircuit {
  const inverse: CircuitInstruction[] = [];
  for (const instruction of [...circuit.instructions].reverse()) {
    if (instruction.type !== "gate") throw new Error("Only unitary gate-only circuits can be inverted by this helper.");
    const g = instruction.gate; let replacement: GateOperation["gate"] = g; const params = { ...instruction.params };
    if (["S", "T", "SX"].includes(g)) replacement = ({ S: "SDG", T: "TDG", SX: "SXDG" } as const)[g as "S" | "T" | "SX"];
    else if (["SDG", "TDG", "SXDG"].includes(g)) replacement = ({ SDG: "S", TDG: "T", SXDG: "SX" } as const)[g as "SDG" | "TDG" | "SXDG"];
    else if (["RX", "RY", "RZ", "P", "CP", "CRX", "CRY", "CRZ"].includes(g)) params.theta = -(params.theta ?? 0);
    else if (g === "U3") { const originalPhi = params.phi ?? 0; params.phi = -(params.lambda ?? 0); params.lambda = -originalPhi; params.theta = -(params.theta ?? 0); }
    inverse.push({ ...instruction, id: createId("inverse"), gate: replacement, params });
  }
  return { ...circuit, id: createId("inverse-circuit"), name: `${circuit.name}†`, instructions: inverse };
}
