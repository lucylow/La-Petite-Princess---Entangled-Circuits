// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
export type AssignmentMatrix = number[][];
export interface ReadoutCalibration { qubits: number; assignment: AssignmentMatrix; confusionByQubit: Array<[[number, number], [number, number]]>; }
function invert(matrix: number[][]): number[][] {
  const n = matrix.length; if (!n || matrix.some((row) => row.length !== n)) throw new Error("Matrix must be square and non-empty.");
  const a = matrix.map((row, i) => [...row, ...Array.from({ length: n }, (_, j) => i === j ? 1 : 0)]);
  for (let col = 0; col < n; col += 1) {
    let pivot = col; for (let row = col + 1; row < n; row += 1) if (Math.abs(a[row][col]) > Math.abs(a[pivot][col])) pivot = row;
    if (Math.abs(a[pivot][col]) < 1e-12) throw new Error("Calibration assignment matrix is singular and cannot be inverted.");
    [a[col], a[pivot]] = [a[pivot], a[col]]; const divisor = a[col][col];
    for (let j = 0; j < 2 * n; j += 1) a[col][j] /= divisor;
    for (let row = 0; row < n; row += 1) if (row !== col) { const factor = a[row][col]; for (let j = 0; j < 2 * n; j += 1) a[row][j] -= factor * a[col][j]; }
  }
  return a.map((row) => row.slice(n));
}
export function calibrationFromSingleQubit(p0Given0: number, p1Given1: number): AssignmentMatrix {
  [p0Given0, p1Given1].forEach((p) => { if (!Number.isFinite(p) || p < 0 || p > 1) throw new Error("Readout assignment probabilities must be in [0,1]."); });
  return [[p0Given0, 1 - p1Given1], [1 - p0Given0, p1Given1]];
}
export function tensorAssignmentMatrices(matrices: AssignmentMatrix[]): AssignmentMatrix {
  let result: AssignmentMatrix = [[1]];
  for (const matrix of matrices) {
    if (matrix.length !== 2 || matrix.some((row) => row.length !== 2)) throw new Error("Each local readout matrix must be 2×2.");
    const next = Array.from({ length: result.length * 2 }, () => Array.from({ length: result.length * 2 }, () => 0));
    for (let r1 = 0; r1 < result.length; r1 += 1) for (let c1 = 0; c1 < result.length; c1 += 1)
      for (let r2 = 0; r2 < 2; r2 += 1) for (let c2 = 0; c2 < 2; c2 += 1)
        next[r1 * 2 + r2][c1 * 2 + c2] = result[r1][c1] * matrix[r2][c2];
    result = next;
  }
  return result;
}
export function buildReadoutCalibration(localMatrices: AssignmentMatrix[]): ReadoutCalibration {
  if (!localMatrices.length || localMatrices.length > 8) throw new Error("Calibration supports 1–8 qubits.");
  const assignment = tensorAssignmentMatrices(localMatrices);
  const confusionByQubit = localMatrices.map((m) => [[m[0][0], m[0][1]], [m[1][0], m[1][1]]] as [[number, number], [number, number]]);
  return { qubits: localMatrices.length, assignment, confusionByQubit };
}
export function mitigateCounts(counts: Record<string, number>, calibration: ReadoutCalibration, options: { clipNegative?: boolean; normalize?: boolean } = {}): Record<string, number> {
  const dim = 2 ** calibration.qubits; const observed = Array.from({ length: dim }, (_, index) => counts[index.toString(2).padStart(calibration.qubits, "0")] ?? 0);
  const total = observed.reduce((sum, value) => sum + value, 0); if (!total) return {};
  const probabilities = observed.map((value) => value / total); const inverse = invert(calibration.assignment);
  const corrected = inverse.map((row) => row.reduce((sum, value, col) => sum + value * probabilities[col], 0));
  const clipped = corrected.map((value) => options.clipNegative === false ? value : Math.max(0, value));
  const norm = clipped.reduce((sum, value) => sum + value, 0); const scale = options.normalize === false || norm === 0 ? total : total / norm;
  return Object.fromEntries(clipped.map((value, index) => [index.toString(2).padStart(calibration.qubits, "0"), value * scale]));
}
export function applyReadoutCalibrationToProbability(probability: number, p0Given0: number, p1Given1: number): number {
  return probability * p1Given1 + (1 - probability) * (1 - p0Given0);
}
export function estimateReadoutFidelity(calibration: ReadoutCalibration): number {
  const dim = calibration.assignment.length; return calibration.assignment.reduce((sum, row, index) => sum + row[index], 0) / dim;
}
export function bootstrapReadoutMitigation(counts: Record<string, number>, calibration: ReadoutCalibration, resamples = 200, random = Math.random): { mean: Record<string, number>; intervals: Record<string, [number, number]> } {
  if (!Number.isInteger(resamples) || resamples < 10 || resamples > 5000) throw new Error("Bootstrap resamples must be between 10 and 5000.");
  const keys = Object.keys(counts); const total = Object.values(counts).reduce((sum, value) => sum + value, 0); const values: Record<string, number[]> = {};
  for (let sample = 0; sample < resamples; sample += 1) {
    const synthetic: Record<string, number> = {}; const cumulative: number[] = []; let sum = 0;
    keys.forEach((key) => { sum += counts[key] / total; cumulative.push(sum); });
    for (let i = 0; i < total; i += 1) { const roll = random(); const index = cumulative.findIndex((value) => roll <= value); const key = keys[index < 0 ? keys.length - 1 : index]; synthetic[key] = (synthetic[key] ?? 0) + 1; }
    const corrected = mitigateCounts(synthetic, calibration); for (const [key, value] of Object.entries(corrected)) (values[key] ??= []).push(value);
  }
  const mean: Record<string, number> = {}; const intervals: Record<string, [number, number]> = {};
  for (const [key, series] of Object.entries(values)) { series.sort((a, b) => a - b); mean[key] = series.reduce((a, b) => a + b, 0) / series.length; intervals[key] = [series[Math.floor(series.length * 0.025)], series[Math.min(series.length - 1, Math.floor(series.length * 0.975))]]; }
  return { mean, intervals };
}
