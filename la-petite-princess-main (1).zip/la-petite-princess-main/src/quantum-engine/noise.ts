// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { C, cMul, cScale, type Complex } from "./complex";
import { matrixMultiply, dagger, type Matrix } from "./matrix";
import { applyDensityUnitary, type DensityMatrix } from "./density";

export interface KrausChannel { name: string; description: string; operators: Matrix[]; }
const m = (a: Complex | number, b: Complex | number, c: Complex | number, d: Complex | number): Matrix => [[typeof a === "number" ? C(a) : a, typeof b === "number" ? C(b) : b], [typeof c === "number" ? C(c) : c, typeof d === "number" ? C(d) : d]];
const scale = (matrix: Matrix, factor: number): Matrix => matrix.map((row) => row.map((v) => cScale(v, factor)));
const checkProbability = (value: number, label: string): void => { if (!Number.isFinite(value) || value < 0 || value > 1) throw new Error(`${label} must be between 0 and 1.`); };

export function bitFlipChannel(probability: number): KrausChannel {
  checkProbability(probability, "Bit-flip probability");
  return { name: "Bit flip", description: "With probability p, an X error is applied.", operators: [scale(m(1, 0, 0, 1), Math.sqrt(1 - probability)), scale(m(0, 1, 1, 0), Math.sqrt(probability))] };
}
export function phaseFlipChannel(probability: number): KrausChannel {
  checkProbability(probability, "Phase-flip probability");
  return { name: "Phase flip", description: "With probability p, a Z error is applied.", operators: [scale(m(1, 0, 0, 1), Math.sqrt(1 - probability)), scale(m(1, 0, 0, -1), Math.sqrt(probability))] };
}
export function depolarizingChannel(probability: number): KrausChannel {
  checkProbability(probability, "Depolarizing probability");
  // Convention: rho -> (1-p)rho + p I/2. Pauli error probabilities are p/4 for I and 3p/4 total for X,Y,Z.
  return { name: "Depolarizing", description: "Shrinks the Bloch vector toward the maximally mixed state.", operators: [
    scale(m(1, 0, 0, 1), Math.sqrt(1 - 3 * probability / 4)),
    scale(m(0, 1, 1, 0), Math.sqrt(probability / 4)),
    scale(m(0, C(0, -1), C(0, 1), 0), Math.sqrt(probability / 4)),
    scale(m(1, 0, 0, -1), Math.sqrt(probability / 4)),
  ] };
}
export function amplitudeDampingChannel(gamma: number): KrausChannel {
  checkProbability(gamma, "Amplitude-damping gamma");
  return { name: "Amplitude damping", description: "Models energy relaxation from |1⟩ toward |0⟩.", operators: [m(1, 0, 0, Math.sqrt(1 - gamma)), m(0, Math.sqrt(gamma), 0, 0)] };
}
export function phaseDampingChannel(lambda: number): KrausChannel {
  checkProbability(lambda, "Phase-damping lambda");
  return { name: "Phase damping", description: "Suppresses off-diagonal coherence without energy relaxation.", operators: [m(1, 0, 0, Math.sqrt(1 - lambda)), m(0, 0, 0, Math.sqrt(lambda))] };
}
export function applyKrausToQubit(rho: DensityMatrix, qubit: number, channel: KrausChannel): DensityMatrix {
  if (!Number.isInteger(qubit) || qubit < 0 || qubit >= rho.qubits) throw new Error("Noise channel qubit is outside the register.");
  const dim = 2 ** rho.qubits; const mask = 1 << qubit;
  const embed = (operator: Matrix): Matrix => {
    const out = Array.from({ length: dim }, () => Array.from({ length: dim }, () => C(0)));
    for (let col = 0; col < dim; col += 1) {
      const inBit = (col & mask) ? 1 : 0; const base = col & ~mask;
      for (let outBit = 0; outBit < 2; outBit += 1) {
        const row = base | (outBit ? mask : 0); out[row][col] = operator[outBit][inBit];
      }
    }
    return out;
  };
  const output = Array.from({ length: dim }, () => Array.from({ length: dim }, () => C(0)));
  for (const local of channel.operators) {
    const k = embed(local); const term = matrixMultiply(matrixMultiply(k, rho.values), dagger(k));
    for (let r = 0; r < dim; r += 1) for (let c = 0; c < dim; c += 1) output[r][c] = { re: output[r][c].re + term[r][c].re, im: output[r][c].im + term[r][c].im };
  }
  return { qubits: rho.qubits, values: output };
}
export function applyReadoutError(bit: 0 | 1, probability: number, random = Math.random): 0 | 1 {
  checkProbability(probability, "Readout error probability");
  return random() < probability ? (bit === 0 ? 1 : 0) : bit;
}
export function applyIndependentNoise(rho: DensityMatrix, probability: number, kind: "depolarizing" | "bit-flip" | "phase-flip" | "amplitude-damping"): DensityMatrix {
  const channel = kind === "depolarizing" ? depolarizingChannel(probability) : kind === "bit-flip" ? bitFlipChannel(probability) : kind === "phase-flip" ? phaseFlipChannel(probability) : amplitudeDampingChannel(probability);
  let result = rho;
  for (let q = 0; q < rho.qubits; q += 1) result = applyKrausToQubit(result, q, channel);
  return result;
}
export function composeKrausChannels(first: KrausChannel, second: KrausChannel): KrausChannel {
  const operators: Matrix[] = [];
  for (const a of second.operators) for (const b of first.operators) operators.push(matrixMultiply(a, b));
  return { name: `${first.name} then ${second.name}`, description: `${first.description} ${second.description}`, operators };
}
