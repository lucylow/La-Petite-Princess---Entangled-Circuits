// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { createCircuit, type QuantumCircuit } from "./circuit";
import { createId } from "./circuit";
import type { GateOperation } from "./gates";

function gate(circuit: QuantumCircuit, name: GateOperation["gate"], target: number, theta?: number): QuantumCircuit {
  const operation: GateOperation = { id: createId(`prep-${name.toLowerCase()}`), gate: name, targets: [target], controls: [], params: theta === undefined ? {} : { theta } };
  return { ...circuit, instructions: [...circuit.instructions, { type: "gate", ...operation }] };
}

function controlled(circuit: QuantumCircuit, name: GateOperation["gate"], control: number, target: number, theta?: number): QuantumCircuit {
  const operation: GateOperation = { id: createId(`prep-c${name.toLowerCase()}`), gate: name, targets: [target], controls: [control], params: theta === undefined ? {} : { theta } };
  return { ...circuit, instructions: [...circuit.instructions, { type: "gate", ...operation }] };
}

export interface BlochAngles {
  theta: number;
  phi: number;
}

export function validateBlochAngles(angles: BlochAngles): void {
  if (!Number.isFinite(angles.theta) || !Number.isFinite(angles.phi)) {
    throw new Error("Bloch angles must be finite numbers.");
  }
}

/** Prepare cos(theta/2)|0> + exp(i phi) sin(theta/2)|1>. */
export function prepareSingleQubitState(angles: BlochAngles, name = "Single-qubit state preparation"): QuantumCircuit {
  validateBlochAngles(angles);
  let circuit = createCircuit(1, name);
  circuit = gate(circuit, "RY", 0, angles.theta);
  circuit = gate(circuit, "RZ", 0, angles.phi);
  return circuit;
}

/** Prepare a product state from independent Bloch-sphere polar and azimuthal angles. */
export function prepareProductState(angles: BlochAngles[], name = "Product-state preparation"): QuantumCircuit {
  if (!angles.length || angles.length > 16) throw new Error("Product-state preparation supports 1–16 qubits.");
  angles.forEach(validateBlochAngles);
  let circuit = createCircuit(angles.length, name);
  angles.forEach((item, qubit) => {
    circuit = gate(circuit, "RY", qubit, item.theta);
    circuit = gate(circuit, "RZ", qubit, item.phi);
  });
  return circuit;
}

export function prepareBasisState(bitString: string, name = "Computational basis state"): QuantumCircuit {
  if (!/^[01]{1,16}$/.test(bitString)) throw new Error("Basis state must be a 1–16 digit binary string.");
  let circuit = createCircuit(bitString.length, name);
  // String notation is written q[n-1]...q[0], matching conventional basis labels.
  [...bitString].reverse().forEach((digit, qubit) => {
    if (digit === "1") circuit = gate(circuit, "X", qubit);
  });
  return circuit;
}

export function prepareUniformSuperposition(qubits: number): QuantumCircuit {
  if (!Number.isInteger(qubits) || qubits < 1 || qubits > 16) throw new Error("Uniform superposition supports 1–16 qubits.");
  let circuit = createCircuit(qubits, `Uniform superposition · ${qubits} qubits`);
  for (let qubit = 0; qubit < qubits; qubit += 1) circuit = gate(circuit, "H", qubit);
  return circuit;
}

export function prepareGraphState(qubits: number, edges: Array<[number, number]>): QuantumCircuit {
  if (!Number.isInteger(qubits) || qubits < 1 || qubits > 16) throw new Error("Graph state supports 1–16 qubits.");
  const seen = new Set<string>();
  for (const [a, b] of edges) {
    if (!Number.isInteger(a) || !Number.isInteger(b) || a < 0 || b < 0 || a >= qubits || b >= qubits || a === b) {
      throw new Error(`Invalid graph-state edge ${a}–${b}.`);
    }
    const key = [Math.min(a, b), Math.max(a, b)].join(":");
    if (seen.has(key)) throw new Error(`Duplicate graph-state edge ${a}–${b}.`);
    seen.add(key);
  }
  let circuit = prepareUniformSuperposition(qubits);
  circuit = { ...circuit, name: `Graph state · ${qubits} vertices, ${edges.length} edges` };
  for (const [a, b] of edges) {
    const operation: GateOperation = { id: createId("graph-cz"), gate: "CZ", targets: [b], controls: [a] };
    circuit = { ...circuit, instructions: [...circuit.instructions, { type: "gate", ...operation }] };
  }
  return circuit;
}

export function prepareLinearClusterState(qubits: number): QuantumCircuit {
  if (!Number.isInteger(qubits) || qubits < 2 || qubits > 16) throw new Error("Linear cluster state supports 2–16 qubits.");
  return prepareGraphState(qubits, Array.from({ length: qubits - 1 }, (_, index) => [index, index + 1] as [number, number]));
}

export function prepareRingClusterState(qubits: number): QuantumCircuit {
  if (!Number.isInteger(qubits) || qubits < 3 || qubits > 16) throw new Error("Ring cluster state supports 3–16 qubits.");
  const edges: Array<[number, number]> = Array.from({ length: qubits - 1 }, (_, index) => [index, index + 1]);
  edges.push([qubits - 1, 0]);
  return prepareGraphState(qubits, edges);
}

export function prepareGHZState(qubits: number): QuantumCircuit {
  if (!Number.isInteger(qubits) || qubits < 2 || qubits > 16) throw new Error("GHZ preparation supports 2–16 qubits.");
  let circuit = createCircuit(qubits, `${qubits}-qubit GHZ preparation`);
  circuit = gate(circuit, "H", 0);
  for (let target = 1; target < qubits; target += 1) circuit = controlled(circuit, "CX", target - 1, target);
  return circuit;
}

export function prepareDickeOneExcitation(qubits: number): QuantumCircuit {
  if (!Number.isInteger(qubits) || qubits < 2 || qubits > 8) throw new Error("The one-excitation Dicke state supports 2–8 qubits.");
  let circuit = createCircuit(qubits, `Dicke state D(${qubits},1)`);
  circuit = gate(circuit, "X", 0);
  for (let target = 1; target < qubits; target += 1) {
    const remaining = qubits - target + 1;
    circuit = controlled(circuit, "CRY", 0, target, 2 * Math.asin(1 / Math.sqrt(remaining)));
    circuit = controlled(circuit, "CX", target, 0);
  }
  return circuit;
}

export function preparePhaseGradient(qubits: number, phaseStep: number): QuantumCircuit {
  if (!Number.isInteger(qubits) || qubits < 1 || qubits > 12) throw new Error("Phase gradient supports 1–12 qubits.");
  if (!Number.isFinite(phaseStep)) throw new Error("Phase step must be finite.");
  let circuit = prepareUniformSuperposition(qubits);
  circuit = { ...circuit, name: `Phase gradient · step ${phaseStep.toFixed(3)}` };
  for (let qubit = 0; qubit < qubits; qubit += 1) circuit = gate(circuit, "P", qubit, phaseStep * 2 ** qubit);
  return circuit;
}

export function prepareParityEigenstate(qubits: number, parity: 0 | 1): QuantumCircuit {
  if (!Number.isInteger(qubits) || qubits < 2 || qubits > 16) throw new Error("Parity eigenstate supports 2–16 qubits.");
  let circuit = createCircuit(qubits, `Parity eigenstate · ${parity}`);
  if (parity) circuit = gate(circuit, "X", 0);
  for (let target = 1; target < qubits; target += 1) circuit = controlled(circuit, "CX", 0, target);
  return circuit;
}

export function productStateParameters(circuit: QuantumCircuit): BlochAngles[] {
  const state = circuit.instructions.filter((instruction) => instruction.type === "gate");
  const angles = Array.from({ length: circuit.qubits }, () => ({ theta: 0, phi: 0 }));
  for (const instruction of state) {
    if (instruction.type !== "gate" || instruction.controls?.length) continue;
    if (instruction.gate === "RY") angles[instruction.targets[0]].theta += instruction.params?.theta ?? 0;
    if (instruction.gate === "RZ") angles[instruction.targets[0]].phi += instruction.params?.theta ?? 0;
  }
  return angles;
}
