// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import type { CircuitInstruction, QuantumCircuit } from "./circuit";

export interface GateDurationProfile {
  singleQubitNs: number;
  twoQubitNs: number;
  measurementNs: number;
  resetNs: number;
  barrierNs: number;
  overrides?: Partial<Record<string, number>>;
}
export interface ScheduledInstruction { instruction: CircuitInstruction; start: number; duration: number; end: number; layer: number; wires: number[]; }
export interface CircuitSchedule { instructions: ScheduledInstruction[]; makespan: number; depth: number; idleTimeByQubit: number[]; }
export const DEFAULT_GATE_DURATIONS: GateDurationProfile = { singleQubitNs: 35, twoQubitNs: 250, measurementNs: 1200, resetNs: 600, barrierNs: 0, overrides: { H: 35, X: 35, Y: 35, Z: 0, CX: 250, CZ: 200, SWAP: 750 } };
function wiresFor(instruction: CircuitInstruction, qubitCount: number): number[] {
  if (instruction.type === "gate") return [...new Set([...instruction.targets, ...(instruction.controls ?? [])])];
  if (instruction.type === "barrier") return instruction.qubits ?? Array.from({ length: qubitCount }, (_, q) => q);
  return instruction.qubits;
}
function durationFor(instruction: CircuitInstruction, profile: GateDurationProfile): number {
  if (instruction.type === "barrier") return profile.barrierNs;
  if (instruction.type === "measure") return profile.measurementNs;
  if (instruction.type === "reset") return profile.resetNs;
  const override = profile.overrides?.[instruction.gate]; if (override !== undefined) return override;
  return instruction.targets.length + (instruction.controls?.length ?? 0) <= 1 ? profile.singleQubitNs : profile.twoQubitNs;
}
export function scheduleCircuit(circuit: QuantumCircuit, profile: GateDurationProfile = DEFAULT_GATE_DURATIONS): CircuitSchedule {
  const ready = Array.from({ length: circuit.qubits }, () => 0); const instructions: ScheduledInstruction[] = [];
  let makespan = 0; let depth = 0; const lastLayer = Array.from({ length: circuit.qubits }, () => -1);
  for (const instruction of circuit.instructions) {
    const wires = wiresFor(instruction, circuit.qubits);
    if (wires.some((q) => !Number.isInteger(q) || q < 0 || q >= circuit.qubits)) throw new Error(`Instruction ${instruction.id} references a wire outside the circuit.`);
    const start = wires.length ? Math.max(...wires.map((q) => ready[q])) : makespan;
    const duration = durationFor(instruction, profile); const end = start + duration;
    const layer = wires.length ? 1 + Math.max(-1, ...wires.map((q) => lastLayer[q])) : depth;
    wires.forEach((q) => { ready[q] = end; lastLayer[q] = layer; });
    makespan = Math.max(makespan, end); depth = Math.max(depth, layer + 1);
    instructions.push({ instruction, start, duration, end, layer, wires });
  }
  const idleTimeByQubit = ready.map((busyTime) => Math.max(0, makespan - busyTime));
  return { instructions, makespan, depth, idleTimeByQubit };
}
export function scheduleByLayer(circuit: QuantumCircuit): CircuitInstruction[][] {
  const schedule = scheduleCircuit(circuit); const groups: CircuitInstruction[][] = [];
  schedule.instructions.forEach((item) => { (groups[item.layer] ??= []).push(item.instruction); });
  return groups;
}
export function gateDurationSummary(schedule: CircuitSchedule): { totalGateTime: number; measurementTime: number; idleTime: number; utilization: number } {
  const totalGateTime = schedule.instructions.filter((item) => item.instruction.type === "gate").reduce((sum, item) => sum + item.duration, 0);
  const measurementTime = schedule.instructions.filter((item) => item.instruction.type === "measure").reduce((sum, item) => sum + item.duration, 0);
  const idleTime = schedule.idleTimeByQubit.reduce((sum, value) => sum + value, 0); const possible = schedule.makespan * schedule.idleTimeByQubit.length;
  return { totalGateTime, measurementTime, idleTime, utilization: possible ? (possible - idleTime) / possible : 0 };
}
export function addDelayGaps(schedule: CircuitSchedule): Array<{ qubit: number; start: number; duration: number }> {
  const delays: Array<{ qubit: number; start: number; duration: number }> = [];
  const byQubit = Array.from({ length: schedule.idleTimeByQubit.length }, () => [] as ScheduledInstruction[]);
  schedule.instructions.forEach((item) => item.wires.forEach((q) => byQubit[q].push(item)));
  byQubit.forEach((items, qubit) => {
    items.sort((a, b) => a.start - b.start); let cursor = 0;
    for (const item of items) { if (item.start > cursor) delays.push({ qubit, start: cursor, duration: item.start - cursor }); cursor = Math.max(cursor, item.end); }
    if (cursor < schedule.makespan) delays.push({ qubit, start: cursor, duration: schedule.makespan - cursor });
  });
  return delays;
}
export function criticalPath(schedule: CircuitSchedule): ScheduledInstruction[] {
  const sorted = [...schedule.instructions].sort((a, b) => a.end - b.end); const best = new Map<string, { length: number; previous?: string }>();
  for (const item of sorted) {
    const candidates = sorted.filter((prior) => prior.end <= item.start && prior.wires.some((wire) => item.wires.includes(wire)));
    const previous = candidates.map((prior) => ({ id: prior.instruction.id, state: best.get(prior.instruction.id)! })).filter((v) => v.state).sort((a, b) => b.state.length - a.state.length)[0];
    best.set(item.instruction.id, { length: (previous?.state.length ?? 0) + item.duration, previous: previous?.id });
  }
  const final = [...best.entries()].sort((a, b) => b[1].length - a[1].length)[0]; if (!final) return [];
  const index = new Map(schedule.instructions.map((item) => [item.instruction.id, item])); const path: ScheduledInstruction[] = []; let cursor: string | undefined = final[0];
  while (cursor) { const item = index.get(cursor); if (!item) break; path.unshift(item); cursor = best.get(cursor)?.previous; }
  return path;
}
