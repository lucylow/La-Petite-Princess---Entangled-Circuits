// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { appendGate, createCircuit, type QuantumCircuit } from "./circuit";
import { applyGateSequence, basisState, zeroState, type StateVector } from "./statevector";
import type { GateOperation } from "./gates";

export interface SyndromeResult { syndrome: string; likelyError: "none" | "q0" | "q1" | "q2" | "ambiguous"; corrected: boolean; }
export function bitFlipEncodeCircuit(): QuantumCircuit {
  let c = createCircuit(3, "Three-qubit bit-flip encoding");
  c = appendGate(c, "CX", [1], [0]); c = appendGate(c, "CX", [2], [0]); return c;
}
export function phaseFlipEncodeCircuit(): QuantumCircuit {
  let c = createCircuit(3, "Three-qubit phase-flip encoding"); c = appendGate(c, "H", [0]);
  c = appendGate(c, "CX", [1], [0]); c = appendGate(c, "CX", [2], [0]);
  return c;
}
export function injectBitFlip(state: StateVector, qubit: number): StateVector {
  return applyGateSequence(state, [{ id: "injected-X", gate: "X", targets: [qubit] }]);
}
export function bitFlipSyndromeFromBasis(index: number): SyndromeResult {
  if (!Number.isInteger(index) || index < 0 || index > 7) throw new Error("Three-qubit syndrome index must be 0–7.");
  const q0 = index & 1; const q1 = (index >> 1) & 1; const q2 = (index >> 2) & 1;
  // Encoded codewords have equal bits. Syndrome is the pair of parities (q0⊕q1, q1⊕q2).
  const s0 = q0 ^ q1; const s1 = q1 ^ q2; const syndrome = `${s0}${s1}`;
  const likelyError = syndrome === "00" ? "none" : syndrome === "10" ? "q0" : syndrome === "11" ? "q1" : syndrome === "01" ? "q2" : "ambiguous";
  return { syndrome, likelyError, corrected: likelyError !== "ambiguous" };
}
export function bitFlipCorrectionCircuit(): QuantumCircuit {
  let c = createCircuit(5, "Bit-flip error correction with two syndrome ancillas");
  // Data qubits 0,1,2; syndrome ancillas 3,4. The encoded input is |0_L> here.
  c = appendGate(c, "CX", [1], [0]); c = appendGate(c, "CX", [2], [0]);
  // Syndrome parity checks: ancilla 3 measures q0⊕q1, ancilla 4 measures q1⊕q2.
  c = appendGate(c, "CX", [3], [0]); c = appendGate(c, "CX", [3], [1]);
  c = appendGate(c, "CX", [4], [1]); c = appendGate(c, "CX", [4], [2]);
  return c;
}
export function repetitionCodeLogicalBasis(bit: 0 | 1): StateVector {
  return basisState(3, bit === 0 ? 0 : 7);
}
export function logicalBitFlipCodeword(state: StateVector): StateVector {
  if (state.qubits !== 1) throw new Error("Logical bit-flip encoding expects one input qubit.");
  const out = zeroState(3); out.amplitudes[0] = state.amplitudes[0]; out.amplitudes[7] = state.amplitudes[1]; return out;
}
export function decodeBitFlipSyndrome(syndrome: string): SyndromeResult {
  const map: Record<string, SyndromeResult["likelyError"]> = { "00": "none", "10": "q0", "11": "q1", "01": "q2" };
  if (!(syndrome in map)) return { syndrome, likelyError: "ambiguous", corrected: false };
  return { syndrome, likelyError: map[syndrome], corrected: true };
}
