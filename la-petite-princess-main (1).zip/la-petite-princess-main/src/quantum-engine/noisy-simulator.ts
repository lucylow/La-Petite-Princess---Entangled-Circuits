// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { densityFromState, applyOperationToDensity, type DensityMatrix } from "./density";
import { amplitudeDampingChannel, applyKrausToQubit, depolarizingChannel, phaseDampingChannel } from "./noise";
import type { QuantumCircuit } from "./circuit";
import { validateCircuit } from "./circuit";
import { zeroState } from "./statevector";

export interface NoiseModel {
  singleQubitDepolarizing?: number;
  twoQubitDepolarizing?: number;
  amplitudeDamping?: number;
  phaseDamping?: number;
  readoutError?: number;
}
export interface NoisyStateResult {
  density: DensityMatrix;
  trace: number;
  purity: number;
  appliedChannels: Array<{ operationId: string; qubit: number; channel: string }>;
}
function checkProbability(p: number | undefined, name: string): void { if (p !== undefined && (!Number.isFinite(p) || p < 0 || p > 1)) throw new Error(`${name} must be between 0 and 1.`); }
export function simulateNoisyDensity(circuit: QuantumCircuit, model: NoiseModel = {}): NoisyStateResult {
  if (circuit.qubits > 6) throw new Error("Noisy density-matrix simulation is limited to 6 qubits in this browser engine.");
  const errors = validateCircuit(circuit).filter((issue) => issue.severity === "error"); if (errors.length) throw new Error(errors.map((i) => i.message).join(" "));
  if (circuit.instructions.some((item) => item.type === "measure" || item.type === "reset" || (item.type === "gate" && item.condition))) throw new Error("Density-matrix noise simulation currently supports gate-only unitary circuits; use runShots for dynamic measurement and reset.");
  checkProbability(model.singleQubitDepolarizing, "Single-qubit depolarizing rate"); checkProbability(model.twoQubitDepolarizing, "Two-qubit depolarizing rate");
  checkProbability(model.amplitudeDamping, "Amplitude-damping rate"); checkProbability(model.phaseDamping, "Phase-damping rate");
  let density = densityFromState(zeroState(circuit.qubits)); const appliedChannels: NoisyStateResult["appliedChannels"] = [];
  for (const instruction of circuit.instructions) {
    if (instruction.type === "gate") {
      density = applyOperationToDensity(density, instruction);
      const touched = [...instruction.targets, ...(instruction.controls ?? [])];
      const depolarizing = touched.length > 1 ? model.twoQubitDepolarizing : model.singleQubitDepolarizing;
      if (depolarizing) for (const q of touched) { density = applyKrausToQubit(density, q, depolarizingChannel(depolarizing)); appliedChannels.push({ operationId: instruction.id, qubit: q, channel: "depolarizing" }); }
      if (model.amplitudeDamping) for (const q of touched) { density = applyKrausToQubit(density, q, amplitudeDampingChannel(model.amplitudeDamping)); appliedChannels.push({ operationId: instruction.id, qubit: q, channel: "amplitude damping" }); }
      if (model.phaseDamping) for (const q of touched) { density = applyKrausToQubit(density, q, phaseDampingChannel(model.phaseDamping)); appliedChannels.push({ operationId: instruction.id, qubit: q, channel: "phase damping" }); }
    }
  }
  const trace = density.values.reduce((sum, row, index) => sum + row[index].re, 0);
  let purity = 0; for (const row of density.values) for (const value of row) purity += value.re * value.re + value.im * value.im;
  return { density, trace, purity, appliedChannels };
}
export function noisyModelDescription(model: NoiseModel): string[] {
  const lines: string[] = [];
  if (model.singleQubitDepolarizing) lines.push(`Single-qubit depolarizing after each gate: p=${model.singleQubitDepolarizing}.`);
  if (model.twoQubitDepolarizing) lines.push(`Two-qubit depolarizing after each multi-qubit gate: p=${model.twoQubitDepolarizing}.`);
  if (model.amplitudeDamping) lines.push(`Amplitude damping after touched gates: γ=${model.amplitudeDamping}.`);
  if (model.phaseDamping) lines.push(`Phase damping after touched gates: λ=${model.phaseDamping}.`);
  if (model.readoutError) lines.push(`Readout bit-flip probability: ${model.readoutError}.`);
  if (!lines.length) lines.push("Ideal simulator: no noise channels enabled.");
  return lines;
}
