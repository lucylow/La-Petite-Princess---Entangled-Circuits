// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { appendGate, createCircuit, type QuantumCircuit } from "./circuit";
import { fidelityPureStates } from "./analysis";
import { simulateState } from "./simulator";
import { zeroState } from "./statevector";
import { invertCircuit } from "./compiler";

export interface MirrorBenchmarkPoint { depth: number; sequence: number; returnProbability: number; }
export interface MirrorBenchmarkSummary { points: MirrorBenchmarkPoint[]; meanReturnProbability: number; sequenceCount: number; caveat: string; }
const SELF_INVERSE = ["H", "X", "Y", "Z"] as const;
export function randomMirrorCircuit(qubits = 2, depth = 10, random = Math.random): QuantumCircuit {
  if (!Number.isInteger(qubits) || qubits < 1 || qubits > 8 || !Number.isInteger(depth) || depth < 1 || depth > 200) throw new Error("Mirror benchmark supports 1–8 qubits and depth 1–200.");
  let circuit = createCircuit(qubits, `Random mirror · depth ${depth}`);
  for (let layer = 0; layer < depth; layer += 1) {
    const q = Math.floor(random() * qubits); const gate = SELF_INVERSE[Math.floor(random() * SELF_INVERSE.length)];
    circuit = appendGate(circuit, gate, [q]);
    if (qubits > 1 && random() < 0.45) {
      let target = Math.floor(random() * qubits); while (target === q) target = Math.floor(random() * qubits);
      circuit = appendGate(circuit, "CX", [target], [q]);
    }
  }
  const inverse = invertCircuit(circuit);
  return { ...circuit, instructions: [...circuit.instructions, ...inverse.instructions.map((item, index) => ({ ...item, id: `mirror-inverse-${index}` }))] };
}
export function runMirrorBenchmark(qubits: number, depths: number[], sequences = 20, random = Math.random): MirrorBenchmarkSummary {
  if (!Number.isInteger(sequences) || sequences < 1 || sequences > 500) throw new Error("Sequence count must be between 1 and 500.");
  const points: MirrorBenchmarkPoint[] = [];
  for (const depth of depths) for (let sequence = 0; sequence < sequences; sequence += 1) {
    const circuit = randomMirrorCircuit(qubits, depth, random); const final = simulateState(circuit); const initial = zeroState(qubits);
    points.push({ depth, sequence, returnProbability: fidelityPureStates(initial, final) });
  }
  return { points, meanReturnProbability: points.reduce((sum, point) => sum + point.returnProbability, 0) / Math.max(1, points.length), sequenceCount: points.length, caveat: "This noiseless mirror-circuit utility checks inverse correctness. It is not a hardware randomized-benchmarking protocol and does not estimate physical gate error." };
}
export function idealMirrorReturnProbability(circuit: QuantumCircuit): number {
  const final = simulateState(circuit); return final.amplitudes[0].re * final.amplitudes[0].re + final.amplitudes[0].im * final.amplitudes[0].im;
}
