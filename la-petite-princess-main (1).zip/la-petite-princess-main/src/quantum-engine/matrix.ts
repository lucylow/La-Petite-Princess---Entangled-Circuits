// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { C, EPSILON, ONE, ZERO, cAdd, cConj, cMul, cScale, type Complex } from "./complex";

export type Matrix = Complex[][];
export type Vector = Complex[];

export function zeros(rows: number, cols: number): Matrix {
  return Array.from({ length: rows }, () => Array.from({ length: cols }, () => ZERO));
}
export function identity(size: number): Matrix {
  const result = zeros(size, size);
  for (let i = 0; i < size; i += 1) result[i][i] = ONE;
  return result;
}
export function cloneMatrix(matrix: Matrix): Matrix { return matrix.map((row) => row.map((v) => C(v.re, v.im))); }
export function shape(matrix: Matrix): [number, number] {
  const rows = matrix.length; const cols = rows ? matrix[0].length : 0;
  if (matrix.some((row) => row.length !== cols)) throw new Error("Matrix rows must all have the same length.");
  return [rows, cols];
}
export function matrixMultiply(a: Matrix, b: Matrix): Matrix {
  const [ar, ac] = shape(a); const [br, bc] = shape(b);
  if (ac !== br) throw new Error(`Matrix dimensions do not multiply: ${ar}×${ac} and ${br}×${bc}.`);
  const out = zeros(ar, bc);
  for (let i = 0; i < ar; i += 1) for (let k = 0; k < ac; k += 1) {
    const aik = a[i][k];
    for (let j = 0; j < bc; j += 1) out[i][j] = cAdd(out[i][j], cMul(aik, b[k][j]));
  }
  return out;
}
export function matrixVectorMultiply(matrix: Matrix, vector: Vector): Vector {
  const [rows, cols] = shape(matrix);
  if (cols !== vector.length) throw new Error("Matrix and vector dimensions do not match.");
  return Array.from({ length: rows }, (_, i) => matrix[i].reduce((sum, item, j) => cAdd(sum, cMul(item, vector[j])), ZERO));
}
export function dagger(matrix: Matrix): Matrix {
  const [rows, cols] = shape(matrix); const out = zeros(cols, rows);
  for (let r = 0; r < rows; r += 1) for (let c = 0; c < cols; c += 1) out[c][r] = cConj(matrix[r][c]);
  return out;
}
export function transpose(matrix: Matrix): Matrix {
  const [rows, cols] = shape(matrix); const out = zeros(cols, rows);
  for (let r = 0; r < rows; r += 1) for (let c = 0; c < cols; c += 1) out[c][r] = matrix[r][c];
  return out;
}
export function trace(matrix: Matrix): Complex {
  const [rows, cols] = shape(matrix);
  if (rows !== cols) throw new Error("Trace is defined only for square matrices.");
  return matrix.reduce((sum, row, index) => cAdd(sum, row[index]), ZERO);
}
export function tensor(a: Matrix, b: Matrix): Matrix {
  const [ar, ac] = shape(a); const [br, bc] = shape(b); const out = zeros(ar * br, ac * bc);
  for (let i = 0; i < ar; i += 1) for (let j = 0; j < ac; j += 1)
    for (let k = 0; k < br; k += 1) for (let l = 0; l < bc; l += 1)
      out[i * br + k][j * bc + l] = cMul(a[i][j], b[k][l]);
  return out;
}
export function scaleMatrix(matrix: Matrix, scalar: number): Matrix { return matrix.map((row) => row.map((value) => cScale(value, scalar))); }
export function addMatrices(a: Matrix, b: Matrix): Matrix {
  const [ar, ac] = shape(a); const [br, bc] = shape(b);
  if (ar !== br || ac !== bc) throw new Error("Matrix dimensions must match for addition.");
  return a.map((row, i) => row.map((value, j) => cAdd(value, b[i][j])));
}
export function matrixEquals(a: Matrix, b: Matrix, epsilon = EPSILON): boolean {
  const [ar, ac] = shape(a); const [br, bc] = shape(b);
  if (ar !== br || ac !== bc) return false;
  return a.every((row, i) => row.every((value, j) => Math.hypot(value.re - b[i][j].re, value.im - b[i][j].im) <= epsilon));
}
export function isUnitary(matrix: Matrix, epsilon = 1e-8): boolean {
  const [rows, cols] = shape(matrix); if (rows !== cols) return false;
  return matrixEquals(matrixMultiply(dagger(matrix), matrix), identity(rows), epsilon);
}
export function outerProduct(a: Vector, b: Vector): Matrix {
  return a.map((left) => b.map((right) => C(left.re * right.re + left.im * right.im, left.im * right.re - left.re * right.im)));
}
export function normalizeVector(vector: Vector): Vector {
  const norm = Math.sqrt(vector.reduce((sum, value) => sum + value.re * value.re + value.im * value.im, 0));
  if (norm < EPSILON) throw new Error("Cannot normalize a zero vector.");
  return vector.map((value) => cScale(value, 1 / norm));
}
export function matrixToString(matrix: Matrix, digits = 3): string {
  return matrix.map((row) => `[ ${row.map((v) => `${v.re.toFixed(digits)}${v.im < 0 ? "" : "+"}${v.im.toFixed(digits)}i`).join("  ")} ]`).join("\n");
}
