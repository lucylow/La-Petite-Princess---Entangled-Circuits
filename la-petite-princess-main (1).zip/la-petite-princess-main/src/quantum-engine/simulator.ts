// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { C, ZERO, cAbs2, cScale } from "./complex";
import type { CircuitInstruction, QuantumCircuit } from "./circuit";
import { validateCircuit } from "./circuit";
import { applyGate, basisProbabilities, measureAll, measureQubit, zeroState, type StateVector } from "./statevector";

export interface ShotResult { classicalBits: number[]; memory: string; finalState: StateVector; }
export interface SimulationSummary {
  shots: number;
  counts: Record<string, number>;
  probabilities: Record<string, number>;
  memory?: string[];
  depth: number;
  gateCount: number;
  elapsedMs: number;
  seed?: number;
}
export interface SimulatorOptions { shots?: number; seed?: number; keepMemory?: boolean; maxShots?: number; }

export function seededRandom(seed: number): () => number {
  let state = seed >>> 0;
  return () => { state += 0x6D2B79F5; let t = state; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}
function applyReset(state: StateVector, qubit: number, random: () => number): StateVector {
  const measurement = measureQubit(state, qubit, random());
  if (measurement.outcome === 0) return measurement.state;
  // A reset is measurement followed by X when the result is one.
  return applyGate(measurement.state, { id: "internal-reset-x", gate: "X", targets: [qubit] });
}
function bitString(bits: number[]): string { return bits.slice().reverse().join(""); }
function executeOneShot(circuit: QuantumCircuit, random: () => number): ShotResult {
  let state = zeroState(circuit.qubits);
  const classical = Array.from({ length: circuit.classicalBits }, () => 0);
  for (const instruction of circuit.instructions) {
    if (instruction.type === "gate") {
      if (instruction.condition && classical[instruction.condition.bit] !== instruction.condition.equals) continue;
      state = applyGate(state, instruction);
    } else if (instruction.type === "measure") {
      instruction.qubits.forEach((qubit, index) => {
        const measured = measureQubit(state, qubit, random()); state = measured.state;
        classical[instruction.classicalBits[index]] = measured.outcome;
      });
    } else if (instruction.type === "reset") {
      for (const qubit of instruction.qubits) state = applyReset(state, qubit, random);
    }
  }
  // If no explicit measurement exists, use a final computational-basis measurement.
  if (!circuit.instructions.some((item) => item.type === "measure")) {
    const result = measureAll(state, random()); state = result.state;
    result.bitString.split("").reverse().forEach((bit, index) => { classical[index] = Number(bit); });
  }
  return { classicalBits: classical, memory: bitString(classical), finalState: state };
}
export function simulateCircuitShot(circuit: QuantumCircuit, random: () => number = Math.random): ShotResult {
  const errors = validateCircuit(circuit).filter((issue) => issue.severity === "error");
  if (errors.length) throw new Error(`Circuit validation failed: ${errors.map((issue) => issue.message).join(" ")}`);
  return executeOneShot(circuit, random);
}
export function simulateState(circuit: QuantumCircuit): StateVector {
  const errors = validateCircuit(circuit).filter((issue) => issue.severity === "error");
  if (errors.length) throw new Error(`Circuit validation failed: ${errors.map((issue) => issue.message).join(" ")}`);
  if (circuit.instructions.some((item) => item.type === "measure" || item.type === "reset")) throw new Error("State-only simulation cannot include measurement or reset. Use runShots for dynamic circuits.");
  return circuit.instructions.reduce((state, instruction) => instruction.type === "gate" ? applyGate(state, instruction) : state, zeroState(circuit.qubits));
}
export function runShots(circuit: QuantumCircuit, options: SimulatorOptions = {}): SimulationSummary {
  const errors = validateCircuit(circuit).filter((issue) => issue.severity === "error");
  if (errors.length) throw new Error(`Circuit validation failed: ${errors.map((issue) => issue.message).join(" ")}`);
  const shots = options.shots ?? 1024; const maxShots = options.maxShots ?? 100_000;
  if (!Number.isInteger(shots) || shots < 1 || shots > maxShots) throw new Error(`Shots must be an integer between 1 and ${maxShots}.`);
  const random = options.seed === undefined ? Math.random : seededRandom(options.seed);
  const start = typeof performance !== "undefined" ? performance.now() : Date.now();
  const counts: Record<string, number> = {}; const memory: string[] = [];
  for (let i = 0; i < shots; i += 1) {
    const result = executeOneShot(circuit, random); counts[result.memory] = (counts[result.memory] ?? 0) + 1;
    if (options.keepMemory) memory.push(result.memory);
  }
  const elapsedMs = (typeof performance !== "undefined" ? performance.now() : Date.now()) - start;
  const probabilities = Object.fromEntries(Object.entries(counts).map(([key, count]) => [key, count / shots]));
  return { shots, counts, probabilities, memory: options.keepMemory ? memory : undefined, depth: circuitDepthEstimate(circuit), gateCount: circuit.instructions.filter((item) => item.type === "gate").length, elapsedMs, seed: options.seed };
}
function circuitDepthEstimate(circuit: QuantumCircuit): number {
  const last = Array.from({ length: circuit.qubits }, () => -1); let max = -1;
  for (const instruction of circuit.instructions) {
    if (instruction.type === "barrier") continue;
    const wires = instruction.type === "gate" ? [...instruction.targets, ...(instruction.controls ?? [])] : instruction.qubits;
    const depth = Math.max(-1, ...wires.map((q) => last[q] ?? -1)) + 1;
    wires.forEach((q) => { if (q >= 0 && q < last.length) last[q] = depth; }); max = Math.max(max, depth);
  }
  return max + 1;
}
export function exactMeasurementDistribution(circuit: QuantumCircuit): Record<string, number> {
  const state = simulateState(circuit); const probabilities = basisProbabilities(state);
  return Object.fromEntries(probabilities.map((p, index) => [index.toString(2).padStart(circuit.qubits, "0"), p]).filter(([, probability]) => (probability as number) > 1e-12));
}
export function stateVectorAfterPrefix(circuit: QuantumCircuit, instructionCount: number): StateVector {
  if (!Number.isInteger(instructionCount) || instructionCount < 0 || instructionCount > circuit.instructions.length) throw new Error("Instruction prefix count is invalid.");
  let state = zeroState(circuit.qubits);
  const prefix = circuit.instructions.slice(0, instructionCount);
  if (prefix.some((item) => item.type !== "gate" && item.type !== "barrier")) throw new Error("Prefix includes a measurement or reset; use shot simulation for dynamic execution.");
  for (const instruction of prefix) if (instruction.type === "gate") state = applyGate(state, instruction);
  return state;
}
export function fidelityAgainstBasis(state: StateVector, basisIndex: number): number {
  if (basisIndex < 0 || basisIndex >= state.amplitudes.length) throw new Error("Basis index is out of range.");
  return cAbs2(state.amplitudes[basisIndex]);
}
export function circuitHasDynamicInstructions(circuit: QuantumCircuit): boolean { return circuit.instructions.some((item) => item.type === "measure" || item.type === "reset" || (item.type === "gate" && Boolean(item.condition))); }
export function runSingleStateDiagnostic(circuit: QuantumCircuit): { normSquared: number; maxProbability: number; nonzeroTerms: number } {
  const state = simulateState(circuit); const probabilities = basisProbabilities(state);
  return { normSquared: state.amplitudes.reduce((sum, value) => sum + cAbs2(value), 0), maxProbability: Math.max(...probabilities), nonzeroTerms: probabilities.filter((p) => p > 1e-10).length };
}
export function zeroClassicalRegister(size: number): number[] { return Array.from({ length: size }, () => 0); }
export function resetRegister(qubits: number): StateVector { return zeroState(qubits); }
