// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { C } from "./complex";
import { oneQubitEigenvalues, type DensityMatrix } from "./density";
import { applySingleQubitMatrix, type StateVector } from "./statevector";
import { matrixForGate } from "./gates";

export type TomographyBasis = "X" | "Y" | "Z";
export interface TomographyEstimate { basis: TomographyBasis; expectation: number; standardError: number; shots: number; }
export interface ReconstructedQubit { density: DensityMatrix; bloch: { x: number; y: number; z: number }; purity: number; eigenvalues: [number, number]; }
export function tomographyRotatedState(state: StateVector, qubit: number, basis: TomographyBasis): StateVector {
  if (basis === "Z") return state;
  // To measure X, rotate with H. To measure Y, rotate with H·S†.
  if (basis === "X") return applySingleQubitMatrix(state, qubit, matrixForGate("H"));
  let next = applySingleQubitMatrix(state, qubit, matrixForGate("SDG"));
  return applySingleQubitMatrix(next, qubit, matrixForGate("H"));
}
export function sampleTomographyBasis(state: StateVector, qubit: number, basis: TomographyBasis, shots = 2048, random = Math.random): TomographyEstimate {
  if (!Number.isInteger(shots) || shots < 1) throw new Error("Tomography shots must be a positive integer.");
  const rotated = tomographyRotatedState(state, qubit, basis); let sum = 0;
  for (let shot = 0; shot < shots; shot += 1) {
    let p0 = 0; rotated.amplitudes.forEach((a, index) => { if (((index >> qubit) & 1) === 0) p0 += a.re * a.re + a.im * a.im; });
    sum += random() < p0 ? 1 : -1;
  }
  const expectation = sum / shots;
  return { basis, expectation, standardError: Math.sqrt(Math.max(0, 1 - expectation * expectation) / shots), shots };
}
export function reconstructSingleQubitDensity(estimates: TomographyEstimate[]): ReconstructedQubit {
  const get = (basis: TomographyBasis): number => { const result = estimates.find((item) => item.basis === basis); if (!result) throw new Error(`Missing ${basis}-basis tomography estimate.`); return result.expectation; };
  const x = get("X"); const y = get("Y"); const z = get("Z");
  const density: DensityMatrix = { qubits: 1, values: [[C((1 + z) / 2), C(x / 2, -y / 2)], [C(x / 2, y / 2), C((1 - z) / 2)]] };
  const purity = (1 + x * x + y * y + z * z) / 2; const eigenvalues = oneQubitEigenvalues(density);
  return { density, bloch: { x, y, z }, purity, eigenvalues };
}
export function tomographyReport(estimate: ReconstructedQubit): { purityLabel: string; stateLabel: string; blochRadius: number } {
  const radius = Math.sqrt(estimate.bloch.x ** 2 + estimate.bloch.y ** 2 + estimate.bloch.z ** 2);
  return { purityLabel: estimate.purity > 0.98 ? "Nearly pure" : estimate.purity > 0.55 ? "Partially mixed" : "Strongly mixed", stateLabel: radius > 0.98 ? "Near the Bloch-sphere surface" : radius < 0.05 ? "Near the maximally mixed state" : "Inside the Bloch sphere", blochRadius: radius };
}
