// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { describe, expect, it } from "vitest";
import { C } from "../complex";
import { appendGate, createCircuit } from "../circuit";
import { simulateState } from "../simulator";
import { basisDensity, densityFromState, densityTrace, fidelityPureToDensity, linearEntropy, maximallyMixed, oneQubitEigenvalues, partialTrace, purity, vonNeumannEntropy, isPositiveTraceOne } from "../density";
import { amplitudeDampingChannel, applyIndependentNoise, applyKrausToQubit, bitFlipChannel, composeKrausChannels, depolarizingChannel, phaseDampingChannel, phaseFlipChannel } from "../noise";
import { simulateNoisyDensity } from "../noisy-simulator";
import { applyGate, zeroState, basisProbabilities } from "../statevector";

describe("density matrix construction and diagnostics", () => {
  it("constructs a basis-state density matrix", () => {
    const rho = basisDensity(2, 2);
    expect(rho.values[2][2]).toEqual(C(1));
    expect(densityTrace(rho)).toBeCloseTo(1, 12);
    expect(purity(rho)).toBeCloseTo(1, 12);
  });

  it("constructs the maximally mixed one-qubit state", () => {
    const rho = maximallyMixed(1);
    expect(rho.values[0][0].re).toBeCloseTo(0.5, 12);
    expect(rho.values[1][1].re).toBeCloseTo(0.5, 12);
    expect(purity(rho)).toBeCloseTo(0.5, 12);
    expect(vonNeumannEntropy(rho)).toBeCloseTo(1, 12);
  });

  it("rejects an unsupported dense density matrix size", () => {
    expect(() => maximallyMixed(9)).toThrow();
  });

  it("converts a pure state into a rank-one density matrix", () => {
    const state = applyGate(zeroState(1), { id: "h", gate: "H", targets: [0] });
    const rho = densityFromState(state);
    expect(purity(rho)).toBeCloseTo(1, 12);
    expect(densityTrace(rho)).toBeCloseTo(1, 12);
  });

  it("computes a partial trace of one half of a Bell pair", () => {
    let state = zeroState(2);
    state = applyGate(state, { id: "h", gate: "H", targets: [0] });
    state = applyGate(state, { id: "cx", gate: "CX", targets: [1], controls: [0] });
    const reduced = partialTrace(densityFromState(state), [0]);
    expect(reduced.values[0][0].re).toBeCloseTo(0.5, 10);
    expect(reduced.values[1][1].re).toBeCloseTo(0.5, 10);
    expect(purity(reduced)).toBeCloseTo(0.5, 10);
  });

  it("computes partial trace with a nonzero retained qubit index", () => {
    let state = zeroState(3);
    state = applyGate(state, { id: "x", gate: "X", targets: [2] });
    const reduced = partialTrace(densityFromState(state), [2]);
    expect(reduced.values[1][1].re).toBeCloseTo(1, 10);
    expect(reduced.values[0][0].re).toBeCloseTo(0, 10);
  });

  it("rejects repeated and out-of-range retained qubits", () => {
    const rho = densityFromState(zeroState(2));
    expect(() => partialTrace(rho, [0, 0])).toThrow();
    expect(() => partialTrace(rho, [2])).toThrow();
    expect(() => partialTrace(rho, [])).toThrow();
  });

  it("computes one-qubit density eigenvalues", () => {
    const eigenvalues = oneQubitEigenvalues(maximallyMixed(1));
    expect(eigenvalues[0]).toBeCloseTo(0.5, 12);
    expect(eigenvalues[1]).toBeCloseTo(0.5, 12);
  });

  it("detects valid density matrix Hermiticity and trace", () => {
    const rho = densityFromState(zeroState(2));
    expect(isPositiveTraceOne(rho)).toBe(true);
  });

  it("reports pure-state fidelity as one", () => {
    const state = simulateState(appendGate(createCircuit(2), "H", [1]));
    expect(fidelityPureToDensity(state, densityFromState(state))).toBeCloseTo(1, 10);
  });

  it("calculates linear entropy", () => {
    expect(linearEntropy(maximallyMixed(1))).toBeCloseTo(0.5, 10);
    expect(linearEntropy(basisDensity(1))).toBeCloseTo(0, 10);
  });
});

describe("Kraus noise channels", () => {
  it("creates trace-preserving bit-flip Kraus operators", () => {
    expect(bitFlipChannel(0.1).operators).toHaveLength(2);
  });

  it("creates phase-flip and depolarizing channels", () => {
    expect(phaseFlipChannel(0.2).operators).toHaveLength(2);
    expect(depolarizingChannel(0.2).operators).toHaveLength(4);
  });

  it("rejects invalid channel probabilities", () => {
    expect(() => bitFlipChannel(-0.1)).toThrow();
    expect(() => phaseFlipChannel(1.1)).toThrow();
    expect(() => depolarizingChannel(Number.NaN)).toThrow();
    expect(() => amplitudeDampingChannel(Infinity)).toThrow();
    expect(() => phaseDampingChannel(-1)).toThrow();
  });

  it("models amplitude damping of |1> into |0>", () => {
    const state = applyGate(zeroState(1), { id: "x", gate: "X", targets: [0] });
    const rho = applyKrausToQubit(densityFromState(state), 0, amplitudeDampingChannel(1));
    expect(rho.values[0][0].re).toBeCloseTo(1, 10);
    expect(rho.values[1][1].re).toBeCloseTo(0, 10);
    expect(densityTrace(rho)).toBeCloseTo(1, 10);
  });

  it("reduces coherence with phase damping but preserves populations", () => {
    const plus = applyGate(zeroState(1), { id: "h", gate: "H", targets: [0] });
    const rho = applyKrausToQubit(densityFromState(plus), 0, phaseDampingChannel(1));
    expect(rho.values[0][0].re).toBeCloseTo(0.5, 10);
    expect(rho.values[1][1].re).toBeCloseTo(0.5, 10);
    expect(Math.hypot(rho.values[0][1].re, rho.values[0][1].im)).toBeCloseTo(0, 10);
  });

  it("shrinks a pure state toward mixedness under depolarizing noise", () => {
    const plus = applyGate(zeroState(1), { id: "h", gate: "H", targets: [0] });
    const rho = applyKrausToQubit(densityFromState(plus), 0, depolarizingChannel(0.2));
    expect(purity(rho)).toBeLessThan(1);
    expect(densityTrace(rho)).toBeCloseTo(1, 10);
  });

  it("composes two channels by multiplying their Kraus operators", () => {
    const composed = composeKrausChannels(bitFlipChannel(0.1), phaseFlipChannel(0.2));
    expect(composed.operators.length).toBe(4);
    expect(composed.name).toContain("then");
  });

  it("applies independent noise to every qubit", () => {
    const rho = applyIndependentNoise(densityFromState(zeroState(2)), 0.1, "bit-flip");
    expect(densityTrace(rho)).toBeCloseTo(1, 9);
    expect(purity(rho)).toBeLessThan(1);
  });
});

describe("noisy circuit simulation", () => {
  it("returns a trace-one noisy Bell state", () => {
    let circuit = createCircuit(2);
    circuit = appendGate(circuit, "H", [0]);
    circuit = appendGate(circuit, "CX", [1], [0]);
    const result = simulateNoisyDensity(circuit, { twoQubitDepolarizing: 0.01 });
    expect(result.trace).toBeCloseTo(1, 8);
    expect(result.purity).toBeLessThan(1);
    expect(result.appliedChannels.length).toBeGreaterThan(0);
  });

  it("returns a pure result when all noise rates are zero", () => {
    const circuit = appendGate(createCircuit(1), "H", [0]);
    const result = simulateNoisyDensity(circuit, { singleQubitDepolarizing: 0, amplitudeDamping: 0, phaseDamping: 0 });
    expect(result.purity).toBeCloseTo(1, 10);
  });

  it("rejects noisy dynamic circuits", () => {
    const circuit = { ...createCircuit(1), instructions: [{ type: "measure" as const, id: "m", qubits: [0], classicalBits: [0] }] };
    expect(() => simulateNoisyDensity(circuit, { singleQubitDepolarizing: 0.1 })).toThrow(/gate-only/);
  });

  it("enforces the dense noise simulator qubit limit", () => {
    const circuit = createCircuit(7);
    expect(() => simulateNoisyDensity(circuit, {})).toThrow(/6 qubits/);
  });
});
