// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { describe, expect, it } from "vitest";
import { appendGate, createCircuit } from "../circuit";
import { C } from "../complex";
import { simulateState } from "../simulator";
import { zeroState, applyGate, basisProbabilities } from "../statevector";
import { sampleTomographyBasis, reconstructSingleQubitDensity, tomographyReport } from "../tomography";
import { pauliExpectation, pauliWordFromLabel, pauliWordsCommute, groupCommutingPaulis, multiplyPauliWords } from "../pauli";
import { calculateCircuitMetrics, countGateFamilies, gateFrequency, gateInteractionGraph, scheduleCircuitMoments, qubitParticipation } from "../circuit-analysis";
import { marginalDistribution, projectState, probabilityOfSubspace, conditionalMarginalDistribution } from "../subspace";
import { circuitToUnitary, equivalentUpToGlobalPhase, verifyUnitary } from "../unitary";
import { identity } from "../matrix";

function plusState() {
  return applyGate(zeroState(1), { id: "h", gate: "H", targets: [0] });
}

describe("Pauli observables", () => {
  it("parses valid Pauli strings", () => {
    expect(pauliWordFromLabel("xYz")).toEqual(["X", "Y", "Z"]);
  });

  it("rejects invalid Pauli strings", () => {
    expect(() => pauliWordFromLabel("AXB")).toThrow();
    expect(() => pauliWordFromLabel("")).toThrow();
  });

  it("measures X expectation of the plus state as +1", () => {
    expect(pauliExpectation(plusState(), ["X"])).toBeCloseTo(1, 10);
  });

  it("measures Z expectation of the plus state as zero", () => {
    expect(pauliExpectation(plusState(), ["Z"])).toBeCloseTo(0, 10);
  });

  it("measures a two-qubit ZZ Bell correlation as +1", () => {
    let circuit = createCircuit(2);
    circuit = appendGate(circuit, "H", [0]);
    circuit = appendGate(circuit, "CX", [1], [0]);
    expect(pauliExpectation(simulateState(circuit), ["Z", "Z"])).toBeCloseTo(1, 10);
  });

  it("identifies commuting and anticommuting Pauli words", () => {
    expect(pauliWordsCommute(["X", "I"], ["Z", "I"])).toBe(false);
    expect(pauliWordsCommute(["X", "X"], ["Z", "Z"])).toBe(true);
    expect(pauliWordsCommute(["X", "Y"], ["Z", "Z"])).toBe(true);
  });

  it("multiplies Pauli words with the correct phase", () => {
    const product = multiplyPauliWords(["X"], ["Y"]);
    expect(product.word).toEqual(["Z"]);
    expect(product.phase.re).toBeCloseTo(0, 10);
    expect(product.phase.im).toBeCloseTo(1, 10);
  });

  it("groups mutually commuting observables", () => {
    const groups = groupCommutingPaulis([["X", "I"], ["I", "Z"], ["Z", "Z"]]);
    expect(groups.flat().length).toBe(3);
    groups.forEach((group) => group.forEach((a) => group.forEach((b) => expect(pauliWordsCommute(a, b)).toBe(true))));
  });
});

describe("single-qubit quantum tomography", () => {
  it("reconstructs |0> from noiseless Z and X/Y measurements", () => {
    const state = zeroState(1);
    const estimates = (["X", "Y", "Z"] as const).map((basis) => sampleTomographyBasis(state, 0, basis, 10000, () => 0.01));
    const reconstructed = reconstructSingleQubitDensity(estimates);
    expect(reconstructed.bloch.z).toBeCloseTo(1, 10);
    expect(reconstructed.purity).toBeCloseTo(1, 10);
  });

  it("reconstructs the |+i> Y-axis state", () => {
    let state = zeroState(1);
    state = applyGate(state, { id: "h", gate: "H", targets: [0] });
    state = applyGate(state, { id: "s", gate: "S", targets: [0] });
    const estimates = (["X", "Y", "Z"] as const).map((basis) => sampleTomographyBasis(state, 0, basis, 10000, () => 0.01));
    const reconstructed = reconstructSingleQubitDensity(estimates);
    expect(reconstructed.bloch.y).toBeCloseTo(1, 9);
  });

  it("reports the purity and Bloch radius of an estimate", () => {
    const state = zeroState(1);
    const estimates = (["X", "Y", "Z"] as const).map((basis) => sampleTomographyBasis(state, 0, basis, 5000, () => 0.01));
    const report = tomographyReport(reconstructSingleQubitDensity(estimates));
    expect(report.purityLabel).toBe("Nearly pure");
    expect(report.blochRadius).toBeCloseTo(1, 10);
  });
});

describe("circuit metrics and moments", () => {
  it("schedules independent gates into the same moment", () => {
    let circuit = createCircuit(2);
    circuit = appendGate(circuit, "H", [0]);
    circuit = appendGate(circuit, "X", [1]);
    const moments = scheduleCircuitMoments(circuit);
    expect(moments).toHaveLength(1);
    expect(moments[0].instructionIds).toHaveLength(2);
  });

  it("schedules dependent gates in successive moments", () => {
    let circuit = createCircuit(1);
    circuit = appendGate(circuit, "H", [0]);
    circuit = appendGate(circuit, "X", [0]);
    expect(scheduleCircuitMoments(circuit)).toHaveLength(2);
  });

  it("calculates basic gate metrics", () => {
    let circuit = createCircuit(3);
    circuit = appendGate(circuit, "H", [0]);
    circuit = appendGate(circuit, "CX", [1], [0]);
    const metrics = calculateCircuitMetrics(circuit);
    expect(metrics.qubits).toBe(3);
    expect(metrics.unitaryGates).toBe(2);
    expect(metrics.oneQubitGates).toBe(1);
    expect(metrics.controlledGates).toBe(1);
    expect(metrics.idleQubits).toEqual([2]);
  });

  it("counts gate families and specific gates", () => {
    let circuit = createCircuit(2);
    circuit = appendGate(circuit, "H", [0]);
    circuit = appendGate(circuit, "RY", [1], [], { theta: 0.3 });
    circuit = appendGate(circuit, "CX", [1], [0]);
    expect(countGateFamilies(circuit)).toEqual({ single: 1, rotation: 1, controlled: 1 });
    expect(gateFrequency(circuit).CX).toBe(1);
  });

  it("counts participation for each qubit", () => {
    let circuit = createCircuit(3);
    circuit = appendGate(circuit, "H", [0]);
    circuit = appendGate(circuit, "CX", [1], [0]);
    expect(qubitParticipation(circuit)).toEqual([2, 1, 0]);
  });

  it("builds an interaction graph from multi-qubit operations", () => {
    let circuit = createCircuit(3);
    circuit = appendGate(circuit, "CX", [1], [0]);
    circuit = appendGate(circuit, "CX", [2], [0]);
    const graph = gateInteractionGraph(circuit);
    expect(graph).toEqual([{ source: 0, target: 1, weight: 1 }, { source: 0, target: 2, weight: 1 }]);
  });
});

describe("subspace projection and marginal distributions", () => {
  it("computes a one-qubit marginal from a Bell pair", () => {
    let state = zeroState(2);
    state = applyGate(state, { id: "h", gate: "H", targets: [0] });
    state = applyGate(state, { id: "cx", gate: "CX", controls: [0], targets: [1] });
    expect(marginalDistribution(state, [0])).toEqual([0.5, 0.5]);
    expect(marginalDistribution(state, [1])).toEqual([0.5, 0.5]);
  });

  it("postselects a Bell pair and normalizes the conditional state", () => {
    let state = zeroState(2);
    state = applyGate(state, { id: "h", gate: "H", targets: [0] });
    state = applyGate(state, { id: "cx", gate: "CX", controls: [0], targets: [1] });
    const projected = projectState(state, [0], [1]);
    expect(projected.successProbability).toBeCloseTo(0.5, 10);
    expect(basisProbabilities(projected.state)[3]).toBeCloseTo(1, 10);
  });

  it("computes the probability of a parity subspace", () => {
    let state = zeroState(2);
    state = applyGate(state, { id: "h", gate: "H", targets: [0] });
    state = applyGate(state, { id: "cx", gate: "CX", controls: [0], targets: [1] });
    expect(probabilityOfSubspace(state, [0, 1], [0, 0])).toBeCloseTo(0.5, 10);
  });

  it("computes conditional marginals", () => {
    let state = zeroState(2);
    state = applyGate(state, { id: "h", gate: "H", targets: [0] });
    state = applyGate(state, { id: "cx", gate: "CX", controls: [0], targets: [1] });
    const result = conditionalMarginalDistribution(state, [1], [0], [1]);
    expect(result.conditionProbability).toBeCloseTo(0.5, 10);
    expect(result.probabilities).toEqual([0, 1]);
  });
});

describe("unitary extraction and verification", () => {
  it("extracts a unitary matrix for a Hadamard circuit", () => {
    const circuit = appendGate(createCircuit(1), "H", [0]);
    const matrix = circuitToUnitary(circuit);
    expect(verifyUnitary(matrix).isUnitary).toBe(true);
    expect(matrix.length).toBe(2);
  });

  it("verifies identity matrices", () => {
    expect(verifyUnitary(identity(4)).maxDeviation).toBeCloseTo(0, 12);
  });

  it("detects a matrix that is not unitary", () => {
    const notUnitary = [[C(2), C(0)], [C(0), C(1)]];
    expect(verifyUnitary(notUnitary).isUnitary).toBe(false);
  });

  it("rejects extracting a unitary from a measured circuit", () => {
    const circuit = { ...createCircuit(1), instructions: [{ type: "measure" as const, id: "m", qubits: [0], classicalBits: [0] }] };
    expect(() => circuitToUnitary(circuit)).toThrow();
  });

  it("recognizes equivalent unitary circuits up to global phase", () => {
    const a = appendGate(createCircuit(1), "X", [0]);
    let b = appendGate(createCircuit(1), "X", [0]);
    b = appendGate(b, "P", [0], [], { theta: 2 * Math.PI });
    expect(equivalentUpToGlobalPhase(a, b)).toBe(true);
  });
});
