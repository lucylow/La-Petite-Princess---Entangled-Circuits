// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { describe, expect, it } from "vitest";
import { appendGate, createCircuit, validateCircuit } from "../circuit";
import { applyGate, basisProbabilities, zeroState } from "../statevector";
import { optimizeCircuit, estimateCircuitCost } from "../optimizer";
import { decomposeControlledZ, decomposeFredkin, decomposeSwap, decomposeToffoli, compileToCliffordT, invertCircuit } from "../compiler";
import { routeCircuitToCouplingMap, lineCouplingMap, ringCouplingMap, shortestPath } from "../routing";
import { simulateState } from "../simulator";
import { equivalentUpToGlobalPhase, stateFidelity } from "../unitary";
import type { GateOperation } from "../gates";
import type { CircuitInstruction } from "../circuit";

function evolve(qubits: number, input: number, operations: Array<GateOperation | CircuitInstruction>) {
  let state = zeroState(qubits);
  for (let bit = 0; bit < qubits; bit += 1) if ((input >> bit) & 1) state = applyGate(state, { id: `input-${bit}`, gate: "X", targets: [bit] });
  return operations.reduce((current, operation) => {
    if ("type" in operation && operation.type !== "gate") throw new Error("Composite decomposition unexpectedly contained a non-gate instruction.");
    const gateOperation = "type" in operation ? operation : operation;
    return applyGate(current, gateOperation as GateOperation);
  }, state);
}

function mostLikelyBasis(probabilities: number[]): number {
  return probabilities.reduce((best, value, index) => value > probabilities[best] ? index : best, 0);
}

describe("exact composite-gate decomposition", () => {
  it("decomposes SWAP into three controlled-X operations", () => {
    const operations = decomposeSwap(0, 1);
    expect(operations).toHaveLength(3);
    for (let input = 0; input < 4; input += 1) {
      const state = evolve(2, input, operations);
      const expected = ((input & 1) << 1) | ((input & 2) >> 1);
      expect(mostLikelyBasis(basisProbabilities(state))).toBe(expected);
    }
  });

  it("decomposes controlled-Z with Hadamard conjugation", () => {
    const operations = decomposeControlledZ(0, 1);
    for (let input = 0; input < 4; input += 1) {
      const decomposed = evolve(2, input, operations);
      const direct = applyGate(evolve(2, input, []), { id: "cz", gate: "CZ", controls: [0], targets: [1] });
      expect(stateFidelity(decomposed, direct)).toBeCloseTo(1, 9);
    }
  });

  it("decomposes Toffoli correctly for all eight computational inputs", () => {
    const operations = decomposeToffoli(0, 1, 2);
    expect(operations).toHaveLength(15);
    for (let input = 0; input < 8; input += 1) {
      const decomposed = evolve(3, input, operations);
      const direct = applyGate(evolve(3, input, []), { id: "ccx", gate: "CCX", controls: [0, 1], targets: [2] });
      expect(stateFidelity(decomposed, direct)).toBeCloseTo(1, 9);
    }
  });

  it("decomposes Fredkin correctly for all eight computational inputs", () => {
    const operations = decomposeFredkin(0, 1, 2);
    for (let input = 0; input < 8; input += 1) {
      const decomposed = evolve(3, input, operations);
      const direct = applyGate(evolve(3, input, []), { id: "cswap", gate: "CSWAP", controls: [0], targets: [1, 2] });
      expect(stateFidelity(decomposed, direct)).toBeCloseTo(1, 9);
    }
  });

  it("compiles SWAP, CZ, CCX and CSWAP into the advertised basis", () => {
    let circuit = createCircuit(3, "Composite gates");
    circuit = appendGate(circuit, "SWAP", [0, 1]);
    circuit = appendGate(circuit, "CZ", [2], [1]);
    circuit = appendGate(circuit, "CCX", [2], [0, 1]);
    circuit = appendGate(circuit, "CSWAP", [1, 2], [0]);
    const compiled = compileToCliffordT(circuit);
    const forbidden = compiled.circuit.instructions.filter((item) => item.type === "gate" && ["SWAP", "CZ", "CCX", "CSWAP"].includes(item.gate));
    expect(forbidden).toHaveLength(0);
    expect(compiled.compiledGateCount).toBeGreaterThan(compiled.originalGateCount);
  });

  it("warns when continuous rotations remain unsynthesized", () => {
    const circuit = appendGate(createCircuit(1), "RY", [0], [], { theta: 0.314 });
    const result = compileToCliffordT(circuit);
    expect(result.warnings.join(" ")).toContain("parameterized");
  });

  it("inverts a mixed single-qubit gate sequence", () => {
    let circuit = createCircuit(1);
    circuit = appendGate(circuit, "H", [0]);
    circuit = appendGate(circuit, "RZ", [0], [], { theta: 0.77 });
    circuit = appendGate(circuit, "S", [0]);
    const combined = { ...circuit, instructions: [...circuit.instructions, ...invertCircuit(circuit).instructions] };
    expect(basisProbabilities(simulateState(combined))[0]).toBeCloseTo(1, 8);
  });

  it("inverts a controlled phase gate", () => {
    let circuit = createCircuit(2);
    circuit = appendGate(circuit, "H", [0]);
    circuit = appendGate(circuit, "CP", [1], [0], { theta: Math.PI / 3 });
    const inverse = invertCircuit(circuit);
    const combined = { ...circuit, instructions: [...circuit.instructions, ...inverse.instructions] };
    expect(basisProbabilities(simulateState(combined))[0]).toBeCloseTo(1, 8);
  });
});

describe("circuit optimizer", () => {
  it("removes adjacent self-inverse pairs", () => {
    let circuit = createCircuit(1);
    circuit = appendGate(circuit, "H", [0]);
    circuit = appendGate(circuit, "H", [0]);
    const result = optimizeCircuit(circuit);
    expect(result.circuit.instructions).toHaveLength(0);
  });

  it("merges adjacent rotations around the same axis", () => {
    let circuit = createCircuit(1);
    circuit = appendGate(circuit, "RX", [0], [], { theta: 0.2 });
    circuit = appendGate(circuit, "RX", [0], [], { theta: 0.4 });
    const result = optimizeCircuit(circuit);
    expect(result.circuit.instructions).toHaveLength(1);
    const gate = result.circuit.instructions[0];
    expect(gate.type).toBe("gate");
    if (gate.type === "gate") expect(gate.params?.theta).toBeCloseTo(0.6, 10);
  });

  it("removes a rotation pair that sums to a full turn", () => {
    let circuit = createCircuit(1);
    circuit = appendGate(circuit, "RZ", [0], [], { theta: Math.PI });
    circuit = appendGate(circuit, "RZ", [0], [], { theta: Math.PI });
    expect(optimizeCircuit(circuit).circuit.instructions).toHaveLength(0);
  });

  it("does not cancel gates on different wires", () => {
    let circuit = createCircuit(2);
    circuit = appendGate(circuit, "H", [0]);
    circuit = appendGate(circuit, "H", [1]);
    expect(optimizeCircuit(circuit).circuit.instructions).toHaveLength(2);
  });

  it("does not cancel non-adjacent inverse gates across a noncommuting operation", () => {
    let circuit = createCircuit(1);
    circuit = appendGate(circuit, "H", [0]);
    circuit = appendGate(circuit, "X", [0]);
    circuit = appendGate(circuit, "H", [0]);
    expect(optimizeCircuit(circuit).circuit.instructions).toHaveLength(3);
  });

  it("preserves the output state when optimizing a circuit", () => {
    let circuit = createCircuit(2);
    circuit = appendGate(circuit, "H", [0]);
    circuit = appendGate(circuit, "X", [1]);
    circuit = appendGate(circuit, "X", [1]);
    circuit = appendGate(circuit, "RZ", [0], [], { theta: 0.3 });
    circuit = appendGate(circuit, "RZ", [0], [], { theta: -0.3 });
    const optimized = optimizeCircuit(circuit).circuit;
    expect(equivalentUpToGlobalPhase(circuit, optimized)).toBe(true);
  });

  it("estimates two-qubit operations at a higher synthetic cost", () => {
    let circuit = createCircuit(2);
    circuit = appendGate(circuit, "H", [0]);
    circuit = appendGate(circuit, "CX", [1], [0]);
    const cost = estimateCircuitCost(circuit);
    expect(cost.twoQubit).toBe(1);
    expect(cost.oneQubit).toBe(1);
    expect(cost.total).toBeGreaterThan(cost.oneQubit + cost.twoQubit);
  });
});

describe("hardware connectivity routing", () => {
  it("finds a shortest path along a line graph", () => {
    expect(shortestPath(lineCouplingMap(5), 0, 4)).toEqual([0, 1, 2, 3, 4]);
    expect(shortestPath(lineCouplingMap(5), 2, 4)).toEqual([2, 3, 4]);
  });

  it("uses the wraparound edge on a ring", () => {
    expect(shortestPath(ringCouplingMap(5), 0, 4)).toEqual([0, 4]);
  });

  it("rejects disconnected coupling maps", () => {
    expect(() => shortestPath({ qubits: 3, edges: [[0, 1]] }, 0, 2)).toThrow(/No route/);
  });

  it("inserts SWAPs for a nonadjacent controlled gate", () => {
    const circuit = appendGate(createCircuit(4), "CX", [3], [0]);
    const routed = routeCircuitToCouplingMap(circuit, lineCouplingMap(4));
    expect(routed.insertedSwaps).toBeGreaterThan(0);
    expect(routed.circuit.instructions.length).toBeGreaterThan(circuit.instructions.length);
  });

  it("preserves a logical-to-physical layout mapping", () => {
    const circuit = appendGate(createCircuit(3), "CX", [2], [0]);
    const routed = routeCircuitToCouplingMap(circuit, lineCouplingMap(3));
    expect(routed.logicalToPhysical).toHaveLength(3);
    expect(new Set(routed.logicalToPhysical).size).toBe(3);
  });

  it("keeps measurement qubits aligned with the routed layout", () => {
    let circuit = appendGate(createCircuit(3), "CX", [2], [0]);
    circuit = { ...circuit, instructions: [...circuit.instructions, { type: "measure", id: "measure-0", qubits: [0, 2], classicalBits: [0, 2] }] };
    const routed = routeCircuitToCouplingMap(circuit, lineCouplingMap(3));
    const last = routed.circuit.instructions[routed.circuit.instructions.length - 1];
    expect(last.type).toBe("measure");
    if (last.type === "measure") expect(last.qubits).toEqual([routed.logicalToPhysical[0], routed.logicalToPhysical[2]]);
  });

  it("rejects an undersized hardware map", () => {
    expect(() => routeCircuitToCouplingMap(createCircuit(4), lineCouplingMap(3))).toThrow();
  });
});

describe("circuit validation and unitary equivalence", () => {
  it("returns no errors for a valid Bell circuit", () => {
    const circuit = appendGate(appendGate(createCircuit(2), "H", [0]), "CX", [1], [0]);
    expect(validateCircuit(circuit).filter((issue) => issue.severity === "error")).toHaveLength(0);
  });

  it("finds duplicated instruction identifiers", () => {
    const circuit = createCircuit(1);
    const operation = { type: "gate" as const, id: "same", gate: "X" as const, targets: [0], controls: [] };
    const duplicate = { ...circuit, instructions: [operation, { ...operation }] };
    expect(validateCircuit(duplicate).some((issue) => issue.code === "DUPLICATE_INSTRUCTION_ID")).toBe(true);
  });

  it("computes unitary equivalence up to global phase", () => {
    let a = createCircuit(1);
    a = appendGate(a, "H", [0]);
    let b = createCircuit(1);
    b = appendGate(b, "H", [0]);
    b = appendGate(b, "P", [0], [], { theta: 2 * Math.PI });
    expect(equivalentUpToGlobalPhase(a, b)).toBe(true);
  });
});
