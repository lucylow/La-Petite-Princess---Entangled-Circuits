// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { describe, expect, it } from "vitest";
import { C } from "../complex";
import { appendGate, createCircuit } from "../circuit";
import { GATE_DEFINITIONS, type GateId } from "../gates";
import { applyGate, basisProbabilities, basisState, blochVector, measureAll, measureQubit, stateAsTerms, stateNormSquared, zeroState } from "../statevector";
import { simulateState, simulateCircuitShot, runShots } from "../simulator";
import { prepareBasisState, prepareProductState, prepareSingleQubitState, prepareUniformSuperposition } from "../state-preparation";
import { stateQubitBlochCoordinates } from "../bloch";

function addGate(circuit: ReturnType<typeof createCircuit>, gate: GateId, targets: number[], controls: number[] = [], theta = Math.PI / 2) {
  return appendGate(circuit, gate, targets, controls, { theta });
}

function assertNormalized(probabilities: number[], tolerance = 1e-9): void {
  expect(probabilities.reduce((sum, value) => sum + value, 0)).toBeCloseTo(1, Math.round(-Math.log10(tolerance)));
}

describe("state-vector foundations", () => {
  it("starts in the computational zero state", () => {
    const state = zeroState(3);
    expect(state.qubits).toBe(3);
    expect(state.amplitudes).toHaveLength(8);
    expect(state.amplitudes[0]).toEqual(C(1));
    expect(stateNormSquared(state)).toBeCloseTo(1, 12);
  });

  it("creates exact computational basis states without retaining |0> amplitude", () => {
    for (let index = 0; index < 8; index += 1) {
      const state = basisState(3, index);
      expect(basisProbabilities(state)[index]).toBeCloseTo(1, 12);
      expect(basisProbabilities(state).reduce((sum, value) => sum + value, 0)).toBeCloseTo(1, 12);
      expect(basisProbabilities(state).filter((probability) => probability > 1e-12)).toHaveLength(1);
    }
  });

  it("rejects unsupported state sizes", () => {
    expect(() => zeroState(0)).toThrow();
    expect(() => zeroState(17)).toThrow();
    expect(() => zeroState(1.5)).toThrow();
  });

  it("normalizes a Hadamard superposition", () => {
    const circuit = addGate(createCircuit(1), "H", [0]);
    const state = simulateState(circuit);
    const probabilities = basisProbabilities(state);
    expect(probabilities[0]).toBeCloseTo(0.5, 12);
    expect(probabilities[1]).toBeCloseTo(0.5, 12);
    assertNormalized(probabilities);
  });

  it("applies Pauli-X as a bit flip", () => {
    const state = applyGate(zeroState(1), { id: "x", gate: "X", targets: [0] });
    expect(basisProbabilities(state)).toEqual([0, 1]);
  });

  it("applies Pauli-Y with the expected imaginary phase", () => {
    const state = applyGate(zeroState(1), { id: "y", gate: "Y", targets: [0] });
    expect(state.amplitudes[0].re).toBeCloseTo(0, 12);
    expect(state.amplitudes[0].im).toBeCloseTo(0, 12);
    expect(state.amplitudes[1].re).toBeCloseTo(0, 12);
    expect(state.amplitudes[1].im).toBeCloseTo(1, 12);
  });

  it("applies Pauli-Z as a phase flip without changing probabilities", () => {
    let state = zeroState(1);
    state = applyGate(state, { id: "h", gate: "H", targets: [0] });
    state = applyGate(state, { id: "z", gate: "Z", targets: [0] });
    expect(state.amplitudes[0].re).toBeCloseTo(1 / Math.sqrt(2), 12);
    expect(state.amplitudes[1].re).toBeCloseTo(-1 / Math.sqrt(2), 12);
    expect(basisProbabilities(state)).toEqual(expect.arrayContaining([0.5, 0.5]));
  });

  it("applies Hadamard twice as identity", () => {
    let circuit = createCircuit(1);
    circuit = addGate(circuit, "H", [0]);
    circuit = addGate(circuit, "H", [0]);
    const state = simulateState(circuit);
    expect(basisProbabilities(state)[0]).toBeCloseTo(1, 12);
    expect(basisProbabilities(state)[1]).toBeCloseTo(0, 12);
  });

  it("applies S and S dagger as inverses", () => {
    let circuit = createCircuit(1);
    circuit = addGate(circuit, "H", [0]);
    circuit = addGate(circuit, "S", [0]);
    circuit = addGate(circuit, "SDG", [0]);
    circuit = addGate(circuit, "H", [0]);
    expect(basisProbabilities(simulateState(circuit))[0]).toBeCloseTo(1, 12);
  });

  it("applies T and T dagger as inverses", () => {
    let circuit = createCircuit(1);
    circuit = addGate(circuit, "H", [0]);
    circuit = addGate(circuit, "T", [0]);
    circuit = addGate(circuit, "TDG", [0]);
    circuit = addGate(circuit, "H", [0]);
    expect(basisProbabilities(simulateState(circuit))[0]).toBeCloseTo(1, 12);
  });

  it("preserves norm under all declared single-qubit gates", () => {
    const singles = GATE_DEFINITIONS.filter((definition) => definition.targetCount === 1 && definition.controlCount === 0);
    for (const definition of singles) {
      let state = zeroState(1);
      state = applyGate(state, { id: `h-${definition.id}`, gate: "H", targets: [0] });
      state = applyGate(state, { id: `gate-${definition.id}`, gate: definition.id, targets: [0], params: { theta: 0.713, phi: -0.2, lambda: 0.4 } });
      expect(stateNormSquared(state)).toBeCloseTo(1, 9);
    }
  });

  it("rejects applying a gate to an invalid qubit", () => {
    expect(() => applyGate(zeroState(1), { id: "bad", gate: "X", targets: [1] })).toThrow(/outside/);
    expect(() => applyGate(zeroState(1), { id: "bad", gate: "X", targets: [-1] })).toThrow(/outside/);
  });

  it("rejects repeated target and control wires", () => {
    expect(() => applyGate(zeroState(2), { id: "bad", gate: "CX", targets: [0], controls: [0] })).toThrow();
    expect(() => applyGate(zeroState(3), { id: "bad", gate: "CCX", targets: [2], controls: [0, 0] })).toThrow();
  });

  it("creates an equal two-qubit Bell distribution", () => {
    let circuit = createCircuit(2);
    circuit = addGate(circuit, "H", [0]);
    circuit = addGate(circuit, "CX", [1], [0]);
    const probabilities = basisProbabilities(simulateState(circuit));
    expect(probabilities[0]).toBeCloseTo(0.5, 12);
    expect(probabilities[3]).toBeCloseTo(0.5, 12);
    expect(probabilities[1]).toBeCloseTo(0, 12);
    expect(probabilities[2]).toBeCloseTo(0, 12);
  });

  it("measures a deterministic |0> qubit as zero", () => {
    const result = measureQubit(zeroState(1), 0, 0.99);
    expect(result.outcome).toBe(0);
    expect(result.probability).toBeCloseTo(1, 12);
    expect(basisProbabilities(result.state)).toEqual([1, 0]);
  });

  it("measures a deterministic |1> qubit as one", () => {
    const state = applyGate(zeroState(1), { id: "x", gate: "X", targets: [0] });
    const result = measureQubit(state, 0, 0.01);
    expect(result.outcome).toBe(1);
    expect(result.probability).toBeCloseTo(1, 12);
  });

  it("collapses a Bell pair consistently after measuring q0", () => {
    let state = zeroState(2);
    state = applyGate(state, { id: "h", gate: "H", targets: [0] });
    state = applyGate(state, { id: "cx", gate: "CX", controls: [0], targets: [1] });
    const result = measureQubit(state, 0, 0.1);
    expect(result.outcome).toBe(0);
    expect(basisProbabilities(result.state)[0]).toBeCloseTo(1, 12);
    const other = measureQubit(state, 0, 0.9);
    expect(other.outcome).toBe(1);
    expect(basisProbabilities(other.state)[3]).toBeCloseTo(1, 12);
  });

  it("samples a basis state from a supplied random draw", () => {
    const state = applyGate(zeroState(2), { id: "h", gate: "H", targets: [1] });
    expect(measureAll(state, 0.1).bitString).toBe("00");
    expect(measureAll(state, 0.9).bitString).toBe("10");
  });

  it("reports state terms in basis order", () => {
    const state = simulateState(addGate(createCircuit(1), "H", [0]));
    const terms = stateAsTerms(state);
    expect(terms.map((term) => term.basis)).toEqual(["|0⟩", "|1⟩"]);
    expect(terms.every((term) => term.probability > 0)).toBe(true);
  });

  it("computes north and south pole Bloch vectors", () => {
    expect(blochVector(zeroState(1), 0)).toEqual({ x: 0, y: 0, z: 1 });
    const one = applyGate(zeroState(1), { id: "x", gate: "X", targets: [0] });
    expect(blochVector(one, 0)).toEqual({ x: 0, y: 0, z: -1 });
  });

  it("computes the equatorial plus-state Bloch vector", () => {
    const state = simulateState(addGate(createCircuit(1), "H", [0]));
    const vector = stateQubitBlochCoordinates(state, 0);
    expect(vector.x).toBeCloseTo(1, 10);
    expect(vector.y).toBeCloseTo(0, 10);
    expect(vector.z).toBeCloseTo(0, 10);
  });
});

describe("state preparation helpers", () => {
  it("prepares a computational basis bit string", () => {
    const state = simulateState(prepareBasisState("1010"));
    expect(basisProbabilities(state)[10]).toBeCloseTo(1, 12);
  });

  it("prepares all-zero basis state from zero bits", () => {
    const state = simulateState(prepareBasisState("000"));
    expect(basisProbabilities(state)[0]).toBeCloseTo(1, 12);
  });

  it("rejects an invalid basis string", () => {
    expect(() => prepareBasisState("10x1")).toThrow();
    expect(() => prepareBasisState("")).toThrow();
  });

  it("prepares a uniform three-qubit superposition", () => {
    const probabilities = basisProbabilities(simulateState(prepareUniformSuperposition(3)));
    expect(probabilities).toHaveLength(8);
    probabilities.forEach((probability) => expect(probability).toBeCloseTo(1 / 8, 12));
  });

  it("prepares a single-qubit Bloch state with the requested polar angle", () => {
    const state = simulateState(prepareSingleQubitState({ theta: Math.PI / 2, phi: 0 }));
    const vector = blochVector(state, 0);
    expect(vector.x).toBeCloseTo(1, 10);
    expect(vector.y).toBeCloseTo(0, 10);
    expect(vector.z).toBeCloseTo(0, 10);
  });

  it("prepares a product state with independent qubit angles", () => {
    const state = simulateState(prepareProductState([
      { theta: 0, phi: 0 },
      { theta: Math.PI, phi: 0 },
    ]));
    expect(basisProbabilities(state)[2]).toBeCloseTo(1, 10);
  });

  it("rejects non-finite Bloch angles", () => {
    expect(() => prepareSingleQubitState({ theta: Number.NaN, phi: 0 })).toThrow();
    expect(() => prepareProductState([{ theta: 0, phi: Infinity }])).toThrow();
  });
});

describe("shot simulation interface", () => {
  it("returns deterministic counts for a deterministic circuit", () => {
    const circuit = appendGate(createCircuit(2), "X", [1]);
    const result = runShots(circuit, { shots: 100, seed: 7 });
    expect(result.counts).toEqual({ "10": 100 });
    expect(result.probabilities["10"]).toBe(1);
  });

  it("returns reproducible sampling with a fixed seed", () => {
    const circuit = appendGate(createCircuit(2), "H", [0]);
    const first = runShots(circuit, { shots: 512, seed: 99 });
    const second = runShots(circuit, { shots: 512, seed: 99 });
    expect(first.counts).toEqual(second.counts);
  });

  it("keeps the requested number of shots", () => {
    const result = runShots(createCircuit(1), { shots: 73, seed: 1 });
    expect(Object.values(result.counts).reduce((sum, value) => sum + value, 0)).toBe(73);
  });

  it("rejects invalid shot counts", () => {
    expect(() => runShots(createCircuit(1), { shots: 0 })).toThrow();
    expect(() => runShots(createCircuit(1), { shots: -2 })).toThrow();
    expect(() => runShots(createCircuit(1), { shots: 1.5 })).toThrow();
  });

  it("reports a final state measurement when no explicit measurement is present", () => {
    const result = simulateCircuitShot(appendGate(createCircuit(1), "X", [0]), () => 0.25);
    expect(result.memory).toBe("1");
  });
});
