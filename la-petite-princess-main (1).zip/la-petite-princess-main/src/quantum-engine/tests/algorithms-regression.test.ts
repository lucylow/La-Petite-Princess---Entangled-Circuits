// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { describe, expect, it } from "vitest";
import { createCircuit } from "../circuit";
import { basisProbabilities, applyGate, zeroState } from "../statevector";
import { simulateCircuitShot } from "../simulator";
import { runShots, simulateState } from "../simulator";
import {
  bellCircuit,
  ghzCircuit,
  wStateCircuit,
  qftCircuit,
  groverCircuit,
  deutschJozsaCircuit,
  bernsteinVaziraniCircuit,
  teleportationCircuit,
  phaseEstimationCircuit,
  qaoaMaxCutCircuit,
  makeTeachingCircuit,
} from "../algorithms";
import { pureTwoQubitConcurrence, entanglementEntropyOfQubit } from "../entanglement";
import { C } from "../complex";
import { partialTrace, densityFromState, fidelityPureToDensity } from "../density";

function basisState(qubits: number, index: number) {
  const state = zeroState(qubits);
  state.amplitudes.fill(C(0));
  state.amplitudes[index] = C(1);
  return state;
}

function concatenate(...circuits: ReturnType<typeof createCircuit>[]) {
  const qubits = Math.max(...circuits.map((circuit) => circuit.qubits));
  const instructions = circuits.flatMap((circuit) => circuit.instructions.map((instruction, index) => ({ ...instruction, id: `${circuit.id}-${index}-${instruction.id}` })));
  return { ...createCircuit(qubits, "Composed test circuit"), instructions };
}

describe("Bell and multipartite state constructors", () => {
  it("creates the phi-plus Bell state", () => {
    const state = simulateState(bellCircuit("phi-plus"));
    const probabilities = basisProbabilities(state);
    expect(probabilities[0]).toBeCloseTo(0.5, 10);
    expect(probabilities[3]).toBeCloseTo(0.5, 10);
    expect(pureTwoQubitConcurrence(state)).toBeCloseTo(1, 10);
  });

  it("creates the phi-minus Bell state with negative relative phase", () => {
    const state = simulateState(bellCircuit("phi-minus"));
    expect(state.amplitudes[0].re).toBeCloseTo(1 / Math.sqrt(2), 10);
    expect(state.amplitudes[3].re).toBeCloseTo(-1 / Math.sqrt(2), 10);
    expect(pureTwoQubitConcurrence(state)).toBeCloseTo(1, 10);
  });

  it("creates the psi-plus Bell state", () => {
    const state = simulateState(bellCircuit("psi-plus"));
    const probabilities = basisProbabilities(state);
    expect(probabilities[1] + probabilities[2]).toBeCloseTo(1, 10);
    expect(probabilities[0] + probabilities[3]).toBeCloseTo(0, 10);
    expect(pureTwoQubitConcurrence(state)).toBeCloseTo(1, 10);
  });

  it("creates the psi-minus Bell state", () => {
    const state = simulateState(bellCircuit("psi-minus"));
    expect(state.amplitudes[1].re).toBeCloseTo(1 / Math.sqrt(2), 10);
    expect(state.amplitudes[2].re).toBeCloseTo(-1 / Math.sqrt(2), 10);
  });

  it("creates GHZ states with only all-zero and all-one support", () => {
    for (const qubits of [2, 3, 4, 5]) {
      const probabilities = basisProbabilities(simulateState(ghzCircuit(qubits)));
      expect(probabilities[0]).toBeCloseTo(0.5, 9);
      expect(probabilities[probabilities.length - 1]).toBeCloseTo(0.5, 9);
      probabilities.slice(1, -1).forEach((probability) => expect(probability).toBeCloseTo(0, 9));
    }
  });

  it("rejects unsupported GHZ sizes", () => {
    expect(() => ghzCircuit(1)).toThrow();
    expect(() => ghzCircuit(13)).toThrow();
  });

  it("creates a three-qubit W state with equal one-excitation probabilities", () => {
    const probabilities = basisProbabilities(simulateState(wStateCircuit(3)));
    expect(probabilities[1]).toBeCloseTo(1 / 3, 9);
    expect(probabilities[2]).toBeCloseTo(1 / 3, 9);
    expect(probabilities[4]).toBeCloseTo(1 / 3, 9);
    expect(probabilities.reduce((sum, value) => sum + value, 0)).toBeCloseTo(1, 9);
  });

  it("creates W states with equal excitation support for larger registers", () => {
    for (const qubits of [4, 5, 6]) {
      const probabilities = basisProbabilities(simulateState(wStateCircuit(qubits)));
      const support = probabilities.map((value, index) => ({ value, index })).filter((item) => item.value > 1e-8);
      expect(support).toHaveLength(qubits);
      support.forEach((item) => expect(item.value).toBeCloseTo(1 / qubits, 8));
    }
  });
});

describe("quantum Fourier transform", () => {
  it("is inverted by its inverse on selected computational basis states", () => {
    for (const input of [0, 1, 3, 5, 7]) {
      const prepared = basisState(3, input);
      const prepCircuit = createCircuit(3, "Input basis");
      const gates = Array.from({ length: 3 }, (_, qubit) => ({
        type: "gate" as const,
        id: `x-${qubit}`,
        gate: "X" as const,
        targets: [qubit],
        controls: [],
      })).filter((operation) => (input >> operation.targets[0]) & 1);
      const circuit = { ...prepCircuit, instructions: [...gates, ...qftCircuit(3).instructions, ...qftCircuit(3, true).instructions] };
      const final = simulateState(circuit);
      expect(basisProbabilities(final)[input]).toBeCloseTo(1, 8);
      expect(prepared.qubits).toBe(3);
    }
  });

  it("returns a normalized state after a forward transform", () => {
    const state = simulateState(qftCircuit(4));
    expect(basisProbabilities(state).reduce((sum, value) => sum + value, 0)).toBeCloseTo(1, 9);
  });

  it("supports a one-qubit Fourier transform", () => {
    const state = simulateState(qftCircuit(1));
    expect(basisProbabilities(state)[0]).toBeCloseTo(0.5, 9);
    expect(basisProbabilities(state)[1]).toBeCloseTo(0.5, 9);
  });

  it("rejects unsupported QFT sizes", () => {
    expect(() => qftCircuit(0)).toThrow();
    expect(() => qftCircuit(9)).toThrow();
  });
});

describe("search and oracle algorithms", () => {
  it("amplifies a selected Grover item", () => {
    const state = simulateState(groverCircuit(3, 5, 2));
    expect(basisProbabilities(state)[5]).toBeGreaterThan(0.9);
  });

  it("respects a different marked Grover item", () => {
    const state = simulateState(groverCircuit(3, 2, 2));
    expect(basisProbabilities(state)[2]).toBeGreaterThan(0.9);
  });

  it("accepts a zero-round Grover circuit as a uniform state", () => {
    const probabilities = basisProbabilities(simulateState(groverCircuit(3, 3, 0)));
    probabilities.forEach((probability) => expect(probability).toBeCloseTo(1 / 8, 9));
  });

  it("rejects a marked item outside the search space", () => {
    expect(() => groverCircuit(3, 8)).toThrow();
    expect(() => groverCircuit(3, -1)).toThrow();
  });

  it("recovers the secret string in Bernstein–Vazirani", () => {
    for (const secret of ["0", "1", "0101", "1011", "111111"]) {
      const result = runShots(bernsteinVaziraniCircuit(secret), { shots: 32, seed: 9 });
      expect(Object.keys(result.counts)).toEqual([secret]);
    }
  });

  it("measures only the input register in Bernstein–Vazirani", () => {
    const circuit = bernsteinVaziraniCircuit("1011");
    expect(circuit.classicalBits).toBe(4);
    const result = runShots(circuit, { shots: 5, seed: 3 });
    expect(Object.keys(result.counts)[0]).toBe("1011");
  });

  it("distinguishes a balanced Deutsch–Jozsa oracle from a constant oracle", () => {
    const constant = runShots(deutschJozsaCircuit(3, 0), { shots: 16, seed: 3 });
    const balanced = runShots(deutschJozsaCircuit(3, 5), { shots: 16, seed: 3 });
    expect(Object.keys(constant.counts)).toEqual(["000"]);
    expect(Object.keys(balanced.counts)[0]).not.toBe("000");
  });
});

describe("phase estimation and teleportation", () => {
  it("estimates a binary-representable phase of one quarter", () => {
    const result = runShots(phaseEstimationCircuit(3, 0.25), { shots: 32, seed: 4 });
    expect(Object.keys(result.counts)).toEqual(["010"]);
  });

  it("keeps only the precision register in the classical output", () => {
    expect(phaseEstimationCircuit(4, 0.125).classicalBits).toBe(4);
  });

  it("rejects an eigenphase outside [0,1)", () => {
    expect(() => phaseEstimationCircuit(3, 1)).toThrow();
    expect(() => phaseEstimationCircuit(3, -0.1)).toThrow();
  });

  it("uses exactly two classical bits for teleportation outcomes", () => {
    expect(teleportationCircuit().classicalBits).toBe(2);
  });

  it("teleports an arbitrary input state for all four Bell-measurement branches", () => {
    const theta = 0.91;
    const phi = -0.43;
    const circuit = teleportationCircuit(theta, phi);
    let prepared = zeroState(3);
    for (const instruction of circuit.instructions.slice(0, 2)) {
      if (instruction.type === "gate") prepared = applyGate(prepared, instruction);
    }
    const expected = partialTrace(densityFromState(prepared), [0]);
    for (const drawA of [0.1, 0.9]) {
      for (const drawB of [0.1, 0.9]) {
        const draws = [drawA, drawB];
        let drawIndex = 0;
        const shot = simulateCircuitShot(circuit, () => draws[Math.min(drawIndex++, 1)]);
        const actual = partialTrace(densityFromState(shot.finalState), [2]);
        for (let row = 0; row < 2; row += 1) {
          for (let column = 0; column < 2; column += 1) {
            expect(actual.values[row][column].re).toBeCloseTo(expected.values[row][column].re, 8);
            expect(actual.values[row][column].im).toBeCloseTo(expected.values[row][column].im, 8);
          }
        }
      }
    }
  });

  it("builds QAOA Max-Cut circuits with the requested qubit register", () => {
    const circuit = qaoaMaxCutCircuit(4, 2, [0.4, 0.8], [0.2, 0.3]);
    expect(circuit.qubits).toBe(4);
    expect(circuit.instructions.filter((item) => item.type === "gate").length).toBeGreaterThan(20);
    expect(basisProbabilities(simulateState(circuit)).reduce((sum, value) => sum + value, 0)).toBeCloseTo(1, 8);
  });

  it("rejects incomplete QAOA layer parameters", () => {
    expect(() => qaoaMaxCutCircuit(3, 2, [0.2], [0.3])).toThrow();
  });

  it("provides all named teaching presets", () => {
    const names = ["bell", "ghz", "qft", "grover", "teleportation", "deutsch-jozsa", "bv", "qpe", "qaoa"] as const;
    names.forEach((name) => expect(makeTeachingCircuit(name).instructions.length).toBeGreaterThan(0));
  });
});
