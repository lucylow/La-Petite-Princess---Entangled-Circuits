// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { C, INV_SQRT2, cExpI, type Complex } from "./complex";
import type { Matrix } from "./matrix";

export type GateId =
  | "I" | "X" | "Y" | "Z" | "H" | "S" | "SDG" | "T" | "TDG" | "SX" | "SXDG"
  | "RX" | "RY" | "RZ" | "P" | "U3"
  | "CX" | "CY" | "CZ" | "CH" | "CP" | "CRX" | "CRY" | "CRZ"
  | "SWAP" | "CCX" | "CSWAP";

export interface GateDefinition {
  id: GateId;
  label: string;
  symbol: string;
  description: string;
  category: "single" | "rotation" | "controlled" | "multi";
  targetCount: number;
  controlCount: number;
  parameterCount: number;
  selfInverse: boolean;
  qasm?: string;
  educationalNote: string;
}

export interface GateParameters { theta?: number; phi?: number; lambda?: number; }
export interface GateOperation {
  id: string;
  gate: GateId;
  targets: number[];
  controls?: number[];
  params?: GateParameters;
  label?: string;
  disabled?: boolean;
  condition?: { bit: number; equals: 0 | 1 };
}

const phase = (angle: number): Complex => cExpI(angle);
const mat = (a: number | Complex, b: number | Complex, c: number | Complex, d: number | Complex): Matrix => [
  [typeof a === "number" ? C(a) : a, typeof b === "number" ? C(b) : b],
  [typeof c === "number" ? C(c) : c, typeof d === "number" ? C(d) : d],
];

export const GATE_MATRICES: Record<"I" | "X" | "Y" | "Z" | "H" | "S" | "SDG" | "T" | "TDG" | "SX" | "SXDG", Matrix> = {
  I: mat(1, 0, 0, 1),
  X: mat(0, 1, 1, 0),
  Y: mat(0, C(0, -1), C(0, 1), 0),
  Z: mat(1, 0, 0, -1),
  H: mat(INV_SQRT2, INV_SQRT2, INV_SQRT2, -INV_SQRT2),
  S: mat(1, 0, 0, C(0, 1)),
  SDG: mat(1, 0, 0, C(0, -1)),
  T: mat(1, 0, 0, phase(Math.PI / 4)),
  TDG: mat(1, 0, 0, phase(-Math.PI / 4)),
  SX: mat(C(0.5, 0.5), C(0.5, -0.5), C(0.5, -0.5), C(0.5, 0.5)),
  SXDG: mat(C(0.5, -0.5), C(0.5, 0.5), C(0.5, 0.5), C(0.5, -0.5)),
};

export const GATE_DEFINITIONS: GateDefinition[] = [
  { id: "I", label: "Identity", symbol: "I", description: "Leaves the state unchanged.", category: "single", targetCount: 1, controlCount: 0, parameterCount: 0, selfInverse: true, qasm: "id", educationalNote: "Useful as a placeholder in a circuit diagram." },
  { id: "X", label: "Pauli-X", symbol: "X", description: "Bit flip around the Bloch sphere X axis.", category: "single", targetCount: 1, controlCount: 0, parameterCount: 0, selfInverse: true, qasm: "x", educationalNote: "Maps |0⟩ to |1⟩ and |1⟩ to |0⟩." },
  { id: "Y", label: "Pauli-Y", symbol: "Y", description: "Bit and phase flip around the Y axis.", category: "single", targetCount: 1, controlCount: 0, parameterCount: 0, selfInverse: true, qasm: "y", educationalNote: "Includes a relative phase as well as a bit flip." },
  { id: "Z", label: "Pauli-Z", symbol: "Z", description: "Phase flip around the Bloch sphere Z axis.", category: "single", targetCount: 1, controlCount: 0, parameterCount: 0, selfInverse: true, qasm: "z", educationalNote: "Leaves |0⟩ unchanged and flips the sign of |1⟩." },
  { id: "H", label: "Hadamard", symbol: "H", description: "Creates or recombines equal superpositions.", category: "single", targetCount: 1, controlCount: 0, parameterCount: 0, selfInverse: true, qasm: "h", educationalNote: "H|0⟩ = (|0⟩ + |1⟩)/√2." },
  { id: "S", label: "Phase-S", symbol: "S", description: "Adds a quarter-turn phase to |1⟩.", category: "single", targetCount: 1, controlCount: 0, parameterCount: 0, selfInverse: false, qasm: "s", educationalNote: "S is the square root of Z." },
  { id: "SDG", label: "S dagger", symbol: "S†", description: "Inverse of the S phase gate.", category: "single", targetCount: 1, controlCount: 0, parameterCount: 0, selfInverse: false, qasm: "sdg", educationalNote: "S†S = I." },
  { id: "T", label: "T gate", symbol: "T", description: "Adds a π/4 phase to |1⟩.", category: "single", targetCount: 1, controlCount: 0, parameterCount: 0, selfInverse: false, qasm: "t", educationalNote: "Together with Clifford gates, T enables universal gate sets." },
  { id: "TDG", label: "T dagger", symbol: "T†", description: "Inverse of the T phase gate.", category: "single", targetCount: 1, controlCount: 0, parameterCount: 0, selfInverse: false, qasm: "tdg", educationalNote: "T†T = I." },
  { id: "SX", label: "Square-root X", symbol: "√X", description: "A gate whose square is X.", category: "single", targetCount: 1, controlCount: 0, parameterCount: 0, selfInverse: false, qasm: "sx", educationalNote: "SX·SX = X." },
  { id: "SXDG", label: "Square-root X dagger", symbol: "√X†", description: "Inverse square-root X operation.", category: "single", targetCount: 1, controlCount: 0, parameterCount: 0, selfInverse: false, qasm: "sxdg", educationalNote: "SX†·SX = I." },
  { id: "RX", label: "Rotate X", symbol: "Rx", description: "Rotation around the Bloch sphere X axis.", category: "rotation", targetCount: 1, controlCount: 0, parameterCount: 1, selfInverse: false, qasm: "rx", educationalNote: "The angle θ determines the rotation amount." },
  { id: "RY", label: "Rotate Y", symbol: "Ry", description: "Rotation around the Bloch sphere Y axis.", category: "rotation", targetCount: 1, controlCount: 0, parameterCount: 1, selfInverse: false, qasm: "ry", educationalNote: "Ry(θ)|0⟩ = cos(θ/2)|0⟩ + sin(θ/2)|1⟩." },
  { id: "RZ", label: "Rotate Z", symbol: "Rz", description: "Rotation around the Bloch sphere Z axis.", category: "rotation", targetCount: 1, controlCount: 0, parameterCount: 1, selfInverse: false, qasm: "rz", educationalNote: "Rz changes relative phase rather than basis probabilities." },
  { id: "P", label: "Phase", symbol: "P(θ)", description: "Applies a phase e^(iθ) to |1⟩.", category: "rotation", targetCount: 1, controlCount: 0, parameterCount: 1, selfInverse: false, qasm: "p", educationalNote: "Equivalent to a Z rotation up to a global phase." },
  { id: "U3", label: "Universal U3", symbol: "U3", description: "General single-qubit unitary parameterized by three angles.", category: "rotation", targetCount: 1, controlCount: 0, parameterCount: 3, selfInverse: false, qasm: "u", educationalNote: "Any single-qubit unitary can be expressed in this form up to global phase." },
  { id: "CX", label: "Controlled-X", symbol: "CX", description: "Flips the target when the control is 1.", category: "controlled", targetCount: 1, controlCount: 1, parameterCount: 0, selfInverse: true, qasm: "cx", educationalNote: "H on the control followed by CX can create a Bell pair." },
  { id: "CY", label: "Controlled-Y", symbol: "CY", description: "Applies Pauli-Y when the control is 1.", category: "controlled", targetCount: 1, controlCount: 1, parameterCount: 0, selfInverse: true, qasm: "cy", educationalNote: "A controlled unitary acts conditionally on a control qubit." },
  { id: "CZ", label: "Controlled-Z", symbol: "CZ", description: "Adds a phase of −1 to |11⟩.", category: "controlled", targetCount: 1, controlCount: 1, parameterCount: 0, selfInverse: true, qasm: "cz", educationalNote: "CZ is symmetric: either wire can be regarded as control." },
  { id: "CH", label: "Controlled-H", symbol: "CH", description: "Applies Hadamard to the target when control is 1.", category: "controlled", targetCount: 1, controlCount: 1, parameterCount: 0, selfInverse: true, qasm: "ch", educationalNote: "Controlled-H is useful for demonstrating conditional operations." },
  { id: "CP", label: "Controlled phase", symbol: "CP", description: "Adds a parameterized phase to the |11⟩ component.", category: "controlled", targetCount: 1, controlCount: 1, parameterCount: 1, selfInverse: false, qasm: "cp", educationalNote: "Controlled phases appear in the quantum Fourier transform." },
  { id: "CRX", label: "Controlled-Rx", symbol: "CRx", description: "Conditionally rotates the target around X.", category: "controlled", targetCount: 1, controlCount: 1, parameterCount: 1, selfInverse: false, qasm: "crx", educationalNote: "The control preserves the branch where its bit is zero." },
  { id: "CRY", label: "Controlled-Ry", symbol: "CRy", description: "Conditionally rotates the target around Y.", category: "controlled", targetCount: 1, controlCount: 1, parameterCount: 1, selfInverse: false, qasm: "cry", educationalNote: "Controlled rotations are common in variational circuits." },
  { id: "CRZ", label: "Controlled-Rz", symbol: "CRz", description: "Conditionally rotates the target around Z.", category: "controlled", targetCount: 1, controlCount: 1, parameterCount: 1, selfInverse: false, qasm: "crz", educationalNote: "CRZ introduces conditional phase evolution." },
  { id: "SWAP", label: "Swap", symbol: "×", description: "Exchanges the states of two qubits.", category: "multi", targetCount: 2, controlCount: 0, parameterCount: 0, selfInverse: true, qasm: "swap", educationalNote: "A SWAP can be decomposed into three controlled-X gates." },
  { id: "CCX", label: "Toffoli", symbol: "CCX", description: "Flips the target only when both controls are 1.", category: "multi", targetCount: 1, controlCount: 2, parameterCount: 0, selfInverse: true, qasm: "ccx", educationalNote: "The Toffoli gate is a reversible classical AND with a preserved target bit." },
  { id: "CSWAP", label: "Fredkin", symbol: "CSWAP", description: "Swaps two targets when the control is 1.", category: "multi", targetCount: 2, controlCount: 1, parameterCount: 0, selfInverse: true, qasm: "cswap", educationalNote: "Fredkin is a controlled permutation gate." },
];

export function rotationMatrix(axis: "X" | "Y" | "Z", theta: number): Matrix {
  const c = Math.cos(theta / 2); const s = Math.sin(theta / 2);
  if (axis === "X") return [[C(c), C(0, -s)], [C(0, -s), C(c)]];
  if (axis === "Y") return [[C(c), C(-s)], [C(s), C(c)]];
  return [[C(c, -s), C()], [C(), C(c, s)]];
}
export function phaseMatrix(theta: number): Matrix { return [[C(1), C()], [C(), cExpI(theta)]]; }
export function u3Matrix(theta: number, phi: number, lambda: number): Matrix {
  const c = Math.cos(theta / 2); const s = Math.sin(theta / 2);
  return [[C(c), C(-s * Math.cos(lambda), -s * Math.sin(lambda))], [C(s * Math.cos(phi), s * Math.sin(phi)), C(c * Math.cos(phi + lambda), c * Math.sin(phi + lambda))]];
}
export function matrixForGate(gate: GateId, params: { theta?: number; phi?: number; lambda?: number } = {}): Matrix {
  if (gate in GATE_MATRICES) return GATE_MATRICES[gate as keyof typeof GATE_MATRICES];
  const theta = params.theta ?? 0;
  if (gate === "RX" || gate === "RY" || gate === "RZ") return rotationMatrix(gate.slice(1) as "X" | "Y" | "Z", theta);
  if (gate === "P") return phaseMatrix(theta);
  if (gate === "U3") return u3Matrix(theta, params.phi ?? 0, params.lambda ?? 0);
  if (gate === "CP") return phaseMatrix(theta);
  if (gate === "CRX" || gate === "CRY" || gate === "CRZ") return rotationMatrix(gate.slice(2) as "X" | "Y" | "Z", theta);
  if (gate === "CX") return GATE_MATRICES.X;
  if (gate === "CY") return GATE_MATRICES.Y;
  if (gate === "CZ") return GATE_MATRICES.Z;
  if (gate === "CH") return GATE_MATRICES.H;
  throw new Error(`Gate ${gate} does not have a single-qubit matrix.`);
}
export function gateDefinition(gate: GateId): GateDefinition {
  const found = GATE_DEFINITIONS.find((item) => item.id === gate);
  if (!found) throw new Error(`Unknown gate: ${gate}`);
  return found;
}
