// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { C, ZERO, cAbs2, cAdd, cMul, cScale, type Complex } from "./complex";
import { dagger, identity, matrixMultiply, type Matrix } from "./matrix";
import { applyGate, basisState, zeroState, type StateVector } from "./statevector";
import type { GateOperation } from "./gates";

export interface DensityMatrix { qubits: number; values: Matrix; }
export function densityFromState(state: StateVector): DensityMatrix {
  const values = state.amplitudes.map((a) => state.amplitudes.map((b) => cMul(a, { re: b.re, im: -b.im })));
  return { qubits: state.qubits, values };
}
export function maximallyMixed(qubits: number): DensityMatrix {
  if (!Number.isInteger(qubits) || qubits < 1 || qubits > 8) throw new Error("Dense density matrices are limited to 1–8 qubits.");
  const dim = 2 ** qubits; const values = Array.from({ length: dim }, (_, r) => Array.from({ length: dim }, (_, c) => r === c ? C(1 / dim) : ZERO));
  return { qubits, values };
}
export function basisDensity(qubits: number, basisIndex = 0): DensityMatrix {
  const dim = 2 ** qubits; if (!Number.isInteger(basisIndex) || basisIndex < 0 || basisIndex >= dim) throw new Error("Basis index out of range.");
  const values = Array.from({ length: dim }, (_, r) => Array.from({ length: dim }, (_, c) => r === basisIndex && c === basisIndex ? C(1) : ZERO));
  return { qubits, values };
}
export function cloneDensity(rho: DensityMatrix): DensityMatrix { return { qubits: rho.qubits, values: rho.values.map((row) => row.map((v) => C(v.re, v.im))) }; }
export function applyDensityUnitary(rho: DensityMatrix, unitary: Matrix): DensityMatrix {
  const dim = 2 ** rho.qubits;
  if (rho.values.length !== dim || unitary.length !== dim || unitary.some((row) => row.length !== dim)) throw new Error("Density matrix and unitary dimensions do not match.");
  return { qubits: rho.qubits, values: matrixMultiply(matrixMultiply(unitary, rho.values), dagger(unitary)) };
}
export function fullUnitaryForOperation(qubits: number, operation: GateOperation): Matrix {
  if (!Number.isInteger(qubits) || qubits < 1 || qubits > 8) throw new Error("Dense unitary construction is limited to 1–8 qubits.");
  const dim = 2 ** qubits; const output = Array.from({ length: dim }, () => Array.from({ length: dim }, () => ZERO));
  for (let col = 0; col < dim; col += 1) {
    const basis = basisState(qubits, col); const evolved = applyGate(basis, operation);
    evolved.amplitudes.forEach((amplitude, row) => { output[row][col] = amplitude; });
  }
  return output;
}
export function applyOperationToDensity(rho: DensityMatrix, operation: GateOperation): DensityMatrix {
  return applyDensityUnitary(rho, fullUnitaryForOperation(rho.qubits, operation));
}
/** Trace out all qubits except keepQubits. Kept qubits are ordered as supplied, leftmost first in the reduced basis string. */
export function partialTrace(rho: DensityMatrix, keepQubits: number[]): DensityMatrix {
  if (new Set(keepQubits).size !== keepQubits.length || keepQubits.some((q) => q < 0 || q >= rho.qubits)) throw new Error("Kept qubits must be unique and inside the register.");
  if (!keepQubits.length) throw new Error("At least one qubit must be retained.");
  const keep = [...keepQubits]; const traced = Array.from({ length: rho.qubits }, (_, q) => q).filter((q) => !keep.includes(q));
  const reducedDim = 2 ** keep.length; const fullDim = 2 ** rho.qubits;
  const out = Array.from({ length: reducedDim }, () => Array.from({ length: reducedDim }, () => C(0)));
  const compress = (index: number): number => keep.reduce((acc, q, position) => acc | (((index >> q) & 1) << position), 0);
  const sameTracedBits = (a: number, b: number): boolean => traced.every((q) => ((a >> q) & 1) === ((b >> q) & 1));
  for (let row = 0; row < fullDim; row += 1) for (let col = 0; col < fullDim; col += 1) {
    if (!sameTracedBits(row, col)) continue;
    const r = compress(row); const c = compress(col); out[r][c] = cAdd(out[r][c], rho.values[row][col]);
  }
  return { qubits: keep.length, values: out };
}
export function densityTrace(rho: DensityMatrix): number { return rho.values.reduce((sum, row, index) => sum + row[index].re, 0); }
export function purity(rho: DensityMatrix): number {
  let result = 0;
  for (let i = 0; i < rho.values.length; i += 1) for (let j = 0; j < rho.values.length; j += 1) result += cAbs2(rho.values[i][j]);
  return result;
}
export function linearEntropy(rho: DensityMatrix): number { return 1 - purity(rho); }
export function oneQubitEigenvalues(rho: DensityMatrix): [number, number] {
  if (rho.qubits !== 1 || rho.values.length !== 2) throw new Error("Expected a one-qubit density matrix.");
  const a = rho.values[0][0].re; const d = rho.values[1][1].re; const b = rho.values[0][1];
  const delta = Math.sqrt(Math.max(0, (a - d) * (a - d) + 4 * cAbs2(b)));
  return [Math.max(0, (a + d + delta) / 2), Math.max(0, (a + d - delta) / 2)];
}
export function vonNeumannEntropy(rho: DensityMatrix, base = 2): number {
  if (rho.qubits === 1) return oneQubitEigenvalues(rho).reduce((sum, lambda) => lambda > 1e-14 ? sum - lambda * Math.log(lambda) / Math.log(base) : sum, 0);
  // For larger registers use a documented Rényi-2 lower-cost entropy estimate.
  return -Math.log(Math.max(1e-14, purity(rho))) / Math.log(base);
}
export function fidelityPureToDensity(state: StateVector, rho: DensityMatrix): number {
  if (state.qubits !== rho.qubits) throw new Error("State and density matrix register sizes differ.");
  let value = C(0);
  for (let r = 0; r < state.amplitudes.length; r += 1) for (let c = 0; c < state.amplitudes.length; c += 1) {
    value = cAdd(value, cMul(cMul({ re: state.amplitudes[r].re, im: -state.amplitudes[r].im }, rho.values[r][c]), state.amplitudes[c]));
  }
  return Math.max(0, Math.min(1, value.re));
}
export function densityFromCircuit(qubits: number, operations: GateOperation[]): DensityMatrix {
  if (qubits > 8) throw new Error("Density matrix simulation is limited to 8 qubits.");
  let rho = densityFromState(zeroState(qubits));
  for (const operation of operations) rho = applyOperationToDensity(rho, operation);
  return rho;
}
export function tensorDensity(a: DensityMatrix, b: DensityMatrix): DensityMatrix {
  const dimA = 2 ** a.qubits; const dimB = 2 ** b.qubits; const values = Array.from({ length: dimA * dimB }, () => Array.from({ length: dimA * dimB }, () => C(0)));
  for (let r1 = 0; r1 < dimA; r1 += 1) for (let c1 = 0; c1 < dimA; c1 += 1)
    for (let r2 = 0; r2 < dimB; r2 += 1) for (let c2 = 0; c2 < dimB; c2 += 1)
      values[r1 * dimB + r2][c1 * dimB + c2] = cMul(a.values[r1][c1], b.values[r2][c2]);
  return { qubits: a.qubits + b.qubits, values };
}
export function isPositiveTraceOne(rho: DensityMatrix, tolerance = 1e-7): boolean {
  if (Math.abs(densityTrace(rho) - 1) > tolerance) return false;
  for (let r = 0; r < rho.values.length; r += 1) for (let c = 0; c < rho.values.length; c += 1) {
    const a = rho.values[r][c]; const b = rho.values[c][r];
    if (Math.hypot(a.re - b.re, a.im + b.im) > tolerance) return false;
  }
  return true;
}
