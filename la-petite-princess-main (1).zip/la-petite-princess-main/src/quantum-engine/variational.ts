// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { appendGate, createCircuit, type QuantumCircuit } from "./circuit";
import { expectationHamiltonian, type Hamiltonian } from "./hamiltonian";
import { simulateState } from "./simulator";
import { type GateId } from "./gates";

export interface VariationalLayer { rotationGates: Array<"RX" | "RY" | "RZ">; entangler: "CX" | "CZ" | "None"; }
export interface AnsatzDefinition { qubits: number; layers: VariationalLayer[]; name: string; }
export interface ParameterEvaluation { parameters: number[]; energy: number; }
export interface OptimizationHistory { step: number; energy: number; gradientNorm: number; parameters: number[]; accepted: boolean; }
export interface VariationalResult { parameters: number[]; energy: number; history: OptimizationHistory[]; converged: boolean; }
export function hardwareEfficientAnsatz(qubits = 2, layers = 2): AnsatzDefinition {
  if (!Number.isInteger(qubits) || qubits < 1 || qubits > 8 || !Number.isInteger(layers) || layers < 1 || layers > 12) throw new Error("Ansatz supports 1–8 qubits and 1–12 layers.");
  return { qubits, name: "Hardware-efficient layered ansatz", layers: Array.from({ length: layers }, () => ({ rotationGates: ["RY", "RZ"], entangler: qubits > 1 ? "CX" : "None" })) };
}
export function parameterCount(ansatz: AnsatzDefinition): number { return ansatz.layers.reduce((sum, layer) => sum + ansatz.qubits * layer.rotationGates.length, 0); }
export function buildParameterizedCircuit(ansatz: AnsatzDefinition, parameters: number[]): QuantumCircuit {
  const expected = parameterCount(ansatz); if (parameters.length !== expected || parameters.some((p) => !Number.isFinite(p))) throw new Error(`Expected ${expected} finite parameters.`);
  let cursor = 0; let circuit = createCircuit(ansatz.qubits, ansatz.name);
  for (const layer of ansatz.layers) {
    for (const gate of layer.rotationGates) for (let q = 0; q < ansatz.qubits; q += 1) circuit = appendGate(circuit, gate as GateId, [q], [], { theta: parameters[cursor++] });
    if (layer.entangler === "CX") for (let q = 0; q < ansatz.qubits - 1; q += 1) circuit = appendGate(circuit, "CX", [q + 1], [q]);
    if (layer.entangler === "CZ") for (let q = 0; q < ansatz.qubits - 1; q += 1) circuit = appendGate(circuit, "CZ", [q + 1], [q]);
  }
  return circuit;
}
export function evaluateVariational(ansatz: AnsatzDefinition, hamiltonian: Hamiltonian, parameters: number[]): ParameterEvaluation {
  const circuit = buildParameterizedCircuit(ansatz, parameters); const state = simulateState(circuit);
  return { parameters: [...parameters], energy: expectationHamiltonian(state, hamiltonian) };
}
export function parameterShiftGradient(ansatz: AnsatzDefinition, hamiltonian: Hamiltonian, parameters: number[]): number[] {
  const gradient: number[] = [];
  for (let index = 0; index < parameters.length; index += 1) {
    const plus = parameters.slice(); const minus = parameters.slice(); plus[index] += Math.PI / 2; minus[index] -= Math.PI / 2;
    gradient.push((evaluateVariational(ansatz, hamiltonian, plus).energy - evaluateVariational(ansatz, hamiltonian, minus).energy) / 2);
  }
  return gradient;
}
export function gradientDescentVQE(ansatz: AnsatzDefinition, hamiltonian: Hamiltonian, initial: number[], options: { learningRate?: number; maxSteps?: number; tolerance?: number; seed?: number } = {}): VariationalResult {
  const learningRate = options.learningRate ?? 0.08; const maxSteps = options.maxSteps ?? 100; const tolerance = options.tolerance ?? 1e-5;
  if (learningRate <= 0 || !Number.isFinite(learningRate) || !Number.isInteger(maxSteps) || maxSteps < 1) throw new Error("Invalid optimization settings.");
  let parameters = [...initial]; let current = evaluateVariational(ansatz, hamiltonian, parameters); const history: OptimizationHistory[] = [];
  let converged = false;
  for (let step = 0; step < maxSteps; step += 1) {
    const gradient = parameterShiftGradient(ansatz, hamiltonian, parameters); const norm = Math.sqrt(gradient.reduce((sum, value) => sum + value * value, 0));
    if (norm < tolerance) { converged = true; history.push({ step, energy: current.energy, gradientNorm: norm, parameters: [...parameters], accepted: true }); break; }
    let scale = learningRate; let candidate = parameters; let candidateEval = current; let accepted = false;
    for (let lineSearch = 0; lineSearch < 8; lineSearch += 1) {
      candidate = parameters.map((value, index) => value - scale * gradient[index]); candidateEval = evaluateVariational(ansatz, hamiltonian, candidate);
      if (candidateEval.energy <= current.energy) { accepted = true; break; }
      scale *= 0.5;
    }
    history.push({ step, energy: current.energy, gradientNorm: norm, parameters: [...parameters], accepted });
    if (!accepted) break;
    const improvement = current.energy - candidateEval.energy; parameters = candidate; current = candidateEval;
    if (improvement < tolerance && norm < Math.sqrt(tolerance)) { converged = true; break; }
  }
  return { parameters, energy: current.energy, history, converged };
}
export function randomParameters(count: number, random = Math.random): number[] {
  if (!Number.isInteger(count) || count < 0) throw new Error("Parameter count must be a non-negative integer.");
  return Array.from({ length: count }, () => (random() * 2 - 1) * Math.PI);
}
export function wrapParameters(parameters: number[]): number[] { return parameters.map((value) => ((value + Math.PI) % (2 * Math.PI) + 2 * Math.PI) % (2 * Math.PI) - Math.PI); }
