// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { C, cAbs2, cScale } from "./complex";
import { densityFromState, oneQubitEigenvalues, partialTrace, purity, type DensityMatrix } from "./density";
import { zeroState, type StateVector } from "./statevector";

export interface EntanglementReport {
  qubits: number;
  purity: number;
  subsystemEntropyBits: number;
  concurrence?: number;
  tangle?: number;
  schmidtCoefficients?: number[];
  interpretation: string;
}
function binaryEntropy(probability: number): number {
  const p = Math.min(1, Math.max(0, probability));
  const term = (x: number) => x <= 1e-14 ? 0 : -x * Math.log2(x);
  return term(p) + term(1 - p);
}
export function entanglementEntropyOfQubit(state: StateVector, qubit: number): number {
  const rho = partialTrace(densityFromState(state), [qubit]); const eigenvalues = oneQubitEigenvalues(rho);
  return binaryEntropy(eigenvalues[0]);
}
export function pureTwoQubitConcurrence(state: StateVector): number {
  if (state.qubits !== 2) throw new Error("Pure-state concurrence in this helper is defined for exactly two qubits.");
  const [a00, a01, a10, a11] = state.amplitudes;
  // C = 2 |a00 a11 − a01 a10| for a normalized pure two-qubit state.
  const real = a00.re * a11.re - a00.im * a11.im - a01.re * a10.re + a01.im * a10.im;
  const imag = a00.re * a11.im + a00.im * a11.re - a01.re * a10.im - a01.im * a10.re;
  return Math.min(1, 2 * Math.hypot(real, imag));
}
export function pureTwoQubitTangle(state: StateVector): number { const c = pureTwoQubitConcurrence(state); return c * c; }
export function schmidtCoefficientsForOneVsRest(state: StateVector, qubit: number): number[] {
  const rho = partialTrace(densityFromState(state), [qubit]); return oneQubitEigenvalues(rho).map((value) => Math.sqrt(Math.max(0, value)));
}
export function isProductAcrossOneQubitCut(state: StateVector, qubit: number, tolerance = 1e-8): boolean {
  return entanglementEntropyOfQubit(state, qubit) <= tolerance;
}
export function entanglementReport(state: StateVector): EntanglementReport {
  if (state.qubits === 1) return { qubits: 1, purity: 1, subsystemEntropyBits: 0, interpretation: "A single qubit has no internal bipartition to test for entanglement." };
  const rho = densityFromState(state); const first = partialTrace(rho, [0]); const entropy = oneQubitEigenvalues(first).reduce((sum, p) => p > 1e-14 ? sum - p * Math.log2(p) : sum, 0);
  if (state.qubits === 2) {
    const concurrence = pureTwoQubitConcurrence(state);
    return { qubits: 2, purity: purity(rho), subsystemEntropyBits: entropy, concurrence, tangle: concurrence * concurrence, schmidtCoefficients: schmidtCoefficientsForOneVsRest(state, 0), interpretation: concurrence > 1 - 1e-7 ? "Maximally entangled pure two-qubit state." : concurrence > 1e-7 ? "Entangled pure two-qubit state." : "Product pure two-qubit state." };
  }
  return { qubits: state.qubits, purity: purity(rho), subsystemEntropyBits: entropy, interpretation: "Entropy is computed for the q0-versus-rest cut. Other bipartitions may give different results." };
}
export function reducedBlochVector(rho: DensityMatrix, qubit: number): { x: number; y: number; z: number } {
  const reduced = partialTrace(rho, [qubit]); const off = reduced.values[0][1];
  return { x: 2 * off.re, y: -2 * off.im, z: reduced.values[0][0].re - reduced.values[1][1].re };
}
export function ghzEntanglementWitness(qubits: number): { expectedOverlap: number; threshold: number; description: string } {
  if (!Number.isInteger(qubits) || qubits < 2 || qubits > 16) throw new Error("GHZ witness expects 2–16 qubits.");
  return { expectedOverlap: 1, threshold: 0.5, description: `For the ideal ${qubits}-qubit GHZ state, the overlap with the target GHZ vector is 1. This simple overlap is a teaching diagnostic, not a full device-independent witness.` };
}
export function ghzState(qubits: number): StateVector {
  if (!Number.isInteger(qubits) || qubits < 2 || qubits > 16) throw new Error("GHZ state expects 2–16 qubits.");
  const state = zeroState(qubits); state.amplitudes[0] = C(1 / Math.sqrt(2)); state.amplitudes[state.amplitudes.length - 1] = C(1 / Math.sqrt(2)); return state;
}
