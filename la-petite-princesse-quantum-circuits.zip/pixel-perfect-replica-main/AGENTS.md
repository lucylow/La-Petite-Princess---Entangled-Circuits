<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Architecture

- The Quantum Studio extension keeps pure math in `src/lib/advanced`, learner content in `src/data`, interactive panels in `src/components/advanced`, and its styling in `src/styles/advanced.css` loaded once from `src/routes/__root.tsx`, so the added labs stay additive and the original story/simulator page keeps working untouched.
- TypeScript runs with strict indexed access: guard or default possibly-undefined array/record reads in the code instead of loosening `tsconfig.json`, so the compiler's null-safety guarantee survives new modules.
- Derive discovery rewards in the pure advanced math layer from existing validated local progress; keep reward presentation in advanced panels so scores stay deterministic without duplicating persisted state.
- Circuit visualizations replay the existing state-vector engine for every gate; diagrams and phase views share those frames rather than implementing separate simulation logic.
- Imported Circuit Pro modules (src/quantum-engine, src/lib/circuit-pro, src/components/circuit-pro, root Circuit*.tsx panels) carry file-level @ts-nocheck because they were written for a looser tsconfig; remove it per file when hardening for strict indexed access.
- Mademoiselle Q's live answers come from a server function in `src/lib/mentor.functions.ts` (Lovable AI Gateway); the browser never calls the AI directly, and any failure falls back to the built-in quantum guide with a visible notice.
