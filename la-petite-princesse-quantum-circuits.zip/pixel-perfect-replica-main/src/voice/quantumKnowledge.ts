// @ts-nocheck
export type QuantumTopic =
  | "qubit" | "superposition" | "entanglement" | "measurement" | "gates"
  | "decoherence" | "teleportation" | "no-cloning" | "algorithms"
  | "braiding" | "quantum-vs-classical" | "applications" | "unknown";

export interface MentorReply {
  topic: QuantumTopic;
  title: string;
  paragraphs: string[];
  formula?: string;
  experiment?: string;
  misconception?: string;
  followUps: string[];
}

interface KnowledgeCard extends Omit<MentorReply, "topic"> {
  topic: Exclude<QuantumTopic, "unknown">;
  keywords: string[];
}

const cards: KnowledgeCard[] = [
  {
    topic: "qubit", keywords: ["qubit", "quantum bit", "two level", "spin"], title: "Meet the qubit",
    paragraphs: [
      "A qubit is a quantum system used to encode quantum information. Its computational basis states are written |0⟩ and |1⟩.",
      "A pure qubit can be written α|0⟩ + β|1⟩, where α and β are complex probability amplitudes. The normalization rule is |α|² + |β|² = 1.",
      "A qubit is not simply a classical bit that is secretly both 0 and 1. The amplitudes carry phase information, which can affect interference before measurement."
    ], formula: "|ψ⟩ = α|0⟩ + β|1⟩     |α|² + |β|² = 1",
    experiment: "In the State Explorer, start at |0⟩. Apply H, then inspect the amplitudes and measurement probabilities.",
    misconception: "A qubit does not let you read out both values at once. A measurement gives one classical outcome, sampled according to the quantum probabilities.",
    followUps: ["What is a probability amplitude?", "How is a qubit different from a bit?", "Show me the Bloch sphere"]
  },
  {
    topic: "superposition", keywords: ["superposition", "hadamard", "hadamard gate", "h gate", "possibilities"], title: "The mathematics of superposition",
    paragraphs: [
      "Superposition means a quantum state is a linear combination of basis states. For one qubit, α|0⟩ + β|1⟩ is a superposition when both amplitudes are nonzero.",
      "The Hadamard gate H maps |0⟩ to (|0⟩ + |1⟩)/√2. Measuring this state in the computational basis gives 0 and 1 with equal probability.",
      "The amplitudes are complex numbers, so their relative phases matter. Later gates can make amplitudes reinforce or cancel through quantum interference."
    ], formula: "H|0⟩ = (|0⟩ + |1⟩)/√2",
    experiment: "Apply H twice to |0⟩. The second H reverses the first, returning the qubit to |0⟩. This is a useful way to see that amplitudes—not just probabilities—matter.",
    misconception: "Superposition is not the same as ordinary uncertainty about a hidden classical value. Quantum interference can distinguish the two descriptions.",
    followUps: ["Why do amplitudes have phases?", "Can you explain interference?", "What happens when I apply H twice?"]
  },
  {
    topic: "entanglement", keywords: ["entangle", "entanglement", "bell state", "bell pair", "correlated", "correlation"], title: "When qubits share a joint state",
    paragraphs: [
      "Entanglement occurs when a joint quantum state cannot be factored into separate states for each subsystem. The whole system contains correlations that cannot be explained by assigning each qubit its own independent pure state.",
      "A familiar example is the Bell state Φ⁺ = (|00⟩ + |11⟩)/√2. If both qubits are measured in the computational basis, their results are perfectly correlated: 00 or 11.",
      "Entanglement is a resource in quantum information, but it does not allow faster-than-light communication. A local measurement result is still random; the correlation becomes visible when results are compared."
    ], formula: "|Φ⁺⟩ = (|00⟩ + |11⟩)/√2",
    experiment: "Create a Bell pair: apply H to the control qubit, then CNOT with that qubit as control. Measure both qubits over many shots and inspect the histogram.",
    misconception: "Two ordinary strands tied together are only a metaphor. Physical entanglement is a property of the mathematical joint quantum state.",
    followUps: ["How do I build a Bell pair?", "What is Bell's inequality?", "Why can't entanglement send messages faster than light?"]
  },
  {
    topic: "measurement", keywords: ["measurement", "measure", "collapse", "born rule", "probability"], title: "Measurement: one result from a distribution",
    paragraphs: [
      "In a computational-basis measurement, the probability of outcome 0 is |α|² and the probability of outcome 1 is |β|² for the state α|0⟩ + β|1⟩.",
      "One run produces one result. Repeating the same preparation and measurement many times produces frequencies that approach the Born-rule probabilities.",
      "Measurement is basis-dependent. Measuring in the X basis is different from measuring in the computational Z basis; a Hadamard before a Z measurement converts an X-basis measurement into that circuit pattern."
    ], formula: "P(0) = |α|²     P(1) = |β|²",
    experiment: "Prepare |+⟩ = (|0⟩ + |1⟩)/√2 and collect 100 shots. Then apply H before measurement and compare the distribution.",
    misconception: "A single measurement does not reveal the entire state vector. State reconstruction requires repeated measurements under different settings.",
    followUps: ["What is the Born rule?", "What is a measurement basis?", "Why do I need many shots?"]
  },
  {
    topic: "gates", keywords: ["gate", "gates", "circuit", "cnot", "pauli", "rotation", "unitary"], title: "Quantum gates are reversible operations",
    paragraphs: [
      "An ideal quantum gate is represented by a unitary matrix U. It transforms a state vector while preserving total probability: U†U = I.",
      "The Pauli-X gate swaps |0⟩ and |1⟩. Z changes the phase of |1⟩. H creates or recombines superpositions. CNOT flips its target when its control is |1⟩.",
      "A circuit is an ordered sequence of gates and measurements. The order matters because quantum operations generally do not commute: applying A then B can differ from applying B then A."
    ], formula: "U†U = I",
    experiment: "Build X → H → X on one qubit and compare it with H → X → X. Use the circuit simulator to inspect how order changes the state.",
    misconception: "Quantum gates are not arbitrary logical shortcuts. Before measurement, ideal gates must preserve inner products and be reversible.",
    followUps: ["What does CNOT do?", "What is a unitary matrix?", "Which gates create entanglement?"]
  },
  {
    topic: "decoherence", keywords: ["decoherence", "noise", "error", "errors", "environment", "fidelity"], title: "Why quantum states are delicate",
    paragraphs: [
      "Decoherence occurs when a quantum system becomes correlated with uncontrolled degrees of freedom in its environment. The phase relationships needed for interference become less accessible in the system alone.",
      "Real devices also experience imperfect gates, readout errors, leakage and drift. These effects reduce the fidelity of an experiment compared with an ideal mathematical circuit.",
      "Researchers use careful control, calibration, error mitigation and quantum error correction. Error correction encodes logical information across multiple physical qubits and requires extra hardware and operations."
    ], formula: "F(|ψ⟩, |φ⟩) = |⟨ψ|φ⟩|²  (pure states)",
    experiment: "Open the Noise Lab. Increase the depolarizing noise parameter and observe how the output distribution departs from the ideal result.",
    misconception: "Quantum error correction does not simply copy an unknown qubit. It detects error syndromes without directly measuring the encoded logical information.",
    followUps: ["What is a bit-flip code?", "What does fidelity measure?", "How does depolarizing noise work?"]
  },
  {
    topic: "teleportation", keywords: ["teleport", "teleportation", "classical bits", "alice", "bob"], title: "Quantum teleportation moves a state, not matter",
    paragraphs: [
      "Quantum teleportation is a protocol that transfers an unknown quantum state from one location to another using a shared entangled pair, two classical bits, and a correction operation.",
      "The sender performs a Bell-basis measurement on the input qubit and their half of the shared pair. The two-bit measurement result is sent classically; the receiver applies a corresponding Pauli correction.",
      "The original state is consumed by the measurement, and no information travels faster than the classical message. The protocol transfers quantum state information, not a person or physical object."
    ], formula: "1 shared Bell pair + 2 classical bits + conditional correction",
    experiment: "Run the Teleportation example in the algorithm gallery. Inspect the two classical measurement bits and the receiver's correction.",
    misconception: "Teleportation is not instant transport. Classical communication is essential, so the protocol cannot transmit information faster than light.",
    followUps: ["Why are two classical bits needed?", "What is a Bell measurement?", "How does the receiver know which correction to apply?"]
  },
  {
    topic: "no-cloning", keywords: ["no cloning", "no-cloning", "clone", "copy a qubit", "copy quantum"], title: "The no-cloning theorem",
    paragraphs: [
      "The no-cloning theorem says there is no physical operation that can perfectly copy every possible unknown quantum state while leaving the original unchanged.",
      "The key reason is linearity: a unitary that copies |0⟩ and |1⟩ would not also copy arbitrary superpositions in the required way.",
      "This does not mean quantum information can never be transferred. Teleportation transfers a state using entanglement and classical communication, while consuming the original input."
    ], formula: "No universal U exists with U|ψ⟩|0⟩ = |ψ⟩|ψ⟩ for every unknown |ψ⟩.",
    experiment: "Compare what a CNOT does when the control is |0⟩, |1⟩, and |+⟩. Notice that copying computational basis values does not clone an arbitrary superposition.",
    misconception: "The theorem forbids perfect universal cloning of unknown states. It does not forbid preparing two fresh copies when the state is already known.",
    followUps: ["Why does linearity matter?", "Can classical bits be copied?", "How is teleportation different from cloning?"]
  },
  {
    topic: "algorithms", keywords: ["algorithm", "grover", "search", "shor", "qft", "fourier", "qaoa", "phase estimation"], title: "What makes a quantum algorithm?",
    paragraphs: [
      "A quantum algorithm is a sequence of quantum operations, often followed by measurement and classical post-processing. Its advantage, when one exists, depends on the problem structure and assumptions about the hardware and input model.",
      "Grover's algorithm gives a quadratic query speedup for unstructured search. Shor's algorithm offers a polynomial-time quantum method for integer factoring, assuming a sufficiently capable fault-tolerant quantum computer.",
      "Quantum computers are not faster for every task. Many workloads are better handled by classical computers, and practical advantage must include data loading, error rates and total resource costs."
    ], formula: "Grover query complexity: O(√N) vs. classical O(N)",
    experiment: "Try the Grover Search Lab with a small number of qubits. Compare the measured marked-state probability after each iteration.",
    misconception: "A quantum computer does not try every answer and read them all out. Interference reshapes probabilities so useful outcomes become more likely.",
    followUps: ["How does Grover's algorithm work?", "What is the quantum Fourier transform?", "Does quantum computing beat classical computing at everything?"]
  },
  {
    topic: "braiding", keywords: ["braid", "braiding", "anyon", "topological", "topological quantum"], title: "Braids, anyons and topological quantum computing",
    paragraphs: [
      "In some two-dimensional quantum systems, exotic quasiparticles called anyons can have exchange properties different from ordinary bosons and fermions. Their exchanges can be represented by braid-group operations.",
      "In topological quantum computing proposals, information is encoded nonlocally and computational operations are associated with braiding quasiparticles through spacetime. Certain braiding schemes can offer intrinsic protection against some local disturbances.",
      "This is an advanced research area, not the same thing as ordinary entanglement. A drawing of braided hair is a story metaphor; a physical anyon-braiding platform requires specialized quantum matter and experimental control."
    ], formula: "Braid generators: σᵢ σᵢ₊₁ σᵢ = σᵢ₊₁ σᵢ σᵢ₊₁",
    experiment: "Open Braid Mathematics to compare two equivalent braid words. Then explore why this mathematical structure is relevant to topological quantum computing.",
    misconception: "A braid diagram alone is not a quantum computer. The braid must correspond to physically realizable exchanges in a suitable quantum system.",
    followUps: ["What is an anyon?", "How is topological protection different from error correction?", "Is braiding the same as entanglement?"]
  },
  {
    topic: "quantum-vs-classical", keywords: ["classical", "difference", "quantum computer", "regular computer", "bit vs", "faster"], title: "Quantum computers are different, not universally faster",
    paragraphs: [
      "A classical bit is represented as 0 or 1. A qubit is described by a quantum state with amplitudes and phase, and multiple qubits can be entangled.",
      "Quantum processors use interference and entanglement as computational resources. A quantum algorithm must arrange operations so that useful outcomes become more probable at measurement.",
      "Quantum machines are specialized accelerators under development. Classical computers remain essential for control, error correction, data handling and most everyday computing."
    ], formula: "Classical n-bit state: one of 2ⁿ strings; quantum n-qubit pure state: 2ⁿ complex amplitudes",
    experiment: "Use the Circuit Comparison panel to compare a classical bit-flip idea with a superposition-and-interference circuit.",
    misconception: "Having many amplitudes does not mean all answers can be read out. Measurement returns a limited classical result.",
    followUps: ["What is a qubit register?", "Why can't we read every amplitude?", "Where could quantum computers be useful?"]
  },
  {
    topic: "applications", keywords: ["application", "useful", "chemistry", "drug", "materials", "optimization", "real world"], title: "Where quantum computing might help",
    paragraphs: [
      "Potential applications include simulating quantum chemistry and materials, certain optimization tasks, and specialized problems in cryptography and physics. These are research directions, not guarantees of near-term practical advantage.",
      "Because molecules and materials are quantum systems, quantum processors may eventually represent some of their behavior more naturally than classical approximations. But noise, scale and algorithmic overhead remain major challenges.",
      "A responsible project compares quantum methods with the best available classical baselines and reports the hardware assumptions, resource estimates and uncertainty."
    ],
    experiment: "Choose a small molecule or optimization example in the Quantum Impact Lab. Write down what is being optimized and what a fair classical comparison would be.",
    misconception: "Quantum computing is not automatically a better way to solve climate, medical or AI problems. A concrete algorithmic advantage must be demonstrated.",
    followUps: ["How might quantum computers help chemistry?", "What is a classical baseline?", "What is a variational quantum algorithm?"]
  },
  {
    topic: "applications", keywords: ["women", "woman", "girl", "girls", "female", "role model", "scientist", "who invented", "famous"], title: "Women who shaped quantum science",
    paragraphs: [
      "Chien-Shiung Wu ran precise experiments in the 1950s that showed nature is not mirror-symmetric, and she measured entangled photons long before it was fashionable.",
      "Emmy Noether proved that symmetries lead to conservation laws, a theorem every quantum physicist uses. Maria Goeppert Mayer won the 1963 Nobel Prize for the nuclear shell model.",
      "Today, women lead quantum hardware teams, error-correction research and quantum start-ups around the world. Their common habit was curiosity plus practice, not a special 'math brain'."
    ],
    experiment: "Pick one of these scientists and build the Bell pair circuit in the lab. Wu's experiments tested exactly this kind of correlation.",
    followUps: ["What careers use quantum physics?", "Am I good enough at math for this?", "How do I build a Bell pair?"]
  },
  {
    topic: "applications", keywords: ["career", "job", "jobs", "become", "study", "university", "college", "future", "work in"], title: "Your path into quantum and STEM",
    paragraphs: [
      "Quantum teams need physicists, software engineers, mathematicians, electrical engineers, chemists, designers and science communicators.",
      "A good starting path: algebra and trigonometry, then vectors and complex numbers, a little programming (Python is great), and lots of small experiments like the ones in this studio.",
      "Join a coding club, a science fair, or a free online quantum course. Asking questions out loud, like you are doing now, is already how scientists work."
    ],
    experiment: "Try the Academy's first lesson today, then explain a qubit to a friend in one sentence. Teaching is the fastest way to learn.",
    followUps: ["Who are famous women in quantum science?", "Am I good enough at math for this?", "What is a qubit?"]
  },
  {
    topic: "applications", keywords: ["not smart", "too hard", "bad at math", "good enough", "scared", "confused", "can i", "difficult", "give up"], title: "You belong in science",
    paragraphs: [
      "Feeling confused is not a sign you are bad at physics. It is what learning physics feels like, even for professors.",
      "Ability in math grows with practice. Research shows that believing you can improve actually helps you improve.",
      "Let's take one tiny step together: a qubit is like an arrow that can point between 0 and 1. That's it. Everything else builds from there."
    ],
    experiment: "Open the Quantum Lab, press H once, and watch the probabilities split 50/50. You just made a superposition.",
    followUps: ["Explain a qubit like I'm new to physics", "Who are famous women in quantum science?", "What careers use quantum physics?"]
  },
];

const fallback: MentorReply = {
  topic: "unknown", title: "Let's untangle the quantum question",
  paragraphs: [
    "I am Mademoiselle Q, your quantum-learning companion. I can help with qubits, superposition, entanglement, gates, measurement, algorithms, noise, teleportation and topological braiding.",
    "Try asking one focused question, such as “Why does a Hadamard gate create superposition?” or “How do I build a Bell pair?”"
  ],
  followUps: ["Explain a qubit like I'm new to physics", "Who are famous women in quantum science?", "What careers use quantum physics?"]
};

export function answerQuantumQuestion(input: string): MentorReply {
  const normalized = input.toLowerCase().replace(/[^a-z0-9|+\- ]/g, " ").replace(/\s+/g, " ").trim();
  if (!normalized) return fallback;

  const scored = cards.map((card) => ({
    card,
    score: card.keywords.reduce((total, keyword) => {
      const key = keyword.toLowerCase();
      return total + (normalized.includes(key) ? (key.includes(" ") ? 3 : 2) : 0);
    }, 0)
  })).sort((a, b) => b.score - a.score);

  if (scored[0]?.score) {
    const { keywords: _keywords, ...reply } = scored[0].card;
    return reply;
  }

  if (/hello|hi |hey|good morning|good evening/.test(normalized)) {
    return {
      topic: "unknown", title: "Bonjour, curious mind!",
      paragraphs: ["I'm Mademoiselle Q. Ask me anything about the quantum ideas in this project. We can start with one qubit, create a superposition, or braid our way toward entanglement—one careful experiment at a time."],
      followUps: ["What is a qubit?", "Explain superposition", "Let's create entanglement"]
    };
  }
  return fallback;
}

export const QUANTUM_MENTOR_SYSTEM_PROMPT = `You are Mademoiselle Q, a warm, confident female-voiced quantum physics learning companion for La Petite Princesse: Entangled — The Quantum Universe. Stay focused on quantum physics, quantum information, quantum circuits, quantum algorithms, and the mathematics needed to understand them. Teach with curiosity, warmth, and respect; never patronize girls or imply that gender predicts ability. Explain concepts accurately, distinguish metaphors from physics, and correct misconceptions gently. Use short paragraphs, define notation, and offer a small experiment when useful. Never claim that quantum computers are universally faster, that entanglement enables faster-than-light communication, or that a measurement reveals every amplitude. Distinguish ordinary entanglement from topological anyon braiding. If uncertain, say so. Avoid collecting personal information. Do not provide unrelated advice; gently redirect to quantum learning. Keep answers suitable for teens and adults, without assuming prior knowledge.`;
