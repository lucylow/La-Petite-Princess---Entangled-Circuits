// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import type { CircuitDefinition } from "./types";
import { runCircuitShots } from "./simulator";

export interface NoiseScaleObservation { scale: number; expectation: number; standardError?: number; shots?: number; }
export interface ExtrapolationResult { estimateAtZeroNoise: number; degree: number; coefficients: number[]; fitted: number[]; residualRms: number; observations: NoiseScaleObservation[]; method: "polynomial" | "richardson"; }
export interface ReadoutCalibration { qubitCount: number; matrix: number[][]; conditionEstimate: number; labels: string[]; }
export interface MitigatedCounts { raw: number[]; quasiProbabilities: number[]; clippedProbabilities: number[]; normalization: number; residual: number; }
function validateObservations(points: NoiseScaleObservation[]): void {
  if (points.length < 2) throw new Error("At least two noise-scale observations are required.");
  if (points.some((point) => !Number.isFinite(point.scale) || point.scale < 0 || !Number.isFinite(point.expectation))) throw new Error("Noise scales must be non-negative and expectations must be finite.");
  if (new Set(points.map((point) => point.scale)).size !== points.length) throw new Error("Noise scales must be distinct.");
}
function solveLinearSystem(matrix: number[][], vector: number[], ridge = 0): number[] {
  const n = vector.length; const a = matrix.map((row, index) => [...row, vector[index]]);
  for (let i = 0; i < n; i += 1) a[i][i] += ridge;
  for (let pivot = 0; pivot < n; pivot += 1) {
    let selected = pivot;
    for (let row = pivot + 1; row < n; row += 1) if (Math.abs(a[row][pivot]) > Math.abs(a[selected][pivot])) selected = row;
    if (Math.abs(a[selected][pivot]) < 1e-14) throw new Error("The calibration or fit matrix is singular; add observations or regularization.");
    [a[pivot], a[selected]] = [a[selected], a[pivot]];
    const divisor = a[pivot][pivot]; for (let col = pivot; col <= n; col += 1) a[pivot][col] /= divisor;
    for (let row = 0; row < n; row += 1) if (row !== pivot) {
      const factor = a[row][pivot]; for (let col = pivot; col <= n; col += 1) a[row][col] -= factor * a[pivot][col];
    }
  }
  return a.map((row) => row[n]);
}
function polynomialFit(x: number[], y: number[], degree: number, weights?: number[]): number[] {
  const order = degree + 1; const normal = Array.from({ length: order }, () => Array(order).fill(0)); const rhs = Array(order).fill(0);
  x.forEach((value, index) => {
    const weight = weights?.[index] ?? 1; const powers = Array.from({ length: 2 * degree + 1 }, (_, exponent) => value ** exponent);
    for (let row = 0; row < order; row += 1) { rhs[row] += weight * y[index] * powers[row]; for (let col = 0; col < order; col += 1) normal[row][col] += weight * powers[row + col]; }
  });
  return solveLinearSystem(normal, rhs, 1e-13);
}
function evaluatePolynomial(coefficients: number[], x: number): number { return coefficients.reduceRight((value, coefficient) => value * x + coefficient, 0); }
/** Zero-noise extrapolation by weighted polynomial least squares in the supplied noise scale. */
export function zeroNoiseExtrapolate(observations: NoiseScaleObservation[], degree = 1): ExtrapolationResult {
  validateObservations(observations);
  if (!Number.isInteger(degree) || degree < 1 || degree >= observations.length) throw new RangeError("Polynomial degree must be between 1 and observationCount - 1.");
  const points = [...observations].sort((a, b) => a.scale - b.scale);
  const weights = points.map((point) => point.standardError && point.standardError > 0 ? 1 / (point.standardError ** 2) : 1);
  const coefficients = polynomialFit(points.map((point) => point.scale), points.map((point) => point.expectation), degree, weights);
  const fitted = points.map((point) => evaluatePolynomial(coefficients, point.scale));
  const residualRms = Math.sqrt(fitted.reduce((sum, value, index) => sum + (value - points[index].expectation) ** 2, 0) / points.length);
  return { estimateAtZeroNoise: coefficients[0], degree, coefficients, fitted, residualRms, observations: points, method: "polynomial" };
}
/** Richardson coefficients cancel polynomial error terms at specified scale factors. */
export function richardsonCoefficients(scales: number[]): number[] {
  if (scales.length < 2 || scales.some((scale) => !Number.isFinite(scale) || scale <= 0) || new Set(scales).size !== scales.length) throw new Error("Richardson scales must be distinct positive finite values.");
  return scales.map((scale, index) => scales.reduce((product, other, otherIndex) => otherIndex === index ? product : product * (-other) / (scale - other), 1));
}
export function richardsonExtrapolate(observations: NoiseScaleObservation[]): ExtrapolationResult {
  validateObservations(observations); const points = [...observations].sort((a, b) => a.scale - b.scale);
  const coefficients = richardsonCoefficients(points.map((point) => point.scale));
  const estimateAtZeroNoise = points.reduce((sum, point, index) => sum + point.expectation * coefficients[index], 0);
  const fitted = points.map((point) => point.expectation);
  return { estimateAtZeroNoise, degree: points.length - 1, coefficients, fitted, residualRms: 0, observations: points, method: "richardson" };
}
export function runNoiseScaleStudy(circuit: CircuitDefinition, scales: number[], shots: number, observable: (counts: Record<string, number>) => number, seed = 7): NoiseScaleObservation[] {
  if (!Number.isInteger(shots) || shots < 1) throw new RangeError("shots must be positive.");
  return scales.map((scale, index) => {
    if (!(scale >= 0) || !Number.isFinite(scale)) throw new RangeError("Noise scales must be non-negative.");
    const scaledOperations = circuit.operations.map((operation) => ({ ...operation, params: operation.params ? { ...operation.params } : undefined }));
    // The current local shot runner is ideal; annotate the requested scale so callers can
    // pair this helper with a backend/noise model that actually scales physical errors.
    const shotsResult = runCircuitShots({ ...circuit, operations: scaledOperations }, shots, seed + index);
    const expectation = observable(shotsResult.counts);
    return { scale, expectation, shots };
  });
}
function identity(size: number): number[][] { return Array.from({ length: size }, (_, row) => Array.from({ length: size }, (_, col) => Number(row === col))); }
function matrixNormInfinity(matrix: number[][]): number { return Math.max(...matrix.map((row) => row.reduce((sum, value) => sum + Math.abs(value), 0))); }
function invertMatrix(matrix: number[][]): number[][] {
  const n = matrix.length; if (!n || matrix.some((row) => row.length !== n)) throw new Error("Matrix must be non-empty and square.");
  const a = matrix.map((row, index) => [...row, ...identity(n)[index]]);
  for (let pivot = 0; pivot < n; pivot += 1) {
    let selected = pivot; for (let row = pivot + 1; row < n; row += 1) if (Math.abs(a[row][pivot]) > Math.abs(a[selected][pivot])) selected = row;
    if (Math.abs(a[selected][pivot]) < 1e-13) throw new Error("Readout calibration matrix is singular.");
    [a[pivot], a[selected]] = [a[selected], a[pivot]];
    const divisor = a[pivot][pivot]; for (let col = 0; col < 2 * n; col += 1) a[pivot][col] /= divisor;
    for (let row = 0; row < n; row += 1) if (row !== pivot) { const factor = a[row][pivot]; for (let col = 0; col < 2 * n; col += 1) a[row][col] -= factor * a[pivot][col]; }
  }
  return a.map((row) => row.slice(n));
}
export function buildReadoutCalibration(preparedToObserved: number[][], qubitCount: number): ReadoutCalibration {
  const dimension = 2 ** qubitCount;
  if (!Number.isInteger(qubitCount) || qubitCount < 1 || qubitCount > 5 || preparedToObserved.length !== dimension || preparedToObserved.some((row) => row.length !== dimension)) throw new Error("Readout matrix dimensions must be 2^n × 2^n for 1..5 qubits.");
  const matrix = preparedToObserved.map((row) => [...row]);
  for (let column = 0; column < dimension; column += 1) {
    const probabilities = matrix.map((row) => row[column]);
    if (probabilities.some((value) => value < 0 || !Number.isFinite(value)) || Math.abs(probabilities.reduce((sum, value) => sum + value, 0) - 1) > 1e-5) throw new Error(`Readout column ${column} must be a normalized probability vector.`);
  }
  const inverse = invertMatrix(matrix);
  const conditionEstimate = matrixNormInfinity(matrix) * matrixNormInfinity(inverse);
  return { qubitCount, matrix, conditionEstimate, labels: Array.from({ length: dimension }, (_, index) => index.toString(2).padStart(qubitCount, "0")) };
}
export function mitigateReadoutDistribution(calibration: ReadoutCalibration, observedCounts: number[], ridge = 1e-8): MitigatedCounts {
  const dimension = 2 ** calibration.qubitCount;
  if (observedCounts.length !== dimension || observedCounts.some((value) => !Number.isFinite(value) || value < 0)) throw new Error("Observed counts must match the calibrated state space and be non-negative.");
  const total = observedCounts.reduce((sum, value) => sum + value, 0); if (total <= 0) throw new Error("At least one observed shot is required.");
  const observed = observedCounts.map((value) => value / total); const inverse = invertMatrix(calibration.matrix);
  const quasiProbabilities = inverse.map((row) => row.reduce((sum, value, index) => sum + value * observed[index], 0));
  const clipped = quasiProbabilities.map((value) => Math.max(0, value)); const clippedTotal = clipped.reduce((sum, value) => sum + value, 0);
  if (clippedTotal <= 0) throw new Error("Readout mitigation produced no positive probability mass.");
  const clippedProbabilities = clipped.map((value) => value / clippedTotal);
  const residual = Math.sqrt(quasiProbabilities.reduce((sum, value, index) => sum + (value - clippedProbabilities[index]) ** 2, 0));
  return { raw: observed, quasiProbabilities, clippedProbabilities, normalization: clippedTotal, residual };
}
export function binomialStandardError(probability: number, shots: number): number {
  if (!(probability >= 0 && probability <= 1) || !Number.isInteger(shots) || shots < 1) throw new Error("Probability must be in [0,1] and shots must be positive.");
  return Math.sqrt(probability * (1 - probability) / shots);
}
export function wilsonInterval(successes: number, shots: number, z = 1.96): [number, number] {
  if (!Number.isInteger(successes) || !Number.isInteger(shots) || shots < 1 || successes < 0 || successes > shots || !(z > 0)) throw new Error("Invalid binomial counts or confidence multiplier.");
  const p = successes / shots; const z2 = z * z; const denominator = 1 + z2 / shots;
  const center = (p + z2 / (2 * shots)) / denominator;
  const half = z * Math.sqrt(p * (1 - p) / shots + z2 / (4 * shots * shots)) / denominator;
  return [successes === 0 ? 0 : Math.max(0, center - half), successes === shots ? 1 : Math.min(1, center + half)];
}
