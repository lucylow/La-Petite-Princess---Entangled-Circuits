// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { assertValidCircuit } from "./circuit";
import { createOperation } from "./circuit";
import type { CircuitDefinition, CircuitOperation, GateName } from "./types";

export function serializeCircuit(circuit: CircuitDefinition, pretty = true): string {
  return JSON.stringify(circuit, null, pretty ? 2 : 0);
}
export function parseCircuit(source: string): CircuitDefinition {
  const parsed: unknown = JSON.parse(source);
  if (!parsed || typeof parsed !== "object") throw new Error("Circuit file must contain a JSON object.");
  const circuit = parsed as CircuitDefinition;
  if (circuit.version !== 1 || typeof circuit.name !== "string" || !Array.isArray(circuit.operations)) throw new Error("Unsupported or malformed circuit document.");
  assertValidCircuit(circuit);
  return circuit;
}

const QASM_GATE: Partial<Record<GateName, string>> = {
  I: "id", X: "x", Y: "y", Z: "z", H: "h", S: "s", SDG: "sdg", T: "t", TDG: "tdg",
  SX: "sx", RX: "rx", RY: "ry", RZ: "rz", U3: "u3", CX: "cx", CY: "cy", CZ: "cz",
  CH: "ch", CP: "cp", CRX: "crx", CRY: "cry", CRZ: "crz", SWAP: "swap", CCX: "ccx", CSWAP: "cswap",
  BARRIER: "barrier", MEASURE: "measure",
};
function qasmParameter(value: number): string {
  if (!Number.isFinite(value)) throw new Error("QASM parameters must be finite.");
  const ratio = value / Math.PI;
  if (Math.abs(ratio - 1) < 1e-10) return "pi";
  if (Math.abs(ratio + 1) < 1e-10) return "-pi";
  if (Math.abs(ratio) < 1e-10) return "0";
  return Number(value.toPrecision(12)).toString();
}
export function circuitToOpenQasm(circuit: CircuitDefinition): string {
  assertValidCircuit(circuit);
  const lines = ["OPENQASM 2.0;", 'include "qelib1.inc";', `qreg q[${circuit.qubitCount}];`];
  if (circuit.classicalBitCount) lines.push(`creg c[${circuit.classicalBitCount}];`);
  for (const operation of circuit.operations) {
    const gate = QASM_GATE[operation.gate];
    if (!gate) throw new Error(`OpenQASM 2.0 exporter does not support ${operation.gate}.`);
    const targets = operation.targets.map((q) => `q[${q}]`);
    const controls = (operation.controls ?? []).map((q) => `q[${q}]`);
    if (operation.gate === "BARRIER") { lines.push(`barrier ${[...controls, ...targets].join(",")};`); continue; }
    if (operation.gate === "MEASURE") { lines.push(`measure ${targets[0]} -> c[${operation.classicalBit ?? 0}];`); continue; }
    let params = "";
    if (["RX", "RY", "RZ", "CP", "CRX", "CRY", "CRZ"].includes(operation.gate)) params = `(${qasmParameter(operation.params?.theta ?? 0)})`;
    if (operation.gate === "U3") params = `(${qasmParameter(operation.params?.theta ?? 0)}, ${qasmParameter(operation.params?.phi ?? 0)}, ${qasmParameter(operation.params?.lambda ?? 0)})`;
    lines.push(`${gate}${params} ${[...controls, ...targets].join(",")};`);
  }
  return `${lines.join("\n")}\n`;
}

export function parseOpenQasm(source: string): CircuitDefinition {
  const cleaned = source.replace(/\/\/.*$/gm, "").replace(/\/\*([\s\S]*?)\*\//g, "");
  const statements = cleaned.split(";").map((line) => line.trim()).filter(Boolean);
  let qubitCount = 0; let classicalBitCount = 0; const operations: CircuitOperation[] = [];
  const parseWire = (value: string): number => {
    const match = value.trim().match(/^[qQ]\[(\d+)\]$/);
    if (!match) throw new Error(`Unsupported QASM wire expression: ${value}`);
    return Number(match[1]);
  };
  const parseAngle = (value: string): number => {
    const normalized = value.replace(/\s/g, "").toLowerCase();
    if (normalized === "pi") return Math.PI;
    if (normalized === "-pi") return -Math.PI;
    const ratio = normalized.match(/^(-?(?:\d+(?:\.\d+)?)?)\*?pi\/(\d+(?:\.\d+)?)$/);
    if (ratio) return (ratio[1] === "" || ratio[1] === "-" ? Number(`${ratio[1]}1`) : Number(ratio[1])) * Math.PI / Number(ratio[2]);
    const valueNumber = Number(normalized);
    if (!Number.isFinite(valueNumber)) throw new Error(`Unsupported QASM angle: ${value}`);
    return valueNumber;
  };
  for (const statement of statements) {
    if (/^OPENQASM\s+/i.test(statement) || /^include\s+/i.test(statement)) continue;
    const qreg = statement.match(/^qreg\s+q\[(\d+)\]$/i);
    if (qreg) { qubitCount = Number(qreg[1]); continue; }
    const creg = statement.match(/^creg\s+c\[(\d+)\]$/i);
    if (creg) { classicalBitCount = Number(creg[1]); continue; }
    const measurement = statement.match(/^measure\s+q\[(\d+)\]\s*->\s*c\[(\d+)\]$/i);
    if (measurement) { operations.push({ ...createOperation("MEASURE", Number(measurement[1])), classicalBit: Number(measurement[2]) }); continue; }
    if (/^barrier\b/i.test(statement)) {
      const wires = statement.replace(/^barrier\s*/i, "").split(",").map(parseWire);
      operations.push(createOperation("BARRIER", wires.length ? wires : [0])); continue;
    }
    const gateMatch = statement.match(/^([a-z][a-z0-9]*)(?:\(([^)]*)\))?\s+(.+)$/i);
    if (!gateMatch) throw new Error(`Cannot parse QASM statement: ${statement}`);
    const token = gateMatch[1].toLowerCase(); const parameterText = gateMatch[2];
    const mapping: Record<string, GateName> = Object.fromEntries(Object.entries(QASM_GATE).map(([key, value]) => [value, key as GateName]));
    mapping.id = "I"; mapping.u = "U3"; mapping.ccx = "CCX"; mapping.cnot = "CX";
    const gate = mapping[token];
    if (!gate) throw new Error(`Unsupported OpenQASM gate: ${token}`);
    const wires = gateMatch[3].split(",").map(parseWire);
    let controls: number[] = []; let targets = wires;
    if (["CX", "CY", "CZ", "CH", "CP", "CRX", "CRY", "CRZ"].includes(gate)) { controls = [wires[0]]; targets = [wires[1]]; }
    else if (gate === "CCX") { controls = wires.slice(0, 2); targets = [wires[2]]; }
    else if (gate === "CSWAP") { controls = [wires[0]]; targets = wires.slice(1); }
    let params: CircuitOperation["params"];
    if (parameterText !== undefined) {
      const values = parameterText.split(",").map(parseAngle);
      params = gate === "U3" ? { theta: values[0], phi: values[1], lambda: values[2] } : { theta: values[0] };
    }
    operations.push(createOperation(gate, targets, controls, params));
  }
  if (!qubitCount) throw new Error("QASM program is missing qreg q[n].");
  const circuit: CircuitDefinition = { id: "qasm-import", name: "Imported QASM circuit", qubitCount, classicalBitCount, operations, version: 1 };
  assertValidCircuit(circuit);
  return circuit;
}

export function circuitToQiskitPython(circuit: CircuitDefinition): string {
  assertValidCircuit(circuit);
  const lines = ["from qiskit import QuantumCircuit", `qc = QuantumCircuit(${circuit.qubitCount}, ${circuit.classicalBitCount})`, ""];
  for (const operation of circuit.operations) {
    const gate = operation.gate.toLowerCase(); const targets = operation.targets; const controls = operation.controls ?? [];
    if (operation.gate === "BARRIER") { lines.push(`qc.barrier(${[...controls, ...targets].join(", ")})`); continue; }
    if (operation.gate === "MEASURE") { lines.push(`qc.measure(${targets[0]}, ${operation.classicalBit ?? 0})`); continue; }
    if (["RX", "RY", "RZ", "CP", "CRX", "CRY", "CRZ"].includes(operation.gate)) lines.push(`qc.${gate}(${operation.params?.theta ?? 0}, ${[...controls, ...targets].join(", ")})`);
    else if (operation.gate === "U3") lines.push(`qc.u(${operation.params?.theta ?? 0}, ${operation.params?.phi ?? 0}, ${operation.params?.lambda ?? 0}, ${targets[0]})`);
    else if (operation.gate === "CX" || operation.gate === "CY" || operation.gate === "CZ" || operation.gate === "CH") lines.push(`qc.${gate}(${controls[0]}, ${targets[0]})`);
    else if (operation.gate === "CCX") lines.push(`qc.ccx(${controls[0]}, ${controls[1]}, ${targets[0]})`);
    else if (operation.gate === "CSWAP") lines.push(`qc.cswap(${controls[0]}, ${targets[0]}, ${targets[1]})`);
    else if (operation.gate === "SWAP" || operation.gate === "ISWAP") lines.push(`qc.${gate}(${targets[0]}, ${targets[1]})`);
    else lines.push(`qc.${gate}(${targets[0]})`);
  }
  lines.push("", "print(qc.draw())");
  return `${lines.join("\n")}\n`;
}
