const SYMBOLS: Record<string, string> = {
  rangle: "⟩", langle: "⟨", otimes: "⊗", oplus: "⊕", cdot: "·", times: "×", pm: "±", to: "→", rightarrow: "→",
  approx: "≈", neq: "≠", leq: "≤", geq: "≥", infty: "∞", dagger: "†", psi: "ψ", phi: "φ", theta: "θ", alpha: "α",
  beta: "β", gamma: "γ", lambda: "λ", pi: "π", omega: "ω", sigma: "σ", rho: "ρ", hbar: "ħ", sum: "Σ", ket: "",
};

/** Turn LaTeX-flavoured model output into readable plain text for the chat bubble. */
export function plainMath(text: string): string {
  let out = text.replace(/\\\(|\\\)|\\\[|\\\]|\$\$?/g, "");
  out = out.replace(/\\ket\{([^}]*)\}/g, "|$1⟩").replace(/\\bra\{([^}]*)\}/g, "⟨$1|");
  out = out.replace(/\\frac\{([^}]*)\}\{([^}]*)\}/g, "($1)/($2)").replace(/\\sqrt\{([^}]*)\}/g, "√$1");
  out = out.replace(/\\(?:left|right|big|Big)\b/g, "");
  out = out.replace(/\\([a-zA-Z]+)/g, (match, name: string) => SYMBOLS[name] ?? match.slice(1));
  out = out.replace(/\\[,;! ]/g, " ").replace(/\\/g, "");
  out = out.replace(/\*\*([^*]+)\*\*/g, "$1").replace(/`([^`]+)`/g, "$1");
  return out.replace(/[ \t]{2,}/g, " ").trim();
}
