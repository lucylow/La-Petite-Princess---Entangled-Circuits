import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { QUANTUM_MENTOR_SYSTEM_PROMPT } from "@/voice/quantumKnowledge";
import { plainMath } from "./mentorText";

const inputSchema = z.object({
  messages: z
    .array(z.object({ role: z.enum(["user", "assistant"]), content: z.string().min(1).max(4000) }))
    .min(1)
    .max(12),
});

export type MentorResult =
  | { ok: true; reply: string }
  | { ok: false; reason: "busy" | "credits" | "unavailable" };

export const askMentor = createServerFn({ method: "POST" })
  .validator((data) => inputSchema.parse(data))
  .handler(async ({ data }): Promise<MentorResult> => {
    const { generateResponse, GatewayError, RateLimitError, PaymentRequiredError } = await import("@lovable.dev/ai-gateway");
    try {
      const response = await generateResponse({
        model: "openai/gpt-6-astra",
        instructions: `${QUANTUM_MENTOR_SYSTEM_PROMPT}\n\nFormatting: replies are shown as plain text. Never use LaTeX, Markdown symbols, or code blocks; write math with plain Unicode such as |0⟩, |1⟩, √2, θ, ⊗.`,
        input: data.messages.map((m) => ({ role: m.role, content: m.content })),
      });
      let text = "";
      for (const item of response.output ?? []) {
        if (item.type !== "message") continue;
        for (const part of item.content ?? []) if (part.type === "output_text") text += part.text;
      }
      text = plainMath(text);
      return text ? { ok: true, reply: text } : { ok: false, reason: "unavailable" };
    } catch (error) {
      if (error instanceof RateLimitError) return { ok: false, reason: "busy" };
      if (error instanceof PaymentRequiredError) return { ok: false, reason: "credits" };
      if (error instanceof GatewayError) console.error("Mentor gateway error", error.code, error.ids);
      else console.error("Mentor error", error);
      return { ok: false, reason: "unavailable" };
    }
  });
