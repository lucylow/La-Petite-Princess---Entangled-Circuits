import { describe, expect, it } from "vitest";
import { plainMath } from "./mentorText";

describe("plainMath", () => {
  it("turns LaTeX kets and square roots into readable symbols", () => {
    expect(plainMath("maps \\(|0\\rangle\\) to \\((|0\\rangle+|1\\rangle)/\\sqrt{2}\\)")).toBe("maps |0⟩ to (|0⟩+|1⟩)/√2");
  });
  it("leaves plain sentences untouched", () => {
    expect(plainMath("A qubit can be measured as 0 or 1.")).toBe("A qubit can be measured as 0 or 1.");
  });
});
