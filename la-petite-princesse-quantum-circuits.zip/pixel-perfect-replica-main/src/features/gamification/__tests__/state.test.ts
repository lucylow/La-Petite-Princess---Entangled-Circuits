import { describe, expect, it } from "vitest";
import { createInitialGamificationState } from "../defaults";
import { addQuestProgress, recordLearningActivity } from "../engine/state";

const date = (day: string) => new Date(`${day}T12:00:00.000Z`);

describe("gamification state transitions", () => {
  it("awards quest XP exactly once when a quest is completed", () => {
    const start = createInitialGamificationState(date("2026-11-04"));
    const once = addQuestProgress(start, "daily-discovery", 1, date("2026-11-04"));
    const twice = addQuestProgress(once, "daily-discovery", 1, date("2026-11-04"));

    expect(once.totalXp).toBe(30);
    expect(once.completedQuestsCount).toBe(1);
    expect(twice.totalXp).toBe(30);
    expect(twice.completedQuestsCount).toBe(1);
  });

  it("increments a streak on consecutive local calendar days", () => {
    const start = createInitialGamificationState(date("2026-11-02"));
    const dayOne = recordLearningActivity(start, 10, "Lesson", date("2026-11-02"));
    const sameDay = recordLearningActivity(dayOne, 10, "Practice", new Date("2026-11-02T17:00:00.000Z"));
    const dayTwo = recordLearningActivity(sameDay, 10, "Lesson", date("2026-11-03"));

    expect(dayOne.streak).toBe(1);
    expect(sameDay.streak).toBe(1);
    expect(dayTwo.streak).toBe(2);
  });

  it("resets an expired streak when a day is missed", () => {
    const start = createInitialGamificationState(date("2026-11-01"));
    const dayOne = recordLearningActivity(start, 10, "Lesson", date("2026-11-01"));
    const dayThree = recordLearningActivity(dayOne, 10, "Lesson", date("2026-11-03"));
    expect(dayThree.streak).toBe(1);
  });

  it("unlocks the first XP achievement when its threshold is reached", () => {
    const start = createInitialGamificationState(date("2026-11-04"));
    const next = recordLearningActivity(start, 50, "Milestone lesson", date("2026-11-04"));
    expect(next.achievements.find((item) => item.id === "first-steps")?.unlockedAt).toBeTruthy();
  });
});
