import { describe, expect, it } from "vitest";
import { getLevelProgress, xpFloorForLevel } from "../engine/progression";

describe("level progression", () => {
  it("starts at level one with an empty progress bar", () => {
    expect(getLevelProgress(0)).toMatchObject({ level: 1, progressXp: 0, requiredXp: 100, progressPercent: 0 });
  });

  it("levels up at the cumulative XP threshold", () => {
    expect(getLevelProgress(99).level).toBe(1);
    expect(getLevelProgress(100)).toMatchObject({ level: 2, progressXp: 0, requiredXp: 200 });
    expect(getLevelProgress(300).level).toBe(3);
  });

  it("uses increasing cumulative thresholds", () => {
    expect(xpFloorForLevel(4)).toBe(600);
    expect(xpFloorForLevel(0)).toBe(0);
  });

  it("handles negative and invalid XP safely", () => {
    expect(getLevelProgress(-50).level).toBe(1);
    expect(getLevelProgress(Number.NaN).progressPercent).toBe(0);
  });
});
