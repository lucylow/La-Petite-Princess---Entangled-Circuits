// @ts-nocheck
import type { Achievement } from "../types";

export interface AchievementGridProps {
  achievements: Achievement[];
  limit?: number;
}

export function AchievementGrid({ achievements, limit = 6 }: AchievementGridProps) {
  const visible = achievements.slice(0, limit);
  const unlocked = achievements.filter((item) => item.unlockedAt).length;

  return (
    <section className="gami-panel" aria-labelledby="gami-achievements-title">
      <div className="gami-section-heading">
        <div>
          <span className="gami-eyebrow">Milestones</span>
          <h2 id="gami-achievements-title">Achievements</h2>
        </div>
        <span className="gami-section-count">{unlocked}/{achievements.length} unlocked</span>
      </div>
      <div className="gami-achievement-grid">
        {visible.map((achievement) => {
          const isUnlocked = Boolean(achievement.unlockedAt);
          return (
            <article className={`gami-achievement${isUnlocked ? " is-unlocked" : " is-locked"}`} key={achievement.id}>
              <div className="gami-achievement__icon" aria-hidden="true">{achievement.icon}</div>
              <div>
                <h3>{achievement.title}</h3>
                <p>{achievement.description}</p>
                <span className="gami-achievement__status">{isUnlocked ? "Unlocked" : "In progress"}</span>
              </div>
            </article>
          );
        })}
      </div>
    </section>
  );
}
