// @ts-nocheck
import type { LeaderboardEntry } from "../types";

export interface LeaderboardPanelProps {
  entries: LeaderboardEntry[];
  title?: string;
  description?: string;
  limit?: number;
}

/** Presentation-only leaderboard. Supply real, permission-checked data from your backend. */
export function LeaderboardPanel({
  entries,
  title = "Learning leaderboard",
  description = "A little friendly momentum from your learning community.",
  limit = 5,
}: LeaderboardPanelProps) {
  const ranked = [...entries].sort((a, b) => b.xp - a.xp).slice(0, limit);

  return (
    <section className="gami-panel" aria-labelledby="gami-leaderboard-title">
      <div className="gami-section-heading">
        <div>
          <span className="gami-eyebrow">Community</span>
          <h2 id="gami-leaderboard-title">{title}</h2>
          <p className="gami-panel-description">{description}</p>
        </div>
        <span className="gami-section-count">{entries.length} learners</span>
      </div>
      {ranked.length === 0 ? (
        <div className="gami-empty-state"><span aria-hidden="true">✧</span><h3>Your community starts here</h3><p>Leaderboard entries will appear when community participation is enabled.</p></div>
      ) : (
        <ol className="gami-leaderboard">
          {ranked.map((entry, index) => (
            <li className={entry.isCurrentUser ? "is-current-user" : ""} key={entry.id}>
              <span className={`gami-leaderboard__rank rank-${index + 1}`}>{index + 1}</span>
              {entry.avatarUrl ? <img className="gami-leaderboard__avatar" src={entry.avatarUrl} alt="" loading="lazy" /> : <span className="gami-leaderboard__avatar gami-leaderboard__avatar--fallback" aria-hidden="true">{entry.displayName.trim().charAt(0).toUpperCase() || "?"}</span>}
              <span className="gami-leaderboard__name">{entry.displayName}{entry.isCurrentUser ? <small>YOU</small> : null}</span>
              <strong>{entry.xp.toLocaleString()} XP</strong>
            </li>
          ))}
        </ol>
      )}
    </section>
  );
}
