// @ts-nocheck
import type { ReactNode } from "react";

export interface ProgressRingProps {
  value: number;
  size?: number;
  strokeWidth?: number;
  label?: string;
  children?: ReactNode;
  className?: string;
}

export function ProgressRing({
  value,
  size = 76,
  strokeWidth = 7,
  label = "Progress",
  children,
  className = "",
}: ProgressRingProps) {
  const safeValue = Math.min(100, Math.max(0, Number.isFinite(value) ? value : 0));
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;

  return (
    <div className={`gami-ring ${className}`} style={{ width: size, height: size }} role="img" aria-label={`${label}: ${Math.round(safeValue)}%`}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} aria-hidden="true">
        <circle className="gami-ring__track" cx={size / 2} cy={size / 2} r={radius} fill="none" strokeWidth={strokeWidth} />
        <circle
          className="gami-ring__value"
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          strokeWidth={strokeWidth}
          strokeDasharray={circumference}
          strokeDashoffset={circumference * (1 - safeValue / 100)}
          strokeLinecap="round"
          transform={`rotate(-90 ${size / 2} ${size / 2})`}
        />
      </svg>
      <span className="gami-ring__content">{children ?? `${Math.round(safeValue)}%`}</span>
    </div>
  );
}
