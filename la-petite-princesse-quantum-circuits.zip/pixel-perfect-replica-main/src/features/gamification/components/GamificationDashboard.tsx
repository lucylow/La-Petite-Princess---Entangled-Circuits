// @ts-nocheck
import { getLevelProgress } from "../engine/progression";
import type { GamificationState, Quest } from "../types";
import { AchievementGrid } from "./AchievementGrid";
import { ProgressRing } from "./ProgressRing";
import { QuestCard } from "./QuestCard";
import { WeeklyActivity } from "./WeeklyActivity";
import { JourneyMilestones } from "./JourneyMilestones";

export interface GamificationDashboardProps {
  state: GamificationState;
  onQuestSelect?: (quest: Quest) => void;
  title?: string;
  subtitle?: string;
  className?: string;
}

export function GamificationDashboard({
  state,
  onQuestSelect,
  title = "Your learning journey",
  subtitle = "Small steps, meaningful progress. Keep exploring.",
  className = "",
}: GamificationDashboardProps) {
  const level = getLevelProgress(state.totalXp);
  const activeQuests = state.quests.filter((quest) => !quest.completedAt);
  const completedToday = state.quests.filter((quest) => quest.cadence === "daily" && quest.completedAt).length;

  return (
    <main className={`gami-dashboard ${className}`}>
      <header className="gami-dashboard__heading">
        <div>
          <span className="gami-eyebrow">Progress hub</span>
          <h1>{title}</h1>
          <p>{subtitle}</p>
        </div>
        <div className="gami-streak-pill" aria-label={`${state.streak} day learning streak`}>
          <span aria-hidden="true">✦</span>
          <strong>{state.streak}</strong>
          <span>day streak</span>
        </div>
      </header>

      <section className="gami-hero" aria-labelledby="gami-level-title">
        <div className="gami-hero__copy">
          <span className="gami-eyebrow">Current rank</span>
          <h2 id="gami-level-title">Level {level.level}</h2>
          <p>{level.title}</p>
          <div className="gami-xp-line">
            <span>{level.progressXp.toLocaleString()} / {level.requiredXp.toLocaleString()} XP</span>
            <strong>{Math.round(level.progressPercent)}%</strong>
          </div>
          <div className="gami-progress-track gami-progress-track--hero" role="progressbar" aria-label="Progress to next level" aria-valuemin={0} aria-valuemax={level.requiredXp} aria-valuenow={level.progressXp}>
            <span style={{ width: `${level.progressPercent}%` }} />
          </div>
          <small>{Math.max(0, level.requiredXp - level.progressXp)} XP to the next level</small>
        </div>
        <ProgressRing value={level.progressPercent} size={132} strokeWidth={10} label="Level progress">
          <span className="gami-level-number">{level.level}</span>
          <span className="gami-level-caption">LEVEL</span>
        </ProgressRing>
        <div className="gami-hero__spark" aria-hidden="true">✧</div>
      </section>

      <section className="gami-stat-grid" aria-label="Learning statistics">
        <article className="gami-stat-card">
          <span className="gami-stat-card__icon" aria-hidden="true">✦</span>
          <span className="gami-eyebrow">Total experience</span>
          <strong>{state.totalXp.toLocaleString()}</strong>
          <small>XP earned so far</small>
        </article>
        <article className="gami-stat-card">
          <span className="gami-stat-card__icon" aria-hidden="true">♨</span>
          <span className="gami-eyebrow">Learning streak</span>
          <strong>{state.streak}<small className="gami-stat-unit"> days</small></strong>
          <small>Consecutive active days</small>
        </article>
        <article className="gami-stat-card">
          <span className="gami-stat-card__icon" aria-hidden="true">⚑</span>
          <span className="gami-eyebrow">Quests completed</span>
          <strong>{state.completedQuestsCount}</strong>
          <small>{completedToday} daily quests finished</small>
        </article>
      </section>

      <section className="gami-panel" aria-labelledby="gami-quests-title">
        <div className="gami-section-heading">
          <div>
            <span className="gami-eyebrow">Your next moves</span>
            <h2 id="gami-quests-title">Active quests</h2>
          </div>
          <span className="gami-section-count">{activeQuests.length} active</span>
        </div>
        {state.quests.length === 0 ? (
          <div className="gami-empty-state">
            <span aria-hidden="true">✧</span>
            <h3>A fresh page</h3>
            <p>New quests will appear here when your learning plan is ready.</p>
          </div>
        ) : (
          <div className="gami-quest-list">
            {state.quests.map((quest) => <QuestCard key={quest.id} quest={quest} onSelect={onQuestSelect} />)}
          </div>
        )}
      </section>

      <WeeklyActivity events={state.xpHistory} />
      <JourneyMilestones totalXp={state.totalXp} />
      <AchievementGrid achievements={state.achievements} />
      <footer className="gami-dashboard__footer">
        <span>Progress is saved on this device by default.</span>
        <span>{state.xpHistory.length} recent XP events tracked</span>
      </footer>
    </main>
  );
}
