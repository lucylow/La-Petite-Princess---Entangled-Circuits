// @ts-nocheck
import type { Quest } from "../types";

export interface QuestCardProps {
  quest: Quest;
  onSelect?: (quest: Quest) => void;
}

export function QuestCard({ quest, onSelect }: QuestCardProps) {
  const percent = Math.min(100, Math.max(0, (quest.progress / quest.target) * 100));
  const completed = Boolean(quest.completedAt) || percent >= 100;

  return (
    <article className={`gami-quest${completed ? " is-complete" : ""}`}>
      <div className="gami-quest__icon" aria-hidden="true">{quest.icon}</div>
      <div className="gami-quest__main">
        <div className="gami-quest__meta">
          <span className="gami-eyebrow">{quest.category}</span>
          <span className="gami-quest__cadence">{quest.cadence}</span>
        </div>
        <h3>{quest.title}</h3>
        <p>{quest.description}</p>
        <div className="gami-progress-track" role="progressbar" aria-label={`${quest.title} progress`} aria-valuemin={0} aria-valuemax={quest.target} aria-valuenow={quest.progress}>
          <span style={{ width: `${percent}%` }} />
        </div>
        <div className="gami-quest__footer">
          <span>{quest.progress}/{quest.target} completed</span>
          <strong>+{quest.xpReward} XP</strong>
        </div>
      </div>
      {onSelect && (
        <button className="gami-icon-button gami-quest__action" type="button" onClick={() => onSelect(quest)} aria-label={`Open ${quest.title}`} disabled={completed}>
          {completed ? "✓" : "↗"}
        </button>
      )}
    </article>
  );
}
