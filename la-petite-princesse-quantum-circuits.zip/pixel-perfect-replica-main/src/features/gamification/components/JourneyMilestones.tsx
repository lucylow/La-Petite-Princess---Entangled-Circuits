// @ts-nocheck
import { xpFloorForLevel } from "../engine/progression";

export interface JourneyMilestone {
  id: string;
  level: number;
  title: string;
  description: string;
}

export interface JourneyMilestonesProps {
  totalXp: number;
  milestones?: JourneyMilestone[];
}

export const DEFAULT_JOURNEY_MILESTONES: JourneyMilestone[] = [
  { id: "foundations", level: 1, title: "Foundations", description: "Start building your learning practice." },
  { id: "exploration", level: 3, title: "Exploration", description: "Unlock deeper guided investigations." },
  { id: "circuits", level: 5, title: "Circuit explorer", description: "Take on more advanced circuit challenges." },
  { id: "mastery", level: 8, title: "Mastery path", description: "Connect concepts through longer projects." },
  { id: "innovator", level: 12, title: "Innovator", description: "Reach the frontier of your learning journey." },
];

export function JourneyMilestones({ totalXp, milestones = DEFAULT_JOURNEY_MILESTONES }: JourneyMilestonesProps) {
  return (
    <section className="gami-panel" aria-labelledby="gami-journey-title">
      <div className="gami-section-heading">
        <div><span className="gami-eyebrow">The long game</span><h2 id="gami-journey-title">Journey map</h2></div>
        <span className="gami-section-count">{milestones.filter((item) => totalXp >= xpFloorForLevel(item.level)).length}/{milestones.length} milestones</span>
      </div>
      <ol className="gami-journey">
        {milestones.map((milestone) => {
          const unlocked = totalXp >= xpFloorForLevel(milestone.level);
          return (
            <li className={unlocked ? "is-unlocked" : "is-locked"} key={milestone.id}>
              <span className="gami-journey__node" aria-hidden="true">{unlocked ? "✓" : milestone.level}</span>
              <div><span className="gami-eyebrow">Level {milestone.level}</span><h3>{milestone.title}</h3><p>{milestone.description}</p></div>
              <span className="gami-journey__status">{unlocked ? "Unlocked" : "Locked"}</span>
            </li>
          );
        })}
      </ol>
    </section>
  );
}
