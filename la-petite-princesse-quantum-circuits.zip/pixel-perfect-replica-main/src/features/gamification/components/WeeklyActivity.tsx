// @ts-nocheck
import { localDateKey } from "../engine/date";
import type { XpEvent } from "../types";

export interface WeeklyActivityProps {
  events: XpEvent[];
  now?: Date;
}

export function WeeklyActivity({ events, now = new Date() }: WeeklyActivityProps) {
  const days = Array.from({ length: 7 }, (_, index) => {
    const date = new Date(now);
    date.setHours(0, 0, 0, 0);
    date.setDate(date.getDate() - (6 - index));
    const key = localDateKey(date);
    const xp = events.reduce((total, event) => {
      const eventDate = new Date(event.createdAt);
      return Number.isNaN(eventDate.getTime()) || localDateKey(eventDate) !== key ? total : total + event.amount;
    }, 0);
    return { key, label: date.toLocaleDateString(undefined, { weekday: "short" }), xp };
  });
  const maxXp = Math.max(20, ...days.map((day) => day.xp));
  const total = days.reduce((sum, day) => sum + day.xp, 0);

  return (
    <section className="gami-panel" aria-labelledby="gami-activity-title">
      <div className="gami-section-heading">
        <div>
          <span className="gami-eyebrow">Consistency</span>
          <h2 id="gami-activity-title">Last 7 days</h2>
        </div>
        <span className="gami-section-count">{total.toLocaleString()} XP earned</span>
      </div>
      <div className="gami-week-bars" role="img" aria-label={`XP earned over the last seven days: ${days.map((day) => `${day.label} ${day.xp} XP`).join(", ")}`}>
        {days.map((day) => (
          <div className="gami-week-bars__day" key={day.key}>
            <span className="gami-week-bars__value">{day.xp > 0 ? day.xp : ""}</span>
            <div className="gami-week-bars__track"><span style={{ height: `${day.xp === 0 ? 3 : Math.max(8, (day.xp / maxXp) * 100)}%` }} /></div>
            <span className="gami-week-bars__label">{day.label}</span>
          </div>
        ))}
      </div>
    </section>
  );
}
