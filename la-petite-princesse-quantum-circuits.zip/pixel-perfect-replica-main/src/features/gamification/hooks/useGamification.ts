// @ts-nocheck
import { useCallback, useEffect, useMemo, useState } from "react";
import { DEFAULT_STORAGE_KEY, createInitialGamificationState } from "../defaults";
import { addQuestProgress, normaliseGamificationState, recordLearningActivity, resetGamificationState } from "../engine/state";
import { getLevelProgress } from "../engine/progression";
import { loadGamificationState, saveGamificationState } from "../storage/storage";
import type { GamificationState, LevelProgress, UseGamificationOptions } from "../types";

export interface GamificationApi {
  state: GamificationState;
  level: LevelProgress;
  isReady: boolean;
  recordActivity: (xpAmount?: number, reason?: string) => void;
  addQuestProgress: (questId: string, amount?: number) => void;
  resetProgress: () => void;
}

/**
 * Local-first gamification state. The hook is storage-agnostic at the component layer;
 * swap the storage adapter if the application later moves progress to Supabase.
 */
export function useGamification(options: UseGamificationOptions = {}): GamificationApi {
  const storageKey = options.storageKey ?? DEFAULT_STORAGE_KEY;
  const clock = useMemo(() => options.now ?? (() => new Date()), [options.now]);
  const [state, setState] = useState<GamificationState>(() =>
    options.initialState
      ? normaliseGamificationState(options.initialState, clock())
      : createInitialGamificationState(clock()),
  );
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    if (options.initialState) {
      setState(normaliseGamificationState(options.initialState, clock()));
    } else {
      setState(loadGamificationState(storageKey, clock()));
    }
    setIsReady(true);
    // Intentionally hydrate once per storage key; clock is an injected stable dependency.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [storageKey]);

  useEffect(() => {
    if (isReady) saveGamificationState(state, storageKey);
  }, [isReady, state, storageKey]);

  const recordActivity = useCallback((xpAmount = 10, reason = "Learning activity") => {
    const now = clock();
    setState((current) => recordLearningActivity(current, xpAmount, reason, now));
  }, [clock]);

  const addProgress = useCallback((questId: string, amount = 1) => {
    const now = clock();
    setState((current) => addQuestProgress(current, questId, amount, now));
  }, [clock]);

  const resetProgress = useCallback(() => setState(resetGamificationState(clock())), [clock]);
  const level = useMemo(() => getLevelProgress(state.totalXp), [state.totalXp]);

  return { state, level, isReady, recordActivity, addQuestProgress: addProgress, resetProgress };
}
