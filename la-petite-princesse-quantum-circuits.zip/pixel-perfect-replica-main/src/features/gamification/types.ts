// @ts-nocheck
export type QuestCadence = "daily" | "weekly";
export type AchievementRequirementType = "total-xp" | "streak" | "quests-completed";

export interface Quest {
  id: string;
  title: string;
  description: string;
  category: string;
  icon: string;
  cadence: QuestCadence;
  progress: number;
  target: number;
  xpReward: number;
  /** Local date key (daily) or ISO week key (weekly) for which progress applies. */
  cycleKey: string;
  completedAt?: string;
}

export interface AchievementRequirement {
  type: AchievementRequirementType;
  value: number;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  requirement: AchievementRequirement;
  unlockedAt?: string;
}

export interface XpEvent {
  id: string;
  amount: number;
  reason: string;
  createdAt: string;
}

export interface GamificationState {
  version: 1;
  totalXp: number;
  streak: number;
  lastActivityDate: string | null;
  completedQuestsCount: number;
  quests: Quest[];
  achievements: Achievement[];
  xpHistory: XpEvent[];
}

export interface LevelProgress {
  level: number;
  title: string;
  currentLevelXp: number;
  nextLevelXp: number;
  progressXp: number;
  requiredXp: number;
  progressPercent: number;
}

export interface UseGamificationOptions {
  storageKey?: string;
  initialState?: GamificationState;
  /** Optional clock override, useful for deterministic tests. */
  now?: () => Date;
}

export interface LeaderboardEntry {
  id: string;
  displayName: string;
  xp: number;
  avatarUrl?: string;
  /** Set to true for the signed-in learner. */
  isCurrentUser?: boolean;
}
