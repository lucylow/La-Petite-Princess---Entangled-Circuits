// @ts-nocheck
import type { Achievement, GamificationState, Quest } from "./types";
import { cycleKeyFor, localDateKey } from "./engine/date";

export const DEFAULT_STORAGE_KEY = "start-here:gamification:v1";

export function createDefaultQuests(date: Date = new Date()): Quest[] {
  return [
    {
      id: "daily-discovery",
      title: "Discover something new",
      description: "Open a new lesson or explore an unfamiliar concept.",
      category: "Discovery",
      icon: "✦",
      cadence: "daily",
      progress: 0,
      target: 1,
      xpReward: 30,
      cycleKey: cycleKeyFor("daily", date),
    },
    {
      id: "daily-focus",
      title: "Make a focused practice session",
      description: "Complete three focused learning activities.",
      category: "Practice",
      icon: "◉",
      cadence: "daily",
      progress: 0,
      target: 3,
      xpReward: 45,
      cycleKey: cycleKeyFor("daily", date),
    },
    {
      id: "weekly-explorer",
      title: "Explore the circuit lab",
      description: "Work through five interactive circuit explorations this week.",
      category: "Exploration",
      icon: "⌁",
      cadence: "weekly",
      progress: 0,
      target: 5,
      xpReward: 100,
      cycleKey: cycleKeyFor("weekly", date),
    },
  ];
}

export function createDefaultAchievements(): Achievement[] {
  return [
    {
      id: "first-steps",
      title: "First steps",
      description: "Earn your first 50 XP.",
      icon: "✧",
      requirement: { type: "total-xp", value: 50 },
    },
    {
      id: "curious-mind",
      title: "Curious mind",
      description: "Earn 250 XP through exploration and practice.",
      icon: "⌕",
      requirement: { type: "total-xp", value: 250 },
    },
    {
      id: "three-day-streak",
      title: "Momentum builder",
      description: "Learn on three consecutive days.",
      icon: "♨",
      requirement: { type: "streak", value: 3 },
    },
    {
      id: "quest-starter",
      title: "Quest starter",
      description: "Complete three quests.",
      icon: "⚑",
      requirement: { type: "quests-completed", value: 3 },
    },
    {
      id: "week-of-learning",
      title: "A week of learning",
      description: "Build a seven-day learning streak.",
      icon: "✺",
      requirement: { type: "streak", value: 7 },
    },
    {
      id: "xp-collector",
      title: "XP collector",
      description: "Reach 1,000 total XP.",
      icon: "◇",
      requirement: { type: "total-xp", value: 1000 },
    },
  ];
}

export function createInitialGamificationState(date: Date = new Date()): GamificationState {
  return {
    version: 1,
    totalXp: 0,
    streak: 0,
    lastActivityDate: null,
    completedQuestsCount: 0,
    quests: createDefaultQuests(date),
    achievements: createDefaultAchievements(),
    xpHistory: [],
  };
}

export function createXpEventId(date: Date = new Date()): string {
  return `xp-${date.getTime()}-${Math.random().toString(36).slice(2, 8)}`;
}

export const INITIAL_LAST_ACTIVITY_DATE = localDateKey;
