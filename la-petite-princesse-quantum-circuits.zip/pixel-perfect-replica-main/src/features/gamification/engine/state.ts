// @ts-nocheck
import { createInitialGamificationState, createXpEventId } from "../defaults";
import type { GamificationState, Quest } from "../types";
import { cycleKeyFor, localDateKey, previousDateKey } from "./date";
import { evaluateAchievements } from "./achievements";
import { clampProgress } from "./progression";

const MAX_XP_HISTORY = 100;

export function normaliseGamificationState(
  candidate: unknown,
  date: Date = new Date(),
): GamificationState {
  const defaults = createInitialGamificationState(date);
  if (!candidate || typeof candidate !== "object") return defaults;
  const value = candidate as Partial<GamificationState>;

  const savedQuests = Array.isArray(value.quests) ? value.quests : [];
  const savedAchievements = Array.isArray(value.achievements) ? value.achievements : [];
  const quests = mergeById(defaults.quests, savedQuests, (item) => sanitizeQuest(item, date));
  const achievements = mergeById(defaults.achievements, savedAchievements, sanitizeAchievement);
  const state: GamificationState = {
    version: 1,
    totalXp: nonNegativeInt(value.totalXp),
    streak: nonNegativeInt(value.streak),
    lastActivityDate: typeof value.lastActivityDate === "string" ? value.lastActivityDate : null,
    completedQuestsCount: nonNegativeInt(value.completedQuestsCount),
    quests,
    achievements,
    xpHistory: Array.isArray(value.xpHistory)
      ? value.xpHistory.filter(isXpEvent).slice(-MAX_XP_HISTORY)
      : [],
  };
  return refreshQuestCycles(state, date);
}

function mergeById<T extends { id: string }>(
  defaults: T[],
  saved: unknown[],
  sanitize: (value: unknown) => T | null,
): T[] {
  const map = new Map<string, T>();
  for (const item of defaults) map.set(item.id, item);
  for (const raw of saved) {
    const item = sanitize(raw);
    if (item) map.set(item.id, { ...map.get(item.id), ...item });
  }
  return [...map.values()];
}

function sanitizeQuest(value: unknown, date: Date): Quest | null {
  if (!value || typeof value !== "object") return null;
  const item = value as Partial<Quest>;
  if (typeof item.id !== "string" || typeof item.title !== "string") return null;
  const target = Math.max(1, nonNegativeInt(item.target));
  return {
    id: item.id,
    title: item.title,
    description: typeof item.description === "string" ? item.description : "",
    category: typeof item.category === "string" ? item.category : "Learning",
    icon: typeof item.icon === "string" ? item.icon : "✦",
    cadence: item.cadence === "weekly" ? "weekly" : "daily",
    progress: clampProgress(nonNegativeInt(item.progress), target),
    target,
    xpReward: nonNegativeInt(item.xpReward),
    cycleKey: typeof item.cycleKey === "string" ? item.cycleKey : cycleKeyFor(item.cadence === "weekly" ? "weekly" : "daily", date),
    ...(typeof item.completedAt === "string" ? { completedAt: item.completedAt } : {}),
  };
}

function sanitizeAchievement(value: unknown) {
  if (!value || typeof value !== "object") return null;
  const item = value as GamificationState["achievements"][number];
  if (typeof item.id !== "string" || typeof item.title !== "string" || !item.requirement) return null;
  if (!["total-xp", "streak", "quests-completed"].includes(item.requirement.type)) return null;
  return {
    id: item.id,
    title: item.title,
    description: typeof item.description === "string" ? item.description : "",
    icon: typeof item.icon === "string" ? item.icon : "✧",
    requirement: { type: item.requirement.type, value: nonNegativeInt(item.requirement.value) },
    ...(typeof item.unlockedAt === "string" ? { unlockedAt: item.unlockedAt } : {}),
  };
}

function isXpEvent(value: unknown): value is GamificationState["xpHistory"][number] {
  if (!value || typeof value !== "object") return false;
  const item = value as GamificationState["xpHistory"][number];
  return typeof item.id === "string" && Number.isFinite(item.amount) && typeof item.reason === "string" && typeof item.createdAt === "string";
}

function nonNegativeInt(value: unknown): number {
  return typeof value === "number" && Number.isFinite(value) ? Math.max(0, Math.floor(value)) : 0;
}

export function refreshQuestCycles(state: GamificationState, date: Date = new Date()): GamificationState {
  let changed = false;
  const quests = state.quests.map((quest) => {
    const nextCycle = cycleKeyFor(quest.cadence, date);
    if (quest.cycleKey === nextCycle) return quest;
    changed = true;
    return { ...quest, cycleKey: nextCycle, progress: 0, completedAt: undefined };
  });
  return changed ? { ...state, quests } : state;
}

export function awardXp(
  state: GamificationState,
  amount: number,
  reason: string,
  date: Date = new Date(),
): GamificationState {
  const safeAmount = nonNegativeInt(amount);
  if (safeAmount <= 0) return state;
  const createdAt = date.toISOString();
  const next: GamificationState = {
    ...state,
    totalXp: state.totalXp + safeAmount,
    xpHistory: [...state.xpHistory, { id: createXpEventId(date), amount: safeAmount, reason, createdAt }].slice(-MAX_XP_HISTORY),
  };
  return evaluateAchievements(next, createdAt);
}

export function recordLearningActivity(
  previousState: GamificationState,
  xpAmount = 10,
  reason = "Learning activity",
  date: Date = new Date(),
): GamificationState {
  const state = refreshQuestCycles(previousState, date);
  const today = localDateKey(date);
  if (state.lastActivityDate === today) return awardXp(state, xpAmount, reason, date);

  const streak = state.lastActivityDate === previousDateKey(date) ? state.streak + 1 : 1;
  const withActivity = { ...state, streak, lastActivityDate: today };
  return evaluateAchievements(awardXp(withActivity, xpAmount, reason, date), date.toISOString());
}

export function addQuestProgress(
  previousState: GamificationState,
  questId: string,
  amount = 1,
  date: Date = new Date(),
): GamificationState {
  const state = refreshQuestCycles(previousState, date);
  const quest = state.quests.find((item) => item.id === questId);
  if (!quest || quest.completedAt || amount <= 0) return state;

  const progress = clampProgress(quest.progress + amount, quest.target);
  const completed = progress >= quest.target;
  const completedAt = completed ? date.toISOString() : undefined;
  const quests = state.quests.map((item) =>
    item.id === questId ? { ...item, progress, ...(completedAt ? { completedAt } : {}) } : item,
  );
  const updated: GamificationState = {
    ...state,
    quests,
    completedQuestsCount: state.completedQuestsCount + (completed ? 1 : 0),
  };
  return completed
    ? evaluateAchievements(awardXp(updated, quest.xpReward, `Quest completed: ${quest.title}`, date), date.toISOString())
    : updated;
}

export function resetGamificationState(date: Date = new Date()): GamificationState {
  return createInitialGamificationState(date);
}
