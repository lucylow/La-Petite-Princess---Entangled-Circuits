// @ts-nocheck
import type { Achievement, GamificationState } from "../types";

export function isAchievementUnlocked(achievement: Achievement, state: GamificationState): boolean {
  const { type, value } = achievement.requirement;
  if (type === "total-xp") return state.totalXp >= value;
  if (type === "streak") return state.streak >= value;
  return state.completedQuestsCount >= value;
}

/** Unlocks eligible achievements once and preserves their original unlock timestamps. */
export function evaluateAchievements(
  state: GamificationState,
  unlockedAt: string = new Date().toISOString(),
): GamificationState {
  let changed = false;
  const achievements = state.achievements.map((achievement) => {
    if (achievement.unlockedAt || !isAchievementUnlocked(achievement, state)) return achievement;
    changed = true;
    return { ...achievement, unlockedAt };
  });
  return changed ? { ...state, achievements } : state;
}
