// @ts-nocheck
import type { LevelProgress } from "../types";

const LEVEL_TITLES = [
  "Curious beginner",
  "Knowledge seeker",
  "Concept explorer",
  "Circuit apprentice",
  "Signal navigator",
  "Systems thinker",
  "Lab specialist",
  "Master explorer",
  "Theory architect",
  "Grand innovator",
];

/** XP required to reach the start of a level. Each level takes 100 more XP than the previous one. */
export function xpFloorForLevel(level: number): number {
  const safeLevel = Math.max(1, Math.floor(level));
  return Math.round((100 * (safeLevel - 1) * safeLevel) / 2);
}

export function getLevelProgress(totalXp: number): LevelProgress {
  const xp = Math.max(0, Math.floor(Number.isFinite(totalXp) ? totalXp : 0));
  let level = 1;
  while (xp >= xpFloorForLevel(level + 1)) level += 1;

  const currentLevelXp = xpFloorForLevel(level);
  const nextLevelXp = xpFloorForLevel(level + 1);
  const requiredXp = nextLevelXp - currentLevelXp;
  const progressXp = xp - currentLevelXp;

  return {
    level,
    title: LEVEL_TITLES[Math.min(level - 1, LEVEL_TITLES.length - 1)],
    currentLevelXp,
    nextLevelXp,
    progressXp,
    requiredXp,
    progressPercent: Math.min(100, Math.max(0, (progressXp / requiredXp) * 100)),
  };
}

export function clampProgress(progress: number, target: number): number {
  if (!Number.isFinite(progress) || !Number.isFinite(target) || target <= 0) return 0;
  return Math.min(target, Math.max(0, progress));
}
