// @ts-nocheck
import { DEFAULT_STORAGE_KEY, createInitialGamificationState } from "../defaults";
import { normaliseGamificationState } from "../engine/state";
import type { GamificationState } from "../types";

function getStorage(): Storage | null {
  try {
    return typeof window === "undefined" ? null : window.localStorage;
  } catch {
    return null;
  }
}

export function loadGamificationState(
  storageKey = DEFAULT_STORAGE_KEY,
  date: Date = new Date(),
): GamificationState {
  const storage = getStorage();
  if (!storage) return createInitialGamificationState(date);
  try {
    const raw = storage.getItem(storageKey);
    return raw ? normaliseGamificationState(JSON.parse(raw), date) : createInitialGamificationState(date);
  } catch {
    return createInitialGamificationState(date);
  }
}

export function saveGamificationState(
  state: GamificationState,
  storageKey = DEFAULT_STORAGE_KEY,
): boolean {
  const storage = getStorage();
  if (!storage) return false;
  try {
    storage.setItem(storageKey, JSON.stringify(state));
    return true;
  } catch {
    // Storage can be disabled or full. The in-memory experience still works.
    return false;
  }
}
