// @ts-nocheck
const CONTRACTIONS: Record<string, string> = {
  "what's": "what is",
  "whats": "what is",
  "it's": "it is",
  "its": "it is",
  " i'm ": " i am ",
  "i'm": "i am",
  "don't": "do not",
  "doesn't": "does not",
  "didn't": "did not",
  "can't": "cannot",
  "won't": "will not",
  "you're": "you are",
  "we're": "we are",
  "they're": "they are",
  "that's": "that is",
  "there's": "there is",
  "how's": "how is",
  "couldn't": "could not",
  "wouldn't": "would not",
  "shouldn't": "should not",
};

const STOP_WORDS = new Set([
  "a", "an", "the", "and", "or", "but", "is", "are", "was", "were",
  "be", "been", "being", "to", "of", "in", "on", "for", "with", "at",
  "by", "from", "as", "it", "its", "this", "that", "these", "those",
  "i", "me", "my", "we", "our", "you", "your", "he", "she", "they",
  "them", "do", "does", "did", "can", "could", "would", "should", "will",
  "please", "just", "very", "really", "about", "into", "than", "then",
]);

export function normalizeText(input: string): string {
  let value = input
    .normalize("NFKC")
    .toLocaleLowerCase()
    .replace(/[’‘]/g, "'")
    .replace(/[“”]/g, '"')
    .replace(/\s+/g, " ")
    .trim();

  for (const [from, to] of Object.entries(CONTRACTIONS)) {
    value = value.replace(new RegExp(`(^|\\s)${escapeRegExp(from.trim())}(?=\\s|$)`, "g"), (_m, prefix: string) => `${prefix}${to}`);
  }

  return value
    .replace(/[^\p{L}\p{N}\s@:/._'-]/gu, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export function tokenize(input: string, options: { removeStopWords?: boolean } = {}): string[] {
  const normalized = normalizeText(input);
  const words = normalized.match(/[\p{L}\p{N}]+(?:['-][\p{L}\p{N}]+)*/gu) ?? [];
  return options.removeStopWords ? words.filter((word) => !STOP_WORDS.has(word)) : words;
}

export function uniqueTokens(input: string): string[] {
  return [...new Set(tokenize(input, { removeStopWords: true }))];
}

export function escapeRegExp(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

export function clamp(value: number, min = 0, max = 1): number {
  return Math.min(max, Math.max(min, value));
}
