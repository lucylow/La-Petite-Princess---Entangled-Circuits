// @ts-nocheck
import type { IntentDefinition } from "../types";

/** Product-focused starter intents. Tune phrases to match your users' vocabulary. */
export const DEFAULT_INTENTS: IntentDefinition[] = [
  {
    id: "greeting", label: "Greeting", priority: 1.2, threshold: 0.2,
    phrases: ["hello", "hi there", "good morning", "good afternoon", "hey"],
    keywords: ["hello", "hi", "hey", "morning", "afternoon"],
    examples: ["Hey, how are you?", "Good morning"],
  },
  {
    id: "help", label: "Help", priority: 1.15, threshold: 0.23,
    phrases: ["what can you do", "how can you help", "i need help", "show me what is available"],
    keywords: ["help", "support", "options", "capabilities", "guide"],
    examples: ["What can you help me with?", "I need help"],
  },
  {
    id: "explain", label: "Explain a concept", priority: 1.1, threshold: 0.2,
    phrases: ["explain this", "what does this mean", "how does it work", "teach me", "break it down"],
    keywords: ["explain", "meaning", "define", "teach", "understand", "concept", "example"],
    examples: ["Explain circuit analysis", "What does XP mean?"],
  },
  {
    id: "learning_path", label: "Learning path", priority: 1.05, threshold: 0.2,
    phrases: ["where should i start", "what should i learn next", "make me a study plan", "recommend a lesson"],
    keywords: ["start", "next", "lesson", "course", "study", "path", "roadmap", "practice"],
    examples: ["Where should I start?", "Recommend my next lesson"],
  },
  {
    id: "progress", label: "Learning progress", priority: 1.05, threshold: 0.2,
    phrases: ["show my progress", "how am i doing", "how many points do i have", "my current level"],
    keywords: ["progress", "xp", "points", "level", "streak", "achievement", "badge", "quest"],
    examples: ["Show my progress", "How do I earn more XP?"],
  },
  {
    id: "circuit_help", label: "Circuit help", priority: 1.1, threshold: 0.22,
    phrases: ["help me solve this circuit", "explain ohms law", "explain ohm's law", "explain circuit analysis", "calculate voltage", "calculate current"],
    keywords: ["circuit", "analysis", "voltage", "current", "resistance", "ohm", "ohm's", "ohms", "amplitude", "phase"],
    examples: ["Explain Ohm's law", "How do I calculate current?"],
  },
  {
    id: "troubleshoot", label: "Troubleshooting", priority: 1.1, threshold: 0.22,
    phrases: ["it is not working", "something went wrong", "i am stuck", "i cannot continue"],
    keywords: ["error", "broken", "issue", "problem", "stuck", "failed", "not working", "bug"],
    examples: ["I am stuck on a lesson", "The chat is not working"],
  },
  {
    id: "account", label: "Account help", priority: 1.0, threshold: 0.23,
    phrases: ["i cannot log in", "reset my password", "update my profile"],
    keywords: ["account", "login", "log in", "password", "profile", "email", "sign in"],
    examples: ["I cannot log in", "How do I update my profile?"],
  },
  {
    id: "goodbye", label: "Goodbye", priority: 1.15, threshold: 0.2,
    phrases: ["goodbye", "see you later", "talk to you later", "that is all"],
    keywords: ["bye", "goodbye", "later", "thanks", "thank you"],
    examples: ["Thanks, that's all", "See you later"],
  },
];
