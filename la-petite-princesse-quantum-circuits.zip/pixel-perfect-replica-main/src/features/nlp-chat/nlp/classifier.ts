// @ts-nocheck
import type {
  ClassificationResult,
  ConversationContext,
  EntityMatch,
  IntentDefinition,
  IntentMatch,
} from "../types";
import { extractEntities } from "./entities";
import { clamp, normalizeText, tokenize } from "./normalize";
import { diceSimilarity, tokenSimilarity } from "./similarity";

const UNKNOWN_INTENT: IntentDefinition = {
  id: "unknown", label: "Other", phrases: [], keywords: [], threshold: 1,
};

const FOLLOW_UP_PATTERNS = [
  /^(and\s+)?(what about|how about)\b/i,
  /^(why|how|when|where|who|which)\??$/i,
  /^(tell me more|go on|continue|expand on that|give me an example)\b/i,
  /^(what do you mean|can you clarify|explain more)\b/i,
  /^(that one|this one|the same|it|that|those|them)\??$/i,
];

export function isFollowUpMessage(input: string): boolean {
  const text = normalizeText(input);
  return FOLLOW_UP_PATTERNS.some((pattern) => pattern.test(text));
}

export function classifyIntent(
  input: string,
  intents: IntentDefinition[],
  context?: ConversationContext,
): ClassificationResult {
  const normalizedText = normalizeText(input);
  const tokens = tokenize(normalizedText, { removeStopWords: true });
  const entities = extractEntities(input);
  const followUp = Boolean(context?.lastIntent && isFollowUpMessage(normalizedText));

  const matches = intents.map((intent) => scoreIntent(normalizedText, tokens, intent, followUp && context?.lastIntent === intent.id));
  matches.sort((a, b) => b.score - a.score);

  let primary = matches[0] ?? { intent: UNKNOWN_INTENT, score: 0, confidence: 0, matchedTerms: [] };
  const required = primary.intent.threshold ?? 0.2;

  if (followUp && context?.lastIntent) {
    const previous = matches.find((match) => match.intent.id === context.lastIntent);
    if (previous) {
      // Short follow-ups often contain little lexical information; preserve topic continuity.
      primary = {
        ...previous,
        score: Math.max(previous.score, 0.35),
        confidence: Math.max(previous.confidence, 0.58),
      };
    }
  }

  if (primary.score < required || primary.confidence < 0.12) {
    primary = { intent: UNKNOWN_INTENT, score: 0, confidence: 0, matchedTerms: [] };
  }

  const alternatives = matches
    .filter((match) => match.intent.id !== primary.intent.id && match.score >= 0.08)
    .slice(0, 3);

  return {
    primary,
    alternatives,
    entities,
    normalizedText,
    isFollowUp: followUp,
  };
}

function scoreIntent(
  text: string,
  tokens: string[],
  intent: IntentDefinition,
  continuing: boolean,
): IntentMatch {
  const matchedTerms: string[] = [];
  const tokenSet = new Set(tokens);
  let phraseScore = 0;

  for (const phrase of intent.phrases) {
    const normalizedPhrase = normalizeText(phrase);
    if (!normalizedPhrase) continue;
    if (text === normalizedPhrase || text.includes(normalizedPhrase)) {
      phraseScore = Math.max(phraseScore, text === normalizedPhrase ? 1 : 0.82);
      matchedTerms.push(phrase);
      continue;
    }
    const fuzzy = Math.max(diceSimilarity(text, normalizedPhrase), tokenSimilarity(text, normalizedPhrase) * 0.9);
    if (fuzzy >= 0.58) {
      phraseScore = Math.max(phraseScore, fuzzy * 0.72);
      matchedTerms.push(phrase);
    }
  }

  let keywordScore = 0;
  let keywordHits = 0;
  for (const keyword of intent.keywords) {
    const normalizedKeyword = normalizeText(keyword);
    const keywordTokens = tokenize(normalizedKeyword, { removeStopWords: true });
    const matched = normalizedKeyword.includes(" ")
      ? text.includes(normalizedKeyword)
      : keywordTokens.some((token) => tokenSet.has(token));
    if (matched) {
      keywordHits += 1;
      matchedTerms.push(keyword);
    }
  }
  if (intent.keywords.length > 0) {
    keywordScore = Math.min(0.78, keywordHits * 0.3);
  }

  const priority = clamp((intent.priority ?? 1) / 1.25, 0.6, 1.15);
  const continuity = continuing ? 0.1 : 0;
  const score = clamp(Math.max(phraseScore, keywordScore) * priority + continuity, 0, 1.15);
  const confidence = clamp(score / 0.92);

  return {
    intent,
    score,
    confidence,
    matchedTerms: [...new Set(matchedTerms)],
  };
}

export function resolveTopic(entities: EntityMatch[], previousTopic?: string): string | undefined {
  const topic = entities.find((entity) => entity.type === "topic");
  return topic?.normalizedValue ?? topic?.value ?? previousTopic;
}
