// @ts-nocheck
import type { EntityMatch, EntityType } from "../types";
import { normalizeText } from "./normalize";

interface EntityPattern {
  type: EntityType;
  pattern: RegExp;
  normalize?: (value: string) => string;
}

const PATTERNS: EntityPattern[] = [
  {
    type: "measurement",
    pattern: /\b\d+(?:\.\d+)?\s?(?:millivolts?|mv|volts?|v|milliamps?|ma|amps?|a|kohms?|kω|ohms?|ω|khz|mhz|hz|kilowatts?|kw|watts?|w|farads?|µf|uf)\b/gi,
    normalize: (v) => v.toLowerCase().replace(/\s+/g, " "),
  },
  { type: "email", pattern: /\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/gi, normalize: (v) => v.toLowerCase() },
  { type: "url", pattern: /\bhttps?:\/\/[^\s<>()]+/gi, normalize: (v) => v.replace(/[),.!?]+$/, "") },
  {
    type: "duration",
    pattern: /\b\d+\s?(?:seconds?|secs?|minutes?|mins?|hours?|hrs?|days?|weeks?|months?)\b/gi,
    normalize: (v) => v.toLowerCase().replace(/\s+/g, " "),
  },
  { type: "date", pattern: /\b(?:today|tomorrow|yesterday|next week|this week|\d{4}-\d{2}-\d{2})\b/gi, normalize: (v) => v.toLowerCase() },
  { type: "level", pattern: /\b(?:beginner|intermediate|advanced|expert|level\s?\d+)\b/gi, normalize: (v) => v.toLowerCase() },
  { type: "number", pattern: /\b\d+(?:\.\d+)?%?\b/g, normalize: (v) => v },
];

const TOPIC_ALIASES: Record<string, string[]> = {
  "learning path": ["learning path", "study path", "course path", "roadmap"],
  "circuit analysis": ["circuit analysis", "circuit", "voltage", "current", "resistance", "ohms law", "ohm's law"],
  "voltage divider": ["voltage divider", "potential divider"],
  "capacitors": ["capacitor", "capacitors", "capacitance"],
  "inductors": ["inductor", "inductors", "inductance"],
  "chatbot": ["chatbot", "chat bot", "assistant", "nlp", "natural language"],
  "progress": ["progress", "xp", "experience points", "level", "streak", "achievement", "badge", "quest"],
  "account": ["account", "profile", "login", "sign in", "password"],
  "accessibility": ["accessibility", "screen reader", "keyboard navigation", "contrast"],
};

export function extractEntities(input: string): EntityMatch[] {
  const entities: EntityMatch[] = [];

  for (const rule of PATTERNS) {
    rule.pattern.lastIndex = 0;
    for (const match of input.matchAll(rule.pattern)) {
      const value = match[0];
      const start = match.index ?? 0;
      entities.push({
        type: rule.type,
        value,
        normalizedValue: rule.normalize?.(value),
        start,
        end: start + value.length,
      });
    }
  }

  const normalizedInput = normalizeText(input);
  for (const [topic, aliases] of Object.entries(TOPIC_ALIASES)) {
    const found = aliases.find((alias) => normalizedInput.includes(normalizeText(alias)));
    if (found) {
      const start = normalizedInput.indexOf(normalizeText(found));
      entities.push({
        type: "topic",
        value: found,
        normalizedValue: topic,
        start: Math.max(0, start),
        end: Math.max(0, start) + found.length,
      });
    }
  }

  return removeOverlaps(entities).sort((a, b) => a.start - b.start || a.end - b.end);
}

function removeOverlaps(entities: EntityMatch[]): EntityMatch[] {
  const sorted = [...entities].sort((a, b) => {
    const lengthDifference = (b.end - b.start) - (a.end - a.start);
    return lengthDifference || a.start - b.start;
  });
  const accepted: EntityMatch[] = [];

  for (const entity of sorted) {
    const overlaps = accepted.some((existing) => entity.start < existing.end && entity.end > existing.start);
    if (!overlaps) accepted.push(entity);
  }
  return accepted;
}
