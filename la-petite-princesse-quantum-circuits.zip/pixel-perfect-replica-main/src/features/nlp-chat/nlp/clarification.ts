// @ts-nocheck
import type { ClassificationResult, IntentMatch } from "../types";

export interface ClarificationPolicy {
  /** Ask when the best intent is below this confidence. */
  minimumConfidence: number;
  /** Ask when the best two intent scores are closer than this margin. */
  minimumScoreMargin: number;
  /** Never interrupt a clear short follow-up with a clarification prompt. */
  preserveFollowUps: boolean;
}

export const DEFAULT_CLARIFICATION_POLICY: ClarificationPolicy = {
  minimumConfidence: 0.32,
  minimumScoreMargin: 0.075,
  preserveFollowUps: true,
};

export interface ClarificationDecision {
  needed: boolean;
  reason?: "unknown-intent" | "low-confidence" | "ambiguous-intent";
  candidates: IntentMatch[];
}

/**
 * Separates intent detection from the decision to ask a clarifying question.
 * Applications can tune this policy without changing the classifier itself.
 */
export function evaluateClarification(
  result: ClassificationResult,
  policy: Partial<ClarificationPolicy> = {},
): ClarificationDecision {
  const config = { ...DEFAULT_CLARIFICATION_POLICY, ...policy };
  const primary = result.primary;

  if (config.preserveFollowUps && result.isFollowUp && primary.intent.id !== "unknown") {
    return { needed: false, candidates: [primary] };
  }

  if (primary.intent.id === "unknown") {
    return { needed: true, reason: "unknown-intent", candidates: result.alternatives.slice(0, 2) };
  }

  if (primary.confidence < config.minimumConfidence) {
    return { needed: true, reason: "low-confidence", candidates: [primary, ...result.alternatives].slice(0, 2) };
  }

  const second = result.alternatives[0];
  if (second && primary.score - second.score < config.minimumScoreMargin) {
    return { needed: true, reason: "ambiguous-intent", candidates: [primary, second] };
  }

  return { needed: false, candidates: [primary] };
}

export function createClarificationPrompt(decision: ClarificationDecision): string {
  if (decision.reason === "ambiguous-intent" && decision.candidates.length > 1) {
    const [first, second] = decision.candidates;
    return `I can take this in two directions: **${first.intent.label}** or **${second.intent.label}**. Which would be more useful?`;
  }
  if (decision.candidates.length > 0) {
    const choices = decision.candidates.map((candidate) => candidate.intent.label.toLowerCase());
    return `I want to make sure I understand. Are you asking about ${joinChoices(choices)}, or something else?`;
  }
  return "I’m not quite sure what you mean yet. Could you share the topic and what you want to accomplish?";
}

function joinChoices(values: string[]): string {
  if (values.length === 1) return values[0];
  if (values.length === 2) return `${values[0]} or ${values[1]}`;
  return `${values.slice(0, -1).join(", ")}, or ${values[values.length - 1]}`;
}
