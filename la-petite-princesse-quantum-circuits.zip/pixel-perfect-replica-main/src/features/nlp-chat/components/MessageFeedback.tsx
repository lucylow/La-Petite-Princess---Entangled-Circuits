// @ts-nocheck
import type { ChatFeedbackRating } from "../engine/feedback";

export interface MessageFeedbackProps {
  messageId: string;
  value?: ChatFeedbackRating;
  onChange: (messageId: string, rating: ChatFeedbackRating) => void;
  disabled?: boolean;
}

export function MessageFeedback({ messageId, value, onChange, disabled = false }: MessageFeedbackProps) {
  return (
    <div className="nlp-chat__feedback" aria-label="Rate this answer">
      <span>Was this helpful?</span>
      <button
        type="button"
        aria-label="This answer was helpful"
        aria-pressed={value === "helpful"}
        disabled={disabled}
        onClick={() => onChange(messageId, "helpful")}
      >
        <span aria-hidden="true">👍</span>
      </button>
      <button
        type="button"
        aria-label="This answer was not helpful"
        aria-pressed={value === "not_helpful"}
        disabled={disabled}
        onClick={() => onChange(messageId, "not_helpful")}
      >
        <span aria-hidden="true">👎</span>
      </button>
    </div>
  );
}
