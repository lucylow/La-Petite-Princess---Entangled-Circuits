// @ts-nocheck
import type { CSSProperties } from "react";

export interface TypingIndicatorProps {
  label?: string;
  className?: string;
}

export function TypingIndicator({ label = "Assistant is thinking", className = "" }: TypingIndicatorProps) {
  return (
    <div className={`nlp-chat__typing ${className}`.trim()} role="status" aria-label={label}>
      <span className="nlp-chat__typing-dot" style={{ "--typing-delay": "0ms" } as CSSProperties} />
      <span className="nlp-chat__typing-dot" style={{ "--typing-delay": "140ms" } as CSSProperties} />
      <span className="nlp-chat__typing-dot" style={{ "--typing-delay": "280ms" } as CSSProperties} />
      <span className="nlp-chat__sr-only">{label}</span>
    </div>
  );
}
