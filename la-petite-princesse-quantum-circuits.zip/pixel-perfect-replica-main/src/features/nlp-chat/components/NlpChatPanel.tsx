// @ts-nocheck
import { useMemo, useRef, useState } from "react";
import type { ChangeEvent, FormEvent, KeyboardEvent, ReactElement } from "react";
import type { ChatMessage } from "../types";
import type { ChatFeedbackRating } from "../engine/feedback";
import { MessageFeedback } from "./MessageFeedback";
import { PromptChips } from "./PromptChips";
import { TypingIndicator } from "./TypingIndicator";
import { useNlpChat, type UseNlpChatOptions } from "../hooks/useNlpChat";

export interface NlpChatPanelProps extends UseNlpChatOptions {
  title?: string;
  subtitle?: string;
  placeholder?: string;
  suggestions?: string[];
  className?: string;
  onFeedback?: (messageId: string, rating: ChatFeedbackRating) => void;
}

export function NlpChatPanel({
  title = "Start Here Assistant",
  subtitle = "Ask a question or tell me what you’re learning.",
  placeholder = "Type your message…",
  suggestions = ["Where should I start?", "Explain a concept", "Help me troubleshoot"],
  className = "",
  onFeedback,
  ...hookOptions
}: NlpChatPanelProps) {
  const chat = useNlpChat(hookOptions);
  const [draft, setDraft] = useState("");
  const [feedbackByMessage, setFeedbackByMessage] = useState<Record<string, ChatFeedbackRating>>({});
  const bottomRef = useRef<HTMLDivElement>(null);
  const latestAssistant = useMemo(
    () => [...chat.messages].reverse().find((message) => message.role === "assistant"),
    [chat.messages],
  );

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const value = draft;
    if (!value.trim() || chat.isThinking) return;
    setDraft("");
    await chat.sendMessage(value);
    bottomRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }

  function handleKeyDown(event: KeyboardEvent<HTMLTextAreaElement>) {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      event.currentTarget.form?.requestSubmit();
    }
  }

  return (
    <section className={`nlp-chat ${className}`.trim()} aria-label="Chat with the learning assistant">
      <header className="nlp-chat__header">
        <div className="nlp-chat__avatar" aria-hidden="true">✦</div>
        <div className="nlp-chat__heading">
          <h2>{title}</h2>
          <p>{subtitle}</p>
        </div>
        <button type="button" className="nlp-chat__clear" onClick={chat.clearConversation}>
          New chat
        </button>
      </header>

      <div className="nlp-chat__transcript" role="log" aria-live="polite" aria-relevant="additions text">
        {chat.messages.map((message) => (
          <MessageBubble
            key={message.id}
            message={message}
            showSuggestions={message.id === latestAssistant?.id}
            showFeedback={message.id === latestAssistant?.id && message.role === "assistant"}
            feedback={feedbackByMessage[message.id]}
            onFeedback={(rating) => {
              setFeedbackByMessage((current) => ({ ...current, [message.id]: rating }));
              onFeedback?.(message.id, rating);
            }}
            onSuggestion={(value) => void chat.sendSuggestion(value)}
          />
        ))}
        {chat.isThinking && (
          <div className="nlp-chat__bubble nlp-chat__bubble--assistant">
            <TypingIndicator />
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {chat.error && <p className="nlp-chat__error" role="alert">{chat.error}</p>}

      {!chat.isThinking && latestAssistant && chat.messages.length <= 2 && (
        <PromptChips prompts={suggestions} onSelect={(value) => void chat.sendSuggestion(value)} disabled={chat.isThinking} />
      )}

      <form className="nlp-chat__composer" onSubmit={(event: FormEvent<HTMLFormElement>) => void submit(event)}>
        <label className="nlp-chat__sr-only" htmlFor="nlp-chat-input">Your message</label>
        <textarea
          id="nlp-chat-input"
          value={draft}
          onChange={(event: ChangeEvent<HTMLTextAreaElement>) => setDraft(event.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={placeholder}
          rows={1}
          maxLength={2_000}
          disabled={chat.isThinking}
        />
        {chat.isThinking ? (
          <button type="button" className="nlp-chat__send" onClick={chat.cancelRequest} aria-label="Cancel response">Stop</button>
        ) : (
          <button type="submit" className="nlp-chat__send" disabled={!draft.trim()} aria-label="Send message">Send</button>
        )}
      </form>
      <p className="nlp-chat__privacy">Do not share passwords, sign-in codes, or sensitive personal information.</p>
    </section>
  );
}

function MessageBubble({
  message,
  showSuggestions,
  showFeedback,
  feedback,
  onFeedback,
  onSuggestion,
}: {
  message: ChatMessage;
  showSuggestions: boolean;
  showFeedback: boolean;
  feedback?: ChatFeedbackRating;
  onFeedback: (rating: ChatFeedbackRating) => void;
  onSuggestion: (value: string) => void;
}) {
  const isUser = message.role === "user";
  return (
    <article className={`nlp-chat__row ${isUser ? "nlp-chat__row--user" : "nlp-chat__row--assistant"}`}>
      <div>
        <div className={`nlp-chat__bubble ${isUser ? "nlp-chat__bubble--user" : "nlp-chat__bubble--assistant"}`}>
          <p>{renderSafeLinks(message.content)}</p>
        </div>
        {showSuggestions && !isUser && message.suggestions?.length ? (
          <PromptChips prompts={message.suggestions} onSelect={onSuggestion} label="Suggested follow-up questions" />
        ) : null}
        {showFeedback && !isUser ? (
          <MessageFeedback messageId={message.id} value={feedback} onChange={(_, rating) => onFeedback(rating)} />
        ) : null}
      </div>
    </article>
  );
}


function renderSafeLinks(content: string) {
  const pattern = /\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g;
  const nodes: Array<string | ReactElement> = [];
  let cursor = 0;
  for (const match of content.matchAll(pattern)) {
    const index = match.index ?? 0;
    if (index > cursor) nodes.push(content.slice(cursor, index));
    const label = match[1];
    const href = match[2];
    try {
      const parsed = new URL(href);
      if (parsed.protocol === "http:" || parsed.protocol === "https:") {
        nodes.push(<a key={`source-${index}`} href={parsed.href} target="_blank" rel="noopener noreferrer">{label}</a>);
      } else {
        nodes.push(match[0]);
      }
    } catch {
      nodes.push(match[0]);
    }
    cursor = index + match[0].length;
  }
  if (cursor < content.length) nodes.push(content.slice(cursor));
  return nodes.length ? nodes : content;
}
