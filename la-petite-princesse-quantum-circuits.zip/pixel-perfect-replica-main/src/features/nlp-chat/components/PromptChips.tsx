// @ts-nocheck
export interface PromptChipsProps {
  prompts: string[];
  onSelect: (prompt: string) => void;
  label?: string;
  disabled?: boolean;
}

export function PromptChips({ prompts, onSelect, label = "Suggested questions", disabled = false }: PromptChipsProps) {
  const unique = [...new Set(prompts.map((value) => value.trim()).filter(Boolean))].slice(0, 6);
  if (!unique.length) return null;
  return (
    <div className="nlp-chat__suggestions" aria-label={label}>
      {unique.map((prompt) => (
        <button key={prompt} type="button" disabled={disabled} onClick={() => onSelect(prompt)}>
          {prompt}
        </button>
      ))}
    </div>
  );
}
