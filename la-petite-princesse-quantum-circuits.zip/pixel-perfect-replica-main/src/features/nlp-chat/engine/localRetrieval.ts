// @ts-nocheck
import { normalizeText, tokenize } from "../nlp/normalize";

export interface KnowledgeDocument {
  id: string;
  title: string;
  content: string;
  url?: string;
  tags?: string[];
  updatedAt?: string;
}

export interface RetrievalHit {
  document: KnowledgeDocument;
  score: number;
  snippet: string;
  matchedTerms: string[];
}

export interface RetrievalOptions {
  limit?: number;
  minimumScore?: number;
  titleBoost?: number;
  tagBoost?: number;
  snippetLength?: number;
}

/**
 * Small deterministic retrieval layer for public lesson/help content.
 * For a large corpus, use a server-side vector or full-text index instead.
 */
export function searchKnowledgeBase(
  query: string,
  documents: KnowledgeDocument[],
  options: RetrievalOptions = {},
): RetrievalHit[] {
  const queryTokens = [...new Set(tokenize(normalizeText(query), { removeStopWords: true }))];
  if (!queryTokens.length) return [];

  const limit = Math.max(1, Math.min(options.limit ?? 5, 20));
  const titleBoost = options.titleBoost ?? 2.4;
  const tagBoost = options.tagBoost ?? 1.8;
  const scored = documents.map((document) => {
    const titleTokens = tokenize(normalizeText(document.title), { removeStopWords: true });
    const bodyTokens = tokenize(normalizeText(document.content), { removeStopWords: true });
    const tagTokens = tokenize(normalizeText((document.tags ?? []).join(" ")), { removeStopWords: true });
    const titleMatches = queryTokens.filter((token) => titleTokens.includes(token));
    const bodyMatches = queryTokens.filter((token) => bodyTokens.includes(token));
    const tagMatches = queryTokens.filter((token) => tagTokens.includes(token));

    const coverage = queryTokens.filter((token) => titleMatches.includes(token) || bodyMatches.includes(token) || tagMatches.includes(token)).length / queryTokens.length;
    const density = queryTokens.reduce((sum, token) => {
      const occurrences = bodyTokens.filter((item) => item === token).length;
      return sum + Math.min(occurrences, 4) / Math.max(1, Math.sqrt(bodyTokens.length));
    }, 0);
    const score = coverage * 0.58 + Math.min(0.24, titleMatches.length * 0.08) * titleBoost / 2.4
      + Math.min(0.12, tagMatches.length * 0.04) * tagBoost / 1.8
      + Math.min(0.06, density * 0.06);
    const matchedTerms = [...new Set([...titleMatches, ...tagMatches, ...bodyMatches])];
    return {
      document,
      score: Math.min(1, score),
      snippet: makeSnippet(document.content, bodyMatches[0], options.snippetLength ?? 220),
      matchedTerms,
    };
  });

  return scored
    .filter((hit) => hit.score >= (options.minimumScore ?? 0.12) && hit.matchedTerms.length > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, limit);
}

function makeSnippet(content: string, focus: string | undefined, maxLength: number): string {
  const clean = content.replace(/\s+/g, " ").trim();
  if (clean.length <= maxLength) return clean;
  const index = focus ? normalizeText(clean).indexOf(focus) : -1;
  const start = index > maxLength / 3 ? Math.max(0, index - Math.floor(maxLength / 3)) : 0;
  const excerpt = clean.slice(start, start + maxLength).trim();
  return `${start > 0 ? "…" : ""}${excerpt}${start + maxLength < clean.length ? "…" : ""}`;
}
