// @ts-nocheck
import type { KnowledgeProvider, KnowledgeResult } from "../types";
import { sanitizeKnowledgeResult } from "./responseSafety";

export interface HttpKnowledgeProviderOptions {
  endpoint: string;
  headers?: Record<string, string>;
  timeoutMs?: number;
  maxHistoryMessages?: number;
  maxHistoryMessageChars?: number;
  maxAnswerChars?: number;
  allowedSourceHosts?: string[];
  fetchImpl?: typeof fetch;
  credentials?: RequestCredentials;
}

export class KnowledgeProviderError extends Error {
  readonly status?: number;
  readonly code: "timeout" | "http" | "invalid-response" | "network";

  constructor(message: string, code: KnowledgeProviderError["code"], status?: number) {
    super(message);
    this.name = "KnowledgeProviderError";
    this.code = code;
    this.status = status;
  }
}

/**
 * Creates a browser-safe adapter for your own authenticated server endpoint.
 * Keep model credentials on that server; never put API keys in this config.
 */
export function createHttpKnowledgeProvider(options: HttpKnowledgeProviderOptions): KnowledgeProvider {
  const fetcher = options.fetchImpl ?? fetch;
  const timeoutMs = options.timeoutMs ?? 18_000;
  const maxHistoryMessages = options.maxHistoryMessages ?? 8;
  const maxHistoryMessageChars = options.maxHistoryMessageChars ?? 1_200;

  return async (request): Promise<KnowledgeResult> => {
    const controller = new AbortController();
    let didTimeout = false;
    const abortFromCaller = () => controller.abort(request.signal?.reason);
    if (request.signal?.aborted) abortFromCaller();
    else request.signal?.addEventListener("abort", abortFromCaller, { once: true });

    const timeout = setTimeout(() => {
      didTimeout = true;
      controller.abort();
    }, timeoutMs);

    try {
      const response = await fetcher(options.endpoint, {
        method: "POST",
        credentials: options.credentials ?? "same-origin",
        headers: { "Content-Type": "application/json", Accept: "application/json", ...options.headers },
        body: JSON.stringify({
          query: request.query.slice(0, 2_000),
          intent: { id: request.intent.intent.id, confidence: request.intent.confidence },
          entities: request.entities.slice(0, 16),
          context: {
            lastIntent: request.context.lastIntent,
            lastTopic: request.context.lastTopic,
            slots: request.context.slots,
            turnCount: request.context.turnCount,
          },
          history: request.history.slice(-maxHistoryMessages).map(({ role, content }) => ({
            role,
            content: content.slice(0, maxHistoryMessageChars),
          })),
        }),
        signal: controller.signal,
      });

      if (!response.ok) {
        throw new KnowledgeProviderError(
          `Assistant endpoint returned HTTP ${response.status}.`,
          "http",
          response.status,
        );
      }

      let payload: unknown;
      try {
        payload = await response.json();
      } catch {
        throw new KnowledgeProviderError("Assistant endpoint returned invalid JSON.", "invalid-response");
      }

      const result = sanitizeKnowledgeResult(payload, {
        maxAnswerChars: options.maxAnswerChars ?? 12_000,
        allowedSourceHosts: options.allowedSourceHosts,
      });
      return result;
    } catch (error) {
      if (request.signal?.aborted) throw createAbortError();
      if (didTimeout) throw new KnowledgeProviderError("The assistant request timed out.", "timeout");
      if (error instanceof KnowledgeProviderError) throw error;
      if (error instanceof Error && error.name === "AbortError") throw error;
      throw new KnowledgeProviderError("Could not connect to the assistant service.", "network");
    } finally {
      clearTimeout(timeout);
      request.signal?.removeEventListener("abort", abortFromCaller);
    }
  };
}

function createAbortError(): Error {
  if (typeof DOMException !== "undefined") return new DOMException("Request cancelled", "AbortError");
  const error = new Error("Request cancelled");
  error.name = "AbortError";
  return error;
}
