// @ts-nocheck
export interface RateLimitOptions {
  limit: number;
  windowMs: number;
  now?: () => number;
}

export interface RateLimitDecision {
  allowed: boolean;
  remaining: number;
  retryAfterMs: number;
}

/** In-memory sliding-window limiter. Enforce the real limit on the server too. */
export class SlidingWindowRateLimiter {
  private readonly events = new Map<string, number[]>();
  private readonly now: () => number;
  private readonly limit: number;
  private readonly windowMs: number;

  constructor(options: RateLimitOptions) {
    if (!Number.isInteger(options.limit) || options.limit < 1) throw new Error("limit must be a positive integer");
    if (!Number.isFinite(options.windowMs) || options.windowMs <= 0) throw new Error("windowMs must be positive");
    this.limit = options.limit;
    this.windowMs = options.windowMs;
    this.now = options.now ?? Date.now;
  }

  consume(key = "default"): RateLimitDecision {
    const currentTime = this.now();
    const validAfter = currentTime - this.windowMs;
    const recent = (this.events.get(key) ?? []).filter((timestamp) => timestamp > validAfter);

    if (recent.length >= this.limit) {
      this.events.set(key, recent);
      return {
        allowed: false,
        remaining: 0,
        retryAfterMs: Math.max(0, recent[0] + this.windowMs - currentTime),
      };
    }

    recent.push(currentTime);
    this.events.set(key, recent);
    return { allowed: true, remaining: this.limit - recent.length, retryAfterMs: 0 };
  }

  reset(key?: string): void {
    if (key === undefined) this.events.clear();
    else this.events.delete(key);
  }

  prune(): void {
    const validAfter = this.now() - this.windowMs;
    for (const [key, timestamps] of this.events) {
      const recent = timestamps.filter((timestamp) => timestamp > validAfter);
      if (recent.length) this.events.set(key, recent);
      else this.events.delete(key);
    }
  }
}
