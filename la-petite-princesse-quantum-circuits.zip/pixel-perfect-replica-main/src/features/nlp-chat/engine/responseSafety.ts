// @ts-nocheck
import type { KnowledgeResult } from "../types";

export interface ResponseSafetyOptions {
  maxAnswerChars: number;
  maxSuggestions: number;
  maxSuggestionChars: number;
  maxSources: number;
  allowedSourceHosts?: string[];
}

export const DEFAULT_RESPONSE_SAFETY: ResponseSafetyOptions = {
  maxAnswerChars: 12_000,
  maxSuggestions: 5,
  maxSuggestionChars: 120,
  maxSources: 6,
};

/**
 * Bounds untrusted provider output before it reaches the UI. This is output
 * hygiene, not a substitute for model-side policy or server authorization.
 */
export function sanitizeKnowledgeResult(
  value: unknown,
  options: Partial<ResponseSafetyOptions> = {},
): KnowledgeResult {
  const config = { ...DEFAULT_RESPONSE_SAFETY, ...options };
  const record = isRecord(value) ? value : {};
  const rawText = typeof record.text === "string" ? record.text : "";
  const text = cleanPlainText(rawText).slice(0, config.maxAnswerChars).trim();
  const suggestions = Array.isArray(record.followUpSuggestions)
    ? record.followUpSuggestions
        .filter((item): item is string => typeof item === "string")
        .map((item) => cleanPlainText(item).slice(0, config.maxSuggestionChars).trim())
        .filter(Boolean)
        .slice(0, config.maxSuggestions)
    : undefined;
  const sources = Array.isArray(record.sources)
    ? record.sources
        .filter(isRecord)
        .map((item) => sanitizeSource(item, config.allowedSourceHosts))
        .filter((item): item is { label: string; url: string } => Boolean(item))
        .slice(0, config.maxSources)
    : undefined;

  return {
    text: text || "I couldn't prepare a response just now. Please try rephrasing your question.",
    ...(sources?.length ? { sources } : {}),
    ...(suggestions?.length ? { followUpSuggestions: suggestions } : {}),
  };
}

export function isSafeHttpUrl(value: string, allowedHosts?: string[]): boolean {
  try {
    const url = new URL(value);
    if (url.protocol !== "https:" && url.protocol !== "http:") return false;
    if (url.username || url.password) return false;
    if (allowedHosts?.length) {
      const host = url.hostname.toLowerCase();
      return allowedHosts.some((allowed) => host === allowed.toLowerCase() || host.endsWith(`.${allowed.toLowerCase()}`));
    }
    return true;
  } catch {
    return false;
  }
}

function sanitizeSource(
  value: Record<string, unknown>,
  allowedHosts?: string[],
): { label: string; url: string } | undefined {
  if (typeof value.url !== "string" || !isSafeHttpUrl(value.url, allowedHosts)) return undefined;
  const label = typeof value.label === "string" ? cleanPlainText(value.label).slice(0, 120).trim() : "Source";
  return { label: label || "Source", url: new URL(value.url).href };
}

function cleanPlainText(value: string): string {
  return value
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, "")
    .replace(/[\u202A-\u202E\u2066-\u2069]/g, "")
    .replace(/\r\n?/g, "\n");
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
