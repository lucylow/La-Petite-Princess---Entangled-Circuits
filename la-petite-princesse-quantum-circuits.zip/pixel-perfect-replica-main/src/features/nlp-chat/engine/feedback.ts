// @ts-nocheck
export type ChatFeedbackRating = "helpful" | "not_helpful";

export interface ChatFeedback {
  messageId: string;
  rating: ChatFeedbackRating;
  createdAt: number;
  reason?: string;
}

export interface FeedbackStore {
  set(feedback: ChatFeedback): void;
  get(messageId: string): ChatFeedback | undefined;
  all(): ChatFeedback[];
  clear(): void;
}

/** In-memory feedback store; forward feedback to an authenticated API as needed. */
export function createFeedbackStore(now: () => number = Date.now): FeedbackStore {
  const values = new Map<string, ChatFeedback>();
  return {
    set(feedback) {
      values.set(feedback.messageId, {
        ...feedback,
        reason: feedback.reason?.slice(0, 240),
        createdAt: Number.isFinite(feedback.createdAt) ? feedback.createdAt : now(),
      });
    },
    get(messageId) { return values.get(messageId); },
    all() { return [...values.values()]; },
    clear() { values.clear(); },
  };
}

export function createFeedback(
  messageId: string,
  rating: ChatFeedbackRating,
  reason?: string,
  now: () => number = Date.now,
): ChatFeedback {
  return { messageId, rating, createdAt: now(), ...(reason ? { reason: reason.slice(0, 240) } : {}) };
}
