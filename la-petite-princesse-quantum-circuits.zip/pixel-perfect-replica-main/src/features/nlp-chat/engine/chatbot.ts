// @ts-nocheck
import type {
  ChatMessage,
  ChatTurnResult,
  ChatbotEngineOptions,
  ChatbotConfig,
  ConversationContext,
  KnowledgeRequest,
} from "../types";
import { DEFAULT_INTENTS } from "../nlp/defaultIntents";
import { classifyIntent } from "../nlp/classifier";
import { DEFAULT_CONFIG } from "./config";
import { EMPTY_CONTEXT, updateContext } from "./context";
import { appendSourceLinks, createLocalResponse } from "./responses";
import { buildContextualQuery } from "./contextualQuery";
import { createClarificationPrompt, evaluateClarification } from "../nlp/clarification";
import { sanitizeKnowledgeResult } from "./responseSafety";

export class ChatbotEngine {
  readonly config: ChatbotConfig;
  private readonly intents;
  private readonly knowledgeProvider;
  private readonly now: () => number;
  private readonly idFactory: () => string;

  constructor(options: ChatbotEngineOptions = {}) {
    this.config = { ...DEFAULT_CONFIG, ...options.config };
    this.intents = options.intents ?? DEFAULT_INTENTS;
    this.knowledgeProvider = options.knowledgeProvider;
    this.now = options.now ?? Date.now;
    this.idFactory = options.idFactory ?? (() => createId());
  }

  createWelcomeMessage(): ChatMessage {
    return this.createMessage("assistant", this.config.welcomeMessage, { status: "sent" });
  }

  createMessage(
    role: ChatMessage["role"],
    content: string,
    extras: Partial<ChatMessage> = {},
  ): ChatMessage {
    return {
      id: this.idFactory(),
      role,
      content,
      createdAt: this.now(),
      status: role === "user" ? "sent" : undefined,
      ...extras,
    };
  }

  async reply(
    rawText: string,
    history: ChatMessage[],
    context: ConversationContext = EMPTY_CONTEXT,
    signal?: AbortSignal,
  ): Promise<ChatTurnResult> {
    const text = rawText.trim();
    if (!text) throw new Error("Please enter a message.");
    if (text.length > this.config.maxMessageLength) {
      throw new Error(`Message is too long. Please keep it under ${this.config.maxMessageLength} characters.`);
    }
    if (signal?.aborted) throw new DOMException("Request cancelled", "AbortError");

    const classification = classifyIntent(text, this.intents, context);
    const nextContext = updateContext(context, classification);
    const userMessage = this.createMessage("user", text, {
      intent: classification.primary.intent.id,
      confidence: classification.primary.confidence,
      entities: classification.entities,
    });

    const recentHistory = [...history, userMessage].slice(-this.config.maxHistory);
    const clarification = evaluateClarification(classification, {
      minimumConfidence: this.config.clarificationMinimumConfidence,
      minimumScoreMargin: this.config.clarificationMinimumScoreMargin,
    });
    const contextualQuery = buildContextualQuery(text, history, context);
    const shouldAskClarification = clarification.needed && classification.primary.intent.id !== "unknown";
    const shouldUseProvider = Boolean(
      !shouldAskClarification &&
      this.knowledgeProvider &&
      classification.primary.intent.id !== "unknown" &&
      classification.primary.confidence >= this.config.lowConfidenceThreshold &&
      !["greeting", "help", "goodbye", "troubleshoot", "account"].includes(classification.primary.intent.id),
    );

    let answer;
    try {
      if (shouldAskClarification) {
        answer = {
          text: createClarificationPrompt(clarification),
          followUpSuggestions: clarification.candidates.map((candidate) => candidate.intent.label).slice(0, 4),
        };
      } else if (shouldUseProvider && this.knowledgeProvider) {
        const request: KnowledgeRequest = {
          query: contextualQuery.retrievalQuery,
          intent: classification.primary,
          entities: classification.entities,
          context: nextContext,
          history: recentHistory,
          signal,
        };
        answer = await this.knowledgeProvider(request);
      } else {
        answer = createLocalResponse(classification, nextContext, this.config);
      }
    } catch (error) {
      if (signal?.aborted || (error instanceof Error && error.name === "AbortError")) throw error;
      answer = {
        text: "I couldn’t reach the learning service just now. Please try again, or rephrase your question so I can offer a general next step.",
      };
    }

    if (signal?.aborted) throw new DOMException("Request cancelled", "AbortError");

    const safeAnswer = sanitizeKnowledgeResult(answer);
    const message = this.createMessage("assistant", appendSourceLinks(safeAnswer), {
      intent: classification.primary.intent.id,
      confidence: classification.primary.confidence,
      entities: classification.entities,
      suggestions: safeAnswer.followUpSuggestions,
      status: "sent",
    });

    return { userMessage, message, classification, context: nextContext };
  }
}

function createId(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  return `chat-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}
