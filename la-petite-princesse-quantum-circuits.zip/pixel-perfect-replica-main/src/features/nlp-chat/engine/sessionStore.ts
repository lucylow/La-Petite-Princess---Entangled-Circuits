// @ts-nocheck
import type { ChatMessage, ConversationContext } from "../types";

const STORE_VERSION = 1;

export interface PersistedChatSession {
  messages: ChatMessage[];
  context: ConversationContext;
  savedAt: number;
}

export interface SessionStorageLike {
  getItem(key: string): string | null;
  setItem(key: string, value: string): void;
  removeItem(key: string): void;
}

export interface ChatSessionStore {
  load(): PersistedChatSession | null;
  save(session: PersistedChatSession): void;
  clear(): void;
}

export interface SessionStoreOptions {
  key?: string;
  storage?: SessionStorageLike;
  maxMessages?: number;
  maxMessageChars?: number;
  now?: () => number;
}

/**
 * Opt-in session persistence. Chat text is stored in the selected browser
 * storage in plain text; do not enable on shared devices or for sensitive chats.
 */
export function createChatSessionStore(options: SessionStoreOptions = {}): ChatSessionStore {
  const key = options.key ?? "start-here:nlp-chat:v1";
  const maxMessages = options.maxMessages ?? 40;
  const maxMessageChars = options.maxMessageChars ?? 2_000;
  const storage = options.storage ?? getBrowserStorage();
  const now = options.now ?? Date.now;

  return {
    load() {
      try {
        const raw = storage.getItem(key);
        if (!raw) return null;
        const envelope: unknown = JSON.parse(raw);
        if (!isRecord(envelope) || envelope.version !== STORE_VERSION || !isRecord(envelope.session)) return null;
        return parseSession(envelope.session, maxMessages, maxMessageChars);
      } catch {
        return null;
      }
    },
    save(session) {
      const safe: PersistedChatSession = {
        messages: session.messages.slice(-maxMessages).map((message) => ({
          ...message,
          content: message.content.slice(0, maxMessageChars),
        })),
        context: sanitizeContext(session.context),
        savedAt: now(),
      };
      try {
        storage.setItem(key, JSON.stringify({ version: STORE_VERSION, session: safe }));
      } catch {
        // Quota and privacy-mode storage failures should not break chat use.
      }
    },
    clear() {
      try { storage.removeItem(key); } catch { /* Ignore storage failures. */ }
    },
  };
}

function parseSession(value: Record<string, unknown>, maxMessages: number, maxChars: number): PersistedChatSession | null {
  if (!Array.isArray(value.messages) || !isRecord(value.context) || typeof value.savedAt !== "number") return null;
  const messages = value.messages.filter(isRecord).slice(-maxMessages).flatMap((item) => {
    if (typeof item.id !== "string" || typeof item.content !== "string") return [];
    if (item.role !== "user" && item.role !== "assistant" && item.role !== "system") return [];
    const message: ChatMessage = {
      id: item.id.slice(0, 100),
      role: item.role,
      content: item.content.slice(0, maxChars),
      createdAt: typeof item.createdAt === "number" ? item.createdAt : 0,
      status: item.status === "error" || item.status === "sending" || item.status === "sent" ? item.status : undefined,
    };
    return [message];
  });
  return { messages, context: sanitizeContext(value.context), savedAt: value.savedAt };
}

function sanitizeContext(value: ConversationContext | Record<string, unknown>): ConversationContext {
  const context = value as Record<string, unknown>;
  const slots = isRecord(context.slots)
    ? Object.fromEntries(Object.entries(context.slots).filter(([, item]) => typeof item === "string").slice(0, 20).map(([key, item]) => [key.slice(0, 60), (item as string).slice(0, 200)]))
    : {};
  return {
    lastIntent: typeof context.lastIntent === "string" ? context.lastIntent.slice(0, 80) : undefined,
    lastTopic: typeof context.lastTopic === "string" ? context.lastTopic.slice(0, 200) : undefined,
    lastEntities: [],
    awaitingClarification: Boolean(context.awaitingClarification),
    turnCount: typeof context.turnCount === "number" && Number.isFinite(context.turnCount) ? Math.max(0, context.turnCount) : 0,
    slots,
  };
}

function getBrowserStorage(): SessionStorageLike {
  if (typeof window === "undefined" || !window.sessionStorage) {
    return { getItem: () => null, setItem: () => undefined, removeItem: () => undefined };
  }
  return window.sessionStorage;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
