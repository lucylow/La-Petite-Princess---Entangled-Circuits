// @ts-nocheck
import type { ChatMessage, ConversationContext } from "../types";

const FOLLOW_UP_ONLY = /^(?:why|how|when|where|who|which|what about that|what about it|tell me more|go on|continue|give me an example|show me another|and then|why is that|how so)[?!.,\s]*$/i;
const MAX_CONTEXT_CHARS = 600;

export interface ContextualQueryOptions {
  maxPreviousQuestionChars?: number;
  includeTopic?: boolean;
  includeIntent?: boolean;
}

/**
 * Expands only very short follow-ups. It never replaces the user's original
 * text; the original is retained in `userQuery` for display and auditing.
 */
export function buildContextualQuery(
  userQuery: string,
  history: ChatMessage[],
  context: ConversationContext,
  options: ContextualQueryOptions = {},
): { userQuery: string; retrievalQuery: string; expanded: boolean } {
  const trimmed = userQuery.trim();
  const isShortFollowUp = trimmed.length <= 64 && FOLLOW_UP_ONLY.test(trimmed);
  if (!isShortFollowUp || (!context.lastTopic && !context.lastIntent && history.length === 0)) {
    return { userQuery: trimmed, retrievalQuery: trimmed, expanded: false };
  }

  const previousQuestion = [...history]
    .reverse()
    .find((message) => message.role === "user")?.content
    ?.slice(0, options.maxPreviousQuestionChars ?? MAX_CONTEXT_CHARS);
  const parts: string[] = [];
  if (options.includeTopic !== false && context.lastTopic) parts.push(`Topic: ${context.lastTopic}.`);
  if (options.includeIntent !== false && context.lastIntent) parts.push(`Previous task: ${context.lastIntent}.`);
  if (previousQuestion) parts.push(`Previous user question: ${previousQuestion}.`);
  parts.push(`Follow-up: ${trimmed}`);

  return { userQuery: trimmed, retrievalQuery: parts.join(" "), expanded: true };
}
