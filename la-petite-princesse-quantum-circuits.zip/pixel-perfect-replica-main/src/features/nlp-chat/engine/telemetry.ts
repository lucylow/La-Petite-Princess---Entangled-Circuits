// @ts-nocheck
export type ChatTelemetryEventName =
  | "message_submitted"
  | "intent_classified"
  | "clarification_shown"
  | "provider_failed"
  | "response_received"
  | "feedback_submitted";

export interface ChatTelemetryEvent {
  name: ChatTelemetryEventName;
  timestamp: number;
  sessionTurn?: number;
  intentId?: string;
  confidenceBucket?: "low" | "medium" | "high";
  durationMs?: number;
  outcome?: "success" | "failure" | "cancelled";
}

export type ChatTelemetrySink = (event: ChatTelemetryEvent) => void;

/** Emits metadata only. It intentionally has no message-text or entity fields. */
export class ChatTelemetry {
  constructor(
    private readonly sink?: ChatTelemetrySink,
    private readonly enabled = false,
    private readonly now: () => number = Date.now,
  ) {}

  track(event: Omit<ChatTelemetryEvent, "timestamp">): void {
    if (!this.enabled || !this.sink) return;
    try {
      this.sink({ ...event, timestamp: this.now() });
    } catch {
      // Analytics failures must never interrupt the conversation.
    }
  }
}

export function confidenceBucket(confidence: number): ChatTelemetryEvent["confidenceBucket"] {
  if (confidence < 0.35) return "low";
  if (confidence < 0.7) return "medium";
  return "high";
}
