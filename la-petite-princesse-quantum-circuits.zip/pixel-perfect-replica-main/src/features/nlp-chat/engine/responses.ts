// @ts-nocheck
import type { ChatbotConfig, ClassificationResult, ConversationContext, KnowledgeResult } from "../types";

export function createLocalResponse(
  classification: ClassificationResult,
  context: ConversationContext,
  config: ChatbotConfig,
): KnowledgeResult {
  const topic = context.lastTopic ? ` about **${context.lastTopic}**` : "";

  switch (classification.primary.intent.id) {
    case "greeting":
      return { text: `Hello! I’m ${config.botName}. What would you like to learn today?`, followUpSuggestions: ["Help me choose a lesson", "Explain a concept", "Show my progress"] };
    case "help":
      return { text: "I can help you find learning material, explain a concept, troubleshoot an activity, and understand your learning progress. Tell me what you’re trying to do, and I’ll guide you to the next step.", followUpSuggestions: ["Where should I start?", "Explain circuit analysis", "I’m stuck on a lesson"] };
    case "goodbye":
      return { text: "You’re welcome. Keep exploring, and come back whenever you’re ready for the next step." };
    case "troubleshoot":
      return { text: "Let’s work through it. What were you trying to do, what did you expect to happen, and what happened instead? Please leave out passwords or other private account details." };
    case "account":
      return { text: "I can help you work out the next step. For account-specific changes, use the account settings or the app’s official support route. Never share your password or sign-in codes in chat." };
    case "progress":
      return { text: "Your learning progress should be visible in the progress dashboard. Look for your completed activities, current level, XP, and streak. I can explain how those measures work, but I can’t read your private account totals unless the app provides an authenticated progress tool." };
    case "explain":
      return { text: `I can break that down step by step${topic}. What part would you like me to focus on: the definition, how it works, or a worked example?`, followUpSuggestions: ["Start with the basics", "Show a worked example", "Explain it in simpler terms"] };
    case "learning_path":
      return { text: "A useful learning path starts with your goal and current experience. What are you trying to learn, and would you describe your level as beginner, intermediate, or advanced?", followUpSuggestions: ["I’m a beginner", "I’m intermediate", "I’m advanced"] };
    case "circuit_help":
      return { text: "I can help with circuit concepts and calculations. Share the circuit values and what you need to find (for example, voltage, current, or resistance). Include units where possible." };
    default:
      return { text: config.fallbackMessage, followUpSuggestions: ["What can you help me with?", "Help me find a lesson", "Explain a concept"] };
  }
}

export function appendSourceLinks(result: KnowledgeResult): string {
  if (!result.sources?.length) return result.text;
  const links = result.sources.map((source) => `- [${source.label}](${source.url})`).join("\n");
  return `${result.text}\n\n**Sources**\n${links}`;
}
