// @ts-nocheck
import type { ChatbotConfig } from "../types";

export const DEFAULT_CONFIG: ChatbotConfig = {
  botName: "Start Here Assistant",
  welcomeMessage: "Hi! I can help you explore lessons, understand concepts, and find your next step. What would you like to work on?",
  fallbackMessage: "I’m not fully sure what you mean yet. Could you rephrase that or tell me the topic you’re working on?",
  lowConfidenceThreshold: 0.34,
  maxHistory: 12,
  maxMessageLength: 2_000,
  typingDelayMs: 0,
  clarificationMinimumConfidence: 0.32,
  clarificationMinimumScoreMargin: 0.075,
};
