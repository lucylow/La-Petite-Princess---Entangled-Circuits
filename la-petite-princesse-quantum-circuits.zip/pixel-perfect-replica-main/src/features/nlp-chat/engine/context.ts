// @ts-nocheck
import type { ClassificationResult, ConversationContext, EntityMatch } from "../types";
import { resolveTopic } from "../nlp/classifier";

export const EMPTY_CONTEXT: ConversationContext = {
  lastEntities: [],
  turnCount: 0,
  slots: {},
};

export function updateContext(
  previous: ConversationContext,
  classification: ClassificationResult,
): ConversationContext {
  const freshEntities = classification.entities;
  const lastEntities = mergeEntities(previous.lastEntities, freshEntities);
  const slots = { ...previous.slots };

  for (const entity of freshEntities) {
    const key = entity.type;
    slots[key] = entity.normalizedValue ?? entity.value;
  }

  const intentId = classification.primary.intent.id;
  return {
    lastIntent: intentId === "unknown" ? previous.lastIntent : intentId,
    lastTopic: resolveTopic(freshEntities, previous.lastTopic),
    lastEntities,
    awaitingClarification: intentId === "unknown" || undefined,
    turnCount: previous.turnCount + 1,
    slots,
  };
}

function mergeEntities(previous: EntityMatch[], current: EntityMatch[]): EntityMatch[] {
  const byKey = new Map<string, EntityMatch>();
  for (const entity of previous) byKey.set(`${entity.type}:${entity.normalizedValue ?? entity.value}`, entity);
  for (const entity of current) byKey.set(`${entity.type}:${entity.normalizedValue ?? entity.value}`, entity);
  return [...byKey.values()].slice(-12);
}

export function buildFollowUpContext(context: ConversationContext): string | undefined {
  if (!context.lastTopic && !context.lastIntent) return undefined;
  const topic = context.lastTopic ? `about ${context.lastTopic}` : "the previous topic";
  return `The user is following up on ${topic}. Previous intent: ${context.lastIntent ?? "unknown"}.`;
}
