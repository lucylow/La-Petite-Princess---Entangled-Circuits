import { describe, expect, it } from "vitest";
import { classifyIntent } from "../nlp/classifier";
import { DEFAULT_INTENTS } from "../nlp/defaultIntents";
import { EMPTY_CONTEXT, updateContext } from "../engine/context";

describe("intent classification", () => {
  it("recognizes common learning and help intents", () => {
    expect(classifyIntent("What can you help me with?", DEFAULT_INTENTS).primary.intent.id).toBe("help");
    expect(classifyIntent("Explain Ohm's law", DEFAULT_INTENTS).primary.intent.id).toBe("circuit_help");
    expect(classifyIntent("Show my XP progress", DEFAULT_INTENTS).primary.intent.id).toBe("progress");
  });

  it("keeps the previous topic for short follow-ups", () => {
    const first = classifyIntent("Explain circuit analysis", DEFAULT_INTENTS);
    const context = updateContext(EMPTY_CONTEXT, first);
    const followUp = classifyIntent("Why?", DEFAULT_INTENTS, context);
    expect(followUp.isFollowUp).toBe(true);
    expect(followUp.primary.intent.id).toBe("circuit_help");
  });

  it("returns unknown for unrelated noise", () => {
    expect(classifyIntent("qzxv 8291 ???", DEFAULT_INTENTS).primary.intent.id).toBe("unknown");
  });
});
