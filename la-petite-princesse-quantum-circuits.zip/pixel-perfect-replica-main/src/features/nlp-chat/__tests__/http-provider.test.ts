import { describe, expect, it, vi } from "vitest";
import { createHttpKnowledgeProvider, KnowledgeProviderError } from "../engine/httpKnowledgeProvider";
import type { KnowledgeRequest } from "../types";

const request: KnowledgeRequest = {
  query: "Explain voltage",
  intent: {
    intent: { id: "explain", label: "Explain", phrases: [], keywords: [] },
    score: 0.8,
    confidence: 0.85,
    matchedTerms: ["explain"],
  },
  entities: [],
  context: { lastIntent: "explain", lastTopic: "voltage", lastEntities: [], turnCount: 1, slots: {} },
  history: [{ id: "1", role: "user", content: "Explain voltage", createdAt: 1 }],
};

describe("HTTP knowledge provider", () => {
  it("sends a bounded payload and validates its result", async () => {
    const fetchImpl = vi.fn(async (_url: RequestInfo | URL, init?: RequestInit) => {
      expect(init?.method).toBe("POST");
      expect(String(init?.body)).toContain("Explain voltage");
      return new Response(JSON.stringify({ text: "Voltage is electric potential difference.", sources: [{ label: "Guide", url: "https://example.com" }] }), { status: 200 });
    }) as unknown as typeof fetch;
    const provider = createHttpKnowledgeProvider({ endpoint: "/api/assistant", fetchImpl, allowedSourceHosts: ["example.com"] });
    const result = await provider(request);
    expect(result.text).toContain("electric potential");
    expect(result.sources).toHaveLength(1);
  });

  it("reports non-success server responses", async () => {
    const fetchImpl = (async () => new Response("unavailable", { status: 503 })) as typeof fetch;
    const provider = createHttpKnowledgeProvider({ endpoint: "/api/assistant", fetchImpl });
    await expect(provider(request)).rejects.toBeInstanceOf(KnowledgeProviderError);
  });
});
