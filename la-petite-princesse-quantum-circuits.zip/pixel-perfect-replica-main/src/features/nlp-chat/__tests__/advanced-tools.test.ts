import { describe, expect, it } from "vitest";
import { evaluateClarification } from "../nlp/clarification";
import { buildContextualQuery } from "../engine/contextualQuery";
import { sanitizeKnowledgeResult, isSafeHttpUrl } from "../engine/responseSafety";
import { SlidingWindowRateLimiter } from "../engine/slidingWindowRateLimiter";
import { searchKnowledgeBase } from "../engine/localRetrieval";
import { createChatSessionStore } from "../engine/sessionStore";
import type { ClassificationResult, ConversationContext } from "../types";

const context: ConversationContext = {
  lastIntent: "explain",
  lastTopic: "Ohm's law",
  lastEntities: [],
  turnCount: 2,
  slots: {},
};

describe("advanced NLP utilities", () => {
  it("expands a short follow-up with the previous user question", () => {
    const result = buildContextualQuery("why?", [{
      id: "u1", role: "user", content: "Explain Ohm's law", createdAt: 1,
    }], context);
    expect(result.expanded).toBe(true);
    expect(result.retrievalQuery).toContain("Ohm's law");
    expect(result.retrievalQuery).toContain("why?");
  });

  it("does not expand a complete new question", () => {
    const result = buildContextualQuery("How do I find resistance?", [], context);
    expect(result.expanded).toBe(false);
    expect(result.retrievalQuery).toBe("How do I find resistance?");
  });

  it("removes unsafe source URLs and bounds answer content", () => {
    const result = sanitizeKnowledgeResult({
      text: `hello\u0000 world`,
      sources: [
        { label: "safe", url: "https://example.com/guide" },
        { label: "bad", url: "javascript:alert(1)" },
      ],
      followUpSuggestions: [" Next ", ""],
    }, { maxAnswerChars: 20, allowedSourceHosts: ["example.com"] });
    expect(result.text).toBe("hello world");
    expect(result.sources).toHaveLength(1);
    expect(result.followUpSuggestions).toEqual(["Next"]);
    expect(isSafeHttpUrl("https://evil.test", ["example.com"])).toBe(false);
  });

  it("blocks requests after the configured sliding window limit", () => {
    let now = 1_000;
    const limiter = new SlidingWindowRateLimiter({ limit: 2, windowMs: 1_000, now: () => now });
    expect(limiter.consume("user-1").allowed).toBe(true);
    expect(limiter.consume("user-1").allowed).toBe(true);
    const blocked = limiter.consume("user-1");
    expect(blocked.allowed).toBe(false);
    expect(blocked.retryAfterMs).toBe(1_000);
    now += 1_001;
    expect(limiter.consume("user-1").allowed).toBe(true);
  });

  it("retrieves documents using titles, tags and body terms", () => {
    const hits = searchKnowledgeBase("voltage divider", [
      { id: "a", title: "Voltage divider basics", content: "A resistor network divides voltage." },
      { id: "b", title: "Study planning", content: "Plan a weekly study routine.", tags: ["habits"] },
    ]);
    expect(hits[0]?.document.id).toBe("a");
  });

  it("stores and restores a bounded session", () => {
    const values = new Map<string, string>();
    const storage = {
      getItem: (key: string) => values.get(key) ?? null,
      setItem: (key: string, value: string) => { values.set(key, value); },
      removeItem: (key: string) => { values.delete(key); },
    };
    const store = createChatSessionStore({ storage, key: "test", now: () => 99 });
    store.save({
      messages: [{ id: "1", role: "user", content: "hello", createdAt: 1 }],
      context,
      savedAt: 1,
    });
    expect(store.load()?.messages[0]?.content).toBe("hello");
    store.clear();
    expect(store.load()).toBeNull();
  });

  it("identifies close intent matches as ambiguous", () => {
    const primary = { intent: { id: "a", label: "Lesson search", phrases: [], keywords: [] }, score: 0.6, confidence: 0.65, matchedTerms: [] };
    const alternative = { intent: { id: "b", label: "Concept explanation", phrases: [], keywords: [] }, score: 0.57, confidence: 0.62, matchedTerms: [] };
    const result: ClassificationResult = {
      primary,
      alternatives: [alternative],
      entities: [],
      normalizedText: "help me learn",
      isFollowUp: false,
    };
    expect(evaluateClarification(result).reason).toBe("ambiguous-intent");
  });
});
