import { describe, expect, it } from "vitest";
import { normalizeText, tokenize } from "../nlp/normalize";

describe("text normalization", () => {
  it("normalizes case, punctuation and whitespace", () => {
    expect(normalizeText("  HELLO!!!   World  ")).toBe("hello world");
  });
  it("expands common contractions", () => {
    expect(normalizeText("What's wrong? I can't log in.")).toContain("what is");
    expect(normalizeText("I can't log in")).toContain("cannot");
  });
  it("can remove stop words while tokenizing", () => {
    expect(tokenize("Can you explain the circuit?", { removeStopWords: true })).toEqual(["explain", "circuit"]);
  });
});
