import { describe, expect, it } from "vitest";
import { ChatbotEngine } from "../engine/chatbot";

describe("chatbot engine", () => {
  it("returns a user and assistant message", async () => {
    const engine = new ChatbotEngine({ now: () => 123, idFactory: (() => { let n = 0; return () => `id-${++n}`; })() });
    const result = await engine.reply("hello", []);
    expect(result.userMessage.role).toBe("user");
    expect(result.message.role).toBe("assistant");
    expect(result.message.content.toLowerCase()).toContain("hello");
  });

  it("uses an injected knowledge provider for concept questions", async () => {
    const engine = new ChatbotEngine({
      knowledgeProvider: async ({ query }) => ({ text: `Retrieved answer for: ${query}`, sources: [{ label: "Learning docs", url: "https://example.com/learn" }] }),
    });
    const result = await engine.reply("Explain circuit analysis", []);
    expect(result.message.content).toContain("Retrieved answer");
    expect(result.message.content).toContain("https://example.com/learn");
  });

  it("rejects an empty message", async () => {
    const engine = new ChatbotEngine();
    await expect(engine.reply("   ", [])).rejects.toThrow("Please enter a message");
  });
});
