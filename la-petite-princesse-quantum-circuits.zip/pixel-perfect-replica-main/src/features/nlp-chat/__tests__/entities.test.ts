import { describe, expect, it } from "vitest";
import { extractEntities } from "../nlp/entities";

describe("entity extraction", () => {
  it("extracts duration, email, numeric and topic entities", () => {
    const found = extractEntities("Remind me in 20 minutes; email me at learner@example.com about circuit analysis with 12 volts and a group of 3 learners");
    expect(found.some((entity) => entity.type === "duration" && entity.normalizedValue === "20 minutes")).toBe(true);
    expect(found.some((entity) => entity.type === "email" && entity.normalizedValue === "learner@example.com")).toBe(true);
    expect(found.some((entity) => entity.type === "topic" && entity.normalizedValue === "circuit analysis")).toBe(true);
    expect(found.some((entity) => entity.type === "number" && entity.value === "12")).toBe(true);
    expect(found.some((entity) => entity.type === "measurement" && entity.normalizedValue === "12 volts")).toBe(true);
  });
});
