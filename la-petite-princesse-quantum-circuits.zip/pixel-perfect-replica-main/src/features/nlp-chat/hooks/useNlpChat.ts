// @ts-nocheck
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { ChatMessage, ChatbotState, ConversationContext } from "../types";
import { ChatbotEngine } from "../engine/chatbot";
import { EMPTY_CONTEXT } from "../engine/context";

export interface UseNlpChatOptions {
  engine?: ChatbotEngine;
  initialMessages?: ChatMessage[];
  onAssistantMessage?: (message: ChatMessage) => void;
}

export interface UseNlpChatResult extends ChatbotState {
  sendMessage: (text: string) => Promise<void>;
  sendSuggestion: (text: string) => Promise<void>;
  clearConversation: () => void;
  cancelRequest: () => void;
}

export function useNlpChat(options: UseNlpChatOptions = {}): UseNlpChatResult {
  const engine = useMemo(() => options.engine ?? new ChatbotEngine(), [options.engine]);
  const [state, setState] = useState<ChatbotState>(() => ({
    messages: options.initialMessages?.length ? options.initialMessages : [engine.createWelcomeMessage()],
    context: EMPTY_CONTEXT,
    isThinking: false,
  }));
  const stateRef = useRef(state);
  const controllerRef = useRef<AbortController | null>(null);
  const pendingRef = useRef(false);

  useEffect(() => { stateRef.current = state; }, [state]);

  const cancelRequest = useCallback(() => {
    controllerRef.current?.abort();
    controllerRef.current = null;
    pendingRef.current = false;
    setState((current) => ({ ...current, isThinking: false }));
  }, []);

  const clearConversation = useCallback(() => {
    cancelRequest();
    const nextState: ChatbotState = { messages: [engine.createWelcomeMessage()], context: EMPTY_CONTEXT, isThinking: false };
    stateRef.current = nextState;
    setState(nextState);
  }, [cancelRequest, engine]);

  const sendMessage = useCallback(async (rawText: string) => {
    const text = rawText.trim();
    if (!text || pendingRef.current) return;
    pendingRef.current = true;
    const controller = new AbortController();
    controllerRef.current = controller;
    const current = stateRef.current;
    setState((previous) => ({ ...previous, isThinking: true, error: undefined }));

    try {
      const result = await engine.reply(text, current.messages, current.context, controller.signal);
      if (controller.signal.aborted) return;
      const nextState: ChatbotState = {
        messages: [...current.messages, result.userMessage, result.message],
        context: result.context,
        isThinking: false,
      };
      stateRef.current = nextState;
      setState(nextState);
      options.onAssistantMessage?.(result.message);
    } catch (error) {
      if (controller.signal.aborted || (error instanceof Error && error.name === "AbortError")) return;
      const message = error instanceof Error ? error.message : "Something went wrong. Please try again.";
      setState((previous) => ({ ...previous, isThinking: false, error: message }));
    } finally {
      // An older aborted request must not unlock a newer in-flight request.
      if (controllerRef.current === controller) {
        controllerRef.current = null;
        pendingRef.current = false;
      }
    }
  }, [engine, options.onAssistantMessage]);

  const sendSuggestion = useCallback((text: string) => sendMessage(text), [sendMessage]);

  return { ...state, sendMessage, sendSuggestion, clearConversation, cancelRequest };
}
