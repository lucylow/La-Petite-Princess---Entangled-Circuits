// @ts-nocheck
export type Role = "user" | "assistant" | "system";

export interface ChatMessage {
  id: string;
  role: Role;
  content: string;
  createdAt: number;
  intent?: string;
  confidence?: number;
  entities?: EntityMatch[];
  suggestions?: string[];
  status?: "sending" | "sent" | "error";
}

export type EntityType =
  | "topic"
  | "email"
  | "url"
  | "number"
  | "duration"
  | "measurement"
  | "date"
  | "level"
  | "unknown";

export interface EntityMatch {
  type: EntityType;
  value: string;
  normalizedValue?: string;
  start: number;
  end: number;
}

export interface IntentDefinition {
  id: string;
  label: string;
  description?: string;
  phrases: string[];
  keywords: string[];
  examples?: string[];
  priority?: number;
  /** Keep this intent from being selected unless its minimum score is met. */
  threshold?: number;
}

export interface IntentMatch {
  intent: IntentDefinition;
  confidence: number;
  score: number;
  matchedTerms: string[];
}

export interface ConversationContext {
  lastIntent?: string;
  lastTopic?: string;
  lastEntities: EntityMatch[];
  awaitingClarification?: boolean;
  turnCount: number;
  slots: Record<string, string>;
}

export interface ClassificationResult {
  primary: IntentMatch;
  alternatives: IntentMatch[];
  entities: EntityMatch[];
  normalizedText: string;
  isFollowUp: boolean;
}

export interface KnowledgeRequest {
  query: string;
  intent: IntentMatch;
  entities: EntityMatch[];
  context: ConversationContext;
  history: ChatMessage[];
  signal?: AbortSignal;
}

export interface KnowledgeResult {
  text: string;
  sources?: Array<{ label: string; url: string }>;
  followUpSuggestions?: string[];
  metadata?: Record<string, unknown>;
}

export type KnowledgeProvider = (request: KnowledgeRequest) => Promise<KnowledgeResult>;

export interface ChatbotConfig {
  botName: string;
  welcomeMessage: string;
  fallbackMessage: string;
  lowConfidenceThreshold: number;
  maxHistory: number;
  maxMessageLength: number;
  typingDelayMs: number;
  clarificationMinimumConfidence: number;
  clarificationMinimumScoreMargin: number;
}

export interface ChatTurnResult {
  userMessage: ChatMessage;
  message: ChatMessage;
  classification: ClassificationResult;
  context: ConversationContext;
}

export interface ChatbotEngineOptions {
  intents?: IntentDefinition[];
  config?: Partial<ChatbotConfig>;
  knowledgeProvider?: KnowledgeProvider;
  now?: () => number;
  idFactory?: () => string;
}

export interface ChatbotState {
  messages: ChatMessage[];
  context: ConversationContext;
  isThinking: boolean;
  error?: string;
}
