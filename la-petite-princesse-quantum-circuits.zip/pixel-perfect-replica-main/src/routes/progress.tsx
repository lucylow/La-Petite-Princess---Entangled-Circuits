import { createFileRoute, Link } from "@tanstack/react-router";
import { GamificationDashboard, useGamification } from "@/features/gamification";
import "@/features/gamification/styles/gamification.css";

export const Route = createFileRoute("/progress")({
  head: () => ({
    meta: [
      { title: "Your Learning Journey — XP, quests and achievements" },
      { name: "description", content: "Track your quantum learning level, streak, quests and achievements." },
      { property: "og:title", content: "Your Quantum Learning Journey" },
      { property: "og:description", content: "Levels, daily quests, streaks and achievements." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ProgressPage,
});

function ProgressPage() {
  const { state } = useGamification();
  return (
    <div>
      <div className="p-4"><Link to="/">← Studio</Link></div>
      <GamificationDashboard state={state} />
    </div>
  );
}
