import { createFileRoute } from "@tanstack/react-router";
import { NlpChatPanel } from "@/features/nlp-chat";
import "@/features/nlp-chat/styles/nlp-chat.css";

export const Route = createFileRoute("/chat")({
  head: () => ({
    meta: [
      { title: "Quantum Assistant Chat" },
      { name: "description", content: "Ask the quantum learning assistant questions about lessons, labs and progress." },
      { property: "og:title", content: "Quantum Assistant Chat" },
      { property: "og:description", content: "Ask the quantum learning assistant questions about lessons, labs and progress." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => (
    <main className="mx-auto w-full max-w-4xl p-4">
      <NlpChatPanel title="Quantum Assistant" subtitle="Your learning companion" />
    </main>
  ),
});
