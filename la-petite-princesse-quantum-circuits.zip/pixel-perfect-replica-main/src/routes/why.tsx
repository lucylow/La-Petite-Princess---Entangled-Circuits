import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";

type Slide = { kicker: string; title: string; lead: string; points: [string, string][]; notes: string };

const SLIDES: Slide[] = [
  { kicker: "01 · Scientific models", title: "Science is a way of learning how to change our minds", lead: "Quantum physics was built by people willing to replace models that no longer matched the evidence.", points: [["Observe", "Blackbody radiation and spectra defied classical predictions."], ["Revise", "Bohr's atom gave way to quantum mechanics as data improved."], ["Practise", "Students rehearse updating a model when evidence demands it."]], notes: "Open with the story of the early 1900s: experiments forced physicists to abandon intuitive pictures. The point is not that old science was 'wrong', but that models have domains of validity. Ask the audience when they last changed their mind because of evidence." },
  { kicker: "02 · Evidence and interpretation", title: "Fact, model and interpretation are not the same thing", lead: "Quantum mechanics predicts experiments with extraordinary accuracy, yet physicists still debate what it means.", points: [["Evidence", "Interference patterns and measured probabilities."], ["Model", "The wavefunction and the rules that predict outcomes."], ["Interpretation", "Copenhagen, many-worlds and others — still open questions."]], notes: "This is a rare chance to show students three layers clearly. Stress that open interpretation questions do not weaken the predictive success. Warn against popular claims that 'quantum' proves mystical ideas — that is speculation, not evidence." },
  { kicker: "03 · Physical information", title: "Information is physical", lead: "Every bit is stored in matter or light, and the physics of the carrier shapes what can be computed and communicated.", points: [["Bit", "Either 0 or 1 at any moment."], ["Qubit", "A superposition described by amplitudes; measurement yields 0 or 1."], ["Limit", "Unknown quantum states cannot be copied (no-cloning)."]], notes: "Avoid saying a qubit is 'both 0 and 1 at once' as a full explanation. Explain amplitudes and that measurement gives one result with predictable probabilities. Use the app's Bloch sphere to make this visible." },
  { kicker: "04 · Technology today", title: "Quantum principles already power everyday technology", lead: "Quantum physics is not only a future technology — it explains devices people already use.", points: [["Mature", "Transistors, lasers, LEDs, MRI, atomic clocks behind GPS."], ["Emerging", "Quantum sensors and quantum key distribution pilots."], ["Long-term", "Large fault-tolerant quantum computers — still in development."]], notes: "Keep the three tiers distinct. Quantum computers are not universally faster; they are expected to help for specific problems such as simulating molecules or certain cryptographic tasks. Be honest about timelines." },
  { kicker: "05 · Measurement", title: "Measurement and precision matter", lead: "In quantum systems, measuring is an active physical interaction — and modern precision science depends on understanding it.", points: [["Disturbance", "Measuring a qubit changes its state."], ["Statistics", "One run tells little; repeated runs reveal probabilities."], ["Precision", "Atomic clocks keep time to about a second in hundreds of millions of years."]], notes: "Connect to lab practice: uncertainty, repeated trials, error bars. Students learn why a single result should not be over-interpreted — a transferable habit for reading any data." },
  { kicker: "06 · Methods", title: "Real experimental and computational methods", lead: "Students can simulate, program and test quantum circuits with the same ideas researchers use.", points: [["Simulate", "Build circuits and watch state vectors evolve."], ["Code", "Export to real frameworks and read results critically."], ["Compare", "Ideal simulations versus noisy hardware results."]], notes: "Demonstrate the Circuit Pro studio live. Highlight that noise and error are central to real quantum work, so students meet honest science rather than a polished myth." },
  { kicker: "07 · Collaboration", title: "Discovery is a collective human achievement", lead: "Quantum theory emerged from decades of exchange between many people across countries and disciplines.", points: [["Then", "Planck, Einstein, Bohr, Heisenberg, Schrödinger, Noether's mathematics and many others."], ["Now", "Physicists, engineers, programmers and chemists work in teams."], ["You", "Every contributor — including young women experimenters and coders — belongs."]], notes: "Move away from the lone-genius myth. Mention that collaboration includes technicians, programmers and theorists. Show diverse participation as normal, without tokenism." },
  { kicker: "08 · Public trust", title: "Understanding builds trust in science", lead: "When people understand how evidence is produced, they can tell genuine progress from hype.", points: [["Spot hype", "Recognise exaggerated quantum marketing claims."], ["Ask questions", "What was measured? By whom? With what uncertainty?"], ["Decide", "Take part in informed public discussion."]], notes: "Trust should be earned through transparency, not demanded. Quantum is a useful case study because it attracts both real breakthroughs and misleading claims." },
  { kicker: "09 · Access", title: "Advanced science belongs before university", lead: "Core quantum ideas can be explored with visual tools and modest mathematics in secondary school.", points: [["Visual", "Spheres, circuits and probability charts before heavy algebra."], ["Gradual", "From coins and polarisers to amplitudes and gates."], ["Equitable", "Free, browser-based tools reach every school."]], notes: "Address the concern that it is 'too hard'. Early exposure lets students know the field exists before they choose subjects. Emphasise teacher support and curriculum fit." },
  { kicker: "10 · Society", title: "The quantum future needs a participating society", lead: "Decisions about quantum technology — security, investment, ethics — should involve informed citizens, not only experts.", points: [["Schools", "Introduce concepts and hands-on tools."], ["Partners", "Museums, universities, industry and funders share resources."], ["Action", "Start one lesson, one lab, one conversation this year."]], notes: "Close with a clear call to action tailored to each audience group. Invite them to try the app's academy and labs with students." },
];

export const Route = createFileRoute("/why")({
  validateSearch: (s: Record<string, unknown>) => ({ slide: Math.min(10, Math.max(1, Number(s["slide"]) || 1)) }),
  head: () => ({
    meta: [
      { title: "Why Quantum Education Matters — 10-slide presentation" },
      { name: "description", content: "Ten reasons quantum education matters, from scientific models to public trust." },
      { property: "og:title", content: "Why Quantum Education Matters" },
      { property: "og:description", content: "A 10-slide presentation for schools, families and partners." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Deck,
});

function Deck() {
  const { slide } = Route.useSearch();
  const nav = Route.useNavigate();
  const [notes, setNotes] = useState(false);
  const i = slide - 1;
  const s = SLIDES[i] ?? SLIDES[0]!;
  const go = (n: number) => nav({ search: { slide: Math.min(10, Math.max(1, n)) }, replace: true });
  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight" || e.key === " ") go(slide + 1);
      if (e.key === "ArrowLeft") go(slide - 1);
      if (e.key === "n") setNotes((v) => !v);
    };
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  });
  let x0 = 0;
  return (
    <div className="deck min-h-screen flex flex-col">
      <div className="deck-slide flex-1 flex flex-col justify-center px-6 md:px-16 py-10 max-w-6xl mx-auto w-full"
        onTouchStart={(e) => (x0 = e.touches[0]?.clientX ?? 0)}
        onTouchEnd={(e) => { const d = (e.changedTouches[0]?.clientX ?? 0) - x0; if (Math.abs(d) > 50) go(d < 0 ? slide + 1 : slide - 1); }}>
        <p className="deck-kicker text-sm">{s.kicker}</p>
        <h1 className="mt-4 text-4xl md:text-6xl font-semibold leading-tight max-w-4xl">{s.title}</h1>
        <p className="deck-muted mt-6 text-lg md:text-2xl max-w-3xl">{s.lead}</p>
        <div className="mt-10 grid gap-4 md:grid-cols-3">
          {s.points.map(([h, t]) => (
            <div key={h} className="deck-card rounded-xl p-5">
              <p className="deck-cyan font-semibold text-lg">{h}</p>
              <p className="deck-muted mt-2">{t}</p>
            </div>
          ))}
        </div>
        {notes && <div className="deck-card rounded-xl p-5 mt-8 text-sm deck-muted"><b className="deck-cyan">Presenter notes: </b>{s.notes}</div>}
      </div>
      <div className="flex items-center justify-between gap-4 px-6 py-4 border-t deck-line text-sm">
        <Link to="/" className="deck-muted">← Studio</Link>
        <div className="flex gap-2">{SLIDES.map((_, n) => <button key={n} aria-label={`Slide ${n + 1}`} data-on={n === i} className="deck-dot h-2 w-6 rounded-full" onClick={() => go(n + 1)} />)}</div>
        <div className="flex gap-3">
          <button onClick={() => setNotes((v) => !v)}>Notes</button>
          <button onClick={() => go(slide - 1)} aria-label="Previous">←</button>
          <span>{slide}/10</span>
          <button onClick={() => go(slide + 1)} aria-label="Next">→</button>
        </div>
      </div>
    </div>
  );
}
