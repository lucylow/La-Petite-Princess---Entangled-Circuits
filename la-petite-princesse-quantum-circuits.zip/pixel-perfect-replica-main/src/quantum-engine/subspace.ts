// @ts-nocheck -- imported Circuit Pro module, written for a looser tsconfig
import { C, cAbs2, cScale, ZERO } from "./complex";
import type { StateVector } from "./statevector";
import { cleanNumber } from "./statevector";

export interface PostselectionResult {
  state: StateVector;
  successProbability: number;
  selectedQubits: number[];
  selectedBits: number[];
  rejectedNormSquared: number;
}

function validateSelection(state: StateVector, qubits: number[], bits: number[]): void {
  if (!qubits.length || qubits.length !== bits.length) throw new Error("Postselection needs matching, non-empty qubit and bit lists.");
  if (new Set(qubits).size !== qubits.length) throw new Error("Postselection qubits must be unique.");
  if (qubits.some((q) => !Number.isInteger(q) || q < 0 || q >= state.qubits)) throw new Error("Postselection qubit is outside the register.");
  if (bits.some((b) => b !== 0 && b !== 1)) throw new Error("Postselection values must be 0 or 1.");
}

export function projectState(state: StateVector, qubits: number[], bits: number[]): PostselectionResult {
  validateSelection(state, qubits, bits);
  let selectedNorm = 0;
  const keep = state.amplitudes.map((amplitude, index) => {
    const matches = qubits.every((qubit, position) => ((index >> qubit) & 1) === bits[position]);
    if (!matches) return ZERO;
    selectedNorm += cAbs2(amplitude);
    return amplitude;
  });
  if (selectedNorm < 1e-14) throw new Error("The selected subspace has zero probability and cannot be normalized.");
  const normalization = 1 / Math.sqrt(selectedNorm);
  const normalized = keep.map((amplitude) => cScale(amplitude, normalization));
  const successProbability = Math.min(1, selectedNorm);
  return {
    state: { qubits: state.qubits, amplitudes: normalized },
    successProbability,
    selectedQubits: [...qubits],
    selectedBits: [...bits],
    rejectedNormSquared: Math.max(0, 1 - selectedNorm),
  };
}

export function probabilityOfSubspace(state: StateVector, qubits: number[], bits: number[]): number {
  validateSelection(state, qubits, bits);
  return state.amplitudes.reduce((sum, amplitude, index) => {
    const matches = qubits.every((qubit, position) => ((index >> qubit) & 1) === bits[position]);
    return matches ? sum + cAbs2(amplitude) : sum;
  }, 0);
}

export function marginalDistribution(state: StateVector, qubits: number[]): number[] {
  if (!qubits.length || new Set(qubits).size !== qubits.length || qubits.some((q) => q < 0 || q >= state.qubits)) {
    throw new Error("Marginal qubits must be unique, non-empty, and in range.");
  }
  const dimension = 2 ** qubits.length;
  const result = Array.from({ length: dimension }, () => 0);
  state.amplitudes.forEach((amplitude, basisIndex) => {
    const compressed = qubits.reduce((value, q, position) => value | (((basisIndex >> q) & 1) << position), 0);
    result[compressed] += cAbs2(amplitude);
  });
  return result.map((value) => cleanNumber(value));
}

export function conditionalMarginalDistribution(state: StateVector, keptQubits: number[], conditionQubits: number[], conditionBits: number[]): { probabilities: number[]; conditionProbability: number } {
  validateSelection(state, conditionQubits, conditionBits);
  if (!keptQubits.length || keptQubits.some((q) => q < 0 || q >= state.qubits) || new Set(keptQubits).size !== keptQubits.length) {
    throw new Error("Kept qubits must be unique, non-empty, and in range.");
  }
  if (keptQubits.some((q) => conditionQubits.includes(q))) throw new Error("Kept and conditioned qubits must be disjoint.");
  const dimension = 2 ** keptQubits.length;
  const probabilities = Array.from({ length: dimension }, () => 0);
  let conditionProbability = 0;
  state.amplitudes.forEach((amplitude, basisIndex) => {
    const matches = conditionQubits.every((q, position) => ((basisIndex >> q) & 1) === conditionBits[position]);
    if (!matches) return;
    conditionProbability += cAbs2(amplitude);
    const compressed = keptQubits.reduce((value, q, position) => value | (((basisIndex >> q) & 1) << position), 0);
    probabilities[compressed] += cAbs2(amplitude);
  });
  if (conditionProbability > 1e-14) {
    for (let index = 0; index < probabilities.length; index += 1) probabilities[index] /= conditionProbability;
  }
  return { probabilities, conditionProbability };
}

export function sampleSubspace(state: StateVector, qubits: number[], bits: number[], random = Math.random): boolean {
  const probability = probabilityOfSubspace(state, qubits, bits);
  const draw = random();
  if (draw < 0 || draw >= 1) throw new Error("Random generator must return a value in [0,1).");
  return draw < probability;
}
